################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA6T2_MCILV1_SPM_HALL_FOC_TUNER_E2S_V122/src/application/rmw/ICS2_RA6T2.o C:/Workspace/RA6T2_MCILV1_SPM_HALL_FOC_TUNER_E2S_V122/src/application/identification/rmw_tuner_library.o

LIBS := -lrm_motor_current -lrm_motor_speed

