################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA6T2_MCB2_MCILV1_SPM_HALL_FOC_E2S_V101/src/application/rmw/ICS2_RA6T2.o

LIBS := -lrm_motor_current -lrm_motor_speed

