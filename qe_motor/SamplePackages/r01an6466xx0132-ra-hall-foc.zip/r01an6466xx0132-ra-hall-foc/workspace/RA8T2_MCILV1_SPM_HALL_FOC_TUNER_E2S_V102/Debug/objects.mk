################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA8T2_MCILV1_SPM_HALL_FOC_TUNER_E2S_V102/src/application/rmw/ICS2_RA8T2.o C:/Workspace/RA8T2_MCILV1_SPM_HALL_FOC_TUNER_E2S_V102/src/application/identification/rmw_tuner_library.o

LIBS := -lrm_motor_current -lrm_motor_speed

