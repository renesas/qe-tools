/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_app_control_cfg.h
* Description : Compile-time configurations
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 20.12.2022 1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_APP_CONTROL_CFG_H
#define R_APP_CONTROL_CFG_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_app_main.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Defines the UI used as default UI (MAIN_UI_BOARD/MAIN_UI_RMW)*/
#define  APP_CFG_USE_UI  (MAIN_UI_RMW)

/* design parameter */
#define     APP_CFG_FREQ_BAND_LIMIT     (3.0f)                       /* Motor control natural frequency limit */
#define     APP_CFG_MAX_CURRENT_OMEGA   (1000.0f)                    /* Max natural frequency of current loop [Hz] */
#define     APP_CFG_MIN_OMEGA           (1.0f)                       /* Min natural frequency of control loop [Hz] */

/* Select SCI port
 * 0x10 - SCI1  PD3/TXD1  PD5/RXD1
 * 0x50 - SCI5  PD7/TXD5  PE0/RXD5
 * 0x51 - SCI5  PB5/TXD5  PB6/RXD5
 * 0x60 - SCI6  PB0/TXD6  PB1/RXD6
 * 0x80 - SCI8  PD0/TXD8  PD1/RXD8
 * 0x81 - SCI8  PC1/TXD8  PC0/RXD8
 * 0x82 - SCI8  PA4/TXD8  PA5/RXD8
 * 0x83 - SCI8  P23/TXD8  P22/RXD8
 * 0x90 - SCI9  P01/TXD9  P00/RXD9
 * 0x91 - SCI9  PA3/TXD9  PA2/RXD9
 * 0x92 - SCI9  PG1/TXD9  PG0/RXD9
 * 0xB1 - SCI11 PD3/TXD11 PD5/RXD11
 * 0xB2 - SCI11 PB5/TXD11 PB6/RXD11
 * 0xB3 - SCI11 PA0/TXD11 PA1/RXD11
 * 0xC0 - SCI12 PB5/TXD12 PB6/RXD12
 * 0xC1 - SCI12 P23/TXD12 P22/RXD12
 * 0xC2 - SCI12 P01/TXD12 P00/RXD12
 */
#define APP_CFG_SCI_CH_SELECT     (0x10)

#endif /* R_APP_CONTROL_CFG_H */
