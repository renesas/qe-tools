/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_motor_module_cfg.h
* Description  : Compile-time configurations
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 20.12.2022 1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MOTOR_MODULE_CFG_H
#define R_MOTOR_MODULE_CFG_H

#include "r_motor_common.h"
#include "r_motor_targetmotor_cfg.h"
#include "r_motor_inverter_cfg.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/**
 * Middle ware Layer Configurations
 */
/*
 * Software system configurations
 */
/*
 * for MCU
 */
#define     MOTOR_MCU_CFG_PWM_TIMER_FREQ        (120.0f)        /* PWM timer frequency [MHz] */
#define     MOTOR_MCU_CFG_CARRIER_FREQ          (20.0f)         /* Carrier wave frequency [kHz] */
#define     MOTOR_MCU_CFG_INTR_DECIMATION       (0)             /* Interrupt skipping number */
#define     MOTOR_MCU_CFG_AD_FREQ               (60.0f)         /* A/D frequency [MHz] */
#define     MOTOR_MCU_CFG_AD_SAMPLING_CYCLE     (6 + 39)        /* Scan start processing time(tD) + */
                                                                /* sample-and-hold processing time(tSPLSH) [cycle] */
#define     MOTOR_MCU_CFG_AD12BIT_DATA          (4095.0f)       /* A/D 12Bit data */
#define     MOTOR_MCU_CFG_ADC_OFFSET            (0x7FF)         /* A/D offset */

#if defined(__TFU)
#define     MOTOR_MCU_CFG_TFU_OPTIMIZE          (MTR_ENABLE)    /* TFU Optimization */
#else
#define     MOTOR_MCU_CFG_TFU_OPTIMIZE          (MTR_DISABLE)
#endif

/*
 * Motor control common configurations
 */
#define MOTOR_TYPE_BLDC     /* The motor used is BLDC. */
//#define MOTOR_TYPE_STM      /* The motor used is STM. */

/* Select control loop mode
* - MOTOR_LOOP_SPEED(default)
*/
#define     MOTOR_COMMON_CFG_LOOP_MODE                  (MOTOR_LOOP_SPEED)

#define     MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT    (1.5f)

#if defined(MOTOR_TYPE_BLDC)
#define     MOTOR_COMMON_CFG_IA_MAX_CALC_MULT           (MTR_SQRT_3)
#elif defined(MOTOR_TYPE_STM)
#define     MOTOR_COMMON_CFG_IA_MAX_CALC_MULT           (MTR_SQRT_2)
#endif

/*
 * other
 */
#define     MOTOR_COMMON_AD_SAMPLING_TIME       (MOTOR_MCU_CFG_AD_SAMPLING_CYCLE / MOTOR_MCU_CFG_AD_FREQ)
                                                        /* A/D sampling time [us] */
#define     MOTOR_COMMON_CARRIER_SET_BASE       ((uint16_t)(MOTOR_MCU_CFG_PWM_TIMER_FREQ * 1000.0f / MOTOR_MCU_CFG_CARRIER_FREQ / 2.0f))
#define     MOTOR_COMMON_DEADTIME_SET           ((uint16_t)(INVERTER_CFG_DEADTIME * MOTOR_MCU_CFG_PWM_TIMER_FREQ))
                                                        /* Setting value of deadtime */
#define     MOTOR_COMMON_CTRL_PERIOD            ((MOTOR_MCU_CFG_INTR_DECIMATION + 1) / (MOTOR_MCU_CFG_CARRIER_FREQ * 1000.0f))
                                                        /* Control period */
/****** Macro of current control*****/
#define     MOTOR_COMMON_LIMIT_IQ               (MOTOR_CFG_NOMINAL_CURRENT_RMS *  MTR_SQRT_3)
                                                        /* speed PI integral term limit for iq */
#define     MOTOR_COMMON_CURRENT_OBS_LIMIT      (MOTOR_CFG_NOMINAL_CURRENT_RMS * MTR_SQRT_3 * 3.0f)
                                                        /* Integration limit value of voltage disturbance estimate */
#define     MOTOR_COMMON_OVERCURRENT_LIMIT      (MOTOR_CFG_NOMINAL_CURRENT_RMS * MTR_SQRT_2 * MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT)
                                                        /* Over current limit [A] */
/* Threshold of speed */
#define     MOTOR_ANGEST_THRESHOLD              (0.5f * (MTR_TWOPI / 2.0f) / 180.0f)
                                                        /* Threshold of angle estimation [rad] */
#define     MOTOR_PF_THRESHOLD                  (10.0f) /* Threshold of polarity */

/*
 * for Current Module(current_rx)
 */
/* Defines whether use voltage error compensation in FOC */
#define     CURRENT_CFG_VOLT_ERR_COMP            (MTR_ENABLE)

/* Select modulation method
* - MOD_METHOD_SPWM
* - MOD_METHOD_SVPWM(default)
*/
#define     CURRENT_CFG_MODULATION_METHOD        (MOD_METHOD_SVPWM)

#define     CURRENT_CFG_OFFSET_CALC_TIME         (512.0f)         /* Current offset calculation time */
#define     CURRENT_CFG_PERIOD_MAG_VALUE         (0.5f)           /* Period magnification value for coordinate */
                                                                  /* transformation */
#define     CURRENT_CFG_PI_INTEGRAL_LIMIT_VD     (INVERTER_CFG_INPUT_V * 0.5f)
                                                                  /* Current PI integral term limit for vd */
#define     CURRENT_CFG_PI_INTEGRAL_LIMIT_VQ     (INVERTER_CFG_INPUT_V * 0.5f)
                                                                  /* Current PI integral term limit for vq */
#define     CURRENT_CFG_OMEGA                    (600.0f)         /* natural frequency for current loop */
#define     CURRENT_CFG_ZETA                     (1.0f)           /* damping ratio for current loop */
#define     CURRENT_CFG_E_OBS_OMEGA              (1000.0f)         /* Natural frequency of BEMF observer */
#define     CURRENT_CFG_E_OBS_ZETA               (1.0f)           /* Damping ratio of BEMF observer */
#define     CURRENT_CFG_ESTLOW_PULSEVOLT         (8.0f)         /* Natural frequency of PLL Speed estimate loop */
#define     CURRENT_CFG_ESTLOW_PULSEVOLT_RUNNING (8.0f)         /* Natural frequency of PLL Speed estimate loop */
#define     CURRENT_CFG_ESTLOW_ESTTIME           (0.2f/MOTOR_COMMON_CTRL_PERIOD)
                                                                  /* Position convergence period time counter [200ms] */
#define     CURRENT_CFG_ESTLOW_ESTTIME_OVER      (0.3f/MOTOR_COMMON_CTRL_PERIOD)
                                                                  /* Position convergence period+judgment period */
                                                                  /* judgment time counter [300ms] */
#define     CURRENT_CFG_PLL_ESTLOW_OMEGA         (50.0f)          /* Natural frequency of PLL Speed estimate loop */
#define     CURRENT_CFG_PLL_ESTLOW_ZETA          (1.0f)           /* Damping ratio of PLL Speed estimate loop */
#define     CURRENT_CFG_PLL_EST_OMEGA            (20.0f)          /* Natural frequency of PLL Speed estimate loop */
#define     CURRENT_CFG_PLL_EST_ZETA             (1.0f)           /* Damping ratio of PLL Speed estimate loop */
#define     CURRENT_CFG_ESTLOW_PULSEFREQ_BOOT    (3)              /* Pulse injection frequency 1/f at the boot mode */
#define     CURRENT_CFG_ESTLOW_PULSEFREQ_DRIVE   (2)              /* Pulse injection frequency 1/f at the drive */
                                                                  /* mode, set 1. */

/*
 * for Speed Module(speed_rx)
 */

/* Defines whether use Speed observer in FOC */
#define    SPEED_CFG_OBSERVER                   (MTR_ENABLE)

#define    SPEED_CFG_MTPA                       (MTR_ENABLE)


#define     SPEED_CFG_CTRL_PERIOD               (0.0005f)         /* control period for speed loop */
#define     SPEED_CFG_OMEGA                     (10.0f)            /* natural frequency for speed loop */
#define     SPEED_CFG_ZETA                      (1.0f)            /* damping ratio for speed loop */
#define     SPEED_CFG_LPF_OMEGA                 (25.0f)           /* natural frequency for speed LPF */
#define     SPEED_CFG_SPEED_LIMIT_RPM           (2850.0f)         /* over speed limit [rpm] (mechanical angle) */
#define     SPEED_CFG_SPEED_LIMIT_MARGIN        (1.1f)            /* over speed limit margin (+10%) */
#define     SPEED_CFG_SPEED_LIMIT_RAD           (SPEED_CFG_SPEED_LIMIT_RPM * SPEED_CFG_SPEED_LIMIT_MARGIN * MOTOR_CFG_POLE_PAIRS * MTR_RPM2RAD)
		                                                          /* over speed limit [rad] (electrical angle) */
#define     SPEED_CFG_RATE_LIMIT_RPM            (50.0f)          /* Rate limit of speed change [rpm/s] */
#define     SPEED_CFG_SOB_OMEGA                 (30.0f)           /* natural frequency for speed observer */
#define     SPEED_CFG_SOB_OUTLIM_START_RPM      (25.0f)           /* limit start speed for speed observer */
#define     SPEED_CFG_SOB_OUTLIM_END_RPM        (30.0f)           /* limit end speed for speed observer */

/*
 * for Driver Module(driver_rx)
 */
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_START    (R_Config_MOTOR_StartTimerCtrl)
                                                        /* The StartTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_STOP     (R_Config_MOTOR_StopTimerCtrl)
                                                        /* The StopTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_ADC_DATA_GET        (R_Config_MOTOR_AdcGetConvVal)
                                                        /* The AdcGetConvVal function of motor component */
#define     DRIVER_CFG_FUNC_DUTY_SET            (R_Config_MOTOR_UpdDuty)
                                                        /* The UpdDuty function of motor component */

#endif /* R_MOTOR_MODULE_CFG_H */
