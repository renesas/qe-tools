################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Users/a5089652/e2_studio/workspace/work_v_6_1/tuner/RA6T2_MCILV1_SPM_IS_FOC_TUNER_E2S_V120/src/application/rmw/ICS2_RA6T2.o C:/Users/a5089652/e2_studio/workspace/work_v_6_1/tuner/RA6T2_MCILV1_SPM_IS_FOC_TUNER_E2S_V120/src/application/identification/rmw_tuner_library.o

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_position

