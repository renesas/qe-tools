################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Users/a5089652/e2_studio/workspace/work_v_6_1/work/RA6T2_MCILV1_SPM_IS_FOC_E2S_V120/src/application/rmw/ICS2_RA6T2.o

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_position

