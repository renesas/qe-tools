################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Release/06_inductive/RA8T1_MCILV1_SPM_IS_FOC_E2S_V110/src/application/rmw/ICS2_RA8T1.o

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_position

