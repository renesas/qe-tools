################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Users/a5089652/e2_studio/workspace/work_v_6_1/ra6t2_new_release/RA6T2_MCB2_MCILV1_SPM_IS_FOC_TUNER_E2S_V100/src/application/rmw/ICS2_RA6T2.o C:/Users/a5089652/e2_studio/workspace/work_v_6_1/ra6t2_new_release/RA6T2_MCB2_MCILV1_SPM_IS_FOC_TUNER_E2S_V100/src/application/identification/rmw_tuner_library.o

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_position

