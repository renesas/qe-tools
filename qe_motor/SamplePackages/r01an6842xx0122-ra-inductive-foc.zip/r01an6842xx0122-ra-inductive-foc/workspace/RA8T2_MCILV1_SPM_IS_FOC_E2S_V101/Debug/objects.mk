################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA8T2_MCILV1_SPM_IS_FOC_E2S_V101/src/application/rmw/ICS2_RA8T2.o

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_position

