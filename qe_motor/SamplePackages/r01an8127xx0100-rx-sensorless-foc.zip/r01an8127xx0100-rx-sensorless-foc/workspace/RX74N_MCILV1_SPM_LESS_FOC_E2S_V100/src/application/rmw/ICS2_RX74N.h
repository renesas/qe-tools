#ifndef __ICS2_RX74N_H__
#define __ICS2_RX74N_H__


#define   ICS_SCI0_P302_P303  (0x01U)  //
#define   ICS_SCI4_PB01_PB00  (0x41U)  //
#define   ICS_SCI5_PA02_PA03  (0x51U)  //
#define   ICS_SCI8_P600_P601  (0x81U)  //
#define   ICS_SCI9_PB07_PB06  (0x91U)  //
#define   ICS_SCI10_PA06_PA07 (0xA1U)  //
#define   ICS_SCI11_PC03_PC02 (0xB1U)  //

void     ics2_init(void * addr, uint8_t port, uint8_t level, uint8_t speed, uint8_t mode);
void     ics2_watchpoint(void);
uint32_t ics2_version(void);

void     ics_int_sci_eri(void);


#endif /* __ICS2_RX74N_H__ */
