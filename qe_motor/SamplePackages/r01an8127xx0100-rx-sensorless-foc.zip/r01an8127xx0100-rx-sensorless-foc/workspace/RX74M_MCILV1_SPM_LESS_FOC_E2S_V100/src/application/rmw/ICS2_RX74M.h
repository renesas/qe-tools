#ifndef __ICS2_RX74M_H__
#define __ICS2_RX74M_H__


#define   ICS_SCI1_P302_P303  (0x11U)  //
#define   ICS_SCI3_P107_P106  (0x31U)  //
#define   ICS_SCI8_P600_P601  (0x81U)  //
#define   ICS_SCI9_P604_P605  (0x91U)  //


void     ics2_init(void * addr, uint8_t port, uint8_t level, uint8_t speed, uint8_t mode);
void     ics2_watchpoint(void);
uint32_t ics2_version(void);

void     ics_int_sci_eri(void);


#endif /* __ICS2_RX74M_H__ */
