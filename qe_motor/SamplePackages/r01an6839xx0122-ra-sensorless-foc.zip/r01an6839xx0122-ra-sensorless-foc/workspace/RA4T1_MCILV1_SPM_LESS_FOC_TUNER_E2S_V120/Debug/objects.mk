################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA4T1_MCILV1_SPM_LESS_FOC_TUNER_E2S_V120/src/application/rmw/ICS2_RA4T1.o C:/Workspace/RA4T1_MCILV1_SPM_LESS_FOC_TUNER_E2S_V120/src/application/identification/rmw_tuner_library.o

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_estimate

