################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA6T2_MCB2_MCILV1_SPM_LESS_FOC_TUNER_E2S_V101/src/application/rmw/ICS2_RA6T2.o C:/Workspace/RA6T2_MCB2_MCILV1_SPM_LESS_FOC_TUNER_E2S_V101/src/application/identification/rmw_tuner_library.o

LIBS := -lrm_motor_current -lrm_motor_estimate -lrm_motor_speed

