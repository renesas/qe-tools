/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ra2t1.h
* Description : Definitions of the processing of a MCU control layer
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_CTRL_RA2T1_H
#define R_MTR_CTRL_RA2T1_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include <stdint.h>
#include "r_mtr_config.h"
#include "r_mtr_control_parameter.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Frequency of timers used for interruption */
#define USE_POEG                        (MTR_SET)           /* Defines whether use POEG for GPT */

#define MTR_CARRIER_FREQ                (CP_CARRIER_FREQ)   /* Carrier wave frequency[kHz] */
#define MTR_SPEED_CALC_TIMER_FREQ       (CP_SPEED_CALC_TIMER_FREQ)
                                                            /* TAU1 timer frequency[kHz] */
#define MTR_PWM_TIMER_FREQ              (CP_PWM_TIMER_FREQ) /* PWM timer frequency[MHz] */

#define MTR_SPEED_CTRL_PERIOD           (CP_SPEED_CTRL_PERIOD)
                                                            /* Control period for speed loop [sec] */
#define MTR_CTRL_PERIOD                 (1.0f /(MTR_CARRIER_FREQ * 1000))
                                                            /* control period [sec] */

#define MTR_WINDOW_DELAY_OFFSET         (3)                 /* Delay of starting timer window caused by MCU */
#define MTR_WINDOW_ADJUST               (0)                 /* Delay of starting timer window for user setting */

#define MTR_OL2CL_BEMF_THRESH           (3)                 /* Thereshold bemf voltage [ADC] */

#define MTR_ADC_OFFSET                  (0x7FF)             /* A/D offset */
#define MTR_DEADTIME                    (IP_DEADTIME)       /* Dead-time [usec] */

/* Setting value of carrier for pwm */
#define MTR_DEADTIME_CNT                ((uint32_t)(MTR_DEADTIME * MTR_PWM_TIMER_FREQ))
                                                            /* Setting value of dead-time */

#if (COMPLEMENTARY == MTRCONF_PWM_MODE)
#define MTR_NOT_CARRIER_CNT             (MTR_PWM_TIMER_FREQ * 1000 / MTR_CARRIER_FREQ / 2)
                                                            /* MTR_CARRIER_SET without dead-time */
#define MTR_CARRIER_CNT                 (MTR_NOT_CARRIER_CNT)
                                                            /* Carrier count of PWM */
#define MTR_MAX_WINDOW_WIDTH            (MTR_NOT_CARRIER_CNT * 0.9)
                                                            /* Maximum window width (90% of carrier period) */
#define MTR_MAX_DUTY_CNT                (MTR_NOT_CARRIER_CNT)
                                                            /* Maximum duty count */
#define MTR_HALF_CARRIER_CNT            ((MTR_CARRIER_CNT + MTR_DEADTIME_CNT) / 2)
                                                            /* Setting value of half carrier */

#elif (NON_COMPLEMENTARY == MTRCONF_PWM_MODE)
#define MTR_CARRIER_CNT                 (MTR_PWM_TIMER_FREQ * 1000 / MTR_CARRIER_FREQ / 2)
                                                            /* Carrier count of PWM */
#define MTR_MAX_WINDOW_WIDTH            (MTR_CARRIER_CNT * 0.9)
                                                            /* Maximum window width (90% of carrier period) */
#define MTR_MAX_DUTY_CNT                (MTR_CARRIER_CNT)   /* Maximum duty count */
#define MTR_HALF_CARRIER_CNT            ((MTR_CARRIER_CNT + MTR_DEADTIME_CNT) / 2)
                                                            /* Setting value of half carrier */
#endif

#define MTR_LOWEST_DUTY_CNT             (MTR_CARRIER_CNT + MTR_DEADTIME_CNT)
                                                            /* Lowest duty count (0% output) */

#define MTR_AD_TRG_DEFAULT_CNT          (CP_AD_TRG_DEFAULT_CNT)
                                                            /* A/D trigger default count */

#define MTR_OFFSET_CALC_ST_WAIT_CNT     (CP_OFFSET_CALC_ST_WAIT_CNT)
                                                            /* Offset calculation stable waiting time  */
#define MTR_CHARGE_CAP_WAIT_CNT         (IP_CHARGE_CAP_WAIT_CNT)
                                                            /* 300us per count */

/* Voltage pattern */
#define MTR_PATTERN_ERROR               (0)                 /* Pattern error */
#define MTR_UP_PWM_VN_ON                (1)                 /* Up(PWM) to Vn(on) */
#define MTR_UP_PWM_WN_ON                (2)                 /* Up(PWM) to Wn(on) */
#define MTR_VP_PWM_UN_ON                (3)                 /* Vp(PWM) to Un(on) */
#define MTR_VP_PWM_WN_ON                (4)                 /* Vp(PWM) to Wn(on) */
#define MTR_WP_PWM_UN_ON                (5)                 /* Wp(PWM) to Un(on) */
#define MTR_WP_PWM_VN_ON                (6)                 /* Wp(PWM) to Vn(on) */
#define MTR_UP_ON_VN_PWM                (7)                 /* Up(on) to Vn(PWM) */
#define MTR_UP_ON_WN_PWM                (8)                 /* Up(on) to Wn(PWM) */
#define MTR_VP_ON_UN_PWM                (9)                 /* Vp(on) to Un(PWM) */
#define MTR_VP_ON_WN_PWM                (10)                /* Vp(on) to Wn(PWM) */
#define MTR_WP_ON_UN_PWM                (11)                /* Wp(on) to Un(PWM) */
#define MTR_WP_ON_VN_PWM                (12)                /* Wp(on) to Vn(PWM) */
#define MTR_U_PWM_VN_ON                 (13)                /* U(PWM) to Vn(on) */
#define MTR_U_PWM_WN_ON                 (14)                /* U(PWM) to Wn(on) */
#define MTR_V_PWM_UN_ON                 (15)                /* V(PWM) to Un(on) */
#define MTR_V_PWM_WN_ON                 (16)                /* V(PWM) to Wn(on) */
#define MTR_W_PWM_UN_ON                 (17)                /* W(PWM) to Un(on) */
#define MTR_W_PWM_VN_ON                 (18)                /* W(PWM) to Vn(on) */
#define MTR_UP_ON_V_PWM                 (19)                /* Up(on) to V(PWM) */
#define MTR_UP_ON_W_PWM                 (20)                /* Up(on) to W(PWM) */
#define MTR_VP_ON_U_PWM                 (21)                /* Vp(on) to U(PWM) */
#define MTR_VP_ON_W_PWM                 (22)                /* Vp(on) to W(PWM) */
#define MTR_WP_ON_U_PWM                 (23)                /* Wp(on) to U(PWM) */
#define MTR_WP_ON_V_PWM                 (24)                /* Wp(on) to V(PWM) */

#define     POEG_RECOVER_TIMEOUT        (3)                 /* count of POEG timeout */
#define     ADC_CONVERT_TIMEOUT         (0xFFFF)            /* count of ADC timeout */

/* speed count */
#define     MTR_SPEED_CNT_MAX           (0x1FFFFFFF)        /* the maximum count for speed */

#if (HALL == MTRCONF_SENSOR_MODE)
/* Port number */
#define MTR_PORT_PIN_HALL_U             (BSP_IO_PORT_02_PIN_06)
                                                            /* port for hall-sensor U */
#define MTR_PORT_PIN_HALL_V             (BSP_IO_PORT_04_PIN_09)
                                                            /* port for hall-sensor V */
#define MTR_PORT_PIN_HALL_W             (BSP_IO_PORT_04_PIN_08)
                                                            /* port for hall-sensor W */

#define MTR_HALL_SIGNAL_L_POLARITY      (1)                 /* hall signal L level polarity */
#define MTR_HALL_SIGNAL_H_POLARITY      (0)                 /* hall signal H level polarity */
#endif

/* System error status */
#define ERROR_NONE                      (0x00)              /* None */
#define ERROR_CHANGE_CLK_TIMEOUT        (0x01)              /* Timeout error at clock initialization */
#define ERROR_CHARGE_CAP_TIMEOUT        (0x02)              /* Timeout error at charge capacitor */
#define ERROR_DRIVING                   (0x03)              /* Error at driving */

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/

#endif /* R_MTR_CTRL_RA2T1_H */
