/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
 * Includes   <System Includes> , "Project Includes"
 **********************************************************************************************************************/

/* Private header file for this package. */
#include "r_mtr_GPT_THREE_PHASE.h"
#include "r_mtr_ra2t1.h"

/*******************************************************************************************************************//**
* @fn             R_MTR_GPT_THREE_PHASE_CompMode2_Open
* @brief          Initialize 3-phase GPT as comp-mode 2
* @param[in,out]  p_ctrl        A pointer to 3-phase GPT control parameters
* @param[in,out]  p_cfg         A pointer to 3-phase AGT configure parameters
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_ASSERTION              A required input pointer is NULL.
 * @retval FSP_ERR_ALREADY_OPEN           Module is already open.
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_CompMode2_Open(three_phase_ctrl_t * const p_ctrl,
                                                three_phase_cfg_t const * const p_cfg)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_cfg);
    FSP_ASSERT(NULL != p__ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN != p_instance_ctrl->open, FSP_ERR_ALREADY_OPEN);
#endif

    fsp_err_t err;

    /* Open all three GPT submodules */
    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        err = R_GPT_Open(p_cfg->p_timer_instance[ch]->p_ctrl, p_cfg->p_timer_instance[ch]->p_cfg);
#if GPT_CFG_PARAM_CHECKING_ENABLE
        if (err)
        {
            /* In case of an error on GPT open, close all opened instances and return the error */
            for (three_phase_channel_t close_ch = THREE_PHASE_CHANNEL_U; close_ch < ch; close_ch++)
            {
                R_GPT_Close(p_cfg->p_timer_instance[close_ch]->p_ctrl);
            }

            return err;
        }

#else
        FSP_PARAMETER_NOT_USED(err);
#endif
        /* Save a pointer to the GPT registers for this channel */
        p_instance_ctrl->p_reg[ch] = ((gpt_instance_ctrl_t *) (p_cfg->p_timer_instance[ch]->p_ctrl))->p_reg;

        /*** The followings are settings for Comp2 */
        /* Set COMP2 mode */
        p_instance_ctrl->p_reg[ch]->GTCR &= ~GPT_THREE_PHASE_PRV_GTCR_MODE_MASK;
        p_instance_ctrl->p_reg[ch]->GTCR |= GPT_THREE_PHASE_PRV_GTCR_COMP2_MODE;

        /* Set the timer cycle to double buffer */
        three_phase_channel_t mch = p_cfg->callback_ch;
        if (ch == mch)
        {
            p_instance_ctrl->p_reg[ch]->GTPDBR = (uint32_t)(MTR_CARRIER_CNT);

            /* ADC start trigger timing setting */
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRADEN = 1;
            p_instance_ctrl->p_reg[ch]->GTINTAD_b.ADTRAUEN = 0;
            p_instance_ctrl->p_reg[ch]->GTADTRA = (uint16_t)(MTR_CARRIER_CNT - MTR_AD_TRG_DEFAULT_CNT);
        }

        /* Set the duty cycle to buffers */
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRA] = (uint16_t)MTR_HALF_CARRIER_CNT;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRC] = (uint16_t)MTR_HALF_CARRIER_CNT;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRE] = (uint16_t)MTR_HALF_CARRIER_CNT;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRD] = (uint16_t)MTR_HALF_CARRIER_CNT;
        p_instance_ctrl->p_reg[ch]->GTCCR[GPT_PRV_GTCCRF] = (uint16_t)MTR_HALF_CARRIER_CNT;

        /* Dead time value register GTDVU */
        p_instance_ctrl->p_reg[ch]->GTDVU = MTR_DEADTIME_CNT;
        /* Dead time value register GTDVD */
        p_instance_ctrl->p_reg[ch]->GTDVD = MTR_DEADTIME_CNT;

        /* GTITC is always present for GPTE and GPTEH timers */
        p_instance_ctrl->p_reg[ch]->GTITC = ((uint32_t) GPT_INTERRUPT_SKIP_SOURCE_NONE << R_GPT0_GTITC_IVTC_Pos) |
                                        ((uint32_t) 0U << R_GPT0_GTITC_IVTT_Pos) |
                                        ((uint32_t) 0U << R_GPT0_GTITC_ADTAL_Pos) |
                                        ((uint32_t) 0U << R_GPT0_GTITC_ADTBL_Pos);
        /*** settings for Comp2 ***/

#if GPT_CFG_WRITE_PROTECT_ENABLE

        /* Re-enable write protection */
        p_instance_ctrl->p_reg[ch]->GTWP = GPT_THREE_PHASE_PRV_GTWP_WRITE_PROTECT;
#endif
    }

    /* Get copy of GPT channel mask and buffer mode */
    p_instance_ctrl->channel_mask = p_cfg->channel_mask;
    p_instance_ctrl->buffer_mode  = p_cfg->buffer_mode;

    /* Save pointer to config struct */
    p_instance_ctrl->p_cfg = p_cfg;

    p_instance_ctrl->open = GPT_THREE_PHASE_OPEN;

    R_MTR_GPT_THREE_PHASE_DisableOutputAll(p_ctrl);
    return FSP_SUCCESS;
} /* End of function R_MTR_GPT_THREE_PHASE_CompMode2_Open */

/*******************************************************************************************************************//**
* @fn             R_MTR_GPT_THREE_PHASE_CompMode2_DutyCycleSet
* @brief          Set duty cycles for 3-phase GPT that runs as comp-mode 2
* @param[in,out]  p_ctrl        A pointer to 3-phase GPT control parameters
* @param[in]      p_duty_cycle  A pointer to duty cycles for 3-phase GPT
 * @retval FSP_SUCCESS                 Duty cycle updated successfully.
 * @retval FSP_ERR_ASSERTION           A required input pointer is NULL.
 * @retval FSP_ERR_NOT_OPEN            The instance is not opened.
 * @retval FSP_ERR_INVALID_ARGUMENT    One or more duty cycle count values was outside the range 0..(period - 1).
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_CompMode2_DutyCycleSet(three_phase_ctrl_t *const p_ctrl,
                                                        three_phase_duty_cycle_t *const p_duty_cycle)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p__ctrl);
    FSP_ASSERT(NULL != p_duty_cycle);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);

    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        FSP_ERROR_RETURN(NULL != sp_reg[ch], FSP_ERR_NOT_OPEN);

        uint32_t gtpr = sp_reg[THREE_PHASE_CHANNEL_U]->GTPR;
        FSP_ERROR_RETURN((p_duty_cycle->duty[ch] < gtpr) && (p_duty_cycle->duty[ch] > 0), FSP_ERR_INVALID_ARGUMENT);

        /* In double-buffer mode also check double buffer */
        FSP_ERROR_RETURN((p_duty_cycle->duty_buffer[ch] < gtpr) && (p_duty_cycle->duty_buffer[ch] > 0),
                         FSP_ERR_INVALID_ARGUMENT);
    }
#endif

    /* Set all duty cycle registers */
    /*
     * Since GPT16n+2, which is the shift trigger to the temporary register, is the V phase,
     * set it in the order of U, W, V.
     */
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTCCR[GPT_PRV_GTCCRD] = p_duty_cycle->duty[THREE_PHASE_CHANNEL_U];
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTCCR[GPT_PRV_GTCCRD] = p_duty_cycle->duty[THREE_PHASE_CHANNEL_W];
    p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTCCR[GPT_PRV_GTCCRD] = p_duty_cycle->duty[THREE_PHASE_CHANNEL_V];

    return FSP_SUCCESS;
} /* End of function R_MTR_GPT_THREE_PHASE_CompMode2_DutyCycleSet */

/*******************************************************************************************************************//**
* @fn             R_MTR_GPT_THREE_PHASE_EnableOutputAll
* @brief          Enable all the output for 3-phase GPT
* @param[in,out]  p_ctrl        A pointer to 3-phase GPT control parameters
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_ASSERTION           A required input pointer is NULL.
 * @retval FSP_ERR_NOT_OPEN               The instance is not opened.
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_EnableOutputAll(three_phase_ctrl_t * const p_ctrl)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        p_instance_ctrl->p_reg[ch]->GTIOR |= GPT_THREE_PHASE_PRV_GTIOR_OUTPUT_DISABLE;
    }

    return FSP_SUCCESS;
} /* End of function R_MTR_GPT_THREE_PHASE_EnableOutputAll */

/*******************************************************************************************************************//**
* @fn             R_MTR_GPT_THREE_PHASE_DisableOutputAll
* @brief          Disable all the output for 3-phase GPT
* @param[in,out]  p_ctrl        A pointer to 3-phase GPT control parameters
 * @retval FSP_SUCCESS                    Initialization was successful.
 * @retval FSP_ERR_ASSERTION              A required input pointer is NULL.
 * @retval FSP_ERR_NOT_OPEN               The instance is not opened.
 **********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_DisableOutputAll(three_phase_ctrl_t * const p_ctrl)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_instance_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    for (three_phase_channel_t ch = THREE_PHASE_CHANNEL_U; ch <= THREE_PHASE_CHANNEL_W; ch++)
    {
        p_instance_ctrl->p_reg[ch]->GTIOR &= ~GPT_THREE_PHASE_PRV_GTIOR_OUTPUT_DISABLE;
    }

    return FSP_SUCCESS;
} /* End of function R_MTR_GPT_THREE_PHASE_DisableOutputAll */

/***********************************************************************************************************************
* @fn             R_MTR_GPT_THREE_PHASE_PatternOutput
* @brief          Set output patterns for 3-phase GPT
* @param[in,out]  p_ctrl        A pointer to 3-phase GPT control parameters
* @param[in]      u2_pattern    An output pattern
* @param[out]     p_u1_err_flg  A pointer to an area for a error flag
* @retval FSP_SUCCESS               Initialization was successful.
**********************************************************************************************************************/
fsp_err_t R_MTR_GPT_THREE_PHASE_PatternOutput (three_phase_ctrl_t * const p_ctrl,
                                                uint16_t u2_pattern, uint8_t *p_u1_err_flg)
{
    gpt_three_phase_instance_ctrl_t * p_instance_ctrl = (gpt_three_phase_instance_ctrl_t *) p_ctrl;

    *p_u1_err_flg = MTR_CLR;

    /*======================*/
    /*     Set register     */
    /*======================*/
    /* PWM output arm setting */
    /***************** Non-complementary synchronous pattern ********************/
    switch (u2_pattern)
    {
        case MTR_WP_PWM_VN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 1; /* Vn: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 1; /* Wp: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 0;
            break;

        case MTR_UP_PWM_WN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 1; /* Up: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 1; /* Wn: PWM Output enable */
            break;

        case MTR_VP_PWM_UN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 1; /* Un: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 1; /* Vp: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 0;
            break;

        case MTR_UP_PWM_VN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 1; /* Up: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 1; /* Vn: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 0;
            break;

        case MTR_VP_PWM_WN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 1; /* Vp: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 1; /* Wn: PWM Output enable */
            break;

        case MTR_WP_PWM_UN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 1; /* Un: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 1; /* Wp: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 0;
            break;

    /***************** Complementary synchronous pattern ********************/
        case MTR_W_PWM_VN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 1; /* Vn: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 1; /* Wp: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 1; /* Wn: PWM Output enable */
            break;

        case MTR_U_PWM_WN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 1; /* Up: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 1; /* Un: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 1; /* Wn: PWM Output enable */
            break;

        case MTR_V_PWM_UN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 1; /* Un: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 1; /* Vp: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 1; /* Vn: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 0;
            break;

        case MTR_U_PWM_VN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 1; /* Up: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 1; /* Un: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 1; /* Vn: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 0;
            break;

        case MTR_V_PWM_WN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 1; /* Vp: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 1; /* Vn: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 1; /* Wn: PWM Output enable */
            break;

        case MTR_W_PWM_UN_ON:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 1; /* Un: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 1; /* Wp: PWM Output enable */
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 1; /* Wn: PWM Output enable */
            break;

        /* The default case is intentionally combined */
        case MTR_PATTERN_ERROR:
        default:
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_U]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_V]->GTIOR_b.OBE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OAE = 0;
            p_instance_ctrl->p_reg[THREE_PHASE_CHANNEL_W]->GTIOR_b.OBE = 0;
            *p_u1_err_flg = MTR_SET;   /* Error status update : BEMF error */
            break;
    }

    return FSP_SUCCESS;
} /* End of function R_MTR_GPT_THREE_PHASE_PatternOutput */
