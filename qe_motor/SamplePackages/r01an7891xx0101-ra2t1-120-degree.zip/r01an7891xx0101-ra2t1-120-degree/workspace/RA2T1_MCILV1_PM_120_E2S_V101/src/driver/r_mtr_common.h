/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

#ifndef DRIVER_R_MTR_COMMON_H_
#define DRIVER_R_MTR_COMMON_H_

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/

#include "hal_data.h"

#include "r_mtr_GPT_THREE_PHASE.h"
#include "r_mtr_ADC.h"
#include "r_mtr_POEG.h"
#include "r_mtr_AGT.h"

/**********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/

#if (HALL == MTRCONF_SENSOR_MODE)
#define R_MTR_ADC_SCAN_MASK_VU      (0x00100000U)
#define R_MTR_ADC_SCAN_MASK_VV      (0x00000080U)
#define R_MTR_ADC_SCAN_MASK_VW      (0x00000040U)

#define R_MTR_ADC_SCAN_MASK_A_HALL  (~(R_MTR_ADC_SCAN_MASK_VU | R_MTR_ADC_SCAN_MASK_VV | R_MTR_ADC_SCAN_MASK_VW))
#define R_MTR_ADC_SCAN_MASK_B_HALL  (0x00000000U)
#endif

#define R_MTR_ADCR_IDC              (ADC_CHANNEL_0)
#define R_MTR_ADCR_VDC              (ADC_CHANNEL_8)

#if (LESS == MTRCONF_SENSOR_MODE)
#define R_MTR_ADCR_VU               (ADC_CHANNEL_20)
#define R_MTR_ADCR_VV               (ADC_CHANNEL_7)
#define R_MTR_ADCR_VW               (ADC_CHANNEL_6)
#endif

/* Flag condition */
#define     MTR_CLR                     (0)                       /* For flag clear */
#define     MTR_SET                     (1)                       /* For flag set */

#endif /* DRIVER_R_MTR_COMMON_H_ */
