/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
 * Includes   <System Includes> , "Project Includes"
 **********************************************************************************************************************/

/* Private header file for this package. */
#include "r_mtr_ADC.h"
#include "r_mtr_ra2t1.h"
//R_ADC0_Type * gp_adc;

/***********************************************************************************************************************
* @fn             R_MTR_ADC_Open
* @brief          Initialize ADC as fast-mode
* @param[in,out]  p_ctrl    A pointer to ADC control parameters
* @param[in,out]  p_cfg     A pointer to ADC configure parameters
 * @retval FSP_SUCCESS                     Module is ready for use.
 * @retval FSP_ERR_ASSERTION               An input argument is invalid.
 * @retval FSP_ERR_ALREADY_OPEN            The instance control structure has already been opened.
 * @retval FSP_ERR_IRQ_BSP_DISABLED        A callback is provided, but the interrupt is not enabled.
 * @retval FSP_ERR_IP_CHANNEL_NOT_PRESENT  The requested unit does not exist on this MCU.
 * @retval FSP_ERR_INVALID_HW_CONDITION    The ADC clock must be at least 1 MHz
 **********************************************************************************************************************/
fsp_err_t R_MTR_ADC_Open(adc_ctrl_t * p_ctrl, adc_cfg_t const * const p_cfg)
{
    fsp_err_t fsp_err = R_ADC_Open(p_ctrl, p_cfg);

    if (FSP_SUCCESS == fsp_err)
    {
        adc_instance_ctrl_t * p_instance_ctrl = (adc_instance_ctrl_t *) p_ctrl;

        /* Enable fast conversion mode */
        p_instance_ctrl->p_reg->ADACSR_b.ADSAC = 1;

        /* Disable group B scan end interrupt */
        p_instance_ctrl->p_reg->ADCSR_b.GBADIE = 0;
    }

    return fsp_err;
} /* End of function R_MTR_ADC_Open */

/***********************************************************************************************************************
* @fn             R_MTR_ADC_WaitConversion
* @brief          Wait until A/D conversion is done
* @param[in,out]  p_ctrl        A pointer to ADC control parameters
* @param[in,out]  p_cfg         A pointer to ADC configure parameters
* @param[in]      timeout_count A clock count for a timeout error
 * @retval FSP_SUCCESS                 Data read into provided p_data.
 * @retval FSP_ERR_TIMEOUT             timeout occurs.
 * @retval FSP_ERR_ASSERTION           An input argument is invalid.
 * @retval FSP_ERR_NOT_OPEN            Unit is not open.
 * @retval FSP_ERR_NOT_INITIALIZED     Unit is not initialized.
 **********************************************************************************************************************/
fsp_err_t R_MTR_ADC_WaitConversion(adc_ctrl_t * p_ctrl, uint16_t timeout_count)
{
    adc_instance_ctrl_t * p_instance_ctrl = (adc_instance_ctrl_t *) p_ctrl;
    uint16_t u2_count = timeout_count;
#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    while (p_instance_ctrl->p_reg->ADCSR & ADC_PRV_ADCSR_ADST)
    {
        /* Wait conversion finished. */
        FSP_ERROR_RETURN(0U < u2_count--, FSP_ERR_TIMEOUT);
    }

    return FSP_SUCCESS;
} /* End of function R_MTR_ADC_WaitConversion */

#if (HALL == MTRCONF_SENSOR_MODE)
/*******************************************************************************************************************//**
* @fn             R_MTR_ADC_SetCannels
* @brief          Set ADC scan channels
* @param[in,out]  p_ctrl        A pointer to ADC control parameters
* @param[in,out]  p_cfg         A pointer to ADC configure parameters
* @param[in]      scan_mask_a   A mask bits for scan channel mask A
* @param[in]      scan_mask_b   A mask bits for scan channel mask B
 * @retval FSP_SUCCESS                 Data read into provided p_data.
 * @retval FSP_ERR_ASSERTION           An input argument is invalid.
 * @retval FSP_ERR_NOT_OPEN            Unit is not open.
 * @retval FSP_ERR_NOT_INITIALIZED     Unit is not initialized.
 **********************************************************************************************************************/
fsp_err_t R_MTR_ADC_SetChannels(adc_ctrl_t * p_ctrl, uint32_t scan_mask_a, uint32_t scan_mask_b)
{
    adc_instance_ctrl_t * p_instance_ctrl = (adc_instance_ctrl_t *) p_ctrl;

#if GPT_THREE_PHASE_CFG_PARAM_CHECKING_ENABLE
    FSP_ASSERT(NULL != p_ctrl);
    FSP_ERROR_RETURN(GPT_THREE_PHASE_OPEN == p_ctrl->open, FSP_ERR_NOT_OPEN);
#endif

    p_instance_ctrl->p_reg->ADANSA[0] &= (uint16_t) (scan_mask_a);
    p_instance_ctrl->p_reg->ADANSB[0] &= (uint16_t) (scan_mask_b);
    p_instance_ctrl->p_reg->ADANSA[1] &= (uint16_t) ((scan_mask_a >> 16));
    p_instance_ctrl->p_reg->ADANSB[1] &= (uint16_t) ((scan_mask_b >> 16));

    return FSP_SUCCESS;
} /* End of function R_MTR_ADC_SetChannels */
#endif
