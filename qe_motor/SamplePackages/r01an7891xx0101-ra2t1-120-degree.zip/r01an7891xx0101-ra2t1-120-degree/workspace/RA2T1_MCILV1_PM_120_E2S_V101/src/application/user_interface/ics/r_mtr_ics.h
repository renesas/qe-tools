/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ics.h
* Description : Definitions of a user interface (tool) processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_ICS_H
#define R_MTR_ICS_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/*#define TS_50US*/
/*#define TS_100US*/
#define TS_300US


/* ICS watch point configuration */
#ifdef TS_300US
#define     ICS_BRR                         (4)

#if (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_16KHZ) || (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_20KHZ)
#define     MTR_ICS_DECIMATION              (5)
#else
#error "ICS watch point error"
#endif /* CP_CARRIER_FREQ_SEL */
#endif /* #ifdef TS_300US */

#ifdef TS_100US
#define     ICS_BRR                         (0)

#if (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_16KHZ) || (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_20KHZ)
#define     MTR_ICS_DECIMATION              (1)
#else
#error "ICS watch point error"
#endif /* CP_CARRIER_FREQ_SEL */
#endif /* #ifdef TS_100US */

#ifdef TS_50US
#define     ICS_BRR                         (0)
/* 50us cycle only. Cannot be used when using interrupt skipping. */
#if (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_16KHZ) || (CP_CARRIER_FREQ_SEL == CP_CARRIER_FREQ_20KHZ)
#define     MTR_ICS_DECIMATION              (0)
#else
#error "ICS watch point error"
#endif /* CP_CARRIER_FREQ_SEL */
#endif /* #ifdef TS_50US */

/* for I/F initialization of Renesas Motor Workbench */
#define     ICS_ADDR                        (0xFE00)
#define     ICS_INT_LEVEL                   (3)
#define     ICS_NUM                         (0x40)
#define     ICS_INT_MODE                    (0)

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    st_mtr_design_parameter_com_t st_com;

    int8_t     com_u1_direction;                  /* Rotation direction (1:CW, -1:CCW) */
    uint16_t   com_u2_mtr_pp;                     /* Motor pole pairs */
    float      com_f4_mtr_r;                      /* Resistance [ohm] */
    float      com_f4_mtr_ld;                     /* d-axis inductance [H] */
    float      com_f4_mtr_lq;                     /* q-axis inductance [H] */
    float      com_f4_mtr_ke;                     /* Induced voltage constant [V s/rad] */
    float      com_f4_mtr_j;                      /* Rotor inertia [kgm^2/(rad s^2] */
    float      com_f4_ref_lim_v;                  /* Lower limit voltage reference [V] */
    float      com_f4_ramp_lim_speed_rpm;         /* Limit of acceleration [rpm/ms] */
    float      com_f4_ref_speed_rpm;              /* Motor speed reference [rpm] */
    uint16_t   com_u2_offset_calc_cnt;            /* Current offset calculation time [cnt] */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    float      com_f4_ramp_lim_v;                 /* Limit of variation of voltage [V/ms] */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    float      com_f4_ramp_lim_current;           /* Limit of variation of current [A/ms] */
    float      com_f4_mtr_d0;                     /* 0th order friction coefficient [kg m^2/(rads^2)] */
    float      com_f4_mtr_d1;                     /* 1st order friction coefficient [kg�m^2/(rad^2�s)] */
#endif

#if (HALL == MTRCONF_SENSOR_MODE)
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    float      com_f4_ref_v_start;                /* Initial reference voltage at start-up[V] */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    float      com_f4_ref_idc_start;              /* Initial reference current at start-up[A] */
#endif

#elif (LESS == MTRCONF_SENSOR_MODE)
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    float      com_f4_ref_v_draw_in;              /* Reference voltage at draw-in [V] */
    float      com_f4_ref_v_ol;                   /* Reference voltage at open-loop drive [V] */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    float      com_f4_ref_idc_draw_in;            /* Current reference at draw-in [A] */
    float      com_f4_ref_idc_ol;                 /* Openloop start reference current [A] */
#endif
    float      com_f4_ol2cl_speed_rpm ;           /* Openloop to sensorless control change speed [rpm] */
    float      com_f4_ol2cl_ramp_speed_rpm;       /* Accelerattion at translating into PI control [rpm/ms] */
    int32_t    com_s4_angle_shift_adjust;         /* Adjust for delay counts */
#endif
    int16_t    com_s2_enable_write;           /* ICS write enable flag */
} st_com_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
void R_MTR_SetIcs (void);
void R_MTR_SetCOMVariables (void);
void R_MTR_ICSVariablesInit (void);

#endif /* R_MTR_ICS_H */
