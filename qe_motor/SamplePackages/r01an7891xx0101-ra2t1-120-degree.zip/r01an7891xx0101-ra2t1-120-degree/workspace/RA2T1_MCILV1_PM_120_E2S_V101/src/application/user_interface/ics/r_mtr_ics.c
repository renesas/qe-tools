/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_ics.c
* Description : Processes of a user interface (tool)
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Main associated header file */
#include "r_mtr_config.h"
#include "rm_mtr_common.h"
#include "rm_mtr_driver.h"
#include "rm_mtr_parameter.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "r_mtr_ics.h"
#include "r_mtr_ra2t1.h"
#include "rm_mtr_ol2cl_ctrl.h"

#include "ICS2_RA2T1.h"

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
st_mtr_ctrl_input_t st_ics;               /* structure for ICS input */

/***********************************************************************************************************************
* Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
const st_com_t g_st_com_init =
{
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    .st_com.f4_speed_omega      = CP_ASR_OMEGA_HZ,
    .st_com.f4_asr_zeta      = CP_ASR_ZETA,
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    .st_com.f4_acr_nf_hz     = CP_ACR_NF_HZ,
    .st_com.f4_asr_nf_hz     = CP_ASR_NF_HZ,
    .st_com.f4_asr_ki_aug    = CP_ASR_KI_AUG,
    .st_com.f4_acr_deadband_lsb = CP_ACR_DEADBAND_LSB,
#endif
    .st_com.f4_asr_deadband_lsb = CP_ASR_DEADBAND_LSB,

    .com_u1_direction           = 0,
    .com_u2_mtr_pp               = MP_POLE_PAIRS,
    .com_f4_mtr_r                = MP_RESISTANCE,
    .com_f4_mtr_ld               = MP_D_INDUCTANCE,
    .com_f4_mtr_lq               = MP_Q_INDUCTANCE,
    .com_f4_mtr_ke               = MP_BEMF_CONSTANT,
    .com_f4_mtr_j                = MP_ROTOR_INERTIA,
    .com_f4_ref_lim_v            = CP_LIMIT_V,
#if (HALL == MTRCONF_SENSOR_MODE)
    .com_f4_ramp_lim_speed_rpm   = CP_RAMP_LIMIT_SPEED_RPM_HALL,
#elif (LESS == MTRCONF_SENSOR_MODE)
    .com_f4_ramp_lim_speed_rpm   = CP_RAMP_LIMIT_SPEED_RPM_LESS,
#endif
    .com_f4_ref_speed_rpm        = (float)CP_MIN_SPEED_RPM,
    .com_u2_offset_calc_cnt      = CP_OFFSET_CALC_CNT,

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
#if (HALL == MTRCONF_SENSOR_MODE)
     .com_f4_ramp_lim_v          = CP_RAMP_LIMIT_V_HALL,
#elif (LESS == MTRCONF_SENSOR_MODE)
     .com_f4_ramp_lim_v          = CP_RAMP_LIMIT_V_LESS,
#endif

#elif (CURRENT == MTRCONF_CONTROL_MODE)
     .com_f4_ramp_lim_current    = CP_RAMP_LIMIT_CURRENT,
     .com_f4_mtr_d0              = MP_FRICTION_0TH_ORDER,
     .com_f4_mtr_d1              = MP_FRICTION_1ST_ORDER,
#endif

#if (HALL == MTRCONF_SENSOR_MODE)
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
     .com_f4_ref_v_start         = CP_START_REF_V,
#elif (CURRENT == MTRCONF_CONTROL_MODE)
     .com_f4_ref_idc_start       = CP_START_REF_IDC,
#endif

#elif (LESS == MTRCONF_SENSOR_MODE)
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
     .com_f4_ref_v_draw_in       = CP_DRAW_IN_REF_V,
     .com_f4_ref_v_ol            = CP_OL_REF_V,
#elif (CURRENT == MTRCONF_CONTROL_MODE)
     .com_f4_ref_idc_draw_in     = CP_DRAW_IN_REF_IDC,
     .com_f4_ref_idc_ol          = CP_OL_REF_IDC,
#endif
     .com_f4_ol2cl_speed_rpm     = CP_OL2CL_SPEED_RPM,
     .com_f4_ol2cl_ramp_speed_rpm = CP_OL2CL_SPEED_RAMP_RPM,
     .com_s4_angle_shift_adjust  = 0,
#endif

    .com_s2_enable_write = 0,
};

st_com_t g_st_com;

const st_mtr_design_parameter_macro_t g_st_design_param_macro =
{
    .f4_dt                  = MTR_CTRL_PERIOD * PU_SF_TIME,
    .f4_dt_speed            = MTR_SPEED_CTRL_PERIOD * PU_SF_TIME,
    .f4_pu_sf_afreq         = PU_SF_AFREQ,
    .f4_speed_limit_rpm     = CP_SPEED_LIMIT_RPM,
    .u1_q_current           = MTR_Q_CURRENT,
    .u1_q_voltage           = MTR_Q_VOLTAGE,
    .u1_q_asr_kp            = MTR_Q_ASR_KP,
    .u1_q_asr_kidt          = MTR_Q_ASR_KIDT,
    .u1_q_asr_err           = MTR_Q_ASR_ERR,
#if (CURRENT == MTRCONF_CONTROL_MODE)
    .u1_q_acr_kp            = MTR_Q_ACR_KP,
    .u1_q_acr_kidt          = MTR_Q_ACR_KIDT,
    .u1_q_acr_err           = MTR_Q_ACR_ERR,
#endif
};

int16_t    g_s2_enable_write;             /* ICS write enable flag */

/***********************************************************************************************************************
* Private variables
***********************************************************************************************************************/
static uint8_t s_u1_cnt_ics = 0;

/***********************************************************************************************************************
* Private functions definitions
***********************************************************************************************************************/
static inline float mtr_limit_float(float f4_value, int32_t s4_max, int32_t s4_min);

/***********************************************************************************************************************
* @fn             R_MTR_SetIcs
* @brief          Set to prepare ICS
* @return         None
***********************************************************************************************************************/
void R_MTR_SetIcs(void)
{
    /*============================*/
    /*         for ICS            */
    /*============================*/
    s_u1_cnt_ics++;

    /* Decimation of ICS call */
    if (MTR_ICS_DECIMATION < s_u1_cnt_ics)
    {
        ics2_watchpoint();
        s_u1_cnt_ics = 0;
    }
} /* End of function R_MTR_SetIcs */

/***********************************************************************************************************************
* @fn             R_MTR_SetCOMVariables
* @brief          Set com variables to "tool" input buffer
* @return         None
***********************************************************************************************************************/
void R_MTR_SetCOMVariables(void)
{
    int8_t s1_dir = MTR_CW;
    /*============================*/
    /*      Get ICS value         */
    /*============================*/
    /***** When com_s2_enable_write and g_s2_enable_write are same value, rewrite enable. *****/
    if (g_st_com.com_s2_enable_write == g_s2_enable_write)
    {
        /***** Limit input speed *****/
        g_st_com.com_f4_ref_speed_rpm = mtr_limit_float(g_st_com.com_f4_ref_speed_rpm,
                                                        CP_MAX_SPEED_RPM, CP_MIN_SPEED_RPM);

        /* Reference speed */
        st_ics.s4_ref_speed = FIX_fromfloat(g_st_com.com_f4_ref_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);

        /* Rotation direction */
        if (MTR_SET == g_st_com.com_u1_direction)
        {
            s1_dir = MTR_CCW;
        }
        else
        {
            s1_dir = MTR_CW;
        }
        st_ics.s1_ref_direction = s1_dir;

        /* Motor parameters */
        st_ics.st_motor.u2_mtr_pp = g_st_com.com_u2_mtr_pp;
        st_ics.st_motor.s4_mtr_r  = FIX_fromfloat(g_st_com.com_f4_mtr_r * PU_SF_RES, MTR_Q_RESISTANCE);
        st_ics.st_motor.s4_mtr_ke = FIX_fromfloat(g_st_com.com_f4_mtr_ke * PU_SF_BEMF_CONST, MTR_Q_BEMF_CONST);
        st_ics.st_motor.s4_mtr_ld = FIX_fromfloat(g_st_com.com_f4_mtr_ld * PU_SF_IND, MTR_Q_INDUCTANCE);
        st_ics.st_motor.s4_mtr_lq = FIX_fromfloat(g_st_com.com_f4_mtr_lq * PU_SF_IND, MTR_Q_INDUCTANCE);
        st_ics.st_motor.s4_mtr_j  = FIX_fromfloat(g_st_com.com_f4_mtr_j * PU_SF_INERTIA, MTR_Q_INERTIA);

        /* Limit of acceleration */
        st_ics.s4_lim_accel = FIX_fromfloat(g_st_com.com_f4_ramp_lim_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);
        /* Number of times current offset is measured */
        st_ics.u2_cnt_offset_calc = g_st_com.com_u2_offset_calc_cnt;
        /* Lower limit voltage reference */
        st_ics.s4_ref_lim_v = (FIX_fromfloat(g_st_com.com_f4_ref_lim_v * PU_SF_VOLTAGE, MTR_Q_VOLTAGE));

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
        /* Limit of variation of voltage */
        st_ics.s4_ramp_lim_v = FIX_fromfloat(g_st_com.com_f4_ramp_lim_v * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
#elif (CURRENT == MTRCONF_CONTROL_MODE)
        /* Limit of variation of current */
        st_ics.s4_lim_current = FIX_fromfloat(g_st_com.com_f4_ramp_lim_current * PU_SF_CURRENT, MTR_Q_CURRENT);
#endif

#if (HALL == MTRCONF_SENSOR_MODE)
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
        /* Initial reference voltage */
        st_ics.s4_ref_v_start = FIX_fromfloat(g_st_com.com_f4_ref_v_start * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
#elif (CURRENT == MTRCONF_CONTROL_MODE)
        /* Initial reference current */
        st_ics.s4_ref_idc_start = FIX_fromfloat(g_st_com.com_f4_ref_idc_start * PU_SF_CURRENT, MTR_Q_CURRENT);
#endif

#elif (LESS == MTRCONF_SENSOR_MODE)
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
        /* Reference voltage at draw-in */
        st_ics.s4_draw_in_ref_v = FIX_fromfloat(g_st_com.com_f4_ref_v_draw_in * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
        /* Open-loop start reference voltage */
        st_ics.s4_ol_ref_v_buff = FIX_fromfloat(g_st_com.com_f4_ref_v_ol * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
#elif (CURRENT == MTRCONF_CONTROL_MODE)
        /* DC link current reference at draw-in */
        st_ics.s4_draw_in_ref_idc = FIX_fromfloat(g_st_com.com_f4_ref_idc_draw_in * PU_SF_CURRENT, MTR_Q_CURRENT);
        /* Open-loop start reference dc link current */
        st_ics.s4_ol_ref_idc_buff = FIX_fromfloat(g_st_com.com_f4_ref_idc_ol * PU_SF_CURRENT, MTR_Q_CURRENT);
#endif
        /* Speed to change from open-loop drive to sensor-less control */
        st_ics.s4_th_speed_ol2cl  = FIX_fromfloat(g_st_com.com_f4_ol2cl_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);
        /* Acceleration at transition from open-loop drive to sensor-less control */
        st_ics.s4_ol2cl_ramp_speed = FIX_fromfloat(g_st_com.com_f4_ol2cl_ramp_speed_rpm * PU_SF_RPM_RAD, MTR_Q_AFREQ);
        /* Speed to change from sensorless control to open-loop drive */
        st_ics.s4_th_speed_cl2ol = FIX_fromfloat((g_st_com.com_f4_ol2cl_speed_rpm - CP_CL2OL_SPEED_MARGIN)
                                                     * PU_SF_RPM_RAD, MTR_Q_AFREQ);
        /* Adjust for delay counts */
        st_ics.s4_angle_shift_adjust = g_st_com.com_s4_angle_shift_adjust;
        /* A/D trigger adjustment count */
#endif /* #if (LESS == MTRCONF_SENSOR_MODE) */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
        /* Motor parameters */
        g_st_ctrl_params.u2_mtr_pp = g_st_com.com_u2_mtr_pp;
        g_st_ctrl_params.f4_r      = g_st_com.com_f4_mtr_r * PU_SF_RES;
        g_st_ctrl_params.f4_ke     = g_st_com.com_f4_mtr_ke * PU_SF_BEMF_CONST;
        g_st_ctrl_params.f4_j      = g_st_com.com_f4_mtr_j * PU_SF_INERTIA;

#elif (CURRENT == MTRCONF_CONTROL_MODE)
        /* Motor parameters */
        g_st_ctrl_params.u2_mtr_pp = g_st_com.com_u2_mtr_pp;
        g_st_ctrl_params.f4_r      = g_st_com.com_f4_mtr_r * PU_SF_RES;
        g_st_ctrl_params.f4_lq     = g_st_com.com_f4_mtr_lq * PU_SF_IND;
        g_st_ctrl_params.f4_ke     = g_st_com.com_f4_mtr_ke * PU_SF_BEMF_CONST;
        g_st_ctrl_params.f4_j      = g_st_com.com_f4_mtr_j * PU_SF_INERTIA;
        /* Calculate the terms related to friction */
        g_st_ctrl_params.f4_d0_div_pm  = (g_st_com.com_f4_mtr_d0 /
                                            (g_st_com.com_u2_mtr_pp * g_st_com.com_f4_mtr_ke))
                                                                                        * PU_SF_CURRENT;
        g_st_ctrl_params.f4_d1_div_p2m = (g_st_com.com_f4_mtr_d1 /
                                            (g_st_com.com_u2_mtr_pp * g_st_com.com_u2_mtr_pp * g_st_com.com_f4_mtr_ke))
                                                                                        * PU_SF_D1_DIV_P2M;
#endif

        /* Speed PI controller */
        /* Current PI gain */
        /* Speed PI gain */
        /* Augmentation rate for integral part of ASR  */
        /* Dead-band */
        g_st_ctrl_params.st_com = g_st_com.st_com;

        /* Copy variables com to ICS input */
        RM_MTR_IcsBufferSet();

        g_s2_enable_write ^= 1;                         /* Changed to 0 or 1 every time */
    }
} /* End of function R_MTR_SetCOMVariables */

/***********************************************************************************************************************
* @fn             R_MTR_ICSVariablesInit
* @brief          Initialize valiables for Analyzer interface
* @return         None
***********************************************************************************************************************/
void R_MTR_ICSVariablesInit(void)
{
    g_st_com = g_st_com_init;

/*    st_ics.st_ctrl_params.st_macro = g_st_design_param_macro; */
    g_st_ctrl_params.st_macro = g_st_design_param_macro;

    g_s2_enable_write   = 0;
} /* End of function R_MTR_ICSVariablesInit */

/***********************************************************************************************************************
* @fn             mtr_limit_float
* @brief          Calculate a limitation for a float value
* @param[in]      f4_value      a value to calculate
* @param[in]      s4_max        the maximum limitation
* @param[in]      s4_min        the minimum limitation
* @return         a limited value
***********************************************************************************************************************/
static inline float mtr_limit_float(float f4_value, int32_t s4_max, int32_t s4_min)
{
    if (f4_value > (float)s4_max)
    {
        return (float)(s4_max);
    }
    else if (f4_value < (float)s4_min)
    {
        return (float)(s4_min);
    }
    else
    {
        return (f4_value);
    }
} /* End of function mtr_limit_float */

