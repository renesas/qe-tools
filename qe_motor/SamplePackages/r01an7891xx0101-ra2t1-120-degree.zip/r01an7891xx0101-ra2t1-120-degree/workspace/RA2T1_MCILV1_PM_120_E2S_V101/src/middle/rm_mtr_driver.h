/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_driver.h
* Description : Definitions of the processing of accessing driver
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef RM_MTR_DRIVER_H
#define RM_MTR_DRIVER_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_parameter.h"
#include "rm_mtr_ctrl_gain.h"
#include "r_mtr_config.h"

/***********************************************************************************************************************
Global structures
***********************************************************************************************************************/
/* Data structure for storing system configuration inputs */
typedef struct
{
    int8_t    s1_ref_direction;                /* Rotation direction (1:CW, -1:CCW) */
    int32_t   s4_ref_speed;                    /* Motor speed reference */
    int32_t   s4_lim_accel;                    /* Limit of acceleration */
    uint16_t  u2_cnt_offset_calc;              /* Number of samples for current offset calibration */
    int32_t   s4_ref_lim_v;                    /* Lower limit voltage reference */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    int32_t   s4_ramp_lim_v;                   /* Limit of rate of voltage change */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    int32_t   s4_lim_current;                  /* Limit of rate of current change */
#endif

#if (HALL == MTRCONF_SENSOR_MODE)
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    int32_t   s4_ref_v_start;                  /* Initial reference voltage for start-up*/
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    int32_t   s4_ref_idc_start;                /* Initial reference current for start-up */
#endif

#elif (LESS == MTRCONF_SENSOR_MODE)
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    int32_t   s4_draw_in_ref_v;                /* Reference voltage at draw-in */
    int32_t   s4_ol_ref_v_buff;                /* Reference voltage at open-loop drive */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    int32_t   s4_draw_in_ref_idc;              /* DC link current reference at draw-in */
    int32_t   s4_ol_ref_idc_buff;              /* Openloop start reference DC link current */
#endif
    int32_t   s4_th_speed_ol2cl;               /* Speed to change from open-loop drive to sensorless control */
    int32_t   s4_ol2cl_ramp_speed;             /* Acceleration at transitioning into PI control */
    int32_t   s4_th_speed_cl2ol;               /* Speed to change from sensorless control to open-loop drive */
    int32_t   s4_angle_shift_adjust;           /* Adjust for delay counts */
#endif /* #if (LESS == MTRCONF_SENSOR_MODE) */

    st_mtr_parameter_t           st_motor;           /* Motor parameters */
} st_mtr_ctrl_input_t;

extern st_mtr_ctrl_input_t             g_st_ics_input_buff; /* structure for ICS input */
extern st_mtr_design_parameter_t       g_st_ctrl_params;    /* Control parameters */
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
extern st_mtr_ctrl_gain_voltage_mode_t g_st_gain_v_buf;     /* Input PI gains for voltage mode */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
extern st_mtr_ctrl_gain_current_mode_t g_st_gain_i_buf;     /* Input PI gains for current mode  */
#endif

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
void RM_MTR_ControlInit (void);
void RM_MTR_EventExec (uint8_t  u1_event);
uint16_t RM_MTR_CapacitorCharge (void);
uint8_t RM_MTR_StatusGet (void);
uint16_t RM_MTR_StatusErrorGet (void);
void RM_MTR_IcsBufferSet (void);
void RM_MTR_VariablesSet (void);
void RM_MTR_InputBuffParamReset (void);
void RM_MTR_UpdatePollingSet (void);

#endif /* RM_MTR_DRIVER_H */
