/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_parameter.h
* Description : Definitions of parameters used in control
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef RM_MTR_PARAMETER_H
#define RM_MTR_PARAMETER_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_mtr_config.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define     MTR_SPEED_PI_LIMIT_V         (IP_INPUT_V)            /* Speed PI output limit [V] */
#define     MTR_MCU_ON_V                 (IP_INPUT_V * 0.8f)     /* MCU power on voltage [V] */
#define     MTR_US_MAX_DRIVE_V           (IP_INPUT_V * 0.96f)    /* Max output voltage [V] */
#if (MTRCONF_MODE == SENSORLESS_CURRENT)
#define     MTR_US_MIN_DRIVE_V           (IP_INPUT_V * 0.05f)     /* Min output voltage [V] */
#else
#define     MTR_US_MIN_DRIVE_V           (IP_INPUT_V * 0.0f)    /* Min output voltage [V] */
#endif
//#define     MTR_US_MIN_DRIVE_V           (CP_LIMIT_V)            /* Min output voltage [V] */
//#define     MTR_US_MIN_DRIVE_V           (IP_INPUT_V * 0.05f)    /* Min output voltage [V] */
/* Max and min output voltage scaled to fixed point [PU] */
#define     MTR_MAX_DRIVE_V              (FIX_fromfloat(MTR_US_MAX_DRIVE_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))
#define     MTR_MIN_DRIVE_V              (FIX_fromfloat(MTR_US_MIN_DRIVE_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))

/* Coefficient for finding the reciprocal of voltage */
#define     MTR_RECIV_COEF         ((int32_t)(2 * PU_BASE_VOLTAGE_V / IP_VDC_RANGE * (1 << MTR_Q_VOLTAGE)))


/* Conversion factor for speed calc(count -> rad/s) */
/* Unscaled conversion factor */
#define     MTR_US_SPEED_CALC_BASE  (MTR_SPEED_CALC_TIMER_FREQ * 1000 * MTR_TWOPI)
/* Conversion factor scaled to fixed-point [PU]*/
#define     MTR_SPEED_CALC_BASE     (FIX_fromfloat(MTR_US_SPEED_CALC_BASE * PU_SF_AFREQ, MTR_SPEED_CALC_BASE_SHIFT))

/* Conversion factor for open-loop (s/rad -> count) */
/* Unscaled conversion factor */
#define     MTR_US_OL_SPEED_CALC_BASE     (MTR_CARRIER_FREQ * 1000 * MTR_TWOPI / MTR_PATTERN_NUM)
/* Conversion factor scaled to fixed-point [PU]*/
//#define     MTR_OL_SPEED_CALC_BASE        (FIX_fromfloat(MTR_US_OL_SPEED_CALC_BASE * PU_SF_AFREQ, MTR_Q_AFREQ))
#define     MTR_OL_SPEED_CALC_BASE        (FIX_fromfloat(MTR_US_OL_SPEED_CALC_BASE * PU_SF_AFREQ, MTR_SPEED_CALC_BASE_SHIFT))

/* Integral term velocity deadband */
#define     MTR_ASR_DEADBAND        (0)

/* Conversion factors for 1st rotation */
#define     MTR_SPEED_CALC_BASE_1ST (MTR_SPEED_CALC_BASE / 6)
#define     MTR_SPEED_CALC_BASE_2ND (MTR_SPEED_CALC_BASE / 3)
#define     MTR_SPEED_CALC_BASE_3RD (MTR_SPEED_CALC_BASE / 2)
//#define     MTR_SPEED_CALC_BASE_4TH (MTR_SPEED_CALC_BASE * 2 / 3)
#define     MTR_SPEED_CALC_BASE_4TH (FIX_fromfloat(MTR_US_SPEED_CALC_BASE * 2 / 3 * PU_SF_AFREQ, MTR_Q_AFREQ))
//#define     MTR_SPEED_CALC_BASE_5TH (MTR_SPEED_CALC_BASE * 5 / 6)
#define     MTR_SPEED_CALC_BASE_5TH (FIX_fromfloat(MTR_US_SPEED_CALC_BASE * 5 / 6 * PU_SF_AFREQ, MTR_Q_AFREQ))


/* Number of bits shift for duty calculation*/
//#define     MTR_BIT_SFT_NUM_FOR_DUTY_CALC                (15)
#define     MTR_BIT_SFT_NUM_FOR_DUTY_CALC                (19)
/* Bits shifted to the left to improve accuracy of duty calculation */
#define     MTR_BIT_SFT_FOR_DUTY_CALC                    (((uint32_t)(1)) << MTR_BIT_SFT_NUM_FOR_DUTY_CALC)

#if (CURRENT == MTRCONF_CONTROL_MODE)
#define     MTR_LIMIT_IDC          (MP_RATED_CURRENT * MTR_SQRT_3)   /* Speed PI limit for DC-link current */
#define     MTR_I_LIMIT_CURRENT    (MP_RATED_CURRENT * MTR_SQRT_3)   /* Speed PI integral term limit for current */
#define     MTR_MIN_IDC_REF        (0)                               /* Min value for reference current */
#endif

#define     MTR_I_LIMIT_VQ         (IP_INPUT_V * 0.9f)               /* current PI integral term limit for vq */

/***********************************************************************************************************************
Global structure
***********************************************************************************************************************/
/* Motor parameter structure */
typedef struct
{
    uint16_t u2_mtr_pp;                  /* Number of pole pairs */
    int32_t  s4_mtr_r;                   /* Resistance [ohm] */
    int32_t  s4_mtr_ld;                  /* Inductance for d-axis [H/rad] */
    int32_t  s4_mtr_lq;                  /* Inductance for q-axis [H/rad] */
    int32_t  s4_mtr_ke;                  /* Induced voltage constant [V s/rad] */
    int32_t  s4_mtr_j;                   /* Rotor inertia [kg�m^2/(rad^2)] */
} st_mtr_parameter_t;

#endif /* RM_MTR_PARAMETER_H */
