/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_carrier.c
* Description : The carrier interrupt handler
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_120.h"
#include "rm_mtr_driver.h"
#include "r_mtr_config.h"
#include "rm_mtr_common.h"
#include "r_mtr_ics.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "rm_mtr_parameter.h"
#include "r_mtr_ra2t1.h"
#include "rm_mtr_statemachine.h"
#include "rm_mtr_ol2cl_ctrl.h"

#include "hal_data.h"
#include "r_mtr_common.h"
/***********************************************************************************************************************

Global variables
***********************************************************************************************************************/
st_mtr_120_control_t g_st_120;                      /* Structure of 120 degree control */

/* Array of voltage pattern for open-loop drive */
               /************  CW  ************/
const uint16_t   g_u2_ol_v_pattern_table_CW[7] = {
                         0,
                         MTR_PATTERN_CW_V_U,        /* 2 */
                         MTR_PATTERN_CW_W_U,        /* 3 */
                         MTR_PATTERN_CW_W_V,        /* 1 */
                         MTR_PATTERN_CW_U_V,        /* 5 */
                         MTR_PATTERN_CW_U_W,        /* 4 */
                         MTR_PATTERN_CW_V_W,        /* 6 */
                };
               /************  CCW  ************/
const uint16_t   g_u2_ol_v_pattern_table_CCW[7] = {
                         0,
                         MTR_PATTERN_CCW_V_W,       /* 2 */
                         MTR_PATTERN_CCW_U_W,       /* 6 */
                         MTR_PATTERN_CCW_U_V,       /* 4 */
                         MTR_PATTERN_CCW_W_V,       /* 5 */
                         MTR_PATTERN_CCW_W_U,       /* 1 */
                         MTR_PATTERN_CCW_V_U,       /* 3 */
                 };

/* Array of chopping pattern */
#if (NON_COMPLEMENTARY == MTRCONF_PWM_MODE)
               /* Non-complementary chopping */
               /***********   CW   ***********/
        const uint16_t g_u2_chopping_pattern_table_CW[6] = {
                         MTR_WP_PWM_VN_ON,          /* 6 */
                         MTR_UP_PWM_VN_ON,          /* 1 */
                         MTR_UP_PWM_WN_ON,          /* 2 */
                         MTR_VP_PWM_WN_ON,          /* 4 */
                         MTR_VP_PWM_UN_ON,          /* 3 */
                         MTR_WP_PWM_UN_ON,          /* 5 */
              };
               /***********   CCW   ***********/
        const uint16_t g_u2_chopping_pattern_table_CCW[6] = {
                         MTR_WP_PWM_VN_ON,          /* 6 */
                         MTR_WP_PWM_UN_ON,          /* 5 */
                         MTR_VP_PWM_UN_ON,          /* 3 */
                         MTR_VP_PWM_WN_ON,          /* 4 */
                         MTR_UP_PWM_WN_ON,          /* 2 */
                         MTR_UP_PWM_VN_ON,          /* 1 */
              };

#elif (COMPLEMENTARY == MTRCONF_PWM_MODE)
               /* Complementary chopping */
               /***********   CW   ***********/
const uint16_t g_u2_chopping_pattern_table_CW[6] = {
                         MTR_W_PWM_VN_ON,           /* 18 */
                         MTR_U_PWM_VN_ON,           /* 13 */
                         MTR_U_PWM_WN_ON,           /* 14 */
                         MTR_V_PWM_WN_ON,           /* 16 */
                         MTR_V_PWM_UN_ON,           /* 15 */
                         MTR_W_PWM_UN_ON,           /* 17 */
              };
               /***********   CCW   ***********/
const uint16_t g_u2_chopping_pattern_table_CCW[6] = {
                         MTR_W_PWM_VN_ON,           /* 18 */
                         MTR_W_PWM_UN_ON,           /* 17 */
                         MTR_V_PWM_UN_ON,           /* 15 */
                         MTR_V_PWM_WN_ON,           /* 16 */
                         MTR_U_PWM_WN_ON,           /* 14 */
                         MTR_U_PWM_VN_ON,           /* 13 */
              };
#endif

#if (LESS == MTRCONF_SENSOR_MODE)
static uint8_t   g_u1_flag_delay = 0;            /* Delay timer interrupt flag */
#endif

/***********************************************************************************************************************
Private functions definitions
***********************************************************************************************************************/
static void mtr_carrier_sequence (void);
static void mtr_carrier_startup_sequence (void);

static void mtr_carrier_vdc_get (int32_t * p_s4_ad_vdc, int16_t * p_s2_ad_vdc_bit);
static void mtr_carrier_idc_get (int32_t * p_s4_ad_idc, int16_t * p_s2_ad_idc_bit,
                                uint32_t u4_ad_offset_idc);

static inline uint16_t mtr_carrier_lim_sw_over_current (int32_t s4_lim_over_current, int32_t s4_ad_idc);

#if (CURRENT == MTRCONF_CONTROL_MODE)
/* Current PI control */
static inline void mtr_current_pi_ctrl(st_mtr_acr_t * p_st_acr, int32_t s4_idc_err,
                                        int32_t *p_s4_ref_v_ctrl, int32_t s4_lim_v);

static inline int32_t mtr_pi_run_acr (st_mtr_pi_t * p_st_pi, int32_t s4_err,
                                        const uint8_t u1_kp_q, const uint8_t u1_q_err_shift,
                                        const uint8_t u1_q_kidt_shift, const uint8_t u1_q_intg_shift);
#endif

static inline void mtr_carrier_set_pwm(uint16_t u2_pattern, int8_t s1_dir, uint16_t * p_u2_pwm_duty,
                                        int32_t s4_ref_v_ctrl, int16_t s2_ad_vdc_bit);
static inline uint16_t mtr_duty_calc (int32_t s4_ref_v, int16_t s4_ad_vdc_bit);

/* Measure current offset for calibration */
static uint8_t mtr_calib_current_offset_dc (st_mtr_120_control_t * p_st_120);

static inline int32_t mtr_abs(int32_t s4_value);
#if (CURRENT == MTRCONF_CONTROL_MODE)
static inline int32_t mtr_limit (int32_t s4_value, int32_t s4_max, int32_t s4_min);
static inline int32_t mtr_limit_abs (int32_t s4_value, int32_t s4_limit_value);
#endif

#if (HALL == MTRCONF_SENSOR_MODE)
static void mtr_hall_signal_process(void);
static inline void mtr_hall_signal_set(void);
#endif

/* Speed calculation */
static inline void mtr_speed_calc(void);
static inline void mtr_set_chopping_pattern (uint16_t u2_pattern);

#if (LESS == MTRCONF_SENSOR_MODE)
static inline void mtr_carrier_voltage_get (int16_t *p_s2_ad_vu, int16_t *p_s2_ad_vv, int16_t *p_s2_ad_vw,
                                            int16_t *p_s2_ad_vn);

static inline uint8_t mtr_detect_zerocross(st_mtr_sensorless_carrier_t *p_st_less, int16_t s2_ad_vn_offset,
                                st_mtr_ol2cl_t *p_st_ol2cl,
                                uint32_t *p_u4_cnt_timeout, int8_t s1_dir, uint16_t u2_v_pattern);
static inline void mtr_drive_openloop_less(void);
static inline void mtr_set_angle_shift(void);
static inline void mtr_start_delay_timer(uint32_t u4_delay_cnt);
static inline uint16_t mtr_openloop_pattern_set(void);
#endif

/***********************************************************************************************************************
Functions
***********************************************************************************************************************/
/**********************************************************************************************************************
* @fn             mtr_carrier_cyclic
* @brief          callback for carrier interrupt
* @param[in]      p_args  A pointer to callback arguments
***********************************************************************************************************************/
void mtr_carrier_cyclic(timer_callback_args_t *p_args)
{
    __enable_irq();

    if (TIMER_EVENT_TROUGH != p_args->event)
    {
        return;
    }

    /* Get Vdc */
    mtr_carrier_vdc_get(&g_st_120.s4_ad_vdc, &g_st_120.st_carrier.s2_ad_vdc_bit);

    if (MTR_DRIVE == g_st_120.u1_state_drive)
    {
        /* 120 degrees control sequence */
        mtr_carrier_sequence();

        /* ICS setting */
        R_MTR_SetIcs();
    }
    else
    {
        /* Stop sequence */
        mtr_carrier_startup_sequence();
    }
} /* End of function mtr_carrier_cyclic */

/***********************************************************************************************************************
* @fn             mtr_carrier_vdc_get
* @brief          Get VDC
* @param[out]     p_s4_ad_vdc   A pointer to an area of VDC value
* @param[out]     p_s2_vdc_bit  A pointer to an area for an AD result
***********************************************************************************************************************/
static void mtr_carrier_vdc_get(int32_t* p_s4_ad_vdc, int16_t* p_s2_ad_vdc_bit)
{
    /* Get A/D value of Vdc */
    R_MTR_ADC_WaitConversion(g_adc0.p_ctrl, ADC_CONVERT_TIMEOUT);
    R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_VDC, (uint16_t * const)&g_st_120.st_carrier.s2_ad_vdc_bit);

    /* Convert Vdc value */
    *p_s4_ad_vdc = (int32_t)(*p_s2_ad_vdc_bit) * (FP_SF_VOLTAGE >> MTR_ADC_12BIT);  /* Convert to [V] */
} /* End of function mtr_carrier_vdc_get */

/**********************************************************************************************************************
* @fn             mtr_carrier_sequence
* @brief          120 degrees control and set PWM modulation at PWM cycle timing
***********************************************************************************************************************/
static inline void mtr_carrier_sequence(void)
{
    /* Detect currents */
    mtr_carrier_idc_get(&g_st_120.st_carrier.s4_ad_idc, &g_st_120.st_carrier.s2_ad_idc_bit,
                        g_st_120.st_carrier.u4_ad_offset_idc);

    g_st_120.u2_error_status |= mtr_carrier_lim_sw_over_current(
                                 g_st_120.st_carrier.s4_lim_over_current,
                                 g_st_120.st_carrier.s4_ad_idc);

#if (LESS == MTRCONF_SENSOR_MODE)
    if (MTR_CLR == g_u1_flag_delay)
    {
        /* Get A/D converted value of Vu, Vv, Vw, Vn (12bit) */
        mtr_carrier_voltage_get(&g_st_120.st_carrier.st_less_carrier.s2_ad_vu,
                                &g_st_120.st_carrier.st_less_carrier.s2_ad_vv,
                                &g_st_120.st_carrier.st_less_carrier.s2_ad_vw,
                                &g_st_120.st_carrier.st_less_carrier.s2_ad_vn);
    }
    g_u1_flag_delay = MTR_CLR;
#endif

#if (CURRENT == MTRCONF_CONTROL_MODE)
    mtr_current_pi_ctrl(&g_st_120.st_acr, g_st_120.s4_ref_idc_ctrl - g_st_120.st_carrier.s4_ad_idc,
                        &g_st_120.s4_ref_v_ctrl, g_st_120.s4_lim_v);
#endif

    /*** PWM duty set ***/
    mtr_carrier_set_pwm(g_st_120.u2_v_pattern, g_st_120.s1_dir, &g_st_120.u2_pwm_duty,
                        g_st_120.s4_ref_v_ctrl, g_st_120.st_carrier.s2_ad_vdc_bit);

#if (LESS == MTRCONF_SENSOR_MODE)
    if (MTR_CTRL_DRIVE != (MTR_CTRL_DRIVE & g_st_120.u1_state_ctrl_mode))
    {
        return;
    }

    R_MTR_AGT_ReadTimerCount_32Bit(g_timer_rotation_speed.p_ctrl,  &g_st_120.u4_speed_timer_cnt);

    /* Estimate BEMF pattern and detect zerocross */
    g_st_120.st_carrier.st_less_carrier.u1_bemf_signal
                = mtr_detect_zerocross(&g_st_120.st_carrier.st_less_carrier, g_st_120.st_less_control.s2_ad_vn_offset,
                                       &g_st_120.st_less_control.st_ol2cl,
                                       &g_st_120.u4_cnt_timeout, g_st_120.s1_dir, g_st_120.u2_v_pattern);

    /* Change from open-loop drive to PI control */
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    if (MTR_REF_MANUAL == g_st_120.u2_state_ref_voltage)
    {
        int16_t s2_ad_v_uvwn[4];
        s2_ad_v_uvwn[0] = g_st_120.st_carrier.st_less_carrier.s2_ad_vu;
        s2_ad_v_uvwn[1] = g_st_120.st_carrier.st_less_carrier.s2_ad_vv;
        s2_ad_v_uvwn[2] = g_st_120.st_carrier.st_less_carrier.s2_ad_vw;
        s2_ad_v_uvwn[3] = g_st_120.st_carrier.st_less_carrier.s2_ad_vn;

        R_MTR_OL2CLCtrl(&g_st_120.st_less_control.st_ol2cl, s2_ad_v_uvwn,
                        g_st_120.s1_dir, g_st_120.st_carrier.st_less_carrier.u4_speed_cnt_ol,
                        g_st_120.st_carrier.st_less_carrier.u1_flg_pattern_change,
                        g_st_120.st_carrier.st_less_carrier.u4_pattern_period_ol,
                        g_st_120.st_carrier.st_less_carrier.u2_v_pattern_ol);
    }
#endif
    if (MTR_SET == g_st_120.st_less_control.st_ol2cl.u1_flg_change)
    {
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
        /* When zero-cross count reaches three times, voltage state is set as PI mode */
        if (CP_OL2CL_ZC_CNT <= g_st_120.st_less_control.st_ol2cl.u2_zc_cnt)
#endif
        {
            g_st_120.st_less_control.st_ol2cl.u1_flg_change  = MTR_CLR;
            g_st_120.st_less_control.st_ol2cl.u1_flg_zc      = MTR_CLR;
            g_st_120.u1_state_ctrl_mode                      = MTR_CTRL_CLL_SPEED_CTRL;

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
            g_st_120.u2_state_ref_voltage                    = MTR_REF_SPEED_PI_OUTPUT;
            g_st_120.s4_lim_v                                = g_st_120.s4_ref_lim_v;
            g_st_120.st_speed.st_voltage_asr.s4_pre_speed    = g_st_120.s4_speed;

#elif (CURRENT == MTRCONF_CONTROL_MODE)
            g_st_120.u2_state_ref_current    = MTR_REF_SPEED_PI_OUTPUT;
            g_st_120.st_acr.st_pi.s4_decimal = 0;
            g_st_120.s4_lim_v                = g_st_120.s4_ref_lim_v;
#endif
        }
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
        else if (MTR_1ST_ZC_CNT == g_st_120.st_less_control.st_ol2cl.u2_zc_cnt)
        {
            /* When first zerocross is detected, skip speed calculation */
            if (MTR_SET == g_st_120.st_carrier.st_less_carrier.u1_flg_pattern_change)
            {
                g_st_120.u4_pre_speed_timer_cnt = g_st_120.u4_speed_timer_cnt;
                g_st_120.st_carrier.st_less_carrier.u1_flg_pattern_change = MTR_CLR;
            }
        }
        else
        {
            /* Do nothing */
        }
#endif
    }

    /* In the case of pattern change */
    if (MTR_SET == g_st_120.st_carrier.st_less_carrier.u1_flg_pattern_change)
    {
        /* Speed calculation */
        mtr_speed_calc();
        if (MTR_DRIVE_OPL == (g_st_120.u1_state_ctrl_mode & MTR_DRIVE_CLL))
        {
            /* When reference speed is below transition speed */
            if ((g_st_120.st_less_control.st_ol2cl.s4_change_speed > (mtr_abs(g_st_120.s4_ref_speed_ctrl))))
            {
                g_st_120.s4_speed = g_st_120.s4_ref_speed_ctrl;
            }
            /* When reference voltage is below lower limit value */
            else if (g_st_120.s4_ref_lim_v > g_st_120.s4_ref_v_ctrl)
            {
                g_st_120.s4_speed = g_st_120.s4_ref_speed_ctrl;
            }
        }
    }

    /* In the case of open-loop drive */
    if (MTR_DRIVE_OPL == (g_st_120.u1_state_ctrl_mode & MTR_DRIVE_CLL))
    {
        /* Set a voltage pattern for open-loop drive */
        mtr_drive_openloop_less();
    }
    /* In the case of PI control */
    else if (MTR_DRIVE_CLL == (g_st_120.u1_state_ctrl_mode & MTR_DRIVE_CLL))
    {
        /* In the case of pattern change */
        if (MTR_SET == g_st_120.st_carrier.st_less_carrier.u1_flg_pattern_change)
        {
            /* Set shift value (delay time) */
            mtr_set_angle_shift();
            /* Set change voltage pattern after delay count */
            mtr_start_delay_timer(g_st_120.st_carrier.st_less_carrier.u4_bemf_delay);
        }
    }
    else
    {
        /* Do nothing */
    }

    g_st_120.st_carrier.st_less_carrier.u1_flg_pattern_change = MTR_CLR;
#endif /* #if (LESS == MTRCONF_SENSOR_MODE) */
} /* End of function mtr_carrier_sequence */

/***********************************************************************************************************************
* @fn             mtr_carrier_idc_get
* @brief          Get IDC
* @param[out]     p_s4_ad_idc       A pointer to an area of IDC value
* @param[out]     p_s2_ad_idc_bit   A pointer to an area for an AD result
* @param[in]      u4_ad_offset_idc  An offset for IDC
***********************************************************************************************************************/
static void mtr_carrier_idc_get(int32_t* p_s4_ad_idc, int16_t* p_s2_ad_idc_bit,
                                uint32_t u4_ad_offset_idc)
{
    int32_t s4_temp;

    /* Get A/D value of IDC */
    R_MTR_ADC_WaitConversion(g_adc0.p_ctrl, ADC_CONVERT_TIMEOUT);
    R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IDC, (uint16_t * const)p_s2_ad_idc_bit);

    s4_temp      = (int32_t)((uint32_t)(*p_s2_ad_idc_bit) - u4_ad_offset_idc);
    *p_s4_ad_idc = s4_temp * (FP_SF_CURRENT >> MTR_ADC_12BIT);           /* Convert to [A] */
} /* End of function mtr_carrier_idc_get */

/***********************************************************************************************************************
* @fn             mtr_carrier_lim_sw_over_current
* @brief          Check the error of software over-current
* @param[in]      s4_lim_over_current   An over-current threshold
* @param[in]      s4_ad_idc             An IDC value
* @retval         MTR_ERROR_NONE             No error
* @retval         MTR_ERROR_OVER_CURRENT_SW  Over-current error has occurred
***********************************************************************************************************************/
static inline uint16_t mtr_carrier_lim_sw_over_current(int32_t s4_lim_over_current, int32_t s4_ad_idc)
{
    uint16_t       u2_temp = ERROR_NONE;

    if (s4_lim_over_current < mtr_abs(s4_ad_idc))
    {
        /* execute error event */
        RM_MTR_EventExec(MTR_EVENT_ERROR);
        u2_temp = MTR_ERROR_OVER_CURRENT_SW;    /* error status update : over current error */
    }

    return (u2_temp);
} /* End of function mtr_carrier_lim_sw_over_current */

#if (CURRENT == MTRCONF_CONTROL_MODE)
/***********************************************************************************************************************
* @fn             mtr_current_pi_ctrl
* @brief          Control current PI
* @param[in,out]  p_st_acr              A pointer to a structure of auto current regulator
* @param[in]      s4_idc_err            An error of IDC
* @param[in,out]  p_s4_ref_v_ctrl       A pointer to a reference voltage
* @param[in]      s4_limit_v            A lower limit of voltage
************************************************************************************************************************/
void mtr_current_pi_ctrl(st_mtr_acr_t *p_st_acr, int32_t s4_idc_err, int32_t *p_s4_ref_v_ctrl, int32_t s4_lim_v)
{
    int32_t s4_ref_v_buff;

    s4_ref_v_buff = mtr_pi_run_acr(&p_st_acr->st_pi, s4_idc_err,
                                   MTR_Q_CURRENT + MTR_Q_ACR_KP - MTR_Q_VOLTAGE,
                                   MTR_Q_CURRENT - MTR_Q_ACR_ERR,
                                   MTR_Q_ACR_KIDT - (MTR_Q_VOLTAGE - MTR_Q_ACR_INTG),
                                   MTR_Q_ACR_ERR - MTR_Q_ACR_INTG);

#if (LESS == MTRCONF_SENSOR_MODE)
    /* overflow limitation */
    s4_ref_v_buff = mtr_limit(s4_ref_v_buff, MTR_MAX_DRIVE_V * 2, s4_lim_v);

#elif (HALL == MTRCONF_SENSOR_MODE)
    /* Limit voltage output */
    if (MTR_MIN_DRIVE_V > s4_lim_v)
    {
        s4_lim_v = MTR_MIN_DRIVE_V;
    }
    s4_ref_v_buff = mtr_limit(s4_ref_v_buff, MTR_MAX_DRIVE_V, s4_lim_v);
#endif

    *p_s4_ref_v_ctrl = s4_ref_v_buff;

} /* End of function mtr_current_pi_ctrl */

/***********************************************************************************************************************
* @fn             mtr_pi_run_acr
* @brief          Current PI control
* @param[in,out]  p_st_pi           A pointer to a structure of PI controller parameters
* @param[in]      s4_err            An error number
* @param[in]      u1_kp_q           A Q-format of PI proportional gain
* @param[in]      u1_q_err_shift    A Shift count of error number
* @param[in]      u1_q_kidt_shift   A Q-format of PI Integral gain
* @param[in]      u1_q_intg_shift   A Shift count of decimal part
* @return         PI output
***********************************************************************************************************************/
static inline int32_t mtr_pi_run_acr(st_mtr_pi_t *p_st_pi, int32_t s4_err,
                                        const uint8_t u1_kp_q, const uint8_t u1_q_err_shift,
                                        const uint8_t u1_q_kidt_shift, const uint8_t u1_q_intg_shift)
{
    int32_t s4_intg;
    int32_t s4_pi_out;

    p_st_pi->s4_decimal += (s4_err >> u1_q_err_shift);

    /* Integral part saturation (symmetric) limiter */
    p_st_pi->s4_decimal = mtr_limit_abs(p_st_pi->s4_decimal, p_st_pi->s4_max_intg);

    s4_intg = (p_st_pi->s4_kidt >> u1_q_kidt_shift)
            * (p_st_pi->s4_decimal >> u1_q_intg_shift);

    s4_pi_out = s4_intg + FIX_mul_rs_sign(p_st_pi->s4_kp, s4_err, u1_kp_q);

    return (s4_pi_out);
} /* End of function mtr_pi_run_acr */
#endif

/***********************************************************************************************************************
* @fn             mtr_carrier_set_pwm
* @brief          Set PWM duties
* @param[in]      u2_pattern    A voltage pattern
* @param[in]      s1_dir        A rotational direction
* @param[in,out]  p_u2_pwm_duty A pointer to an area of the PWM duty
* @param[in]      s4_ref_v_ctrl A reference voltage
* @param[in]      s4_ad_vdc_bit A VDC value
***********************************************************************************************************************/
static inline void mtr_carrier_set_pwm(uint16_t u2_pattern, int8_t s1_dir, uint16_t * p_u2_pwm_duty,
                                       int32_t s4_ref_v_ctrl, int16_t s2_ad_vdc_bit)
{
    three_phase_duty_cycle_t duty_cycle;

    *p_u2_pwm_duty = mtr_duty_calc(s4_ref_v_ctrl, s2_ad_vdc_bit);

    if (MTR_CW == s1_dir) /* CW: Chopping Pattern U->V->W->... */
    {
        /* Set TRD2 register for PWM */
        switch (u2_pattern)
        {
            case MTR_W_PWM_VN_ON:
            case MTR_WP_PWM_VN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = *p_u2_pwm_duty;
                                                                        /* In advance, set the next pattern. */
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = MTR_LOWEST_DUTY_CNT;
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = *p_u2_pwm_duty;
                break;

            case MTR_U_PWM_WN_ON:
            case MTR_UP_PWM_WN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = *p_u2_pwm_duty;
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = *p_u2_pwm_duty;
                                                                        /* In advance, set the next pattern. */
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = MTR_LOWEST_DUTY_CNT;
                break;

            case MTR_V_PWM_UN_ON:
            case MTR_VP_PWM_UN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = MTR_LOWEST_DUTY_CNT;
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = *p_u2_pwm_duty;
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = *p_u2_pwm_duty;
                                                                        /* In advance, set the next pattern. */
                break;

            case MTR_U_PWM_VN_ON:
            case MTR_UP_PWM_VN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = *p_u2_pwm_duty;
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = MTR_LOWEST_DUTY_CNT;
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = MTR_LOWEST_DUTY_CNT;
                                                                        /* In advance, set the next pattern. */
                break;

            case MTR_V_PWM_WN_ON:
            case MTR_VP_PWM_WN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = MTR_LOWEST_DUTY_CNT;
                                                                        /* In advance, set the next pattern. */
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = *p_u2_pwm_duty;
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = MTR_LOWEST_DUTY_CNT;
                break;

            case MTR_W_PWM_UN_ON:
            case MTR_WP_PWM_UN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = MTR_LOWEST_DUTY_CNT;
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = MTR_LOWEST_DUTY_CNT;
                                                                        /* In advance, set the next pattern. */
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = *p_u2_pwm_duty;
                break;

            case MTR_PATTERN_ERROR:
            default:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = (uint16_t)MTR_HALF_CARRIER_CNT;
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = (uint16_t)MTR_HALF_CARRIER_CNT;
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = (uint16_t)MTR_HALF_CARRIER_CNT;
                break;
        }
    }
    else /* CCW: Chopping Pattern W->V->U->... */
    {
        /* Set TRD2 register for PWM */
        switch (u2_pattern)
        {
            case MTR_W_PWM_VN_ON:
            case MTR_WP_PWM_VN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = MTR_LOWEST_DUTY_CNT;
                                                                        /* In advance, set the next pattern. */
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = MTR_LOWEST_DUTY_CNT;
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = *p_u2_pwm_duty;
                break;

            case MTR_U_PWM_WN_ON:
            case MTR_UP_PWM_WN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = *p_u2_pwm_duty;
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = MTR_LOWEST_DUTY_CNT;
                                                                        /* In advance, set the next pattern. */
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = MTR_LOWEST_DUTY_CNT;
                break;

            case MTR_V_PWM_UN_ON:
            case MTR_VP_PWM_UN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = MTR_LOWEST_DUTY_CNT;
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = *p_u2_pwm_duty;
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = MTR_LOWEST_DUTY_CNT;
                                                                        /* In advance, set the next pattern. */
                break;

            case MTR_U_PWM_VN_ON:
            case MTR_UP_PWM_VN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = *p_u2_pwm_duty;
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = MTR_LOWEST_DUTY_CNT;
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = *p_u2_pwm_duty;
                                                                        /* In advance, set the next pattern. */
                break;

            case MTR_V_PWM_WN_ON:
            case MTR_VP_PWM_WN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = *p_u2_pwm_duty;
                                                                        /* In advance, set the next pattern. */
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = *p_u2_pwm_duty;
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = MTR_LOWEST_DUTY_CNT;
                break;

            case MTR_W_PWM_UN_ON:
            case MTR_WP_PWM_UN_ON:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = MTR_LOWEST_DUTY_CNT;
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = *p_u2_pwm_duty;
                                                                        /* In advance, set the next pattern. */
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = *p_u2_pwm_duty;
                break;

            case MTR_PATTERN_ERROR:
            default:
                duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = (uint16_t)MTR_HALF_CARRIER_CNT;
                duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = (uint16_t)MTR_HALF_CARRIER_CNT;
                duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = (uint16_t)MTR_HALF_CARRIER_CNT;
                break;
        }
    }
    R_MTR_GPT_THREE_PHASE_CompMode2_DutyCycleSet(g_three_phase_carrier.p_ctrl, &duty_cycle);
}/* End of function mtr_carrier_set_pwm */


/***********************************************************************************************************************
* @fn             mtr_duty_calc
* @brief          Get duty value
* @param[in]      s4_ref_v      A reference voltage
* @param[in]      s4_ad_vdc_bit A VDC value
* @return           The duty value
***********************************************************************************************************************/
static inline uint16_t mtr_duty_calc(int32_t s4_ref_v, int16_t s2_ad_vdc_bit)
{
    int32_t s4_temp = (MTR_RECIV_COEF / (int32_t)s2_ad_vdc_bit) << MTR_ADC_12BIT;

    s4_temp = FIX_mul_rs(s4_ref_v, s4_temp, MTR_Q_VOLTAGE + MTR_Q_VOLTAGE - MTR_BIT_SFT_NUM_FOR_DUTY_CALC);

#if (COMPLEMENTARY == MTRCONF_PWM_MODE)
    s4_temp = ((int32_t)(MTR_NOT_CARRIER_CNT) * s4_temp) >> MTR_BIT_SFT_NUM_FOR_DUTY_CALC;   /* 15 bits right shift */
#elif (NON_COMPLEMENTARY == MTRCONF_PWM_MODE)
    s4_temp = ((int32_t)(MTR_CARRIER_CNT) * s4_temp) >> MTR_BIT_SFT_NUM_FOR_DUTY_CALC;       /* 15 bits right shift */
#endif
    if (MTR_MAX_DUTY_CNT < s4_temp)
    {
        s4_temp = MTR_MAX_DUTY_CNT;
    }
    s4_temp = (int32_t)MTR_MAX_DUTY_CNT - s4_temp;

    if ((s4_temp == (int32_t)MTR_MAX_DUTY_CNT) && (0 != s4_ref_v))
    {
        --s4_temp;
    }

    return ((uint16_t)s4_temp);
} /* End of function mtr_duty_calc */

/**********************************************************************************************************************
* @fn             mtr_carrier_startup_sequence
* @brief          Do processes while drive is not started
***********************************************************************************************************************/
static inline void mtr_carrier_startup_sequence(void)
{
    /* Calibrate A/D offset */
    if ((MTR_OFFSET_CALC_EXE == g_st_120.u1_state_drive) &&
        (MTR_CLR             == g_st_120.u1_flg_offset_end))
    {
        /* Calibrate offset */
        g_st_120.u1_flg_offset_end = mtr_calib_current_offset_dc(&g_st_120);
    }
    else
    {
        __NOP(); /* do nothing */
    }

    R_MTR_SetIcs();
} /* End of function mtr_carrier_startup_sequence */

/***********************************************************************************************************************
* @brief          Get the absolute value
* @param[in]      s4_value   A target value
* @return           the absolute value
***********************************************************************************************************************/
static uint8_t mtr_calib_current_offset_dc(st_mtr_120_control_t *p_st_120)
{
    uint8_t  u1_temp      = MTR_CLR;

    /* Calculate offset current values */
    if ((p_st_120->st_carrier.u4_offset_calc_cnt + MTR_OFFSET_CALC_ST_WAIT_CNT) <= p_st_120->st_carrier.u4_offset_sample_cnt)
    {
        /* Calculate average of current offset */
        p_st_120->st_carrier.u4_ad_offset_idc =  ((uint16_t)((p_st_120->st_carrier.u4_ad_offset_idc_sum) /
                                                 (uint32_t)p_st_120->st_carrier.u4_offset_calc_cnt));

        u1_temp = MTR_SET;
    }
    else
    {
        if (MTR_OFFSET_CALC_ST_WAIT_CNT <= p_st_120->st_carrier.u4_offset_sample_cnt)
        {

            R_MTR_ADC_WaitConversion(g_adc0.p_ctrl, ADC_CONVERT_TIMEOUT);
            R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_IDC, (uint16_t * const)&p_st_120->st_carrier.s2_ad_idc_bit);

            p_st_120->st_carrier.u4_ad_offset_idc_sum += (uint32_t)p_st_120->st_carrier.s2_ad_idc_bit;
        }
        p_st_120->st_carrier.u4_offset_sample_cnt++;
    }

    return (u1_temp);
} /* End of function mtr_calib_current_offset_dc */

/***********************************************************************************************************************
* @fn             mtr_abs
* @brief          Get the absolute value
* @param[in]      s4_value   A target value
* @return           the absolute value
***********************************************************************************************************************/
static inline int32_t mtr_abs(int32_t s4_value)
{
    return ((s4_value ^ (s4_value >> 31)) - (s4_value >> 31));
} /* End of function mtr_abs */

#if (CURRENT == MTRCONF_CONTROL_MODE)
/***********************************************************************************************************************
* @fn             mtr_limit
* @brief          Limit a value between maximum and minimum limits
* @param[in]      s4_value   A target value
* @param[in]      s4_max     A maximum limit
* @param[in]      s4_min     A minimum limit
* @return           The limited value
***********************************************************************************************************************/
static inline int32_t mtr_limit(int32_t s4_value, int32_t s4_max, int32_t s4_min)
{

    int32_t s4_temp;

    s4_temp = s4_value;

    if (s4_value > s4_max)
    {
        /* Max limit */
        s4_temp = s4_max;
    }
    else if (s4_value < s4_min)
    {
        /* Minimum limit */
        s4_temp = s4_min;
    }

    return (s4_temp);
} /* End of function mtr_limit */

/***********************************************************************************************************************
* @fn             mtr_limit_abs
* @brief          Limit a value between absolute limits
* @param[in]      s4_value         A target value
* @param[in]      s4_limit_value   An absolute limit
* @return           The limited value
***********************************************************************************************************************/
static inline int32_t mtr_limit_abs(int32_t s4_value, int32_t s4_limit_value)
{
    if (s4_value > s4_limit_value)
    {
        return (s4_limit_value);
    }
    else if (s4_value < (-s4_limit_value))
    {
        return (-s4_limit_value);
    }
    else
    {
        return (s4_value);
    }
} /* End of function mtr_limit_abs */
#endif

/***********************************************************************************************************************
* @fn             mtr_delay_interrupt
* @brief          callback for  interrupt of 30-degrees lag from zero-cross
* @param[in]      p_args  Callback argument
***********************************************************************************************************************/
void mtr_delay_interrupt(timer_callback_args_t *p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);

#if (LESS == MTRCONF_SENSOR_MODE)
    __enable_irq();

    if (MTR_DRIVE_CLL == (g_st_120.u1_state_ctrl_mode & MTR_DRIVE_CLL))
    {
        /* Set voltage pattern */
        mtr_set_chopping_pattern(g_st_120.st_carrier.st_less_carrier.u1_bemf_signal);
    }

    /* Output voltage pattern */
    R_MTR_GPT_THREE_PHASE_PatternOutput(g_three_phase_carrier.p_ctrl, g_st_120.u2_v_pattern, &g_st_120.u1_flg_pattern_error);
    g_u1_flag_delay = MTR_SET;
#endif
} /* End of function mtr_delay_interrupt */

#if (LESS == MTRCONF_SENSOR_MODE)
/***********************************************************************************************************************
* @fn             mtr_carrier_voltage_get
* @brief          Get 3-phase and neutral voltages
* @param[out]     p_s2_ad_vu     A pointer to an area of U-phase current
* @param[out]     p_s2_ad_vv     A pointer to an area of V-phase current
* @param[out]     p_s2_ad_vw     A pointer to an area of W-phase current
* @param[out]     p_s2_ad_vn     A pointer to an area of neutral current
***********************************************************************************************************************/
static inline void mtr_carrier_voltage_get(int16_t *p_s2_ad_vu, int16_t *p_s2_ad_vv, int16_t *p_s2_ad_vw,
                                            int16_t *p_s2_ad_vn)
{
    /* Get A/D converted results based on converted channel */
    R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_VU, (uint16_t*)p_s2_ad_vu);
    R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_VV, (uint16_t*)p_s2_ad_vv);
    R_ADC_Read(g_adc0.p_ctrl, R_MTR_ADCR_VW, (uint16_t*)p_s2_ad_vw);

    /* Get non-energized phase voltage */
    switch (g_st_120.u2_v_pattern)
    {
        case MTR_U_PWM_VN_ON:
        case MTR_UP_PWM_VN_ON:
        case MTR_U_PWM_WN_ON:
        case MTR_UP_PWM_WN_ON:
            *p_s2_ad_vn = *p_s2_ad_vu >> 1;
            break;

        case MTR_V_PWM_UN_ON:
        case MTR_VP_PWM_UN_ON:
        case MTR_V_PWM_WN_ON:
        case MTR_VP_PWM_WN_ON:
            *p_s2_ad_vn = *p_s2_ad_vv >> 1;
            break;

        case MTR_W_PWM_UN_ON:
        case MTR_WP_PWM_UN_ON:
        case MTR_W_PWM_VN_ON:
        case MTR_WP_PWM_VN_ON:
            *p_s2_ad_vn = *p_s2_ad_vw >> 1;
            break;

        default:
            /* Do nothing */
            break;
    }
} /* End of function mtr_carrier_voltage_get */

/***********************************************************************************************************************
* @fn             mtr_detect_zerocross
* @brief          Generate a BEMF signal when zero-cross detected
* @param[in,out]  p_st_less         A pointer to a structure of sensor-less control
* @param[in]      s2_ad_vn_offset   A neutral voltage offset
* @param[in,out]  p_st_ol2cl        A pointer to parameters of a transition from open-loop drive mode
*                                   to sensor-less control one
* @param[out]     p_u4_cnt_timeout  A pointer to a clock count for timeout
* @param[in]      s1_dir            A rotational direction
* @param[in]      u2_v_pattern      A voltage pattern
* @return           The generated BEMF signal
***********************************************************************************************************************/
static inline uint8_t mtr_detect_zerocross(st_mtr_sensorless_carrier_t *p_st_less, int16_t s2_ad_vn_offset,
                                st_mtr_ol2cl_t *p_st_ol2cl,
                                uint32_t *p_u4_cnt_timeout, int8_t s1_dir, uint16_t u2_v_pattern)
{
    uint8_t  u1_temp_signal;
    uint32_t u4_temp_cnt;

    p_st_less->u1_pre_bemf_signal = p_st_less->u1_bemf_signal;      /* Keep previous pattern */
    u1_temp_signal = 0;

    if (MTR_CW == s1_dir)
    {
        switch (u2_v_pattern)
        {
             /* ascending non-energized phase voltage */
             case MTR_W_PWM_VN_ON:    /* 18 */
             case MTR_U_PWM_WN_ON:    /* 14 */
             case MTR_V_PWM_UN_ON:    /* 15 */
             case MTR_WP_PWM_VN_ON:   /* 6 */
             case MTR_UP_PWM_WN_ON:   /* 2 */
             case MTR_VP_PWM_UN_ON:   /* 3 */
                     p_st_less->s2_ad_vn_ctrl = (int16_t)(p_st_less->s2_ad_vn - s2_ad_vn_offset);
                     break;

             /* descending non-energized phase voltage */
             case MTR_U_PWM_VN_ON:    /* 13 */
             case MTR_V_PWM_WN_ON:    /* 16 */
             case MTR_W_PWM_UN_ON:    /* 17 */
             case MTR_UP_PWM_VN_ON:   /* 1 */
             case MTR_VP_PWM_WN_ON:   /* 4 */
             case MTR_WP_PWM_UN_ON:   /* 5 */
                 p_st_less->s2_ad_vn_ctrl = (int16_t)(p_st_less->s2_ad_vn + s2_ad_vn_offset);
                 break;

             default:
                 /* do nothing */
                 break;
        }
    }

    else if (MTR_CCW == s1_dir)
    {
        switch (u2_v_pattern)
        {
            /* ascending non-energized phase voltage */
            case MTR_U_PWM_VN_ON:    /* 13 */
            case MTR_W_PWM_UN_ON:    /* 17 */
            case MTR_V_PWM_WN_ON:    /* 16 */
            case MTR_WP_PWM_UN_ON:   /* 5 */
            case MTR_VP_PWM_WN_ON:   /* 4 */
            case MTR_UP_PWM_VN_ON:   /* 1 */
                p_st_less->s2_ad_vn_ctrl = (int16_t)(p_st_less->s2_ad_vn - s2_ad_vn_offset);
                break;

            /* descending non-energized phase voltage */
            case MTR_U_PWM_WN_ON:    /* 14 */
            case MTR_W_PWM_VN_ON:    /* 18 */
            case MTR_V_PWM_UN_ON:    /* 15 */
            case MTR_WP_PWM_VN_ON:   /* 6 */
            case MTR_UP_PWM_WN_ON:   /* 2 */
            case MTR_VP_PWM_UN_ON:   /* 3 */
                p_st_less->s2_ad_vn_ctrl = (int16_t)(p_st_less->s2_ad_vn + s2_ad_vn_offset);
                break;

            default:
                /* do nothing */
                break;
        }
    }

    /*=========================================================*/
    /*     Compare each voltage with neutral voltage           */
    /*                                                         */
    /*     g_st_120.u1_bemf_signal b7:b3 - don't use           */
    /*                      b2    - U phase                    */
    /*                      b1    - V phase                    */
    /*                      b0    - W phase                    */
    /*=========================================================*/
    if (p_st_less->s2_ad_vu > p_st_less->s2_ad_vn_ctrl)             /* U phase */
    {
        u1_temp_signal |= 0x04;
    }
    else
    {
        u1_temp_signal &= 0xFB; //~0x04U;
    }

    if (p_st_less->s2_ad_vv > p_st_less->s2_ad_vn_ctrl)             /* V phase */
    {
        u1_temp_signal |= 0x02;
    }
    else
    {
        u1_temp_signal &= 0xFD; //~0x02U;
    }

    if (p_st_less->s2_ad_vw > p_st_less->s2_ad_vn_ctrl)             /* V phase */
    {
        u1_temp_signal |= 0x01;
    }
    else
    {
        u1_temp_signal &= 0xFE; //~0x01;
    }

    /* Filtering BEMF signal at transition from open-loop drive to sensor-less control */
    if (MTR_SET == p_st_less->u1_flg_pattern_change_ol || MTR_SET == p_st_ol2cl->u1_flg_change)
    {
        /* Filter bemf-signal during zero-cross detection at transition from open-loop drive to PI control*/
        u1_temp_signal = R_MTR_BemfSignalFilter(p_st_ol2cl, p_st_less->u4_speed_cnt_ol,
                                                &(p_st_less->u1_pre_bemf_signal),
                                                u1_temp_signal, p_st_less->u1_flg_pattern_change_ol);
    }

    if (g_st_120.u4_pre_speed_timer_cnt > g_st_120.u4_speed_timer_cnt)
    {
        u4_temp_cnt = g_st_120.u4_pre_speed_timer_cnt - g_st_120.u4_speed_timer_cnt;
    }
    else
    {
        u4_temp_cnt = (MTR_SPEED_CNT_MAX - g_st_120.u4_speed_timer_cnt) + g_st_120.u4_pre_speed_timer_cnt;
    }

    if (u1_temp_signal != p_st_less->u1_pre_bemf_signal)            /* Check signal change */
    {
        /* When timer count exceeds counts for zero-cross detection */
        if (u4_temp_cnt > p_st_less->u4_zerocross_filter_cnt)
        {
            *p_u4_cnt_timeout                = 0;                   /* Clear counter for timeout error */
            u4_temp_cnt                      = 0;
            p_st_less->u1_flg_pattern_change = MTR_SET;

            if (MTR_CLR == p_st_ol2cl->u1_flg_change_speed)
            {
                p_st_less->u1_flg_pattern_change_ol = MTR_CLR;
            }
        }
        else
        {
            u1_temp_signal = p_st_less->u1_pre_bemf_signal;         /* Invalid changed signal */
        }
    }

    return (u1_temp_signal);
} /* End of function mtr_detect_zerocross */


/***********************************************************************************************************************
* @fn             mtr_drive_openloop_less
* @brief          Do forced voltage pattern control for open-loop drive mode
************************************************************************************************************************/
static inline void mtr_drive_openloop_less(void)
{
    /* Check divide by zero */
    if (0 != g_st_120.s4_ref_speed_ctrl)
    {
        uint32_t u4_speed_ctrl = (uint32_t)mtr_abs(g_st_120.s4_ref_speed_ctrl) >> (MTR_Q_AFREQ-MTR_SPEED_CALC_BASE_SHIFT);

        /* Calculate period for 60 degrees with rounding formula at open-loop drive */
        g_st_120.st_carrier.st_less_carrier.u4_pattern_period_ol =
                                    (uint32_t)(((uint32_t)MTR_OL_SPEED_CALC_BASE
                                            + (u4_speed_ctrl >> 1)) / u4_speed_ctrl);

        /* During open-loop drive, voltage pattern is changed depending on count */
        g_st_120.st_carrier.st_less_carrier.u4_speed_cnt_ol++;
        if (g_st_120.st_carrier.st_less_carrier.u4_speed_cnt_ol
                > g_st_120.st_carrier.st_less_carrier.u4_pattern_period_ol)
        {
            g_st_120.u4_cnt_timeout = 0;
            g_st_120.st_carrier.st_less_carrier.u4_speed_cnt_ol = 0;

            /* Set chopping pattern for open-loop drive */
            g_st_120.st_carrier.st_less_carrier.u2_v_pattern_ol = mtr_openloop_pattern_set();
            mtr_set_chopping_pattern(g_st_120.st_carrier.st_less_carrier.u2_v_pattern_ol);
            mtr_start_delay_timer(0);

            if ((MTR_CLR == g_st_120.st_less_control.st_ol2cl.u1_flg_change) &&
                (MTR_CLR == g_st_120.st_less_control.st_ol2cl.u1_flg_change_speed))
            {
               g_st_120.st_carrier.st_less_carrier.u1_flg_pattern_change_ol = MTR_SET;
            }
            else
            {
                /* do nothing */
            }

            g_st_120.st_carrier.st_less_carrier.u4_zerocross_filter_cnt =
                    ((g_st_120.st_carrier.st_less_carrier.u4_zerocross_filter_cnt << 1) +
                            g_st_120.st_carrier.st_less_carrier.u4_zerocross_filter_cnt) >> 2;

#if(CURRENT == MTRCONF_CONTROL_MODE)
            if (MTR_SET == g_st_120.st_less_control.st_ol2cl.u1_flg_change_speed)
            {
                g_st_120.st_less_control.st_ol2cl.u1_flg_change = MTR_SET;
            }
#endif
        }

    }
} /* End of function mtr_drive_openloop_less */

/***********************************************************************************************************************
* @fn             mtr_set_angle_shift
* @brief          Set an adjust shift value for pattern changed
***********************************************************************************************************************/
static inline void mtr_set_angle_shift(void)
{
    uint32_t u4_temp_delay_cnt = 0;

    /* Calculate count of 30 degrees */
    switch (g_st_120.u1_v_pattern_ring_buff)
    {
        case 0:
            u4_temp_delay_cnt = (g_st_120.u4_timer_cnt_buff[5] + g_st_120.u4_timer_cnt_buff[4]) >> 2;
            break;

        case 1:
            u4_temp_delay_cnt = (g_st_120.u4_timer_cnt_buff[0] + g_st_120.u4_timer_cnt_buff[5]) >> 2;
            break;

        case 2:
            u4_temp_delay_cnt = (g_st_120.u4_timer_cnt_buff[1] + g_st_120.u4_timer_cnt_buff[0]) >> 2;
            break;

        case 3:
            u4_temp_delay_cnt = (g_st_120.u4_timer_cnt_buff[2] + g_st_120.u4_timer_cnt_buff[1]) >> 2;
            break;

        case 4:
            u4_temp_delay_cnt = (g_st_120.u4_timer_cnt_buff[3] + g_st_120.u4_timer_cnt_buff[2]) >> 2;
            break;

        case 5:
            u4_temp_delay_cnt = (g_st_120.u4_timer_cnt_buff[4] + g_st_120.u4_timer_cnt_buff[3]) >> 2;
            break;

        default:
            /* Do nothing */
            break;
    }

    /* Delay timer count */
    g_st_120.st_carrier.st_less_carrier.u4_bemf_delay
                    = (uint32_t)((int32_t)u4_temp_delay_cnt + g_st_120.st_less_control.s4_angle_shift_adjust);
    /* Calculate timer count to filter spike noise for zerocross detection (45 degrees) */
    g_st_120.st_carrier.st_less_carrier.u4_zerocross_filter_cnt
                    = u4_temp_delay_cnt + (u4_temp_delay_cnt >> 1);
} /* End of function mtr_set_angle_shift */

/***********************************************************************************************************************
* @fn             mtr_start_delay_timer
* @brief          Start a delay timer
* @param[in]      u4_delay_cnt      A clock count for a delay timer
***********************************************************************************************************************/
static inline void mtr_start_delay_timer(uint32_t u4_delay_cnt)
{
    R_AGT_PeriodSet(g_timer_delay.p_ctrl, u4_delay_cnt+1);
    R_AGT_Start(g_timer_delay.p_ctrl);
} /* End of function mtr_start_delay_timer */

/***********************************************************************************************************************
* @fn             mtr_openloop_pattern_set
* @brief          Set a forced voltage pattern for open-loop drive mode
* @return           The voltage pattern
***********************************************************************************************************************/
static inline uint16_t mtr_openloop_pattern_set(void)
{
    uint16_t u2_pattern;

    /* Set ring buffer  */
    g_st_120.st_carrier.st_less_carrier.u2_v_pattern_num_ol++;
    if (MTR_PATTERN_NUM < g_st_120.st_carrier.st_less_carrier.u2_v_pattern_num_ol)
    {
        g_st_120.st_carrier.st_less_carrier.u2_v_pattern_num_ol = 1;
    }

    if (MTR_CW == g_st_120.s1_dir)
    {
        u2_pattern = g_u2_ol_v_pattern_table_CW[g_st_120.st_carrier.st_less_carrier.u2_v_pattern_num_ol];
    }
    else
    {
        u2_pattern = g_u2_ol_v_pattern_table_CCW[g_st_120.st_carrier.st_less_carrier.u2_v_pattern_num_ol];
    }

    return (u2_pattern);
} /* End of function mtr_openloop_pattern_set */
#endif

#if (HALL == MTRCONF_SENSOR_MODE)
/***********************************************************************************************************************
* @fn             mtr_hall_u_interrupt
* @brief          callback for U phase Hall sensor signal interrupt
***********************************************************************************************************************/
void mtr_hall_u_interrupt(external_irq_callback_args_t *p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);

    mtr_hall_signal_process();
__enable_irq();
} /* End of function mtr_hall_u_interrupt */

/***********************************************************************************************************************
* @fn             mtr_hall_v_interrupt
* @brief          callback for V phase Hall sensor signal interrupt
***********************************************************************************************************************/
void mtr_hall_v_interrupt(external_irq_callback_args_t *p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);

    mtr_hall_signal_process();
__enable_irq();
} /* End of function mtr_hall_v_interrupt */

/***********************************************************************************************************************
* @fn             mtr_hall_w_interrupt
* @brief          callback for W phase Hall sensor signal interrupt
***********************************************************************************************************************/
void mtr_hall_w_interrupt(external_irq_callback_args_t *p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);

    mtr_hall_signal_process();
__enable_irq();
} /* End of function mtr_hall_w_interrupt */

/***********************************************************************************************************************
* @fn             mtr_hall_signal_process
* @brief          Process a hall signal
***********************************************************************************************************************/
static void mtr_hall_signal_process(void)
{
    R_MTR_AGT_ReadTimerCount_32Bit(g_timer_rotation_speed.p_ctrl,  &g_st_120.u4_speed_timer_cnt);

    if (MTR_DRIVE == g_st_120.u1_state_drive)
    {
        mtr_hall_signal_set();                              /* Set voltage pattern */

        if (MTR_CLR == g_st_120.st_speed.st_hall_speed.u1_flg_1st_interrupt)
        {
            mtr_speed_calc();                               /* Speed calculation */
        }
        else
        {
            g_st_120.st_speed.st_hall_speed.u1_flg_1st_interrupt = MTR_CLR;
            R_MTR_AGT_ReadTimerCount_32Bit(g_timer_rotation_speed.p_ctrl,  &g_st_120.u4_pre_speed_timer_cnt);
        }
    }

    /* Timeout error check */
    if ((MTR_DRIVE == g_st_120.u1_state_drive) &&
        (MTR_SPEED_ZERO_CONST != g_st_120.u2_state_ref_speed))
    {
        g_st_120.u4_cnt_timeout = 0;                         /* Timeout counter reset */
    }
} /* End of function mtr_hall_signal_process */

/***********************************************************************************************************************
* @fn             mtr_hall_signal_set
* @brief          Set a voltage pattern from a hall signal
***********************************************************************************************************************/
static inline void mtr_hall_signal_set(void)
{
    bsp_io_level_t u_level = BSP_IO_LEVEL_LOW;
    bsp_io_level_t v_level = BSP_IO_LEVEL_LOW;
    bsp_io_level_t w_level = BSP_IO_LEVEL_LOW;
    uint8_t u_value;
    uint8_t v_value;
    uint8_t w_value;

    /*** Get Hall signal ***/
    R_IOPORT_PinRead(g_ioport.p_ctrl, MTR_PORT_PIN_HALL_U, &u_level);
    R_IOPORT_PinRead(g_ioport.p_ctrl, MTR_PORT_PIN_HALL_V, &v_level);
    R_IOPORT_PinRead(g_ioport.p_ctrl, MTR_PORT_PIN_HALL_W, &w_level);
    u_value = (BSP_IO_LEVEL_LOW == u_level) ? MTR_HALL_SIGNAL_L_POLARITY : MTR_HALL_SIGNAL_H_POLARITY;
    v_value = (BSP_IO_LEVEL_LOW == v_level) ? MTR_HALL_SIGNAL_L_POLARITY : MTR_HALL_SIGNAL_H_POLARITY;
    w_value = (BSP_IO_LEVEL_LOW == w_level) ? MTR_HALL_SIGNAL_L_POLARITY : MTR_HALL_SIGNAL_H_POLARITY;
    g_st_120.st_speed.st_hall_speed.u2_hall_signal  = (u_value << 2) | (v_value << 1) | w_value;

    /*** Set voltage pattern ***/
    mtr_set_chopping_pattern(g_st_120.st_speed.st_hall_speed.u2_hall_signal);

    /* Output voltage pattern */
    R_MTR_GPT_THREE_PHASE_PatternOutput(g_three_phase_carrier.p_ctrl, g_st_120.u2_v_pattern,
                                        &g_st_120.u1_flg_pattern_error);
} /* End of function mtr_hall_signal_set */
#endif

/***********************************************************************************************************************
* @fn             mtr_speed_calc
* @brief          Calculate speed
***********************************************************************************************************************/
static inline void mtr_speed_calc(void)
{
    uint32_t u4_temp;
    int32_t  s4_speed = g_st_120.s4_speed;

    if (g_st_120.u4_pre_speed_timer_cnt > g_st_120.u4_speed_timer_cnt)
    {
        u4_temp = g_st_120.u4_pre_speed_timer_cnt - g_st_120.u4_speed_timer_cnt;
    }
    else
    {
        u4_temp = (MTR_SPEED_CNT_MAX - g_st_120.u4_speed_timer_cnt) + g_st_120.u4_pre_speed_timer_cnt;
    }

    /* Speed calculation */
    if (0 == g_st_120.u1_first_rotation_cnt)
    {
        /* Calculate speed from timer count for one rotation with rounding formula (electric angle) */
        g_st_120.u4_timer_cnt_sum
                          -= g_st_120.u4_timer_cnt_buff[g_st_120.u1_v_pattern_ring_buff];
        g_st_120.u4_timer_cnt_buff[g_st_120.u1_v_pattern_ring_buff]
                           = u4_temp;
        g_st_120.u4_timer_cnt_sum
                          += u4_temp;
        s4_speed           = (int32_t)(((uint32_t)MTR_SPEED_CALC_BASE +
                                    (g_st_120.u4_timer_cnt_sum >> 1)) / g_st_120.u4_timer_cnt_sum);
    }
    else
    {
        /* Calculate speed for first rotation with rounding formula (electric angle) */
        switch (g_st_120.u1_first_rotation_cnt)
        {
            case 6:           /* 60 degrees */
                g_st_120.u4_timer_cnt_buff[0] = u4_temp;
                g_st_120.u4_timer_cnt_sum     = u4_temp;
                s4_speed                      = (int32_t)(((uint32_t)MTR_SPEED_CALC_BASE_1ST +
                                                    (g_st_120.u4_timer_cnt_sum >> 1)) / g_st_120.u4_timer_cnt_sum);
                g_st_120.u1_first_rotation_cnt--;
                break;

            case 5:           /* 120 degrees */
                g_st_120.u4_timer_cnt_buff[1] = u4_temp;
                g_st_120.u4_timer_cnt_sum    += u4_temp;
                s4_speed                      = (int32_t)(((uint32_t)MTR_SPEED_CALC_BASE_2ND +
                                                    (g_st_120.u4_timer_cnt_sum >> 1)) / g_st_120.u4_timer_cnt_sum);
                g_st_120.u1_first_rotation_cnt--;
                break;

            case 4:           /* 180 degrees */
                g_st_120.u4_timer_cnt_buff[2] = u4_temp;
                g_st_120.u4_timer_cnt_sum    += u4_temp;
                s4_speed                      = (int32_t)(((uint32_t)MTR_SPEED_CALC_BASE_3RD +
                                                    (g_st_120.u4_timer_cnt_sum >> 1)) / g_st_120.u4_timer_cnt_sum);
                g_st_120.u1_first_rotation_cnt--;
                break;

            case 3:           /* 240 degrees */
                g_st_120.u4_timer_cnt_buff[3] = u4_temp;
                g_st_120.u4_timer_cnt_sum    += u4_temp;
                s4_speed                      = (int32_t)(((uint32_t)MTR_SPEED_CALC_BASE_4TH +
                                                    (g_st_120.u4_timer_cnt_sum >> 1)) / g_st_120.u4_timer_cnt_sum);
                g_st_120.u1_first_rotation_cnt--;
                break;

            case 2:           /* 300 degrees */
                g_st_120.u4_timer_cnt_buff[4] = u4_temp;
                g_st_120.u4_timer_cnt_sum    += u4_temp;
                s4_speed                      = (int32_t)(((uint32_t)MTR_SPEED_CALC_BASE_5TH +
                                                    (g_st_120.u4_timer_cnt_sum >> 1)) / g_st_120.u4_timer_cnt_sum);
                g_st_120.u1_first_rotation_cnt--;
                break;

            case 1:           /* 360 degrees */
                g_st_120.u4_timer_cnt_buff[5] = u4_temp;
                g_st_120.u4_timer_cnt_sum    += u4_temp;
                s4_speed                      = (int32_t)(((uint32_t)MTR_SPEED_CALC_BASE +
                                                    (g_st_120.u4_timer_cnt_sum >> 1)) / g_st_120.u4_timer_cnt_sum);
                g_st_120.u1_first_rotation_cnt--;
                break;

            default:
            /* Do nothing */
                break;
        }
    }

    /* Set ring buffer */
    g_st_120.u1_v_pattern_ring_buff++;
    if (MTR_TIMER_CNT_BUFFER_SIZE <= g_st_120.u1_v_pattern_ring_buff)
    {
        g_st_120.u1_v_pattern_ring_buff = 0;
    }

    /* When CCW, speed is set to negative value */
    g_st_120.s4_speed = g_st_120.s1_dir * (mtr_abs(s4_speed) << (MTR_Q_AFREQ - MTR_SPEED_CALC_BASE_SHIFT));

    g_st_120.u4_pre_speed_timer_cnt = g_st_120.u4_speed_timer_cnt;     /* Keep timer counter value */
} /* End of function mtr_speed_calc */

/***********************************************************************************************************************
* @fn             mtr_set_chopping_pattern
* @brief          Set a chopping pattern from a voltage pattern
* @param[in]      u2_pattern    A voltage pattern
***********************************************************************************************************************/
static inline void mtr_set_chopping_pattern(uint16_t u2_pattern)
{
    /*** Set voltage pattern ***/
    if (MTR_CW == g_st_120.s1_dir)              /* Check rotation direction */
    {
        switch (u2_pattern)
        {
            case MTR_PATTERN_CW_W_V:            /* From W phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[0];
                break;

            case MTR_PATTERN_CW_U_V:            /* From U phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[1];
                break;

            case MTR_PATTERN_CW_U_W:            /* From U phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[2];
                break;

            case MTR_PATTERN_CW_V_W:            /* From V phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[3];
                break;

            case MTR_PATTERN_CW_V_U:            /* From V phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[4];
                break;

            case MTR_PATTERN_CW_W_U:            /* From W phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[5];
                break;

            default:                            /* Hall signal pattern error */
                g_st_120.u2_v_pattern = MTR_PATTERN_ERROR;
                break;
        }
    }
    else if (MTR_CCW == g_st_120.s1_dir)         /* Check rotation direction */
    {
        switch (u2_pattern)
        {
            case MTR_PATTERN_CCW_W_V:           /* From W phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[0];
                break;

            case MTR_PATTERN_CCW_W_U:           /* From W phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[1];
                break;

            case MTR_PATTERN_CCW_V_U:           /* From V phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[2];
                break;

            case MTR_PATTERN_CCW_V_W:           /* From V phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[3];
                break;

            case MTR_PATTERN_CCW_U_W:           /* From U phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[4];
                break;

            case MTR_PATTERN_CCW_U_V:           /* From U phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[5];
                break;

            default:                            /* Hall signal pattern error */
                g_st_120.u2_v_pattern = MTR_PATTERN_ERROR;
                break;
        }
    }
    else
    {
        /* Do nothing */
    }
} /* End of function mtr_set_chopping_pattern */

