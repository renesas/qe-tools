/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_driver.c
* Description : The processing of accessing driver
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_driver.h"
#include "r_mtr_config.h"
#include "rm_mtr_common.h"
#include "r_mtr_board.h"
#include "rm_mtr_120.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "r_mtr_ra2t1.h"
#include "rm_mtr_ctrl_gain.h"

#include "hal_data.h"
#include "r_mtr_GPT_THREE_PHASE.h"

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
uint8_t g_u1_trig_enable_write;                   /* ICS write enable flag */
st_mtr_design_parameter_t g_st_ctrl_params;      /* Control parameters */
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
st_mtr_ctrl_gain_voltage_mode_t g_st_gain_v_buf; /* Input PI gains for voltage mode */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
st_mtr_ctrl_gain_current_mode_t g_st_gain_i_buf; /* Input PI gains for current mode  */
#endif

extern st_mtr_120_control_t g_st_120;            /* Structure for control */
extern st_mtr_ctrl_input_t st_ics;               /* Structure for ICS input */


/***********************************************************************************************************************
Private variables definitions
***********************************************************************************************************************/
/* Set control variables */

static uint8_t s_state_transition_table[MTR_SIZE_EVENT][MTR_SIZE_STATE] = {
/* Event / State         0:MTR_MODE_INIT, 1:MTR_MODE_DRIVE,  2:MTR_MODE_STOP */
/* 0:MTR_EVENT_STOP  */{   MTR_MODE_STOP,   MTR_MODE_STOP,     MTR_MODE_STOP  },
/* 1:MTR_EVENT_DRIVE */{   MTR_MODE_INIT,   MTR_MODE_DRIVE,    MTR_MODE_DRIVE },
/* 2:MTR_EVENT_ERROR */{   MTR_MODE_STOP,   MTR_MODE_STOP,     MTR_MODE_STOP  },
/* 3:MTR_EVENT_RESET */{   MTR_MODE_INIT,   MTR_MODE_DRIVE,    MTR_MODE_INIT  },};

static mtr_action_t s_action_table[MTR_SIZE_EVENT][MTR_SIZE_STATE] = {
/* Event / State         0:MTR_MODE_INIT,     1:MTR_MODE_DRIVE,  2:MTR_MODE_STOP */
/* 0:MTR_EVENT_STOP  */{   mtr_act_stop,       mtr_act_stop,       mtr_act_none  },
/* 1:MTR_EVENT_DRIVE */{   mtr_act_none,       mtr_act_none,       mtr_act_drive },
/* 2:MTR_EVENT_ERROR */{   mtr_act_error,      mtr_act_error,      mtr_act_error },
/* 3:MTR_EVENT_RESET */{   mtr_act_init,       mtr_act_none,       mtr_act_init  },};

/***********************************************************************************************************************
* Global functions definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* @fn             mtr_statemachine_init
* @brief          Initialize state machine for motor drive system
* @param[in,out]  p_state_machine   A pointer to the state machine structure
***********************************************************************************************************************/
void mtr_statemachine_init(st_mtr_statemachine_t *p_state_machine)
{
    mtr_statemachine_reset(p_state_machine);
} /* End of function mtr_statemachine_init */

/***********************************************************************************************************************
* @fn             mtr_statemachine_reset
* @brief          Reset state machine
* @param[out]     p_state_machine   A pointer to the state machine structure
***********************************************************************************************************************/
void mtr_statemachine_reset(st_mtr_statemachine_t *p_state_machine)
{
    p_state_machine->u1_status          = MTR_MODE_INIT;
    p_state_machine->u1_status_next     = MTR_MODE_INIT;
    p_state_machine->u2_status_error    = MTR_STATEMACHINE_ERROR_NONE;
} /* End of function mtr_statemachine_reset */

/***********************************************************************************************************************
* @fn             mtr_statemachine_event
* @brief          Perform state transition and execute corresponding action when
*                 specified event happen
* @param[in,out]  p_state_machine   A pointer to the state machine structure
* @param[in]      p_object          A pointer to parameters passed to the action handler
* @param[in]      u1_event          an event index to be executed
*                       MTR_EVENT_STOP     Stop the motor drive system
*                       MTR_EVENT_DRIVE    Activate the motor drive system
*                       MTR_EVENT_ERROR    Throw an error and stop driving
*                       MTR_EVENT_RESET    Reset the configurations of motor drive system
* @return         An error status
***********************************************************************************************************************/
uint8_t mtr_statemachine_event(st_mtr_statemachine_t *p_state_machine, void *p_object, uint8_t u1_event)
{
    mtr_action_t func_action;
    uint8_t      action_ret;

    /* Check if accessing state transition table out of bound */
    if (MTR_SIZE_EVENT <= u1_event)
    {
        /* Event is out of bound */
        u1_event = MTR_EVENT_ERROR;

        p_state_machine->u2_status_error |= MTR_STATEMACHINE_ERROR_EVENTOUTBOUND;
    }
    if (MTR_SIZE_STATE <= p_state_machine->u1_status)
    {
        /* State is out of bound */
        u1_event = MTR_EVENT_ERROR;

        p_state_machine->u1_status        = MTR_MODE_INIT;
        p_state_machine->u2_status_error |= MTR_STATEMACHINE_ERROR_STATEOUTBOUND;
    }

    /*
     * u1_current_event : Event happening
     * u1_status        : Current status
     * u1_status_next   : Status after action executed
     */
    p_state_machine->u2_crnt_event = u1_event;
    p_state_machine->u1_status_next   = s_state_transition_table[u1_event][p_state_machine->u1_status];

    /* Get action function from action table and execute action */
    func_action = s_action_table[u1_event][p_state_machine->u1_status];
    action_ret  = func_action(p_state_machine, p_object);

    /* If return value is not zero, set the Action Exception flag */
    if (action_ret)
    {
        p_state_machine->u2_status_error |= MTR_STATEMACHINE_ERROR_ACTIONEXCEPTION;
    }
    p_state_machine->u1_status = p_state_machine->u1_status_next;

    return ((uint8_t)(p_state_machine->u2_status_error));
} /* End of function mtr_statemachine_event */

/***********************************************************************************************************************
* @fn             mtr_statemachine_get_status
* @brief          Get a status of the system
* @param[in]      p_state_machine   A pointer to the state machine structure
* @return         A status of the system
***********************************************************************************************************************/
uint8_t mtr_statemachine_get_status(st_mtr_statemachine_t *p_state_machine)
{
    return (p_state_machine->u1_status);
} /* End of function mtr_statemachine_get_status */


/***********************************************************************************************************************
* @fn             mtr_act_drive
* @brief          Activate the motor control system and enables PWM output
* @param[in]      p_state_machine   A pointer to the state machine structure
* @param[in,out]  p_params   A pointer to the 120 degrees control data
* @retval         0             Success
***********************************************************************************************************************/
uint8_t mtr_act_drive(st_mtr_statemachine_t *p_state_machine, void *p_params)
{
    FSP_PARAMETER_NOT_USED(p_state_machine);

    st_mtr_120_control_t * p_st_120 = p_params;

    RM_MTR_120MotorReset(p_st_120);  /* Initialize variables when motor control start */

    return (0);
} /* End of function mtr_act_drive */

/***********************************************************************************************************************
* @fn             mtr_act_stop
* @brief          Deactivate the motor control system and disables PWM output
* @param[in]      p_state_machine   A pointer to the state machine structure
* @param[in]      p_params   A pointer to the 120 degrees control data
* @retval         0             Success
***********************************************************************************************************************/
uint8_t mtr_act_stop(st_mtr_statemachine_t *p_state_machine, void *p_params)
{
    FSP_PARAMETER_NOT_USED(p_state_machine);
    FSP_PARAMETER_NOT_USED(p_params);

    /* Do Nothing */

    return (0);
} /* End of function mtr_act_stop */

/***********************************************************************************************************************
* @fn             mtr_act_none
* @param[in]      p_state_machine   A pointer to the state machine structure
* @param[in]      p_params   The pointer to the 120 degrees control data
* @retval         0             Success
***********************************************************************************************************************/
uint8_t mtr_act_none(st_mtr_statemachine_t *p_state_machine, void *p_params)
{
    FSP_PARAMETER_NOT_USED(p_state_machine);
    FSP_PARAMETER_NOT_USED(p_params);

    /* Do Nothing */

    return (0);
} /* End of function mtr_act_none */

/***********************************************************************************************************************
* @fn             mtr_act_init
* @brief          Reset the configurations to default and clear error flags
* @param[in]      p_state_machine   A pointer to the state machine structure
* @param[in,out]  p_params   A pointer to the 120 degrees control data
* @retval         0             Success
***********************************************************************************************************************/
uint8_t mtr_act_init(st_mtr_statemachine_t *p_state_machine, void *p_params)
{
    FSP_PARAMETER_NOT_USED(p_state_machine);


    st_mtr_120_control_t * p_st_120 = p_params;

    RM_MTR_120MotorDefaultInit(p_st_120);
    mtr_statemachine_event(&p_st_120->st_speed.st_stm, p_params, MTR_EVENT_STOP);

    return (0);
} /* End of function mtr_act_init */

/***********************************************************************************************************************
* @fn             mtr_act_error
* @brief          Execute the post-processing (include stopping the PWM output) when an error has been detected
* @param[in]      p_state_machine   A pointer to the state machine structure
* @param[in]      p_params   A pointer to the 120 degrees control data
* @retval         0             Success
***********************************************************************************************************************/
uint8_t mtr_act_error(st_mtr_statemachine_t *p_state_machine, void *p_params)
{
    FSP_PARAMETER_NOT_USED(p_state_machine);
    FSP_PARAMETER_NOT_USED(p_params);

    R_MTR_GPT_THREE_PHASE_DisableOutputAll(g_three_phase_carrier.p_ctrl);    /* PWM output disable */

    return (0);
} /* End of function mtr_act_error */


/***********************************************************************************************************************
* @fn             RM_MTR_ControlInit
* @brief          Initialize the motor controller
***********************************************************************************************************************/
void RM_MTR_ControlInit(void)
{
    /* Initialize system state machine */
    mtr_statemachine_init(&g_st_120.st_speed.st_stm);
} /* End of function RM_MTR_ControlInit */

/***********************************************************************************************************************
* @fn             RM_MTR_EventExec
* @brief          Execute event of 120 degrees control
* @param[in]      u1_event   the event index
***********************************************************************************************************************/
void RM_MTR_EventExec(uint8_t u1_event)
{
    mtr_statemachine_event(&g_st_120.st_speed.st_stm, &g_st_120, u1_event);
} /* End of function RM_MTR_EventExec */

/***********************************************************************************************************************
* @fn             RM_MTR_CapacitorCharge
* @brief          Wait for charging capacitor
* @retval         ERROR_NONE                No error
* @retval         ERROR_CHARGE_CAP_TIMEOUT  Timeout error has occurred
***********************************************************************************************************************/
uint16_t RM_MTR_CapacitorCharge(void)
{
    uint16_t i;

    uint16_t u2_charge_cap_error;
    uint16_t u2_charge_cap_cnt   = 0;
    int32_t  s4_thrsld;

    u2_charge_cap_error        = MTR_ERROR_NONE;
    g_st_120.u1_flg_charge_cap = MTR_CLR;

    s4_thrsld = FIX_fromfloat(MTR_MCU_ON_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

    /* wait until Vdc exceeds MCU power on voltage */
    while (s4_thrsld > g_st_120.s4_ad_vdc)
    {
        R_WDT_Refresh(g_wdt0.p_ctrl);                       /* watch dog timer clear */

        for (i = 0; i < MTR_WAIT_CNT_300US; i++)                           /* wait about 300 us */
        {
            __NOP();
        }

        u2_charge_cap_cnt++;

        if (u2_charge_cap_cnt > MTR_CHARGE_CAP_WAIT_CNT)
        {
            u2_charge_cap_error = MTR_ERROR_CHARGE_CAP_TIMEOUT;
            break;
        }
    }

    g_st_120.u1_flg_charge_cap = MTR_SET;

    return (u2_charge_cap_error);
} /* End of function RM_MTR_CapacitorCharge */

/***********************************************************************************************************************
* @fn             RM_MTR_StatusGet
* @brief          Get a status of the motor control system
* @return         A status of the motor
***********************************************************************************************************************/
uint8_t RM_MTR_StatusGet(void)
{
    return (mtr_statemachine_get_status(&g_st_120.st_speed.st_stm));
} /* End of function RM_MTR_StatusGet */

/***********************************************************************************************************************
* @fn             RM_MTR_StatusErrorGet
* @brief          Get a status error of the motor
* @return         A status error of the motor
***********************************************************************************************************************/
uint16_t RM_MTR_StatusErrorGet(void)
{
    return (g_st_120.u2_error_status);
} /* End of function RM_MTR_StatusErrorGet */

/***********************************************************************************************************************
* @fn             RM_MTR_IcsBufferSet
* @brief          Set buffer variables
***********************************************************************************************************************/
void RM_MTR_IcsBufferSet(void)
{
    /* Calculate gains from input parameters */
#if (VOLTQGE == MTRCONF_CONTROL_MODE)
    R_MTR_CtrlGainVoltageMode(&g_st_gain_v_buf, &g_st_ctrl_params);
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    R_MTR_CtrlGainCurrentMode(&g_st_gain_i_buf, &g_st_ctrl_params);
#endif

    /* Write enable switch */
    g_u1_trig_enable_write = MTR_SET;
} /* End of function R_MTR_IcsBufferSet */

/***********************************************************************************************************************
* @fn             RM_MTR_VariablesSet
* @brief          Set control variables
***********************************************************************************************************************/
void RM_MTR_VariablesSet(void)
{
    /* Rotation direction */
    g_st_120.s1_ref_dir                    = st_ics.s1_ref_direction;

    /* Motor parameters */
    g_st_120.st_carrier.st_motor           = st_ics.st_motor;

    /* Reference speed */
    g_st_120.st_speed.s4_ref_speed         = st_ics.s4_ref_speed;

    if (MTR_CCW == g_st_120.s1_ref_dir)
    {
        g_st_120.st_speed.s4_ref_speed     = -g_st_120.st_speed.s4_ref_speed;
    }

    /* Limit of acceleration */
    g_st_120.st_speed.s4_ramp_lim_speed    = st_ics.s4_lim_accel;
    /* Number of samples for current offset calibration */
    g_st_120.st_carrier.u4_offset_calc_cnt = st_ics.u2_cnt_offset_calc;
    /* Minimum voltage */
    g_st_120.s4_ref_lim_v                  = st_ics.s4_ref_lim_v;

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    /* Limit of variation of voltage */
    g_st_120.st_speed.s4_ramp_lim_v        = st_ics.s4_ramp_lim_v;

    /* Speed PI gain */
    g_st_120.st_speed.st_voltage_asr.st_pi.s4_kp       = g_st_gain_v_buf.s4_asr_kp;
    g_st_120.st_speed.st_voltage_asr.st_pi.s4_kidt     = g_st_gain_v_buf.s4_asr_kidt;
    g_st_120.st_speed.st_voltage_asr.st_pi.s4_max_intg = g_st_gain_v_buf.s4_asr_max_intg;
    g_st_120.st_speed.st_voltage_asr.s4_lim_asr_err    = g_st_gain_v_buf.s4_lim_asr_err;

#elif (CURRENT == MTRCONF_CONTROL_MODE)
    /* Limit of variation of current */
    g_st_120.st_acr.s4_ramp_lim_current     = st_ics.s4_lim_current;

    /* Speed PI gain */
    g_st_120.st_speed.st_current_asr.st_pi.s4_kp       = g_st_gain_i_buf.s4_asr_kp;
    g_st_120.st_speed.st_current_asr.st_pi.s4_kidt     = g_st_gain_i_buf.s4_asr_kidt;
    /* Current PI gain */
    g_st_120.st_acr.st_pi.s4_kp             = g_st_gain_i_buf.s4_acr_kp;
    g_st_120.st_acr.st_pi.s4_kidt           = g_st_gain_i_buf.s4_acr_kidt;
    g_st_120.st_acr.st_pi.s4_max_intg       = g_st_gain_i_buf.s4_acr_max_intg;

    /* Calculate the terms related to friction */
    g_st_120.st_speed.st_current_asr.s4_d0_div_pm      = g_st_gain_i_buf.s4_d0_div_pm;
    g_st_120.st_speed.st_current_asr.s4_d1_div_p2m     = g_st_gain_i_buf.s4_d1_div_p2m;
    g_st_120.st_speed.st_current_asr.s4_lim_asr_err    = g_st_gain_i_buf.s4_lim_asr_err;
    g_st_120.st_speed.st_current_asr.st_pi.s4_max_intg = g_st_gain_i_buf.s4_asr_max_intg;
#endif

#if (HALL == MTRCONF_SENSOR_MODE)
    g_st_120.s4_lim_v                       = st_ics.s4_ref_lim_v;

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    /* Open-loop start reference voltage */
    g_st_120.st_speed.st_hall_speed.s4_ref_v_start     = st_ics.s4_ref_v_start;
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    /* Open-loop start reference DCV link current*/
    g_st_120.st_speed.st_hall_speed.s4_ref_idc_start   = st_ics.s4_ref_idc_start;
#endif

#elif (LESS == MTRCONF_SENSOR_MODE)
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    /* Reference voltage at draw-in */
    g_st_120.st_speed.st_less_speed.s4_ref_v_draw_in    = st_ics.s4_draw_in_ref_v;
    /* Voltage constant period at draw-in */
    g_st_120.st_speed.st_less_speed.u4_v_const_period   = (uint16_t)(g_st_120.st_speed.st_less_speed.s4_ref_v_draw_in
                                                                        / g_st_120.st_speed.s4_ramp_lim_v);
    /* Open-loop start reference voltage */
    g_st_120.st_speed.st_less_speed.s4_ref_v_buff_ol    = st_ics.s4_ol_ref_v_buff;

#elif (CURRENT == MTRCONF_CONTROL_MODE)
    /* DC link current reference at draw-in */
    g_st_120.st_speed.st_less_speed.s4_ref_idc_draw_in  = st_ics.s4_draw_in_ref_idc;
    /* DC link current constant period at draw-in */
    g_st_120.st_speed.st_less_speed.u4_idc_const_period = (uint32_t)(g_st_120.st_speed.st_less_speed.s4_ref_idc_draw_in
                                                                        / g_st_120.st_acr.s4_ramp_lim_current);
    /* Open-loop start reference DC link current */
    g_st_120.st_speed.st_less_speed.s4_ref_idc_buff_ol  = st_ics.s4_ol_ref_idc_buff;
#endif

    /* Open-loop to senso-rless control change speed */
    g_st_120.st_less_control.st_ol2cl.s4_change_speed   = st_ics.s4_th_speed_ol2cl;
    /* Acceleration at translating into PI control */
    g_st_120.st_less_control.st_ol2cl.s4_ramp_speed     = st_ics.s4_ol2cl_ramp_speed;
    /* Speed to change from sensorless control to open-loop drive */
    g_st_120.st_speed.st_less_speed.s4_speed_cl2ol_th   = st_ics.s4_th_speed_cl2ol;
    /* Adjusting angle */
    g_st_120.st_less_control.s4_angle_shift_adjust      = st_ics.s4_angle_shift_adjust;

    g_st_120.st_speed.st_less_speed.s4_ramp_lim_v_ol    = g_st_120.s4_ref_lim_v
                                                            / (g_st_120.st_less_control.st_ol2cl.s4_change_speed
                                                                    / g_st_120.st_speed.s4_ramp_lim_speed);
#endif /* #if (LESS == MTRCONF_SENSOR_MODE) */
} /* End of function R_MTR_VariablesSet */

/***********************************************************************************************************************
* @fn             RM_MTR_InputBufferParamReset
* @brief          Reset buffer variables
***********************************************************************************************************************/
void RM_MTR_InputBuffParamReset(void)
{
    /* Rotation direction */
    st_ics.s1_ref_direction          = MTR_CW;

    /* Motor parameters */
    st_ics.st_motor.u2_mtr_pp        = MP_POLE_PAIRS;
    st_ics.st_motor.s4_mtr_r         = FIX_fromfloat(MP_RESISTANCE * PU_SF_RES, MTR_Q_RESISTANCE);
    st_ics.st_motor.s4_mtr_ld        = FIX_fromfloat(MP_D_INDUCTANCE * PU_SF_IND, MTR_Q_INDUCTANCE);
    st_ics.st_motor.s4_mtr_lq        = FIX_fromfloat(MP_Q_INDUCTANCE * PU_SF_IND, MTR_Q_INDUCTANCE);
    st_ics.st_motor.s4_mtr_ke        = FIX_fromfloat(MP_BEMF_CONSTANT * PU_SF_BEMF_CONST, MTR_Q_BEMF_CONST);
    st_ics.st_motor.s4_mtr_j         = FIX_fromfloat(MP_ROTOR_INERTIA * PU_SF_INERTIA, MTR_Q_INERTIA);

    /* Reference speed */
    st_ics.s4_ref_speed              = 0;
    /* Number of times current offset is measured */
    st_ics.u2_cnt_offset_calc        = CP_OFFSET_CALC_CNT;
    /* Minimum value */
    st_ics.s4_ref_lim_v              = FIX_fromfloat(CP_LIMIT_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

#if (HALL == MTRCONF_SENSOR_MODE)
    /* Limit of acceleration */
    st_ics.s4_lim_accel              = FIX_fromfloat(CP_RAMP_LIMIT_SPEED_RPM_HALL * PU_SF_RPM_RAD, MTR_Q_AFREQ);

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    /* Limit of variation of voltage */
    st_ics.s4_ramp_lim_v             = FIX_fromfloat(CP_RAMP_LIMIT_V_HALL * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
    /* Reference voltage at open-loop drive */
    st_ics.s4_ref_v_start            = FIX_fromfloat(CP_START_REF_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    /* Limit of variation of current */
    st_ics.s4_lim_current            = FIX_fromfloat(CP_RAMP_LIMIT_CURRENT * PU_SF_CURRENT, MTR_Q_CURRENT);
    /* Openloop start reference DC link current */
    st_ics.s4_ref_idc_start          = FIX_fromfloat(CP_START_REF_IDC * PU_SF_CURRENT, MTR_Q_CURRENT);
#endif

#elif (LESS == MTRCONF_SENSOR_MODE)
    /* Limit of acceleration */
    st_ics.s4_lim_accel              = FIX_fromfloat(CP_RAMP_LIMIT_SPEED_RPM_LESS * PU_SF_RPM_RAD, MTR_Q_AFREQ);

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    /* Limit of variation of voltage */
    st_ics.s4_ramp_lim_v             = FIX_fromfloat(CP_RAMP_LIMIT_V_LESS * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
    /* Reference voltage at draw-in */
    st_ics.s4_draw_in_ref_v          = FIX_fromfloat(CP_DRAW_IN_REF_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);
    /* Reference voltage at open-loop drive */
    st_ics.s4_ol_ref_v_buff          = FIX_fromfloat(CP_OL_REF_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE);

#elif (CURRENT == MTRCONF_CONTROL_MODE)
    /* Limit of variation of current */
    st_ics.s4_lim_current            = FIX_fromfloat(CP_RAMP_LIMIT_CURRENT * PU_SF_CURRENT, MTR_Q_CURRENT);
    /* DC link current reference at draw-in */
    st_ics.s4_draw_in_ref_idc        = FIX_fromfloat(CP_DRAW_IN_REF_IDC * PU_SF_CURRENT, MTR_Q_CURRENT);
    /* Openloop start reference DC link current */
    st_ics.s4_ol_ref_idc_buff        = FIX_fromfloat(CP_OL_REF_IDC * PU_SF_CURRENT, MTR_Q_CURRENT);
#endif

    /* Accelerattion at translating into PI control */
    st_ics.s4_th_speed_ol2cl         = FIX_fromfloat(CP_OL2CL_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    /* Openloop to sensorless control change speed */
    st_ics.s4_ol2cl_ramp_speed       = FIX_fromfloat(CP_OL2CL_SPEED_RAMP_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    /* Speed to change from sensorless control to open-loop drive */
    st_ics.s4_th_speed_cl2ol         = FIX_fromfloat((CP_OL2CL_SPEED_RPM - CP_CL2OL_SPEED_MARGIN)
                                                     * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    /* Adjusting angle */
    st_ics.s4_angle_shift_adjust     = 0;
#endif /* #if (LESS == MTRCONF_SENSOR_MODE) */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    g_st_ctrl_params.st_macro.f4_dt_speed         = MTR_SPEED_CTRL_PERIOD * PU_SF_TIME;
    g_st_ctrl_params.st_macro.f4_pu_sf_afreq      = PU_SF_AFREQ;
    g_st_ctrl_params.st_macro.u1_q_asr_kp         = MTR_Q_ASR_KP;
    g_st_ctrl_params.st_macro.u1_q_asr_kidt       = MTR_Q_ASR_KIDT;
    g_st_ctrl_params.st_com.f4_asr_deadband_lsb   = CP_ASR_DEADBAND_LSB;

    /* Calculation of PI gain */
    R_MTR_CtrlGainVoltageMode(&g_st_gain_v_buf, &g_st_ctrl_params);

#elif (CURRENT == MTRCONF_CONTROL_MODE)
    g_st_ctrl_params.st_com.f4_acr_nf_hz        = CP_ACR_NF_HZ;
    g_st_ctrl_params.st_com.f4_asr_nf_hz        = CP_ASR_NF_HZ;
    g_st_ctrl_params.st_com.f4_asr_ki_aug       = CP_ASR_KI_AUG;

    g_st_ctrl_params.st_com.f4_asr_deadband_lsb = CP_ASR_DEADBAND_LSB;
    g_st_ctrl_params.st_com.f4_acr_deadband_lsb = CP_ACR_DEADBAND_LSB;

    g_st_ctrl_params.st_macro.f4_dt             = MTR_CTRL_PERIOD * PU_SF_TIME;
    g_st_ctrl_params.st_macro.f4_dt_speed       = MTR_SPEED_CTRL_PERIOD * PU_SF_TIME;

    g_st_ctrl_params.st_macro.f4_pu_sf_afreq    = PU_SF_AFREQ;
    g_st_ctrl_params.st_macro.u1_q_acr_kp       = MTR_Q_ACR_KP;
    g_st_ctrl_params.st_macro.u1_q_acr_kidt     = MTR_Q_ACR_KIDT;
    g_st_ctrl_params.st_macro.u1_q_asr_kp       = MTR_Q_ASR_KP;
    g_st_ctrl_params.st_macro.u1_q_asr_kidt     = MTR_Q_ASR_KIDT;

    g_st_ctrl_params.f4_d0_div_pm
            = (MP_FRICTION_0TH_ORDER / (MP_POLE_PAIRS * MP_BEMF_CONSTANT)) * PU_SF_CURRENT;
    g_st_ctrl_params.f4_d1_div_p2m
            = (MP_FRICTION_1ST_ORDER / (MP_POLE_PAIRS * MP_POLE_PAIRS * MP_BEMF_CONSTANT)) * PU_SF_D1_DIV_P2M;
    /* Calculation of PI gain */
    R_MTR_CtrlGainCurrentMode(&g_st_gain_i_buf, &g_st_ctrl_params);
#endif

    /* Set variables for control */
    RM_MTR_VariablesSet();
    /* Initialize write enable switch */
    g_u1_trig_enable_write = MTR_SET;
} /* End of function R_MTR_InputBuffParamReset */

/***********************************************************************************************************************
* @fn             R_MTR_UpdatePollingSet
* @brief          Poll u1_trig_enable_write to update configurations and commands
***********************************************************************************************************************/
void RM_MTR_UpdatePollingSet(void)
{
    /*** Set control variables ***/
    if (MTR_SET == g_u1_trig_enable_write)
    {
        RM_MTR_VariablesSet();
        g_u1_trig_enable_write = MTR_CLR;
    }
} /* End of function RM_MTR_UpdatePollingSet */
