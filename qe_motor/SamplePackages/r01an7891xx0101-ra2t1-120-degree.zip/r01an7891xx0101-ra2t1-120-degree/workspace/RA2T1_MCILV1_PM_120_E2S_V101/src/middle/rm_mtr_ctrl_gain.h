/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_ctrl_gain.h
* Description : Definitions of the processing of control gain designing
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

#ifndef RM_MTR_CTRL_GAIN_H
#define RM_MTR_CTRL_GAIN_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_mtr_common.h"
#include "r_mtr_config.h"

/***********************************************************************************************************************
* Typedef definitions
***********************************************************************************************************************/
/* Data structure for storing input control parameters */
typedef struct
{
    float    f4_dt;                      /* Period of speed control [s] */
    float    f4_dt_speed;                /* Control period for speed loop [sec] */
    float    f4_pu_sf_afreq;             /* Frequency scale factor */
    float    f4_speed_limit_rpm;         /* Over speed limit [rpm] */

    uint8_t  u1_q_current;               /* Q-format of current */
    uint8_t  u1_q_voltage;               /* Q-format of voltage */
    uint8_t  u1_q_asr_kp;                /* Q-format of PI proportional gain for ASR */
    uint8_t  u1_q_asr_kidt;              /* Q-format of PI (integral gain) * (sampling period) for ASR */
    uint8_t  u1_q_asr_err;               /* Q-format of PI error for ASR */

    /* current control */
    uint8_t  u1_q_acr_kp;                /* Q-format of PI proportional gain for ACR */
    uint8_t  u1_q_acr_kidt;              /* Q-format of PI (integral gain) * (sampling period) for ACR */
    uint8_t  u1_q_acr_err;               /* Q-format of PI error for ACR */
} st_mtr_design_parameter_macro_t;

typedef struct
{
    /* voltage control */
    float    f4_speed_omega;             /* Speed PI controller natural frequency [Hz] */
    float    f4_asr_zeta;                /* Speed PI controller damping factor */

    /* current control */
    float    f4_acr_nf_hz;               /* Current PI controller natural frequency [Hz] */
    float    f4_asr_nf_hz;               /* Speed PI controller natural frequency [Hz] */
    float    f4_asr_ki_aug;              /* Augmentation rate for integral part of ASR */
    float    f4_acr_deadband_lsb;        /* Dead-band of current PI calculation [LSB] */

    float    f4_asr_deadband_lsb;        /* Dead-band of speed PI calculation [LSB] */
} st_mtr_design_parameter_com_t;

typedef struct
{
    st_mtr_design_parameter_macro_t st_macro;
    st_mtr_design_parameter_com_t   st_com;

    uint16_t u2_mtr_pp;                  /* Number of pole pairs */
    float    f4_r;                       /* Resistance [ohm] */
    float    f4_ld;                      /* d-axis inductance [H/rad] */
    float    f4_lq;                      /* q-axis inductance [H/rad] */
    float    f4_ke;                      /* Permanent magnetic flux [V�s/rad] */
    float    f4_j;                       /* Rotor inertia [kg�m^2/(rad^2)] */

    /* current control */
    float    f4_d0_div_pm;               /* (0th order fric-coef) / (Pole pairs * BEMF-const) [PU(A)] */
    float    f4_d1_div_p2m;              /* (1st order fric-coef) / (Pole pairs^2 * BEMF-const) [PU(A s/rad)] */
} st_mtr_design_parameter_t;

/* Data structure for input gains */

typedef struct
{
    int32_t  s4_asr_kp;                  /* Speed PI proportional gain */
    int32_t  s4_asr_kidt;                /* Speed PI integral gain * dt */
    int32_t  s4_asr_max_intg;            /* Speed current PI integral part saturation limit (symmetric) */
    int32_t  s4_lim_asr_err;             /* Speed PI control max error limit [PU(rad/s)] */
} st_mtr_ctrl_gain_voltage_mode_t;


typedef struct
{
    int32_t  s4_asr_kp;                      /* Speed current PI proportional gain */
    int32_t  s4_asr_kidt;                    /* Speed current PI integral gain * dt */
    int32_t  s4_asr_max_intg;                /* Speed current PI integral part saturation limit (symmetric) */
    int32_t  s4_acr_kp;                      /* DC link current PI proportional gain */
    int32_t  s4_acr_kidt;                    /* DC link current PI ki * dt */
    int32_t  s4_acr_max_intg;                /* DC link current PI integral part saturation limit (symmetric) */
    int32_t  s4_d0_div_pm;                   /* (0th order fric-coef) / (Pole pairs * BEMF-const) [PU(A)] */
    int32_t  s4_d1_div_p2m;                  /* (0th order fric-coef) / (Pole pairs * BEMF-const) [PU(A)] */
    int32_t  s4_lim_asr_err;                 /* Speed PI control max error limit [PU(rad/s)] */
} st_mtr_ctrl_gain_current_mode_t;


/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/


void R_MTR_CtrlGainVoltageMode(st_mtr_ctrl_gain_voltage_mode_t * p_st_gain_v_buf,
                               const st_mtr_design_parameter_t * p_st_ctrl_param);

void R_MTR_CtrlGainCurrentMode(st_mtr_ctrl_gain_current_mode_t * p_st_gain_i_buf,
                               const st_mtr_design_parameter_t * p_st_ctrl_param);


#endif /* RM_MTR_CTRL_GAIN_H */
