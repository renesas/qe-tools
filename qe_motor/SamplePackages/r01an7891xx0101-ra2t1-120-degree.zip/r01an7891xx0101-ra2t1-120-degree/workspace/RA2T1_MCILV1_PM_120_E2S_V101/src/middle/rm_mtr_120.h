/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. A8ll rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_120.h
* Description : Definitions of the processing of a motor control layer
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef RM_MTR_120_H
#define RM_MTR_120_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_config.h"
#include "rm_mtr_parameter.h"
#include "rm_mtr_statemachine.h"
#include "rm_mtr_ol2cl_ctrl.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Undetected time = MTR_TIMEOUT_CNT * 1[ms] */
#define     MTR_TIMEOUT_CNT          ((uint16_t)(1.0f / ((float)MP_POLE_PAIRS * CP_MIN_SPEED_RPM / 60) * 1000 * 2))

/* Voltage pattern for rotation (CW) */
#define     MTR_PATTERN_CW_V_U             (2)     /* V phase to U phase */
#define     MTR_PATTERN_CW_W_U             (3)     /* W phase to U phase */
#define     MTR_PATTERN_CW_W_V             (1)     /* W phase to V phase */
#define     MTR_PATTERN_CW_U_V             (5)     /* U phase to V phase */
#define     MTR_PATTERN_CW_U_W             (4)     /* U phase to W phase */
#define     MTR_PATTERN_CW_V_W             (6)     /* V phase to W phase */

#define     MTR_PATTERN_NUM                (6)     /* Number of voltage pattern */
#define     MTR_TIMER_CNT_BUFFER_SIZE      (6)     /* Size of a timer-count buffer */

#if (HALL == MTRCONF_SENSOR_MODE)
#define     MTR_HALL2OL_REV_SPEED_RAD     (FIX_fromfloat(CP_HALL2OL_REV_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ))
                                                   /* When rotor reverses, voltage state is changed to MANUAL */

/* Value of hall pattern (CCW) */
#define     MTR_PATTERN_CCW_V_U            (5)     /* V phase to U phase */
#define     MTR_PATTERN_CCW_V_W            (1)     /* V phase to W phase */
#define     MTR_PATTERN_CCW_U_W            (3)     /* U phase to W phase */
#define     MTR_PATTERN_CCW_U_V            (2)     /* U phase to V phase */
#define     MTR_PATTERN_CCW_W_V            (6)     /* W phase to V phase */
#define     MTR_PATTERN_CCW_W_U            (4)     /* W phase to U phase */

#elif (LESS == MTRCONF_SENSOR_MODE)
/* Pattern for draw-in */
#define     MTR_DRAW_IN_1ST_PATTERN        (1)     /* 1st draw-in pattern */
#define     MTR_DRAW_IN_2ND_PATTERN        (2)     /* 2nd draw-in pattern */

/* Voltage pattern for rotation (CCW) */
#define     MTR_PATTERN_CCW_V_U            (3)     /* V phase to U phase */
#define     MTR_PATTERN_CCW_V_W            (2)     /* V phase to W phase */
#define     MTR_PATTERN_CCW_U_W            (6)     /* U phase to W phase */
#define     MTR_PATTERN_CCW_U_V            (4)     /* U phase to V phase */
#define     MTR_PATTERN_CCW_W_V            (5)     /* W phase to V phase */
#define     MTR_PATTERN_CCW_W_U            (1)     /* W phase to U phase */
#endif

/***********************************************************************************************************************
Macro definitions for sequence control
***********************************************************************************************************************/
/* error status */
#define     MTR_ERROR_NONE              (0x0000)
#define     MTR_ERROR_OVER_CURRENT_HW   (0x0001)
#define     MTR_ERROR_OVER_VOLTAGE      (0x0002)
#define     MTR_ERROR_OVER_SPEED        (0x0004)
#define     MTR_ERROR_HALL_TIMEOUT      (0x0008)
#define     MTR_ERROR_BEMF_TIMEOUT      (0x0010)
#define     MTR_ERROR_HALL_PATTERN      (0x0020)
#define     MTR_ERROR_BEMF_PATTERN      (0x0040)
#define     MTR_ERROR_UNDER_VOLTAGE     (0x0080)
#define     MTR_ERROR_OVER_CURRENT_SW   (0x0100)
#define     MTR_ERROR_CHARGE_CAP_TIMEOUT (0x0400)
#define     MTR_ERROR_UNKNOWN           (0xffff)

/* voltage/current reference status */
#define     MTR_REF_ZERO_CONST           (0)
#define     MTR_REF_MANUAL               (1)
#define     MTR_REF_SPEED_PI_OUTPUT      (2)

/* speed reference status */
#define     MTR_SPEED_ZERO_CONST        (0)
#define     MTR_SPEED_MANUAL            (1)

/* Drive mode status */
#define     MTR_STOP                    (0x00)
#define     MTR_DRIVE                   (0x81)
#define     MTR_DRIVE_INIT              (0x82)
#define     MTR_DRIVE_START             (0x83)
#define     MTR_OFFSET_CALC_EXE         (0x84)
#define     MTR_DRIVE_END               (0x01)
#define     MTR_MASK_RUN_MODE           (0x80)

#define     MTR_CTRL_NONE                 (0x00)
#define     MTR_CTRL_OPL_DRAWIN           (0x01)
#define     MTR_CTRL_OPL_FORCE_SYNC       (0x02)
#define     MTR_CTRL_OPL_FORCE_SYNC_ACCEL (0x45)
#define     MTR_CTRL_CLL_OPL2CLL          (0xC0)
#define     MTR_CTRL_CLL_SPEED_CTRL       (0xC1)

#define     MTR_CTRL_DRAWIN             (0x00)
#define     MTR_CTRL_DRIVE              (0x40)

#define     MTR_DRIVE_OPL               (0x00)
#define     MTR_DRIVE_CLL               (0x80)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
/* PI controller parameter structure */
typedef struct{
    int32_t       s4_kp;                   /* Proportional gain */
    int32_t       s4_kidt;                 /* Integral gain multiply sampling period */
    int32_t       s4_max_intg;             /* Integral part saturation limit (symmetric) */
    int32_t       s4_min_intg;             /* Integral part saturation limit (asymmetric) */
    int32_t       s4_decimal;              /* Stored decimal part */
} st_mtr_pi_t;

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
/* Auto speed regulator parameter structure */
typedef struct
{
    int32_t       s4_pre_speed;            /* Previous difference between reference and estimated speed */
    st_mtr_pi_t   st_pi;
    int32_t       s4_lim_asr_err;          /* Speed PI control max error limit [PU(rad/s)] */
} st_mtr_voltage_asr_t;

#elif (CURRENT == MTRCONF_CONTROL_MODE)
/* Auto current regulator parameter structure */
typedef struct
{
    int32_t       s4_lim_idc;              /* Speed PI control output limit value [PU(A)] */
    int32_t       s4_ramp_lim_current;     /* Limit of current value change [PU(A/ms)] */
    st_mtr_pi_t   st_pi;                   /* DC link current PI control structure */
} st_mtr_acr_t;

/* Auto speed regulator parameter structure */
typedef struct
{
    int32_t       s4_d0_div_pm;            /* (0th order fric-coef) / (Pole pairs * BEMF-const) [PU(A)] */
    int32_t       s4_d1_div_p2m;           /* (0th order fric-coef) / (Pole pairs * BEMF-const) [PU(A)] */
    st_mtr_pi_t   st_pi;                   /* Speed PI control structure */
    int32_t       s4_lim_asr_err;          /* Speed PI control max error limit [PU(rad/s)] */
} st_mtr_current_asr_t;
#endif

#if (HALL == MTRCONF_SENSOR_MODE)
/* Hall-effect-sensor structure for speed */
typedef struct
{
    uint16_t    u2_hall_signal;                /* Hall signal pattern */
    uint8_t     u1_flg_1st_interrupt;         /* Flag for first hall interruption */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    int32_t     s4_ref_v_start;                /* Initial reference voltage for start-up*/
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    int32_t     s4_ref_idc_start;              /* Initial reference DC link current for start-up */
#endif
} st_mtr_hall_speed_t;

#elif (LESS == MTRCONF_SENSOR_MODE)
/* Sensorless structure for carrier/speed */
typedef struct
{
    int16_t     s2_ad_vn_offset;               /* Neutral voltage offset */
    int32_t     s4_angle_shift_adjust;         /* Adjusting angle */
    st_mtr_ol2cl_t st_ol2cl;                   /* Transition into sensorless control structure */
} st_mtr_sensorless_control_t;

/* Sensorless structure for carrier */
typedef struct
{
    uint8_t     u1_flg_pattern_change;        /* Voltage pattern change request flag */
    uint8_t     u1_bemf_signal;                /* Estimated pattern of BEMF */
    uint8_t     u1_pre_bemf_signal;            /* Previous estimated pattern of BEMF */
    uint8_t     u1_flg_pattern_change_ol;     /* Voltage pattern change flag during open-loop drive */
    uint32_t    u4_speed_cnt_ol;               /* Counter for pattern change in open-loop drive */
    uint32_t    u4_pattern_period_ol;          /* Calculated period for open-loop pattern */
    uint16_t    u2_v_pattern_ol;               /* Voltage pattern for open-loop drive*/
    uint16_t    u2_v_pattern_num_ol;           /* Selecting pattern number for open-loop drive */
    uint32_t    u4_bemf_delay;                 /* Delay count as 30 degrees */
    uint32_t    u4_zerocross_filter_cnt;       /* Zero-cross filter count */

    int16_t     s2_ad_vu;                      /* U phase voltage */
    int16_t     s2_ad_vv;                      /* V phase voltage */
    int16_t     s2_ad_vw;                      /* W phase voltage */
    int16_t     s2_ad_vn;                      /* Neutral voltage */
    int16_t     s2_ad_vn_ctrl;                 /* Neutral voltage for control */
} st_mtr_sensorless_carrier_t;

/* Sensorless structure for speed */
typedef struct
{
    uint32_t    u4_cnt_draw_in;                /* Counter for draw-in */
    int32_t     s4_ramp_lim_v_ol;              /* Limit of rate of voltage change during open-loop control*/
    int32_t     s4_speed_cl2ol_th;             /* Speed to change from sensorless control to open-loop drive */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    uint32_t    u4_v_const_period;             /* Voltage constant period at draw-in */
    int32_t     s4_ref_v_draw_in;              /* Voltage reference for draw-in */
    int32_t     s4_ref_v_ol;                   /* Open-loop start reference voltage */
    int32_t     s4_ref_v_buff_ol;              /* Open-loop start reference voltage buffer*/
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    uint32_t    u4_idc_const_period;           /* DC link current constant period at draw-in */
    int32_t     s4_ref_idc_draw_in;            /* DC link current reference for draw-in */
    int32_t     s4_ref_idc_ol;                 /* Open-loop start reference DC link current */
    int32_t     s4_ref_idc_buff_ol;            /* Open-loop start reference DC link current buffer*/
#endif
} st_mtr_sensorless_speed_t;
#endif

/* 120 degree control structure for carrier */
typedef struct
{
    int32_t     s4_ad_idc;                     /* DC link current */
    int16_t     s2_ad_vdc_bit;                 /* Bus voltage (bit value) */
    int16_t     s2_ad_idc_bit;                 /* DC link current (bit value) */
    uint32_t    u4_ad_offset_idc_sum;          /* Current A/D data offset summation */
    uint32_t    u4_ad_offset_idc;              /* Current A/D data offset value */
    uint32_t    u4_offset_calc_cnt;            /* Number of samples for current offset calibration */
    uint32_t    u4_offset_sample_cnt;          /* Number of samples acquired for the calibration */

    int32_t     s4_lim_over_current;           /* Limit of over current [PU(A)] */

#if (LESS == MTRCONF_SENSOR_MODE)
    st_mtr_sensorless_carrier_t  st_less_carrier;
#endif
    st_mtr_parameter_t           st_motor;     /* Motor parameters */
} st_mtr_120_carrier_t;

/* 120 degree control structure for speed */
typedef struct
{
    int32_t     s4_ref_speed;                  /* Motor speed reference */

    int32_t     s4_lim_speed;                  /* Motor speed limit [PU(rad/s)] */
    int32_t     s4_ramp_lim_speed;             /* Limit of acceleration */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    int32_t         s4_ref_v;                  /* Reference voltage */
    int32_t         s4_ramp_lim_v;             /* Limit of rate of voltage change */
    st_mtr_voltage_asr_t st_voltage_asr;       /* Structure for speed PI control */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    int32_t         s4_ref_idc;                /* Reference DC link current value */
    st_mtr_current_asr_t st_current_asr;       /* Speed loop control structure */
#endif

#if (LESS == MTRCONF_SENSOR_MODE)
    st_mtr_sensorless_speed_t st_less_speed;
#elif (HALL == MTRCONF_SENSOR_MODE)
    st_mtr_hall_speed_t       st_hall_speed;
#endif
    st_mtr_statemachine_t     st_stm;          /* Action structure */
} st_mtr_120_speed_t;

/* 120 degree control structure */
typedef struct
{
    uint8_t     u1_state_drive;                /* Drive mode state */
    uint8_t     u1_state_ctrl_mode;            /* State management for control mode */
    int8_t      s1_ref_dir;                    /* Rotation direction reference (1:CW, -1:CCW) */
    int8_t      s1_dir;                        /* Rotation direction (1:CW, -1:CCW) */
    uint8_t     u1_flg_charge_cap;             /* Flag for capacitor charging completed */
    uint8_t     u1_flg_offset_end;             /* Complete offset flag */
    uint8_t     u1_flg_pattern_error;          /* Flag for Hall/BEMF pattern error */
    uint8_t     u1_first_rotation_cnt;         /* Count first 6 pattern changes for speed calculation */
    uint8_t     u1_v_pattern_ring_buff;        /* Buffer counter for timer_cnt_buff */

    uint16_t    u2_state_ref_speed;            /* Speed reference mode */

    uint32_t    u4_speed_timer_cnt;            /* Value of timer counter (TAU) */
    uint32_t    u4_pre_speed_timer_cnt;        /* Previous value of timer counter (TAU) */
    uint32_t    u4_timer_cnt_buff[MTR_TIMER_CNT_BUFFER_SIZE];
                                                /* Counts for 60 degrees */
    uint32_t    u4_timer_cnt_sum;              /* Sum of counts in 360 degrees (electrical angle)*/
    uint16_t    u2_v_pattern;                  /* Voltage pattern */
    uint16_t    u2_pwm_duty;                   /* PWM duty : No scaling */
    uint32_t    u4_cnt_timeout;                /* Counter for timeout error */
    int32_t     s4_speed;                      /* Motor speed */
    int32_t     s4_ref_speed_ctrl;             /* Motor speed reference for control */

    int32_t     s4_ad_vdc;                     /* Bus voltage */

    uint16_t    u2_error_status;               /* Error status */
    int32_t     s4_lim_v;                      /* Lower limit of voltage */
    int32_t     s4_ref_lim_v;                  /* Lower limit of voltage reference value */
    int32_t     s4_ref_v_ctrl;                 /* Reference voltage for control */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    uint16_t    u2_state_ref_voltage;          /* Voltage reference mode */

#elif (CURRENT == MTRCONF_CONTROL_MODE)
    uint16_t    u2_state_ref_current;          /* Current reference mode */
    int32_t     s4_ref_idc_ctrl;               /* Reference DC link current value for current PI control [PU(A)] */
    st_mtr_acr_t st_acr;                       /* Current loop control structure */
#endif

    st_mtr_120_carrier_t        st_carrier;
    st_mtr_120_speed_t          st_speed;

#if (LESS == MTRCONF_SENSOR_MODE)
    st_mtr_sensorless_control_t st_less_control;
#endif
} st_mtr_120_control_t;

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
void RM_MTR_120MotorDefaultInit(st_mtr_120_control_t *);
void RM_MTR_120MotorReset(st_mtr_120_control_t *);

#endif /* RM_MTR_120_H */
