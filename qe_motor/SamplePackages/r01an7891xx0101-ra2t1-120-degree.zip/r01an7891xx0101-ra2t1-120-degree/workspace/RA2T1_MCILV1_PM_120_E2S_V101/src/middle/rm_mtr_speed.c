/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_speed.c
* Description : The interrupt handler
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_driver.h"
#include "r_mtr_config.h"
#include "rm_mtr_common.h"
#include "r_mtr_ics.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "rm_mtr_parameter.h"
#include "rm_mtr_120.h"
#include "r_mtr_ra2t1.h"
#include "rm_mtr_statemachine.h"
#include "rm_mtr_ol2cl_ctrl.h"

#include "hal_data.h"
#include "r_mtr_common.h"

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
extern st_mtr_120_control_t g_st_120;                      /* Structure of 120 degree control */

/* Array of voltage pattern for open-loop drive */
               /************  CW  ************/
extern const uint16_t g_u2_ol_v_pattern_table_CW[7];
               /************  CCW  ************/
extern const uint16_t g_u2_ol_v_pattern_table_CCW[7];
/* Array of chopping pattern */
               /* Complementary chopping */
               /***********   CW   ***********/
extern const uint16_t g_u2_chopping_pattern_table_CW[6];
               /***********   CCW   ***********/
extern const uint16_t g_u2_chopping_pattern_table_CCW[6];

/***********************************************************************************************************************

Private functions definitions
***********************************************************************************************************************/
#if (LESS == MTRCONF_SENSOR_MODE)
static uint8_t mtr_speed_drive_ctrl_less(st_mtr_120_control_t* p_st_120);
static uint8_t mtr_speed_process_opl_ctrl_less(st_mtr_120_control_t *p_st_120,
                                        uint8_t u1_state_ctrl_mode);
static uint8_t mtr_speed_process_cll_ctrl_less(st_mtr_120_control_t *p_st_120,
                                        uint8_t u1_state_ctrl_mode);
#elif (HALL == MTRCONF_SENSOR_MODE)
static uint8_t mtr_speed_drive_ctrl_hall(st_mtr_120_control_t* p_st_120);
static uint8_t mtr_speed_process_opl_ctrl_hall(st_mtr_120_control_t *p_st_120,
                                        uint8_t u1_state_ctrl_mode);
static uint8_t mtr_speed_process_cll_ctrl_hall(st_mtr_120_control_t *p_st_120,
                                        uint8_t u1_state_ctrl_mode);
#endif

static void mtr_offset_calc_init(void);


static void mtr_set_speed_ref (int8_t s1_ref_dir, int8_t s1_dir);

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
static int32_t mtr_set_voltage_ref (st_mtr_120_control_t *p_st_120);
#elif (CURRENT == MTRCONF_CONTROL_MODE)
static int32_t mtr_set_current_ref (st_mtr_120_control_t *p_st_120);
#endif

static int32_t mtr_pi_run_asr (st_mtr_pi_t * p_st_pi, int32_t s4_err,
                            const uint8_t u1_kp_q, const uint8_t u1_q_err_shift,
                            const uint8_t u1_q_kidt_shift, const uint8_t u1_q_intg_shift);
static inline uint16_t mtr_duty_calc (int32_t s4_ref_v, int16_t s4_ad_vdc_bit);

static inline int32_t mtr_abs (int32_t s4_value);
static inline int32_t mtr_limit_abs (int32_t s4_value, int32_t s4_limit_value);

#if ((HALL == MTRCONF_SENSOR_MODE) && (VOLTAGE == MTRCONF_CONTROL_MODE))
static inline int32_t mtr_limit (int32_t s4_value, int32_t s4_max, int32_t s4_min);
#endif

static void mtr_error_check (st_mtr_120_control_t *p_st_120);

#if (HALL == MTRCONF_SENSOR_MODE)
static inline void mtr_hall_signal_set(void);
#endif

static inline void mtr_set_chopping_pattern (uint16_t u2_pattern);

#if (LESS == MTRCONF_SENSOR_MODE)
static void mtr_draw_in_pattern_set(uint8_t u1_state_ctrl_mode, int8_t s1_dir);
static inline void mtr_start_delay_timer(uint32_t u4_delay_cnt);
static inline uint16_t mtr_openloop_pattern_set(void);
#endif

/***********************************************************************************************************************
Functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* @fn             mtr_speed_cyclic
* @brief          callback for 1ms interrupt
* @param[in]      p_args   A pointer to callback arguments
***********************************************************************************************************************/
void mtr_speed_cyclic(timer_callback_args_t * p_args)
{
    FSP_PARAMETER_NOT_USED(p_args);

    uint8_t u1_temp_stm_status;
    uint8_t u1_temp_state_drive;

    __enable_irq();

    /* Get status information */
    u1_temp_stm_status  = mtr_statemachine_get_status(&g_st_120.st_speed.st_stm);
    u1_temp_state_drive = g_st_120.u1_state_drive;

    /* Update state based on state machine status */
    if ((MTR_MODE_STOP == u1_temp_stm_status) && (MTR_MASK_RUN_MODE & g_st_120.u1_state_drive))
    {
        u1_temp_state_drive = MTR_DRIVE_END;
    }
    else if ((MTR_MODE_DRIVE == u1_temp_stm_status)
            && (!(MTR_MASK_RUN_MODE & g_st_120.u1_state_drive)))
    {
        u1_temp_state_drive = MTR_DRIVE_INIT;
    }
    else
    {
        __NOP();  /* Do nothing */
    }

    /* State machine for motor drive control */
    switch (u1_temp_state_drive)
    {
        case MTR_DRIVE:
            /* Normal drive control */
#if (LESS == MTRCONF_SENSOR_MODE)
            g_st_120.u1_state_ctrl_mode = mtr_speed_drive_ctrl_less(&g_st_120);
#elif (HALL == MTRCONF_SENSOR_MODE)
            g_st_120.u1_state_ctrl_mode = mtr_speed_drive_ctrl_hall(&g_st_120);
#endif
            break;

        case MTR_DRIVE_INIT:
            /* Avoiding unintended duty output */
            /* Initialize offset calculation */
            mtr_offset_calc_init();
            u1_temp_state_drive = MTR_DRIVE_START;
            break;

        case MTR_DRIVE_START:
            /* Enable PWM output */
            R_MTR_GPT_THREE_PHASE_EnableOutputAll(g_three_phase_carrier.p_ctrl);
            u1_temp_state_drive = MTR_OFFSET_CALC_EXE;
            break;

        case MTR_OFFSET_CALC_EXE:
            /* Check if offset calculation is completed */
            if (MTR_SET == g_st_120.u1_flg_offset_end)
            {
                g_st_120.u2_pwm_duty = mtr_duty_calc(g_st_120.s4_ref_v_ctrl, g_st_120.st_carrier.s2_ad_vdc_bit);
#if (HALL == MTRCONF_SENSOR_MODE)
                R_MTR_AGT_ReadTimerCount_32Bit(g_timer_rotation_speed.p_ctrl,  &g_st_120.u4_pre_speed_timer_cnt);

                /* Start motor control */
                R_ICU_ExternalIrqEnable(g_external_irq_hall_u.p_ctrl);
                R_ICU_ExternalIrqEnable(g_external_irq_hall_v.p_ctrl);
                R_ICU_ExternalIrqEnable(g_external_irq_hall_w.p_ctrl);

                mtr_hall_signal_set();                       /* Set initial voltage pattern */

                g_st_120.u2_state_ref_speed   = MTR_SPEED_MANUAL;
                g_st_120.u1_state_ctrl_mode   = MTR_CTRL_OPL_FORCE_SYNC_ACCEL;
#elif (LESS == MTRCONF_SENSOR_MODE)
#if (CURRENT == MTRCONF_CONTROL_MODE)
                g_st_120.s4_lim_v             = MTR_MIN_DRIVE_V;
#endif
                g_st_120.u2_state_ref_speed   = MTR_SPEED_ZERO_CONST;
                g_st_120.u1_state_ctrl_mode   = MTR_CTRL_OPL_DRAWIN;

                /* Set voltage pattern to draw-in the rotor */
                mtr_draw_in_pattern_set(g_st_120.u1_state_ctrl_mode, g_st_120.s1_dir);
#endif /* #if (LESS == MTRCONF_SENSOR_MODE) */

 #if (VOLTAGE == MTRCONF_CONTROL_MODE)
                g_st_120.u2_state_ref_voltage = MTR_REF_MANUAL;
#elif (CURRENT == MTRCONF_CONTROL_MODE)
                g_st_120.u2_state_ref_current = MTR_REF_ZERO_CONST;
#endif
                u1_temp_state_drive = MTR_DRIVE;
            }
            break;

        case MTR_DRIVE_END:
#if (HALL == MTRCONF_SENSOR_MODE)
            R_ICU_ExternalIrqDisable(g_external_irq_hall_u.p_ctrl);
            R_ICU_ExternalIrqDisable(g_external_irq_hall_v.p_ctrl);
            R_ICU_ExternalIrqDisable(g_external_irq_hall_w.p_ctrl);
#elif (LESS == MTRCONF_SENSOR_MODE)
            R_AGT_Stop(g_timer_delay.p_ctrl);
#endif
            R_MTR_GPT_THREE_PHASE_DisableOutputAll(g_three_phase_carrier.p_ctrl);
            u1_temp_state_drive = MTR_STOP;
            break;

        default:
            break;
    }

    /* Update drive state */
    g_st_120.u1_state_drive = u1_temp_state_drive;

    /* Update commands and configurations when trigger flag is set */
    RM_MTR_UpdatePollingSet();

    /*============================*/
    /*        Check error         */
    /*============================*/
    mtr_error_check(&g_st_120);
} /* End of function mtr_speed_cyclic */

#if (LESS == MTRCONF_SENSOR_MODE)
/***********************************************************************************************************************
* @fn             mtr_speed_drive_ctrl_less
* @brief          Control motor operations in open-loop and closed-loop modes
* @param[in,out]  p_st_120   A pointer to 120-degree control parameters
* @return         Updated control state
***********************************************************************************************************************/
static uint8_t mtr_speed_drive_ctrl_less(st_mtr_120_control_t* p_st_120)
{
    /* Get current control state */
    uint8_t u1_state_ctrl = p_st_120->u1_state_ctrl_mode;

    switch (u1_state_ctrl)
    {
        case MTR_CTRL_OPL_DRAWIN:
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
            /* When draw-in (rotor initialization) is finished, open-loop drive should be started. */
            if (MTR_REF_ZERO_CONST == g_st_120.u2_state_ref_voltage)
            {
                g_st_120.u2_state_ref_voltage = MTR_REF_MANUAL;
            }
            /* Wait for constant period */
            if (g_st_120.s4_ref_v_ctrl == g_st_120.st_speed.st_less_speed.s4_ref_v_draw_in)
            {
                g_st_120.st_speed.st_less_speed.u4_cnt_draw_in++;
            }
            /* When constant period passed, change to next state */
            if (g_st_120.st_speed.st_less_speed.u4_v_const_period
                    <= g_st_120.st_speed.st_less_speed.u4_cnt_draw_in)
            {
#elif (CURRENT == MTRCONF_CONTROL_MODE)
            if (MTR_REF_ZERO_CONST == g_st_120.u2_state_ref_current)
            {
                p_st_120->u2_state_ref_current = MTR_REF_MANUAL;
            }

            /* Wait for constant period */
            if (p_st_120->s4_ref_idc_ctrl == p_st_120->st_speed.st_less_speed.s4_ref_idc_draw_in)
            {
                p_st_120->st_speed.st_less_speed.u4_cnt_draw_in++;
            }
            /* When constant period passed, change to next state */
            if (p_st_120->st_speed.st_less_speed.u4_idc_const_period
                    <= p_st_120->st_speed.st_less_speed.u4_cnt_draw_in)
            {
#endif
                /* After 1st draw-in, start 2nd draw-in */
                p_st_120->st_speed.st_less_speed.u4_cnt_draw_in = 0;
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
                p_st_120->u2_state_ref_voltage = MTR_REF_ZERO_CONST;
#elif (CURRENT == MTRCONF_CONTROL_MODE)
                p_st_120->u2_state_ref_current = MTR_REF_ZERO_CONST;
#endif
                u1_state_ctrl = MTR_CTRL_OPL_FORCE_SYNC;

                /* Set voltage pattern to draw-in the rotor */
                mtr_draw_in_pattern_set(u1_state_ctrl, p_st_120->s1_dir);
            }
            break;

        case MTR_CTRL_OPL_FORCE_SYNC:
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
            /* When draw-in (rotor initialization) is finished, open-loop drive should be started. */
            if (MTR_REF_ZERO_CONST == g_st_120.u2_state_ref_voltage)
            {
                g_st_120.u2_state_ref_voltage = MTR_REF_MANUAL;
            }
            /* Wait for constant period */
            if (g_st_120.s4_ref_v_ctrl == g_st_120.st_speed.st_less_speed.s4_ref_v_draw_in)
            {
                g_st_120.st_speed.st_less_speed.u4_cnt_draw_in++;
            }
            /* When constant period passed, change to next state */
            if (g_st_120.st_speed.st_less_speed.u4_v_const_period
                    <= g_st_120.st_speed.st_less_speed.u4_cnt_draw_in)
            {
#elif (CURRENT == MTRCONF_CONTROL_MODE)
            if (MTR_REF_ZERO_CONST == g_st_120.u2_state_ref_current)
            {
                p_st_120->u2_state_ref_current = MTR_REF_MANUAL;
            }

            /* Wait for constant period */
            if (p_st_120->s4_ref_idc_ctrl == p_st_120->st_speed.st_less_speed.s4_ref_idc_draw_in)
            {
                p_st_120->st_speed.st_less_speed.u4_cnt_draw_in++;
            }
            /* When constant period passed, change to next state */
            if (p_st_120->st_speed.st_less_speed.u4_idc_const_period
                    <= p_st_120->st_speed.st_less_speed.u4_cnt_draw_in)
            {
#endif
                /* After 2nd draw-in, start open-loop drive */
                p_st_120->st_speed.st_less_speed.u4_cnt_draw_in = 0;
                p_st_120->u2_state_ref_speed                    = MTR_SPEED_MANUAL;
                p_st_120->s4_ref_v_ctrl                         = 0;
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
                p_st_120->st_speed.st_less_speed.s4_ref_v_ol    = p_st_120->st_speed.st_less_speed.s4_ref_v_buff_ol;
                p_st_120->st_speed.s4_ref_v                     = p_st_120->st_speed.st_less_speed.s4_ref_v_ol;
                p_st_120->u2_pwm_duty = mtr_duty_calc(p_st_120->s4_ref_v_ctrl, p_st_120->st_carrier.s2_ad_vdc_bit);
#elif (CURRENT == MTRCONF_CONTROL_MODE)
                p_st_120->st_speed.st_less_speed.s4_ref_idc_ol  = p_st_120->st_speed.st_less_speed.s4_ref_idc_buff_ol;
                p_st_120->st_speed.s4_ref_idc                   = g_st_120.st_speed.st_less_speed.s4_ref_idc_ol;
                p_st_120->s4_ref_idc_ctrl                       = 0;
                p_st_120->s4_lim_v                              = 0;
#endif

                /* Set 1st voltage pattern for open-loop drive */
                p_st_120->st_carrier.st_less_carrier.u2_v_pattern_ol = mtr_openloop_pattern_set();
                mtr_set_chopping_pattern(p_st_120->st_carrier.st_less_carrier.u2_v_pattern_ol);
                mtr_start_delay_timer(0);
                R_MTR_AGT_ReadTimerCount_32Bit(g_timer_rotation_speed.p_ctrl, &p_st_120->u4_pre_speed_timer_cnt);

                u1_state_ctrl = MTR_CTRL_OPL_FORCE_SYNC_ACCEL;
            }
            break;

        case MTR_CTRL_OPL_FORCE_SYNC_ACCEL:
            u1_state_ctrl = mtr_speed_process_opl_ctrl_less(p_st_120, u1_state_ctrl);
            break;

        case MTR_CTRL_CLL_SPEED_CTRL:
            u1_state_ctrl = mtr_speed_process_cll_ctrl_less(p_st_120, u1_state_ctrl);
            break;

        default:
            /* Do Nothing */
            break;
    }

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    /* Set voltage reference */
    p_st_120->s4_ref_v_ctrl   = mtr_set_voltage_ref(p_st_120);
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    /* Set current reference */
    p_st_120->s4_ref_idc_ctrl = mtr_set_current_ref(p_st_120);
#endif

    return u1_state_ctrl;
}

/***********************************************************************************************************************
* @brief          Process motor speed control in open-loop drive mode
* @param[in,out]  p_st_120                  A pointer to 120-degree control parameters
* @param[in]      u1_state_ctrl_mode        The current control state
* @return         Updated control state
***********************************************************************************************************************/
static uint8_t mtr_speed_process_opl_ctrl_less(st_mtr_120_control_t *p_st_120,
                                        uint8_t u1_state_ctrl_mode)
{
    int32_t s4_temp_lim_v;

#if (CURRENT == MTRCONF_CONTROL_MODE)
    if (p_st_120->s4_ref_idc_ctrl >= p_st_120->st_speed.st_less_speed.s4_ref_idc_ol)
#elif (VOLTAGE == MTRCONF_CONTROL_MODE)
    if (p_st_120->s4_ref_v_ctrl >= p_st_120->st_speed.st_less_speed.s4_ref_v_ol)
#endif
    {
        /* Set speed reference */
        mtr_set_speed_ref(p_st_120->s1_ref_dir, p_st_120->s1_dir);

        /* When reference speed is over s2_change_speed_rad, allowed to change to sensor-less control */
        if (mtr_abs(p_st_120->s4_ref_speed_ctrl) >= p_st_120->st_less_control.st_ol2cl.s4_change_speed)
        {
#if (CURRENT == MTRCONF_CONTROL_MODE)
            p_st_120->st_less_control.st_ol2cl.u1_flg_change_speed = MTR_SET;
#elif (VOLTAGE == MTRCONF_CONTROL_MODE)
            /* Set speed reference at transition from open-loop drive to PI control */
            R_MTR_SetSpeedRefOL2CL(&p_st_120->st_less_control.st_ol2cl, p_st_120->s1_dir, &p_st_120->s4_ref_speed_ctrl);
#endif
//            u1_state_ctrl_mode = MTR_CTRL_CLL_SPEED_CTRL;

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
            /* Prepare ASR for transition */
            {
                int32_t s4_temp_voltage     = p_st_120->s4_ref_v_ctrl;
                int32_t s4_kidt             = p_st_120->st_speed.st_voltage_asr.st_pi.s4_kidt;
                int32_t s4_voltage_div_kidt = s4_temp_voltage /
                                           (s4_kidt >> (MTR_Q_ASR_KIDT - (MTR_Q_VOLTAGE - MTR_Q_ASR_INTG)));

                p_st_120->st_speed.st_voltage_asr.st_pi.s4_decimal
                                            = s4_voltage_div_kidt << (MTR_Q_ASR_ERR - MTR_Q_ASR_INTG);
            }
#elif (CURRENT == MTRCONF_CONTROL_MODE)
            /* Prepare ASR for transition */
            {
                int32_t s4_temp_current     = p_st_120->s4_ref_idc_ctrl;
                int32_t s4_kidt             = p_st_120->st_speed.st_current_asr.st_pi.s4_kidt;
                int32_t s4_current_div_kidt = s4_temp_current /
                                           (s4_kidt >> (MTR_Q_ASR_KIDT - (MTR_Q_CURRENT - MTR_Q_ASR_INTG)));

                p_st_120->st_speed.st_current_asr.st_pi.s4_decimal
                                            = s4_current_div_kidt << (MTR_Q_ASR_ERR - MTR_Q_ASR_INTG);
            }
#endif
        }

        /* set lower limit of voltage */
        if ((p_st_120->s1_ref_dir != p_st_120->s1_dir) && (0 != p_st_120->s4_ref_speed_ctrl))
        {
            s4_temp_lim_v      = (p_st_120->s4_ref_lim_v >> 1) - p_st_120->s4_lim_v;
            s4_temp_lim_v      = mtr_limit_abs(s4_temp_lim_v, p_st_120->st_speed.st_less_speed.s4_ramp_lim_v_ol);
            p_st_120->s4_lim_v = p_st_120->s4_lim_v + s4_temp_lim_v;
        }
        else
        {
            s4_temp_lim_v      = p_st_120->s4_ref_lim_v - p_st_120->s4_lim_v;
            s4_temp_lim_v      = mtr_limit_abs(s4_temp_lim_v, p_st_120->st_speed.st_less_speed.s4_ramp_lim_v_ol);
            p_st_120->s4_lim_v = g_st_120.s4_lim_v + s4_temp_lim_v;
        }
    }

    return (u1_state_ctrl_mode);
} /* End of function _speed_process_opl_ctrl_less */

/***********************************************************************************************************************
* @fn             mtr_speed_process_cll_ctrl_less
* @brief          Process motor speed control in closed-loop drive mode
* @param[in,out]  p_st_120                  A pointer to 120-degree control parameters
* @param[in]      u1_state_ctrl_mode        The current control state
* @return         Updated control state
***********************************************************************************************************************/
static uint8_t mtr_speed_process_cll_ctrl_less(st_mtr_120_control_t *p_st_120,
                                            uint8_t u1_state_ctrl_mode)
{
    /* Set speed reference */
    mtr_set_speed_ref(p_st_120->s1_ref_dir, p_st_120->s1_dir);

    /* When reference speed is under s2_cl2ol_speed_rad, change to open-loop drive */
    if (mtr_abs(p_st_120->s4_ref_speed_ctrl) < p_st_120->st_speed.st_less_speed.s4_speed_cl2ol_th)
    {
        /* Set states and voltage for open-loop drive */
        p_st_120->u4_cnt_timeout = 0;

        p_st_120->st_less_control.st_ol2cl.u1_flg_change_speed = MTR_CLR;

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
        p_st_120->st_speed.s4_ref_v                          = p_st_120->st_speed.st_less_speed.s4_ref_v_ol;
        p_st_120->st_speed.st_less_speed.s4_ref_v_ol         = 0;
        p_st_120->u2_state_ref_voltage                       = MTR_REF_MANUAL;
#elif (CURRENT == MTRCONF_CONTROL_MODE)
        p_st_120->st_speed.st_less_speed.s4_ref_idc_ol       = 0;
        p_st_120->u2_state_ref_current                       = MTR_REF_MANUAL;
        p_st_120->st_speed.st_current_asr.st_pi.s4_decimal   = 0;
#endif
        p_st_120->st_less_control.st_ol2cl.s4_ref_speed_buff = p_st_120->st_less_control.st_ol2cl.s4_change_speed;
        p_st_120->st_less_control.st_ol2cl.u2_zc_cnt         = 0;

        u1_state_ctrl_mode = MTR_CTRL_OPL_FORCE_SYNC_ACCEL;
    }

    /*==================================*/
    /*     TimeOut Error Handling       */
    /*==================================*/
    if (MTR_TIMEOUT_CNT >= p_st_120->u4_cnt_timeout)
    {
        p_st_120->u4_cnt_timeout++;
    }

    return (u1_state_ctrl_mode);
} /* End of function _speed_process_cll_ctrl_less */
#endif

#if (HALL == MTRCONF_SENSOR_MODE)
/***********************************************************************************************************************
* @fn             mtr_speed_drive_ctrl_hall
* @param[in,out]  p_st_120                  A pointer to 120-degree control parameters
* @return         Updated control state
***********************************************************************************************************************/
static uint8_t mtr_speed_drive_ctrl_hall(st_mtr_120_control_t* p_st_120)
{
    /* Get current control state */
    uint8_t u1_state_ctrl = p_st_120->u1_state_ctrl_mode;

    if (MTR_DRIVE_OPL == (u1_state_ctrl & 0x80))
    {
        u1_state_ctrl = mtr_speed_process_opl_ctrl_hall(p_st_120, u1_state_ctrl);
    }
    else if (MTR_DRIVE_CLL == (u1_state_ctrl & 0x80))
    {
        u1_state_ctrl = mtr_speed_process_cll_ctrl_hall(p_st_120, u1_state_ctrl);
    }

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    /* Set voltage reference */
    g_st_120.s4_ref_v_ctrl   = mtr_set_voltage_ref(p_st_120);
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    /* Set current reference */
    g_st_120.s4_ref_idc_ctrl = mtr_set_current_ref(p_st_120);
#endif

    return (u1_state_ctrl);
} /* End of function _speed_drive_ctrl_hall */

/***********************************************************************************************************************
* @fn             mtr_speed_process_opl_ctrl_hall
* @brief          Process motor speed control in open-loop drive mode
* @param[in,out]  p_st_120                   A pointer to 120-degree control parameters
* @param[in]      u1_state_ctrl_mode         The Current control state of the open-loop mode
***********************************************************************************************************************/
static uint8_t mtr_speed_process_opl_ctrl_hall(st_mtr_120_control_t *p_st_120,
                                        uint8_t u1_state_ctrl_mode)
{
    /* Set speed reference */
     mtr_set_speed_ref(p_st_120->s1_ref_dir, p_st_120->s1_dir);

     /* After rotation direction has changed, restart PI control */
    if (p_st_120->s1_dir == p_st_120->s1_ref_dir)
    {
         /* Clear values of variables for speed calculation */
         p_st_120->s4_speed                       = 0;
         p_st_120->u4_speed_timer_cnt             = 0;
         p_st_120->u4_pre_speed_timer_cnt         = 0;
         p_st_120->u4_timer_cnt_buff[0]           = 0;
         p_st_120->u4_timer_cnt_buff[1]           = 0;
         p_st_120->u4_timer_cnt_buff[2]           = 0;
         p_st_120->u4_timer_cnt_buff[3]           = 0;
         p_st_120->u4_timer_cnt_buff[4]           = 0;
         p_st_120->u4_timer_cnt_buff[5]           = 0;
         p_st_120->u1_v_pattern_ring_buff         = 0;
         p_st_120->u1_first_rotation_cnt          = MTR_PATTERN_NUM;
         p_st_120->st_speed.st_hall_speed.u1_flg_1st_interrupt
                                                  = MTR_SET;

         u1_state_ctrl_mode                       = MTR_CTRL_CLL_SPEED_CTRL;

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
         /* Prepare ASR for transition */
         {
             int32_t s4_temp_current     = p_st_120->s4_ref_v_ctrl;
             int32_t s4_kidt             = p_st_120->st_speed.st_voltage_asr.st_pi.s4_kidt;
             int32_t s4_current_div_kidt = s4_temp_current /
                                           (s4_kidt >> (MTR_Q_ASR_KIDT - (MTR_Q_CURRENT - MTR_Q_ASR_INTG)));

             p_st_120->st_speed.st_voltage_asr.st_pi.s4_decimal
                                         = s4_current_div_kidt << (MTR_Q_ASR_ERR - MTR_Q_ASR_INTG);
         }

         p_st_120->u2_state_ref_voltage = MTR_REF_SPEED_PI_OUTPUT;
#elif (CURRENT == MTRCONF_CONTROL_MODE)
         /* Prepare ASR for transition */
         {
             int32_t s4_temp_current     = p_st_120->s4_ref_idc_ctrl;
             int32_t s4_kidt             = p_st_120->st_speed.st_current_asr.st_pi.s4_kidt;
             int32_t s4_current_div_kidt = s4_temp_current /
                                           (s4_kidt >> (MTR_Q_ASR_KIDT - (MTR_Q_CURRENT - MTR_Q_ASR_INTG)));

             p_st_120->st_speed.st_current_asr.st_pi.s4_decimal
                                         = s4_current_div_kidt << (MTR_Q_ASR_ERR - MTR_Q_ASR_INTG);
         }

         p_st_120->u2_state_ref_current = MTR_REF_SPEED_PI_OUTPUT;
#endif
    }

    return (u1_state_ctrl_mode);
} /* End of function _speed_process_opl_ctrl_hall */

/***********************************************************************************************************************
* @fn             mtr_speed_process_cll_ctrl_hall
* @brief          Process motor speed control in closed-loop drive mode
* @param[in,out]  p_st_120                   A pointer to 120-degree control parameters
* @param[in]      u1_state_ctrl_mode         The Current control state of the open-loop mode
* @return         Updated control state
***********************************************************************************************************************/
static uint8_t mtr_speed_process_cll_ctrl_hall(st_mtr_120_control_t *p_st_120,
                                            uint8_t u1_state_ctrl_mode)
{
      /* Set speed reference */
      mtr_set_speed_ref(p_st_120->s1_ref_dir, p_st_120->s1_dir);

      /* When rotation direction is changed, reference voltage is set to const */
     if ((p_st_120->s1_dir != p_st_120->s1_ref_dir)
                && (MTR_HALL2OL_REV_SPEED_RAD > mtr_abs(p_st_120->s4_ref_speed_ctrl)))
     {
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
         p_st_120->s4_ref_v_ctrl        = p_st_120->st_speed.st_hall_speed.s4_ref_v_start;
         p_st_120->u2_state_ref_voltage = MTR_REF_MANUAL;
#elif (CURRENT == MTRCONF_CONTROL_MODE)
         p_st_120->s4_ref_idc_ctrl      = p_st_120->st_speed.st_hall_speed.s4_ref_idc_start;
         p_st_120->u2_state_ref_current = MTR_REF_MANUAL;
#endif
         p_st_120->u4_cnt_timeout       = 0;

         u1_state_ctrl_mode = MTR_CTRL_OPL_FORCE_SYNC_ACCEL;
     }

     /* TimeOut Error Handling */
     if (MTR_TIMEOUT_CNT >= p_st_120->u4_cnt_timeout)
     {
         p_st_120->u4_cnt_timeout++;
     }

     return (u1_state_ctrl_mode);
} /* End of function _speed_process_cll_ctrl_hall */
#endif

/***********************************************************************************************************************
* @fn             mtr_offset_calc_init
* @brief          Initialize for offset calculation
***********************************************************************************************************************/
static void mtr_offset_calc_init(void)
{
    three_phase_duty_cycle_t duty_cycle;

    g_st_120.st_carrier.u4_ad_offset_idc_sum = 0;
    g_st_120.st_carrier.u4_offset_sample_cnt = 0;

    /* Configure duty cycles for all three phases */
    duty_cycle.duty[0] = duty_cycle.duty_buffer[0] = (uint16_t)MTR_HALF_CARRIER_CNT;
    duty_cycle.duty[1] = duty_cycle.duty_buffer[1] = (uint16_t)MTR_HALF_CARRIER_CNT;
    duty_cycle.duty[2] = duty_cycle.duty_buffer[2] = (uint16_t)MTR_HALF_CARRIER_CNT;

    /* Set the duty cycle for three-phase PWM in CompMode2 */
    R_MTR_GPT_THREE_PHASE_CompMode2_DutyCycleSet(g_three_phase_carrier.p_ctrl, &duty_cycle);
}

/***********************************************************************************************************************
* @fn             mtr_set_speed_ref
* @brief          Set reference speed
* @param[in]      s1_ref_dir    A reference rotational direction
* @param[in]      s1_dir        A rotational direction
***********************************************************************************************************************/
static void mtr_set_speed_ref(int8_t s1_ref_dir, int8_t s1_dir)
{
    int32_t  s4_temp;
    int32_t  s4_ref_speed_buff;
    int32_t  s4_ref_speed_temp;

    if ((s1_ref_dir != s1_dir) && (0 != g_st_120.s4_ref_speed_ctrl))
    {
        s4_ref_speed_temp = 0;
    }
    else
    {
        s4_ref_speed_temp = g_st_120.st_speed.s4_ref_speed;
    }

    s4_ref_speed_buff = g_st_120.s4_ref_speed_ctrl;

    switch (g_st_120.u2_state_ref_speed)
    {
        /* Voltage constant, frequency no control */
        case MTR_SPEED_ZERO_CONST:
            s4_ref_speed_buff = 0;
            break;

        /* Speed MANUAL control */
        case MTR_SPEED_MANUAL:
            s4_temp = s4_ref_speed_temp - s4_ref_speed_buff;
            s4_temp = mtr_limit_abs(s4_temp, g_st_120.st_speed.s4_ramp_lim_speed);           /* Ramp limit */
            s4_ref_speed_buff += s4_temp;
            break;

        default:
            /* Do nothing */
            break;
    }

    /* Set rotation direction */
    if (0 <= s4_ref_speed_buff)
    {
        g_st_120.s1_dir = MTR_CW;
    }
    else
    {
        g_st_120.s1_dir = MTR_CCW;
    }

    g_st_120.s4_ref_speed_ctrl = s4_ref_speed_buff;
} /* End of function mtr_set_speed_ref */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
/***********************************************************************************************************************
* @fn             mtr_set_voltage_ref
* @brief          Set reference voltage
* @param[in,out]  p_st_120      A pointer to 120-degree control parameters
* @return           The reference voltage
***********************************************************************************************************************/
static int32_t mtr_set_voltage_ref(st_mtr_120_control_t *p_st_120)
{
    int32_t s4_speed_var;
    int32_t s4_ref_v_buff = 0;
    int32_t s4_temp_err   = 0;

    switch (p_st_120->u2_state_ref_voltage)
    {
        /* Zero voltage constantly. */
        case MTR_REF_ZERO_CONST:
            s4_ref_v_buff = 0;
            break;

        /* Manual input */
        case MTR_REF_MANUAL:
            s4_temp_err = p_st_120->st_speed.s4_ref_v - p_st_120->s4_ref_v_ctrl;
                                                                    /* Error */
            s4_temp_err = mtr_limit_abs(s4_temp_err, p_st_120->st_speed.s4_ramp_lim_v);
                                                                    /* Ramp limit */
            s4_ref_v_buff = p_st_120->s4_ref_v_ctrl + s4_temp_err;  /* Add error to control reference */
            break;

        /* PI control */
        case MTR_REF_SPEED_PI_OUTPUT:
            /* Speed error */
            s4_temp_err = p_st_120->s4_ref_speed_ctrl - p_st_120->s4_speed;
            /* Speed PI control */
            if (MTR_CCW == p_st_120->s1_dir)
            {
                s4_temp_err = -s4_temp_err;
            }
            else
            {
                __NOP(); /* Do nothing */
            }

            s4_ref_v_buff = mtr_pi_run_asr(&p_st_120->st_speed.st_voltage_asr.st_pi, s4_temp_err,
                                           (MTR_Q_AFREQ + MTR_Q_ASR_KP) - MTR_Q_VOLTAGE,
                                           (MTR_Q_AFREQ - MTR_Q_ASR_ERR),
                                           MTR_Q_ASR_KIDT - (MTR_Q_VOLTAGE - MTR_Q_ASR_INTG),
                                           MTR_Q_ASR_ERR - MTR_Q_ASR_INTG);


            /* Calculation of speed variation  */
            if (MTR_CW == p_st_120->s1_dir)
            {
                s4_speed_var = p_st_120->s4_speed - p_st_120->st_speed.st_voltage_asr.s4_pre_speed;
            }
            else
            {
                s4_speed_var = p_st_120->st_speed.st_voltage_asr.s4_pre_speed - p_st_120->s4_speed;
            }

            /* Add (speed variation) * (magnetic flux) to voltage for feedforward */
            s4_ref_v_buff += FIX_mul_rs(s4_speed_var, g_st_120.st_carrier.st_motor.s4_mtr_ke,
                                        RSFT_AFREQ_BEMF_CONST_2VOLTAGE);
            p_st_120->st_speed.st_voltage_asr.s4_pre_speed = p_st_120->s4_speed;

            break;

        default:
                /* Do nothing */
            break;
    }

    /* Lower limit voltage */
    if (p_st_120->s4_lim_v > s4_ref_v_buff)
    {
        s4_ref_v_buff = p_st_120->s4_lim_v;
    }
    else
    {
        __NOP(); /* Do nothing */
    }

#if (LESS == MTRCONF_SENSOR_MODE)
    /* overflow limitation */
    if (s4_ref_v_buff > (MTR_MAX_DRIVE_V * 2))
    {
        s4_ref_v_buff = (MTR_MAX_DRIVE_V * 2);
    }
#elif (HALL == MTRCONF_SENSOR_MODE)
    /* Limit voltage output */
    s4_ref_v_buff = mtr_limit(s4_ref_v_buff, MTR_MAX_DRIVE_V, MTR_MIN_DRIVE_V);
#endif

    /* return voltage reference */
    return (s4_ref_v_buff);
} /* End of function mtr_set_voltage_ref */

#elif (CURRENT == MTRCONF_CONTROL_MODE)
/***********************************************************************************************************************
* @fn             mtr_set_current_ref
* @brief          Set reference current
* @param[in,out]  p_st_120      A pointer to 120-degree control parameters
***********************************************************************************************************************/
static int32_t mtr_set_current_ref(st_mtr_120_control_t *p_st_120)
{
    int32_t s4_ref_idc_buff    = 0;
    int32_t s4_temp_err        = 0;
    int32_t s4_temp_d0_div_pm  = 0;

    switch (p_st_120->u2_state_ref_current)
    {
        case MTR_REF_ZERO_CONST:
            s4_ref_idc_buff = 0;             /*** constant zero set ***/
            break;

        case MTR_REF_MANUAL:
            s4_temp_err = p_st_120->st_speed.s4_ref_idc - p_st_120->s4_ref_idc_ctrl;
                                                                        /* Error */
            s4_temp_err = mtr_limit_abs(s4_temp_err, p_st_120->st_acr.s4_ramp_lim_current);
                                                                        /* Limit error */
            s4_ref_idc_buff = p_st_120->s4_ref_idc_ctrl + s4_temp_err;  /* Add error to control reference */
            break;

        case MTR_REF_SPEED_PI_OUTPUT:
            /* Speed error */
            s4_temp_err = p_st_120->s4_ref_speed_ctrl - p_st_120->s4_speed;

            /*** speed PI control ***/
            if (MTR_CW == p_st_120->s1_dir)
            {
                s4_temp_d0_div_pm = p_st_120->st_speed.st_current_asr.s4_d0_div_pm;
            }
            else
            {
                s4_temp_d0_div_pm = -p_st_120->st_speed.st_current_asr.s4_d0_div_pm;
                s4_temp_err = -s4_temp_err;
            }

            /*** speed PI control ***/
            s4_ref_idc_buff  = mtr_pi_run_asr(&p_st_120->st_speed.st_current_asr.st_pi, s4_temp_err,
                                              (MTR_Q_AFREQ + MTR_Q_ASR_KP) - MTR_Q_CURRENT,
                                              (MTR_Q_AFREQ - MTR_Q_ASR_ERR),
                                              MTR_Q_ASR_KIDT - (MTR_Q_CURRENT - MTR_Q_ASR_INTG),
                                              MTR_Q_ASR_ERR - MTR_Q_ASR_INTG);

            s4_ref_idc_buff += s4_temp_d0_div_pm;

            /*** limit iq reference ***/
            s4_ref_idc_buff = mtr_limit_abs(s4_ref_idc_buff, p_st_120->st_acr.s4_lim_idc);
            break;

        default:
            break;
    }

    /* Lower limit of current */
    if (MTR_MIN_IDC_REF > s4_ref_idc_buff)
    {
        s4_ref_idc_buff = MTR_MIN_IDC_REF;
    }
    else
    {
        /* Do nothing */
    }

    /* return iq reference */
    return (s4_ref_idc_buff);
} /* End of function mtr_set_current_ref */
#endif

/***********************************************************************************************************************
* @fn             mtr_pi_run_asr
* @brief          Control Speed PI
* @param[in,out]  p_st_pi          A pointer to PI control parameters
* @param[in]      s4_err           An error number
* @param[in]      u1_kp_q          A Q-format of PI proportional gain
* @param[in]      u1_q_err_shift   A Shift count of error number
* @param[in]      u1_q_kidt_shift  A Q-format of PI Integral gain
* @param[in]      u1_q_intg_shift  A Shift count of decimal part
* @return         PI output
***********************************************************************************************************************/
static int32_t mtr_pi_run_asr(st_mtr_pi_t *p_st_pi, int32_t s4_err,
                                        const uint8_t u1_kp_q, const uint8_t u1_q_err_shift,
                                        const uint8_t u1_q_kidt_shift, const uint8_t u1_q_intg_shift)
{
    int32_t s4_pi_out;
    int32_t s4_intg;

    p_st_pi->s4_decimal += (s4_err >> u1_q_err_shift);

    /* Integral part saturation (symmetric) limiter */
    p_st_pi->s4_decimal = mtr_limit_abs(p_st_pi->s4_decimal, p_st_pi->s4_max_intg);

    s4_intg = (p_st_pi->s4_kidt >> u1_q_kidt_shift)
            * (p_st_pi->s4_decimal >> u1_q_intg_shift);

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    int32_t s4_err_lim = mtr_limit_abs(s4_err, g_st_120.st_speed.st_voltage_asr.s4_lim_asr_err);
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    int32_t s4_err_lim = mtr_limit_abs(s4_err, g_st_120.st_speed.st_current_asr.s4_lim_asr_err);
#endif

    s4_pi_out = s4_intg + FIX_mul_rs_sign(p_st_pi->s4_kp, s4_err_lim, u1_kp_q);

    return (s4_pi_out);
} /* End of function mtr_pi_run_asr */

/***********************************************************************************************************************
* @fn             mtr_duty_calc
* @brief          Get duty value
* @param[in]      s4_ref_v      A reference voltage
* @param[in]      s4_ad_vdc_bit A VDC value
* @return           The duty value
***********************************************************************************************************************/
static inline uint16_t mtr_duty_calc(int32_t s4_ref_v, int16_t s2_ad_vdc_bit)
{
    int32_t s4_temp = (MTR_RECIV_COEF / (int32_t)s2_ad_vdc_bit) << MTR_ADC_12BIT;

    s4_temp = FIX_mul_rs(s4_ref_v, s4_temp, MTR_Q_VOLTAGE + MTR_Q_VOLTAGE - MTR_BIT_SFT_NUM_FOR_DUTY_CALC);

#if (COMPLEMENTARY == MTRCONF_PWM_MODE)
    s4_temp = ((int32_t)(MTR_NOT_CARRIER_CNT) * s4_temp) >> MTR_BIT_SFT_NUM_FOR_DUTY_CALC;   /* 15 bits right shift */
#elif (NON_COMPLEMENTARY == MTRCONF_PWM_MODE)
    s4_temp = ((int32_t)(MTR_CARRIER_CNT) * s4_temp) >> MTR_BIT_SFT_NUM_FOR_DUTY_CALC;       /* 15 bits right shift */
#endif
    if (MTR_MAX_DUTY_CNT < s4_temp)
    {
        s4_temp = MTR_MAX_DUTY_CNT;
    }
    s4_temp = (int32_t)MTR_MAX_DUTY_CNT - s4_temp;

    if ((s4_temp == (int32_t)MTR_MAX_DUTY_CNT) && (0 != s4_ref_v))
    {
        --s4_temp;
    }

    return ((uint16_t)s4_temp);
} /* End of function mtr_duty_calc */

/***********************************************************************************************************************
* @fn             mtr_abs
** @brief          Get the absolute value
* @param[in]      s4_value   A target value
* @return           the absolute value
**********************************************************************************************************************/
static inline int32_t mtr_abs(int32_t s4_value)
{
    return ((s4_value ^ (s4_value >> 31)) - (s4_value >> 31));
} /* End of function mtr_abs */

#if ((HALL == MTRCONF_SENSOR_MODE) && (VOLTAGE == MTRCONF_CONTROL_MODE))
/***********************************************************************************************************************
* @fn             mtr_limit
* @brief          Limit a value between maximum and minimum limits
* @param[in]      s4_value   A target value
* @param[in]      s4_max     A maximum limit
* @param[in]      s4_min     A minimum limit
* @return           The limited value
***********************************************************************************************************************/
static inline int32_t mtr_limit(int32_t s4_value, int32_t s4_max, int32_t s4_min)
{

    int32_t s4_temp;

    s4_temp = s4_value;

    if (s4_value > s4_max)
    {
        /* Max limit */
        s4_temp = s4_max;
    }
    else if (s4_value < s4_min)
    {
        /* Minimum limit */
        s4_temp = s4_min;
    }

    return (s4_temp);
} /* End of function mtr_limit */
#endif

/***********************************************************************************************************************
* @fn             mtr_limit_abs
* @brief          Limit a value between absolute limits
* @param[in]      s4_value         A target value
* @param[in]      s4_limit_value   An absolute limit
* @return           The limited value
***********************************************************************************************************************/
static inline int32_t mtr_limit_abs(int32_t s4_value, int32_t s4_limit_value)
{
    if (s4_value > s4_limit_value)
    {
        return (s4_limit_value);
    }
    else if (s4_value < (-s4_limit_value))
    {
        return (-s4_limit_value);
    }
    else
    {
        return (s4_value);
    }
} /* End of function mtr_limit_abs */

/***********************************************************************************************************************
* @fn             mtr_error_check
* @brief          Check the error status
* @param[in,out]  p_st_120 - A pointer to 120-degree control parameters
***********************************************************************************************************************/
static void mtr_error_check(st_mtr_120_control_t* p_st_120)
{
    uint8_t is_shutdown = 0;
#if (USE_POEG == MTR_SET)
    /*=====================================*/
    /*     HW over current error check     */
    /*=====================================*/
    R_MTR_POEG_RecoverForcedShutdown(g_poeg0.p_ctrl, POEG_RECOVER_TIMEOUT, &is_shutdown);
    if (MTR_SET == is_shutdown)
    {
        p_st_120->u2_error_status |= MTR_ERROR_OVER_CURRENT_HW;
    }
#endif

    /*==================================*/
    /*     Over voltage error check     */
    /*==================================*/
    if (p_st_120->s4_ad_vdc > FIX_fromfloat(IP_OVERVOLTAGE_LIMIT * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))
    {
        p_st_120->u2_error_status |= MTR_ERROR_OVER_VOLTAGE;                      /* Over voltage error */
    }

    /*===================================*/
    /*     Under voltage error check     */
    /*===================================*/
    /* Check "capacitor charge completed" */
    if (MTR_SET == p_st_120->u1_flg_charge_cap)
    {
        if (p_st_120->s4_ad_vdc < FIX_fromfloat(IP_UNDERVOLTAGE_LIMIT * PU_SF_VOLTAGE, MTR_Q_VOLTAGE))
        {
            p_st_120->u2_error_status |= MTR_ERROR_UNDER_VOLTAGE;                 /* Under voltage error */
        }
    }

    /*================================*/
    /*     Over speed error check     */
    /*================================*/
    /* Speed check is only performed at SPEED CHANGE state. */
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    if (MTR_REF_SPEED_PI_OUTPUT == p_st_120->u2_state_ref_voltage)
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    if (MTR_REF_SPEED_PI_OUTPUT == p_st_120->u2_state_ref_current)
#endif
    {
        if (mtr_abs(p_st_120->s4_speed) > p_st_120->st_speed.s4_lim_speed)
        {
            p_st_120->u2_error_status |= MTR_ERROR_OVER_SPEED;                   /* Over speed error */
        }
    }

    /*=============================*/
    /*     Timeout error check     */
    /*==== ========================*/
    /* Timeout check is performed (except for INIT state). */
    if (MTR_TIMEOUT_CNT < g_st_120.u4_cnt_timeout)
    {
#if (HALL == MTRCONF_SENSOR_MODE)
        p_st_120->u2_error_status |= MTR_ERROR_HALL_TIMEOUT;                 /* Hall timeout error */
#elif (LESS == MTRCONF_SENSOR_MODE)
        p_st_120->u2_error_status |= MTR_ERROR_BEMF_TIMEOUT;                 /* Sensor-less timeout error */
#endif
    }

    /*=======================================*/
    /*     Hall/BEMF pattern error check     */
    /*==== ==================================*/
    /* Hall/BEMF pattern check is performed */
    if (MTR_SET == p_st_120->u1_flg_pattern_error)
    {
#if (HALL == MTRCONF_SENSOR_MODE)
        p_st_120->u2_error_status |= MTR_ERROR_HALL_PATTERN;                     /* Hall pattern error */
#elif (LESS == MTRCONF_SENSOR_MODE)
        p_st_120->u2_error_status |= MTR_ERROR_BEMF_PATTERN;                     /* BEMF pattern error */
#endif
    }

    /* When any error happened, ERROR_EVENT should be executed. */
    if (MTR_ERROR_NONE != p_st_120->u2_error_status)
    {
        __disable_irq();
        RM_MTR_EventExec(MTR_EVENT_ERROR);
        __enable_irq();
    }
} /* End of function mtr_error_check */

#if (HALL == MTRCONF_SENSOR_MODE)
/***********************************************************************************************************************
* @fn             mtr_hall_signal_set
* @brief          Set a voltage pattern from a hall signal
***********************************************************************************************************************/
static inline void mtr_hall_signal_set(void)
{
    bsp_io_level_t u_level = BSP_IO_LEVEL_LOW;
    bsp_io_level_t v_level = BSP_IO_LEVEL_LOW;
    bsp_io_level_t w_level = BSP_IO_LEVEL_LOW;
    uint8_t u_value;
    uint8_t v_value;
    uint8_t w_value;

    /*** Get Hall signal ***/
    R_IOPORT_PinRead(g_ioport.p_ctrl, MTR_PORT_PIN_HALL_U, &u_level);
    R_IOPORT_PinRead(g_ioport.p_ctrl, MTR_PORT_PIN_HALL_V, &v_level);
    R_IOPORT_PinRead(g_ioport.p_ctrl, MTR_PORT_PIN_HALL_W, &w_level);
    u_value = (BSP_IO_LEVEL_LOW == u_level) ? 0 : 1;
    v_value = (BSP_IO_LEVEL_LOW == v_level) ? 0 : 1;
    w_value = (BSP_IO_LEVEL_LOW == w_level) ? 0 : 1;
    g_st_120.st_speed.st_hall_speed.u2_hall_signal  = (u_value << 2) | (v_value << 1) | w_value;

    /*** Set voltage pattern ***/
    mtr_set_chopping_pattern(g_st_120.st_speed.st_hall_speed.u2_hall_signal);

    /* Output voltage pattern */
    R_MTR_GPT_THREE_PHASE_PatternOutput(g_three_phase_carrier.p_ctrl, g_st_120.u2_v_pattern,
                                        &g_st_120.u1_flg_pattern_error);
} /* End of function mtr_hall_signal_set */
#endif

/***********************************************************************************************************************
* @fn             mtr_set_chopping_pattern
* @brief          Set a chopping pattern from a voltage pattern
* @param[in]      u2_pattern    A voltage pattern
***********************************************************************************************************************/
static inline void mtr_set_chopping_pattern(uint16_t u2_pattern)
{
    /*** Set voltage pattern ***/
    if (MTR_CW == g_st_120.s1_dir)              /* Check rotation direction */
    {
        switch (u2_pattern)
        {
            case MTR_PATTERN_CW_W_V:            /* From W phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[0];
                break;

            case MTR_PATTERN_CW_U_V:            /* From U phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[1];
                break;

            case MTR_PATTERN_CW_U_W:            /* From U phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[2];
                break;

            case MTR_PATTERN_CW_V_W:            /* From V phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[3];
                break;

            case MTR_PATTERN_CW_V_U:            /* From V phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[4];
                break;

            case MTR_PATTERN_CW_W_U:            /* From W phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CW[5];
                break;

            default:                            /* Hall signal pattern error */
                g_st_120.u2_v_pattern = MTR_PATTERN_ERROR;
                break;
        }
    }
    else if (MTR_CCW == g_st_120.s1_dir)         /* Check rotation direction */
    {
        switch (u2_pattern)
        {
            case MTR_PATTERN_CCW_W_V:           /* From W phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[0];
                break;

            case MTR_PATTERN_CCW_W_U:           /* From W phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[1];
                break;

            case MTR_PATTERN_CCW_V_U:           /* From V phase to U phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[2];
                break;

            case MTR_PATTERN_CCW_V_W:           /* From V phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[3];
                break;

            case MTR_PATTERN_CCW_U_W:           /* From U phase to W phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[4];
                break;

            case MTR_PATTERN_CCW_U_V:           /* From U phase to V phase */
                g_st_120.u2_v_pattern = g_u2_chopping_pattern_table_CCW[5];
                break;

            default:                            /* Hall signal pattern error */
                g_st_120.u2_v_pattern = MTR_PATTERN_ERROR;
                break;
        }
    }
    else
    {
        /* Do nothing */
    }

} /* End of function mtr_set_chopping_pattern */

#if (LESS == MTRCONF_SENSOR_MODE)
/***********************************************************************************************************************
* @fn             mtr_draw_in_pattern_set
* @brief          Set a voltage pattern for draw-in
* @param[in]      u1_state_cgtrl_mode   A driving control mode
* @param[in]      s1_dir                A rotational direction
***********************************************************************************************************************/
static void mtr_draw_in_pattern_set(uint8_t u1_state_ctrl_mode, int8_t s1_dir)
{
    uint16_t u2_pattern = 0;

    /* Set voltage pattern depending on draw-in state */
    switch (u1_state_ctrl_mode)
    {
        case MTR_CTRL_OPL_DRAWIN:
            if (MTR_CW == s1_dir)
            {
                u2_pattern = g_u2_ol_v_pattern_table_CW[MTR_DRAW_IN_1ST_PATTERN];
            }
            else
            {
                u2_pattern = g_u2_ol_v_pattern_table_CCW[MTR_DRAW_IN_1ST_PATTERN];
            }
            break;

        case MTR_CTRL_OPL_FORCE_SYNC:
            if (MTR_CW == s1_dir)
            {
                u2_pattern = g_u2_ol_v_pattern_table_CW[MTR_DRAW_IN_2ND_PATTERN];
            }
            else
            {
                u2_pattern = g_u2_ol_v_pattern_table_CCW[MTR_DRAW_IN_2ND_PATTERN];
            }
            break;

        default:
            /* Do nothing */
            break;
    }

    /*** Set chopping pattern ***/
    mtr_set_chopping_pattern(u2_pattern);
    mtr_start_delay_timer(0);
} /* End of function mtr_draw_in_pattern_set */

/***********************************************************************************************************************
* @fn             mtr_start_delay_timer
* @brief          Start a delay timer
* @param[in]      u4_delay_cnt      A clock count for a delay timer
***********************************************************************************************************************/
static inline void mtr_start_delay_timer(uint32_t u4_delay_cnt)
{
    R_AGT_PeriodSet(g_timer_delay.p_ctrl, u4_delay_cnt+1);
    R_AGT_Start(g_timer_delay.p_ctrl);
} /* End of function mtr_start_delay_timer */

/***********************************************************************************************************************
* @fn             mtr_openloop_pattern_set
* @brief          Set a forced voltage pattern for open-loop drive mode
***********************************************************************************************************************/
static inline uint16_t mtr_openloop_pattern_set(void)
{
    uint16_t u2_pattern;

    /* Set ring buffer  */
    g_st_120.st_carrier.st_less_carrier.u2_v_pattern_num_ol++;
    if (MTR_PATTERN_NUM < g_st_120.st_carrier.st_less_carrier.u2_v_pattern_num_ol)
    {
        g_st_120.st_carrier.st_less_carrier.u2_v_pattern_num_ol = 1;
    }

    if (MTR_CW == g_st_120.s1_dir)
    {
        u2_pattern = g_u2_ol_v_pattern_table_CW[g_st_120.st_carrier.st_less_carrier.u2_v_pattern_num_ol];
    }
    else
    {
        u2_pattern = g_u2_ol_v_pattern_table_CCW[g_st_120.st_carrier.st_less_carrier.u2_v_pattern_num_ol];
    }

    return (u2_pattern);
} /* End of function mtr_openloop_pattern_set */
#endif
