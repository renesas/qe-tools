/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_120.c
* Description : The processing of motor control layer
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_driver.h"
#include "rm_mtr_common.h"
#include "r_mtr_config.h"
#include "rm_mtr_120.h"
#include "r_mtr_ra2t1.h"
#include "RM_DSP_RA2_GCC_32BIT.h"
#include "rm_mtr_statemachine.h"
#include "rm_mtr_parameter.h"

#include "hal_data.h"
#include "r_mtr_common.h"

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
/****** For ICS ******/
volatile uint8_t   g_u1_cnt_ics;                  /* Counter for period of calling "ics_watchpoint" */
/*********************/

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* @fn             RM_MTR_120MotorDefaultInit
* @brief          Initialize motor drive modules with a default configuration
* @param[in,out]  p_st_120        A pointer to 120-degree control
***********************************************************************************************************************/
void RM_MTR_120MotorDefaultInit(st_mtr_120_control_t *p_st_120)
{
    /* 120 degree control structure */
    p_st_120->s1_ref_dir               = MTR_CW;
    p_st_120->s1_dir                   = MTR_CW;

    p_st_120->u1_flg_pattern_error     = MTR_CLR;
    p_st_120->u1_first_rotation_cnt    = MTR_PATTERN_NUM;
    p_st_120->u1_v_pattern_ring_buff   = 0;

    p_st_120->u2_state_ref_speed       = MTR_SPEED_ZERO_CONST;
    p_st_120->u1_flg_offset_end        = MTR_CLR;

    p_st_120->u4_speed_timer_cnt       = 0;
    p_st_120->u4_pre_speed_timer_cnt   = 0;
    p_st_120->u4_timer_cnt_buff[0]     = 0;
    p_st_120->u4_timer_cnt_buff[1]     = 0;
    p_st_120->u4_timer_cnt_buff[2]     = 0;
    p_st_120->u4_timer_cnt_buff[3]     = 0;
    p_st_120->u4_timer_cnt_buff[4]     = 0;
    p_st_120->u4_timer_cnt_buff[5]     = 0;
    p_st_120->u4_timer_cnt_sum         = 0;
    p_st_120->u2_v_pattern             = 0;
    p_st_120->u2_pwm_duty              = 0;
    p_st_120->u4_cnt_timeout           = 0;

    p_st_120->s4_speed                 = 0;                                                            /* PU */
    p_st_120->st_speed.s4_ref_speed    = FIX_fromfloat(CP_MIN_SPEED_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ); /* PU */
    p_st_120->s4_ref_speed_ctrl        = 0;                                                            /* PU */
    p_st_120->s4_ad_vdc                = 0;
    p_st_120->st_carrier.s4_ad_idc     = 0;
    p_st_120->st_carrier.s2_ad_vdc_bit = 0;
    p_st_120->st_carrier.s2_ad_idc_bit = 0;

    p_st_120->st_carrier.u4_ad_offset_idc_sum = 0;
    p_st_120->u2_error_status                 = MTR_ERROR_NONE;

    p_st_120->u1_state_drive           = MTR_STOP;
    p_st_120->u1_state_ctrl_mode       = MTR_CTRL_NONE;

    /* Initialize system protection limits */
    p_st_120->st_speed.s4_lim_speed          = FIX_fromfloat(CP_SPEED_LIMIT_RPM * PU_SF_RPM_RAD, MTR_Q_AFREQ);
    p_st_120->st_carrier.s4_lim_over_current = FIX_fromfloat(CP_OC_LIMIT * PU_SF_CURRENT, MTR_Q_CURRENT);

    /* Initialize system protection limits */
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    p_st_120->u2_state_ref_voltage           = MTR_REF_ZERO_CONST;
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    p_st_120->u2_state_ref_current           = MTR_REF_ZERO_CONST;
    p_st_120->st_acr.s4_ramp_lim_current     = FIX_fromfloat(CP_RAMP_LIMIT_CURRENT * PU_SF_CURRENT, MTR_Q_CURRENT);
    p_st_120->st_acr.s4_lim_idc              = FIX_fromfloat(MTR_LIMIT_IDC * PU_SF_CURRENT, MTR_Q_CURRENT);
#endif

#if (HALL == MTRCONF_SENSOR_MODE)
    /* Hall-effect-sensor control structure */
    p_st_120->st_speed.st_hall_speed.u2_hall_signal       = 0;
    p_st_120->st_speed.st_hall_speed.u1_flg_1st_interrupt = MTR_SET;
    p_st_120->s4_ref_lim_v                                = (FIX_fromfloat(CP_LIMIT_V * PU_SF_VOLTAGE,
                                                                           MTR_Q_VOLTAGE));            /* PU */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    p_st_120->st_speed.st_hall_speed.s4_ref_v_start       = FIX_fromfloat(CP_START_REF_V * PU_SF_VOLTAGE,
                                                                          MTR_Q_VOLTAGE);              /* PU */
    p_st_120->st_speed.s4_ramp_lim_v                      = FIX_fromfloat(CP_RAMP_LIMIT_V_HALL * PU_SF_VOLTAGE,
                                                                          MTR_Q_VOLTAGE);              /* PU */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    p_st_120->st_speed.st_hall_speed.s4_ref_idc_start     = FIX_fromfloat(CP_START_REF_IDC * PU_SF_CURRENT,
                                                                          MTR_Q_CURRENT);              /* PU */
#endif

#elif (LESS == MTRCONF_SENSOR_MODE)
    p_st_120->st_carrier.st_less_carrier.u1_flg_pattern_change  = MTR_CLR;
    p_st_120->st_carrier.st_less_carrier.u1_bemf_signal         = 0;
    p_st_120->st_carrier.st_less_carrier.u1_pre_bemf_signal     = 0;
    p_st_120->u1_state_drive                                    = MTR_DRIVE_INIT;
    p_st_120->u1_state_ctrl_mode                                = MTR_CTRL_OPL_DRAWIN;

    p_st_120->st_carrier.st_less_carrier.u4_speed_cnt_ol        = 0;
    p_st_120->st_carrier.st_less_carrier.u4_pattern_period_ol   = 0;
    p_st_120->st_speed.st_less_speed.u4_cnt_draw_in             = 0;

    p_st_120->s4_ref_lim_v  = (FIX_fromfloat(CP_LIMIT_V * PU_SF_VOLTAGE, MTR_Q_VOLTAGE));              /* PU */
    p_st_120->s4_lim_v      = 0;                                                                       /* PU */

    p_st_120->s4_ref_v_ctrl = 0;                                                                       /* PU */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    p_st_120->st_speed.st_less_speed.s4_ref_v_draw_in  = FIX_fromfloat(CP_DRAW_IN_REF_V * PU_SF_VOLTAGE,
                                                                       MTR_Q_VOLTAGE);                /* PU */
    p_st_120->st_speed.s4_ramp_lim_v                   = FIX_fromfloat(CP_RAMP_LIMIT_V_LESS * PU_SF_VOLTAGE,
                                                                       MTR_Q_VOLTAGE);                /* PU */
    p_st_120->st_speed.s4_ref_v                        = p_st_120->st_speed.st_less_speed.s4_ref_v_draw_in;                                       /* PU */
    p_st_120->st_speed.st_less_speed.u4_v_const_period = (uint16_t)(p_st_120->st_speed.st_less_speed.s4_ref_v_draw_in
                                                                    / p_st_120->st_speed.s4_ramp_lim_v);
                                                                                                      /* PU */
    p_st_120->st_speed.st_less_speed.s4_ref_v_ol       = FIX_fromfloat(CP_OL_REF_V * PU_SF_VOLTAGE,
                                                                       MTR_Q_VOLTAGE);                /* PU */
    p_st_120->st_speed.st_less_speed.s4_ref_v_buff_ol  = FIX_fromfloat(CP_OL_REF_V * PU_SF_VOLTAGE,
                                                                       MTR_Q_VOLTAGE);                /* PU */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    p_st_120->st_speed.st_less_speed.u4_idc_const_period     = (uint32_t)(
                                                                   p_st_120->st_speed.st_less_speed.s4_ref_idc_draw_in
                                                                   / p_st_120->st_acr.s4_ramp_lim_current);
                                                                                                      /* PU */
    p_st_120->st_speed.st_less_speed.s4_ref_idc_draw_in      = FIX_fromfloat(CP_DRAW_IN_REF_IDC * PU_SF_CURRENT,
                                                                             MTR_Q_CURRENT);          /* PU */

    p_st_120->st_speed.s4_ref_idc                            = p_st_120->st_speed.st_less_speed.s4_ref_idc_draw_in;
                                                                                                      /* PU */
    p_st_120->s4_ref_idc_ctrl                                = 0;                                     /* PU */
    p_st_120->st_speed.st_less_speed.s4_ref_idc_ol           = FIX_fromfloat(CP_OL_REF_IDC * PU_SF_CURRENT,
                                                                             MTR_Q_CURRENT);          /* PU */
    p_st_120->st_speed.st_less_speed.s4_ref_idc_buff_ol      = FIX_fromfloat(CP_OL_REF_IDC * PU_SF_CURRENT,
                                                                             MTR_Q_CURRENT);          /* PU */
#endif

    p_st_120->st_carrier.st_less_carrier.u2_v_pattern_ol         = 0;
    p_st_120->st_carrier.st_less_carrier.u2_v_pattern_num_ol     = MTR_DRAW_IN_2ND_PATTERN;
    p_st_120->st_carrier.st_less_carrier.u4_bemf_delay           = 0;

    p_st_120->st_speed.st_less_speed.s4_speed_cl2ol_th           = FIX_fromfloat(
                                                                    (CP_OL2CL_SPEED_RPM - CP_CL2OL_SPEED_MARGIN)
                                                                     * PU_SF_RPM_RAD, MTR_Q_AFREQ);   /* PU */
    p_st_120->st_carrier.st_less_carrier.s2_ad_vu                = 0;
    p_st_120->st_carrier.st_less_carrier.s2_ad_vv                = 0;
    p_st_120->st_carrier.st_less_carrier.s2_ad_vw                = 0;
    p_st_120->st_carrier.st_less_carrier.s2_ad_vn                = 0;
    p_st_120->st_carrier.st_less_carrier.s2_ad_vn_ctrl           = 0;
    p_st_120->st_less_control.s4_angle_shift_adjust              = 0;
    p_st_120->st_speed.s4_ramp_lim_speed                         = FIX_fromfloat(
                                                                    CP_RAMP_LIMIT_SPEED_RPM_LESS * PU_SF_RPM_RAD,
                                                                    MTR_Q_AFREQ);                     /* PU */
    p_st_120->st_carrier.st_less_carrier.u4_zerocross_filter_cnt = (uint32_t)(
                                                                    (MTR_SPEED_CALC_TIMER_FREQ * 1000)
                                                                     / (float)p_st_120->st_speed.s4_ramp_lim_speed);

    /* Structure for transition from openloop drive into sensorless control */
    p_st_120->st_less_control.st_ol2cl.u1_flg_change         = MTR_CLR;
    p_st_120->st_less_control.st_ol2cl.u1_flg_change_speed   = MTR_CLR;
    p_st_120->st_less_control.st_ol2cl.u1_flg_zc             = MTR_CLR;
    p_st_120->st_less_control.st_ol2cl.u1_rotor_pos          = MTR_PHASE_LEAD;
    p_st_120->st_less_control.st_ol2cl.u2_zc_cnt             = 0;
    p_st_120->st_less_control.st_ol2cl.s4_change_speed       = FIX_fromfloat(CP_OL2CL_SPEED_RPM * PU_SF_RPM_RAD,
                                                                             MTR_Q_AFREQ);            /* PU */
    p_st_120->st_less_control.st_ol2cl.s4_ref_speed_buff     = FIX_fromfloat(CP_OL2CL_SPEED_RPM * PU_SF_RPM_RAD,
                                                                             MTR_Q_AFREQ);            /* PU */
    p_st_120->st_less_control.st_ol2cl.s4_ramp_speed         = FIX_fromfloat(CP_OL2CL_SPEED_RAMP_RPM * PU_SF_RPM_RAD,
                                                                             MTR_Q_AFREQ);            /* PU */

    p_st_120->st_carrier.st_less_carrier.u1_flg_pattern_change_ol  = MTR_CLR;

    p_st_120->st_speed.st_less_speed.s4_ramp_lim_v_ol        = p_st_120->s4_ref_lim_v
                                                                 / (p_st_120->st_less_control.st_ol2cl.s4_change_speed
                                                                        / p_st_120->st_speed.s4_ramp_lim_speed);
#endif /* #if (LESS == MTRCONF_SENSOR_MODE) */

    p_st_120->st_carrier.u4_ad_offset_idc       = 0;
    p_st_120->st_carrier.u4_offset_calc_cnt     = CP_OFFSET_CALC_CNT;
    p_st_120->st_carrier.u4_offset_sample_cnt   = 0;

    /* Motor parameter structure */
    p_st_120->st_carrier.st_motor.u2_mtr_pp      = MP_POLE_PAIRS;
    p_st_120->st_carrier.st_motor.s4_mtr_r       = FIX_fromfloat((MP_RESISTANCE * PU_SF_RES),
                                                                 MTR_Q_RESISTANCE);                   /* PU */
    p_st_120->st_carrier.st_motor.s4_mtr_ld      = FIX_fromfloat((MP_D_INDUCTANCE * PU_SF_IND),
                                                                 MTR_Q_INDUCTANCE);                   /* PU */
    p_st_120->st_carrier.st_motor.s4_mtr_lq      = FIX_fromfloat((MP_Q_INDUCTANCE * PU_SF_IND),
                                                                 MTR_Q_INDUCTANCE);                   /* PU */
    p_st_120->st_carrier.st_motor.s4_mtr_ke      = FIX_fromfloat((MP_BEMF_CONSTANT * PU_SF_BEMF_CONST),
                                                                 MTR_Q_BEMF_CONST);                   /* PU */
    p_st_120->st_carrier.st_motor.s4_mtr_j       = FIX_fromfloat((MP_ROTOR_INERTIA * PU_SF_INERTIA),
                                                                 MTR_Q_INERTIA);                      /* PU */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    /* PI control structure */
    /*Speed PI controller */
    p_st_120->st_speed.st_voltage_asr.st_pi.s4_kp         = 0;
    p_st_120->st_speed.st_voltage_asr.st_pi.s4_kidt       = 0;
    p_st_120->st_speed.st_voltage_asr.st_pi.s4_max_intg   = FIX_fromfloat(MTR_I_LIMIT_VQ * PU_SF_VOLTAGE,
                                                                          MTR_Q_VOLTAGE);
    p_st_120->st_speed.st_voltage_asr.st_pi.s4_decimal    = 0;
    p_st_120->st_speed.st_voltage_asr.s4_lim_asr_err      = 0;
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    /* Initialize current PI controllers, gains will be calculated */
    /* Current PI controller */
    p_st_120->st_acr.st_pi.s4_kp                          = 0;
    p_st_120->st_acr.st_pi.s4_kidt                        = 0;
    p_st_120->st_acr.st_pi.s4_max_intg                    = FIX_fromfloat(MTR_I_LIMIT_VQ * PU_SF_VOLTAGE,
                                                                          MTR_Q_VOLTAGE);
    p_st_120->st_acr.st_pi.s4_decimal                     = 0;
    /*Speed PI controller */
    p_st_120->st_speed.st_current_asr.st_pi.s4_kp         = 0;
    p_st_120->st_speed.st_current_asr.st_pi.s4_kidt       = 0;
    p_st_120->st_speed.st_current_asr.st_pi.s4_max_intg   = FIX_fromfloat(MTR_I_LIMIT_CURRENT * PU_SF_CURRENT,
                                                                          MTR_Q_CURRENT);
    p_st_120->st_speed.st_current_asr.st_pi.s4_decimal    = 0;
    p_st_120->st_speed.st_current_asr.s4_lim_asr_err      = 0;
#endif

    p_st_120->u2_error_status = MTR_ERROR_NONE;
} /* End of function RM_MTR_120MotorDefaultInit */

/***********************************************************************************************************************
* @fn             RM_MTR_120MotorReset
* @brief          Reset motor drive modules
* @param[in,out]  p_st_120        A pointer to 120-degree control
***********************************************************************************************************************/
void RM_MTR_120MotorReset(st_mtr_120_control_t *p_st_120)
{
    /* 120 degree control structure */
    p_st_120->s1_dir                         = p_st_120->s1_ref_dir;
    p_st_120->u1_flg_pattern_error           = MTR_CLR;
    p_st_120->u1_first_rotation_cnt          = MTR_PATTERN_NUM;
    p_st_120->u1_v_pattern_ring_buff         = 0;

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    p_st_120->u2_state_ref_voltage           = MTR_REF_ZERO_CONST;
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    p_st_120->u2_state_ref_current           = MTR_REF_ZERO_CONST;
#endif

    p_st_120->u2_state_ref_speed             = MTR_SPEED_ZERO_CONST;
    p_st_120->u1_flg_offset_end              = MTR_CLR;
    p_st_120->u4_speed_timer_cnt             = 0;
    p_st_120->u4_pre_speed_timer_cnt         = 0;
    p_st_120->u4_timer_cnt_buff[0]           = 0;
    p_st_120->u4_timer_cnt_buff[1]           = 0;
    p_st_120->u4_timer_cnt_buff[2]           = 0;
    p_st_120->u4_timer_cnt_buff[3]           = 0;
    p_st_120->u4_timer_cnt_buff[4]           = 0;
    p_st_120->u4_timer_cnt_buff[5]           = 0;
    p_st_120->u4_timer_cnt_sum               = 0;
    p_st_120->u2_v_pattern                   = 0;
    p_st_120->u2_pwm_duty                    = 0;
    p_st_120->u4_cnt_timeout                 = 0;

    p_st_120->s4_speed                       = 0;                                                 /* PU */
    p_st_120->s4_ref_speed_ctrl              = 0;                                                 /* PU */

    p_st_120->u2_error_status                = MTR_ERROR_NONE;
    
    p_st_120->u1_state_drive                 = MTR_STOP;
    p_st_120->u1_state_ctrl_mode             = MTR_CTRL_NONE;

#if (HALL == MTRCONF_SENSOR_MODE)
    /* Hall-effect-sensor control structure */
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    p_st_120->st_speed.s4_ref_v              = p_st_120->st_speed.st_hall_speed.s4_ref_v_start;   /* PU */
    p_st_120->s4_ref_v_ctrl                  = p_st_120->st_speed.st_hall_speed.s4_ref_v_start;   /* PU */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    p_st_120->st_speed.s4_ref_idc            = p_st_120->st_speed.st_hall_speed.s4_ref_idc_start; /* PU */
    p_st_120->s4_ref_idc_ctrl                = p_st_120->st_speed.st_hall_speed.s4_ref_idc_start; /* PU */
#endif

    p_st_120->st_speed.st_hall_speed.u2_hall_signal               = 0;
    p_st_120->st_speed.st_hall_speed.u1_flg_1st_interrupt         = MTR_SET;

#elif (LESS == MTRCONF_SENSOR_MODE)
    p_st_120->st_carrier.st_less_carrier.u1_flg_pattern_change    = MTR_CLR;
    p_st_120->st_carrier.st_less_carrier.u1_bemf_signal           = 0;
    p_st_120->st_carrier.st_less_carrier.u1_pre_bemf_signal       = 0;
    p_st_120->u1_state_ctrl_mode                                  = MTR_CTRL_OPL_DRAWIN;
    p_st_120->u1_state_drive                                      = MTR_DRIVE_INIT;

    p_st_120->st_carrier.st_less_carrier.u4_speed_cnt_ol          = 0;
    p_st_120->st_carrier.st_less_carrier.u4_pattern_period_ol     = 0;
    p_st_120->st_speed.st_less_speed.u4_cnt_draw_in               = 0;
    p_st_120->st_carrier.st_less_carrier.u2_v_pattern_ol          = 0;
    p_st_120->st_carrier.st_less_carrier.u2_v_pattern_num_ol      = MTR_DRAW_IN_2ND_PATTERN;
    p_st_120->st_carrier.st_less_carrier.u4_bemf_delay            = 0;

    p_st_120->st_carrier.st_less_carrier.s2_ad_vu                 = 0;
    p_st_120->st_carrier.st_less_carrier.s2_ad_vv                 = 0;
    p_st_120->st_carrier.st_less_carrier.s2_ad_vw                 = 0;
    p_st_120->st_carrier.st_less_carrier.s2_ad_vn                 = 0;
    p_st_120->st_carrier.st_less_carrier.s2_ad_vn_ctrl            = 0;
    p_st_120->st_less_control.s2_ad_vn_offset                     = 0;
    p_st_120->st_less_control.s4_angle_shift_adjust               = 0;

    p_st_120->st_carrier.st_less_carrier.u1_flg_pattern_change_ol = MTR_CLR;
    p_st_120->st_carrier.st_less_carrier.u4_zerocross_filter_cnt  = (uint32_t)((MTR_SPEED_CALC_TIMER_FREQ * 1000)
                                                                      / (float)p_st_120->st_speed.s4_ramp_lim_speed);


    p_st_120->s4_ref_v_ctrl                                  = 0;                                          /* PU */
    p_st_120->s4_lim_v                                       = 0;                                          /* PU */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    p_st_120->st_speed.s4_ref_v                              = p_st_120->st_speed.st_less_speed.s4_ref_v_draw_in;
                                                                                                           /* PU */
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    p_st_120->st_speed.s4_ref_idc                            = p_st_120->st_speed.st_less_speed.s4_ref_idc_draw_in;
                                                                                                           /* PU */
    p_st_120->s4_ref_idc_ctrl                                = 0;                                          /* PU */
#endif

    /* Structure for transition from open-loop drive to sensorless control */
    p_st_120->st_less_control.st_ol2cl.u1_flg_change         = MTR_CLR;
    p_st_120->st_less_control.st_ol2cl.u1_flg_change_speed   = MTR_CLR;
    p_st_120->st_less_control.st_ol2cl.u1_flg_zc             = MTR_CLR;
    p_st_120->st_less_control.st_ol2cl.u1_rotor_pos          = MTR_PHASE_LEAD;
    p_st_120->st_less_control.st_ol2cl.u2_zc_cnt             = 0;
    p_st_120->st_less_control.st_ol2cl.s4_ref_speed_buff     = p_st_120->st_less_control.st_ol2cl.s4_change_speed;
                                                                                                           /* PU */

#endif /* #if (LESS == MTRCONF_SENSOR_MODE) */

#if (VOLTAGE == MTRCONF_CONTROL_MODE)
    /* PI control structure */
    p_st_120->st_speed.st_voltage_asr.s4_pre_speed     = 0;                                                /* PU */
    p_st_120->st_speed.st_voltage_asr.st_pi.s4_decimal = 0;
#elif (CURRENT == MTRCONF_CONTROL_MODE)
    /* Initialize current PI controllers, gains will be calculated RM_MTR_CtrlGain */
    p_st_120->st_acr.st_pi.s4_decimal                  = 0;
    p_st_120->st_speed.st_current_asr.st_pi.s4_decimal = 0;
#endif
} /* End of function RM_MTR_120MotorReset */
