/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_ol2cl_ctrl.c
* Description : The processes of Open-loop to Closed-loop switch control
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "rm_mtr_common.h"
#include "r_mtr_config.h"
#include "r_mtr_ra2t1.h"
#include "rm_mtr_120.h"
#include "rm_mtr_ol2cl_ctrl.h"

#if (LESS == MTRCONF_SENSOR_MODE)
/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Private functions definitions
***********************************************************************************************************************/
static inline int16_t mtr_get_bemf_voltage(int8_t s1_dir, uint16_t u2_ol_v_pattern, int16_t *s2_v_uvwn_ad);
static inline void mtr_openloop_phase_ctrl(st_mtr_ol2cl_t *p_st_ol2cl, int8_t s1_dir, uint16_t u2_ol_v_pattern,
                                            int16_t *p_s2_v_uvwn_ad);
static inline int16_t mtr_abs(int16_t s2_value);

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* @fn             R_MTR_OL2CLCtrl
* @brief          Change the current mode from open-loop drive to sensor-less control
* @param[in,out]  p_st_ol2cl                A pointer to parameters of a transition from open-loop drive mode
*                                           to sensor-less control one
* @param[in]      s2_v_uvwn_ad              An array of 3-phase and neutral voltages
* @param[in]      s1_dir                    A rotational direction
* @param[in]      u2_cnt_ol_speed           A clock count between patterns in open-loop drive mode
* @param[in]      u1_flag_pattern_change    A flag of voltage pattern changed
* @param[in]      u2_ol_pattern_period      A calculated period between patterns in open-loop drive mode
* @param[in]      u2_ol_v_pattern           A voltage pattern in open-loop drive mode
***********************************************************************************************************************/
void R_MTR_OL2CLCtrl(st_mtr_ol2cl_t *p_st_ol2cl, int16_t *s2_v_uvwn_ad, int8_t s1_dir, uint32_t u4_cnt_ol_speed,
                        uint8_t u1_flag_pattern_change, uint32_t u4_ol_pattern_period, uint16_t u2_ol_v_pattern)
{
    int16_t s2_bemf_voltage;

    /* Judge whether BEMF voltage exceeds threshold voltage */
    if ((MTR_CLR == p_st_ol2cl->u1_flg_change)
        && (MTR_SET == p_st_ol2cl->u1_flg_change_speed))
    {
       if (CP_SKIP_SPIKE_NOISE < u4_cnt_ol_speed)
       {
            /* Calculate BEMF voltage */
            s2_bemf_voltage = mtr_abs(mtr_get_bemf_voltage(s1_dir, u2_ol_v_pattern, s2_v_uvwn_ad) - s2_v_uvwn_ad[3]);

            /* If BEMF voltage is over threshold voltage, u1_flag_change is set*/
            if ((MTR_OL2CL_BEMF_THRESH * 3) < s2_bemf_voltage)
            {
                p_st_ol2cl->u1_flg_change = MTR_SET;
                p_st_ol2cl->s4_ref_speed_buff = p_st_ol2cl->s4_change_speed;
            }
        }
    }

    if (MTR_SET == p_st_ol2cl->u1_flg_change)
    {
        /* Detect zero-cross while avoiding influence of computation */
        if (CP_SKIP_SPIKE_NOISE < u4_cnt_ol_speed)
        {
            if (MTR_SET == u1_flag_pattern_change)
            {
                p_st_ol2cl->u1_flg_zc = MTR_SET;
                p_st_ol2cl->u2_zc_cnt++;
            }
        }

        /* Adjust phase of rotor to detect zero-cross*/
        if ((u4_ol_pattern_period >> 1) == u4_cnt_ol_speed)
        {
            mtr_openloop_phase_ctrl(p_st_ol2cl, s1_dir, u2_ol_v_pattern, s2_v_uvwn_ad);
        }
    }
} /* End of function R_MTR_OL2CLCtrl */

/***********************************************************************************************************************
* @fn             mtr_get_bemf_voltage
* @brief          Get a BEMF voltage
* @param[in]      s1_dir            A rotational direction
* @param[in]      u2_ol_v_pattern   A voltage pattern in open-loop drive mode
* @param[in]      s2_v_uvwn_ad      An array of 3-phase and neutral voltages
* @return           A BEMF voltage
***********************************************************************************************************************/
static inline int16_t mtr_get_bemf_voltage(int8_t s1_dir, uint16_t u2_ol_v_pattern, int16_t *s2_v_uvwn_ad)
{
    int16_t s2_bemf_voltage = 0;

    /* Extract BEMF voltage depending on voltage pattern */
    if (MTR_CW == s1_dir)
    {
        switch (u2_ol_v_pattern)
        {
            case MTR_PATTERN_CW_W_V:
            case MTR_PATTERN_CW_V_W:
                s2_bemf_voltage = s2_v_uvwn_ad[0];     /* U phase has no output */
                break;

            case MTR_PATTERN_CW_U_W:
            case MTR_PATTERN_CW_W_U:
                s2_bemf_voltage = s2_v_uvwn_ad[1];     /* V phase has no output */
                break;

            case MTR_PATTERN_CW_U_V:
            case MTR_PATTERN_CW_V_U:
                s2_bemf_voltage = s2_v_uvwn_ad[2];     /* W phase has no output */
                break;

            default:
                /* Do nothing */
                break;
        }
    }
    else
    {
        switch (u2_ol_v_pattern)
        {
            case MTR_PATTERN_CCW_V_W:
            case MTR_PATTERN_CCW_W_V:
                s2_bemf_voltage = s2_v_uvwn_ad[0];     /* U phase has no output */
                break;

            case MTR_PATTERN_CCW_U_W:
            case MTR_PATTERN_CCW_W_U:
                s2_bemf_voltage = s2_v_uvwn_ad[1];     /* V phase has no output */
                break;

            case MTR_PATTERN_CCW_U_V:
            case MTR_PATTERN_CCW_V_U:
                s2_bemf_voltage = s2_v_uvwn_ad[2];     /* W phase has no output */
                break;

            default:
                /* Do nothing */
                break;
        }
    }

    return (s2_bemf_voltage);
} /* End of function mtr_get_bemf_voltage */

/***********************************************************************************************************************
* @fn             mtr_openloop_phase_ctrl
* @brief          Control position of a rotor to detect zero-cross
* @param[in,out]  p_st_ol2cl        A pointer to parameters of a transition from open-loop drive mode
*                                   to sensor-less control one
* @param[in]      s1_dir            A rotational direction
* @param[in]      u2_ol_v_pattern   A voltage pattern in open-loop drive mode
* @param[in]      s2_v_uvwn_ad      An array of 3-phase and neutral voltages
***********************************************************************************************************************/
static inline void mtr_openloop_phase_ctrl(st_mtr_ol2cl_t *p_st_ol2cl, int8_t s1_dir, uint16_t u2_ol_v_pattern,
                                            int16_t *s2_v_uvwn_ad)
{
    int16_t s2_bemf_temp;

    s2_bemf_temp = mtr_get_bemf_voltage(s1_dir, u2_ol_v_pattern, s2_v_uvwn_ad);

    /* Detect whether phase of rotor is advanced or delayed */
    if (MTR_CW == s1_dir)
    {
        switch (u2_ol_v_pattern)
        {
            /* bemf increasing */
            case MTR_PATTERN_CW_V_U:
            case MTR_PATTERN_CW_W_V:
            case MTR_PATTERN_CW_U_W:
                if (s2_bemf_temp > s2_v_uvwn_ad[3])
                {
                    p_st_ol2cl->u1_rotor_pos = MTR_PHASE_LEAD;   /* Leading phase */
                }
                else if (s2_bemf_temp < s2_v_uvwn_ad[3])
                {
                    p_st_ol2cl->u1_rotor_pos = MTR_PHASE_LAG;   /* Lagged phase */
                }
                else
                {
                    /* Do nothing */
                }
                break;
            /* bemf decreasing */
            case MTR_PATTERN_CW_W_U:
            case MTR_PATTERN_CW_U_V:
            case MTR_PATTERN_CW_V_W:
                if (s2_bemf_temp < s2_v_uvwn_ad[3])
                {
                    p_st_ol2cl->u1_rotor_pos = MTR_PHASE_LEAD;    /* Leading phase */
                }
                else if (s2_bemf_temp > s2_v_uvwn_ad[3])
                {
                    p_st_ol2cl->u1_rotor_pos = MTR_PHASE_LAG;    /* Lagged phase */
                }
                else
                {
                    /* Do nothing */
                }
                break;

            default:
                /* Do nothing */
                break;
        }
    }
    else
    {
        switch (u2_ol_v_pattern)
        {
            case MTR_PATTERN_CCW_W_V:
            case MTR_PATTERN_CCW_V_U:
            case MTR_PATTERN_CCW_U_W:
                if (s2_bemf_temp > s2_v_uvwn_ad[3])
                {
                    p_st_ol2cl->u1_rotor_pos = MTR_PHASE_LAG;     /* Lagged phase */
                } 
                else if (s2_bemf_temp < s2_v_uvwn_ad[3])
                {
                    p_st_ol2cl->u1_rotor_pos = MTR_PHASE_LEAD;     /* Leadinb phase */
                }
                break;

            case MTR_PATTERN_CCW_V_W:
            case MTR_PATTERN_CCW_W_U:
            case MTR_PATTERN_CCW_U_V:
                if (s2_bemf_temp < s2_v_uvwn_ad[3])
                {
                    p_st_ol2cl->u1_rotor_pos = MTR_PHASE_LAG;     /* Lagged phase */
                }
                else if (s2_bemf_temp > s2_v_uvwn_ad[3])
                {
                    p_st_ol2cl->u1_rotor_pos = MTR_PHASE_LEAD;     /* Leading phase */
                }
                break;

            default:
                /* Do nothing */
                break;
        }
    }
} /* End of function mtr_openloop_phase_ctrl */

/***********************************************************************************************************************
* @fn             mtr_abs
* @brief          Get the absolute value
* @param[in]      s2_value      A target value
* @return           The absolute value
***********************************************************************************************************************/
int16_t mtr_abs(int16_t s2_value)
{
    int16_t s2_temp;

    s2_temp = s2_value;

    /* Keep s2_value as positive */
    if (0 > s2_temp)
    {
        s2_temp = -s2_temp;
    }

    return (s2_temp);

} /* End of function mtr_abs */

/***********************************************************************************************************************
* @fn             R_MTR_BemfSignalFilter
* @brief          Filter a BEMF signal
* @param[in,out]  p_st_ol2cl                    A pointer to parameters of a transition from open-loop drive mode
*                                               to sensor-less control one
* @param[in]      u2_cnt_ol_speed               A clock count between patternS in open-loop drive mode
* @param[in,out]  p_u1_pre_bemf_signal          A pointer to the previous estimated pattern of a BEMF signal
* @param[in]      u2_temp_signal                A  temporary pattern of a BEMF signal
* @param[in]      u1_flag_ol patterrn_change    A flag of pattern changed in open-loop drive mode
* @return           The temporary pattern of a BEMF signal
***********************************************************************************************************************/
uint8_t R_MTR_BemfSignalFilter(st_mtr_ol2cl_t *p_st_ol2cl, uint32_t u4_cnt_ol_speed, uint8_t *p_u1_pre_bemf_signal,
                                                      uint8_t u1_temp_signal, uint8_t u1_flag_ol_pattern_change)
{
    /* Transition the current mode from open-loop drive to sensor-less control*/
    if (MTR_SET == p_st_ol2cl->u1_flg_change)
    {
        /* Prepare to detect zero-cross just after speed changed */
        if (CP_SKIP_SPIKE_NOISE == u4_cnt_ol_speed)
        {
            *p_u1_pre_bemf_signal = u1_temp_signal;

            /* Update state of zero-cross flag or zero-cross count */
            if (MTR_SET == p_st_ol2cl->u1_flg_zc)
            {
                p_st_ol2cl->u1_flg_zc = MTR_CLR;
            }
            else
            {
                p_st_ol2cl->u2_zc_cnt = 0;
            }
        }

        /* When zero-cross flag is set, filter the BEMF signal */
        if (MTR_SET == p_st_ol2cl->u1_flg_zc)
        {
            u1_temp_signal = *p_u1_pre_bemf_signal;
        }
    }
    else if ((MTR_CLR == p_st_ol2cl->u1_flg_change_speed) && (MTR_SET == u1_flag_ol_pattern_change))
    {
        /* Open-loop drive mode */
        /* filter the BEMF signal just after speed changed */
        if (CP_SKIP_SPIKE_NOISE > u4_cnt_ol_speed)
        {
            u1_temp_signal = *p_u1_pre_bemf_signal;
        }
        else
        {
            /* do nothing */
        }
    }
    return (u1_temp_signal);
} /* End of function R_MTR_BemfSignalFilter */

/***********************************************************************************************************************
* @fn             R_MTR_SetSpeedRefOL2CL
* @brief          Set the reference speed for sensor-less control mode
* @param[in,out]  p_st_ol2cl                A pointer to parameters of a transition from open-loop drive mode
*                                           to sensor-less control one
* @param[in]      s1_dir                    A rotational direction
* @param[out]     s4_ref_speed_rad_ctrl     A pointer to an area of the reference speed for for sensor-less control mode
***********************************************************************************************************************/
void R_MTR_SetSpeedRefOL2CL(st_mtr_ol2cl_t *p_st_ol2cl, int8_t s1_dir, int32_t *p_s4_ref_speed_rad_ctrl)
{
    p_st_ol2cl->u1_flg_change_speed = MTR_SET;

    /* Set reference speed at transition from open-loop drive to sensor-less control */
    if (MTR_PHASE_LEAD == p_st_ol2cl->u1_rotor_pos)
    {
        p_st_ol2cl->s4_ref_speed_buff += p_st_ol2cl->s4_ramp_speed;
    }
    else
    {
        p_st_ol2cl->s4_ref_speed_buff -= p_st_ol2cl->s4_ramp_speed;
    }

    /* Set reference speed while trying to detect zero-cross */
    if (MTR_CW == s1_dir)
    {
        *p_s4_ref_speed_rad_ctrl = p_st_ol2cl->s4_ref_speed_buff;
    }
    else
    {
        *p_s4_ref_speed_rad_ctrl = -p_st_ol2cl->s4_ref_speed_buff;
    }
} /*End of function R_MTR_SetSpeedRefOL2CL */

#endif /* #if(LESS == MTRCONF_SENSOR_MODE) */
