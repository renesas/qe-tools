/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_ol2cl_ctrl.h
* Description : Definitions of Open-loop to Closed-loop switch control
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef RM_MTR_OL2CL_CTRL_H
#define RM_MTR_OL2CL_CTRL_H

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_mtr_common.h"
#include "r_mtr_config.h"

#if (LESS == MTRCONF_SENSOR_MODE)
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Phase of rotor for open-loop */
#define     MTR_PHASE_LEAD                 (0)     /* Leading phase */
#define     MTR_PHASE_LAG                  (1)     /* Lagged phase */
#if (VOLTAGE == MTRCONF_CONTROL_MODE)
#define     MTR_1ST_ZC_CNT                 (1)     /* First zero-cross detected during transition */
#endif

/***********************************************************************************************************************
Global structure / type definitions
***********************************************************************************************************************/
/* Structure for transition from open-loop drive into sensor-less control */
typedef struct
{
    uint8_t     u1_flg_change;                 /* Transition into sensor-less control flag */
    uint8_t     u1_flg_change_speed;           /* Exceed change_speed_rad flag */
    uint8_t     u1_flg_zc;                     /* Zero-cross flag */
    uint8_t     u1_rotor_pos;                  /* Position of rotor : advanced / delayed */
    uint16_t    u2_zc_cnt;                     /* Counter for zero-cross */
    int32_t     s4_change_speed;               /* Speed allowed to transition into sensor-less control [PU] */
    int32_t     s4_ref_speed_buff;             /* Reference speed buffer [PU] */
    int32_t     s4_ramp_speed;                 /* Acceleration at transition into sensor-less control [PU] */
} st_mtr_ol2cl_t;

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
void R_MTR_OL2CLCtrl(st_mtr_ol2cl_t *p_st_ol2cl, int16_t *s2_v_uvwn_ad, int8_t s1_dir, uint32_t u4_cnt_ol_speed,
                        uint8_t u1_flag_pattern_change, uint32_t u4_ol_pattern_period, uint16_t u2_ol_v_pattern);
uint8_t R_MTR_BemfSignalFilter(st_mtr_ol2cl_t *p_st_ol2cl, uint32_t u4_cnt_ol_speed, uint8_t *p_u1_pre_bemf_signal,
                                uint8_t u1_temp_signal,  uint8_t u1_flag_ol_pattern_change);
void R_MTR_SetSpeedRefOL2CL(st_mtr_ol2cl_t *p_st_ol2cl, int8_t s1_dir, int32_t *p_s4_ref_speed_rad_ctrl);

#endif /* #if(LESS == MTRCONF_SENSOR_MODE) */

#endif /* RM_MTR_OL2CL_CTRL_H */
