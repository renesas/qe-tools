/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_statemachine.h
* Description : Definitions of the state machine for motor drive system
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef RM_MTR_STATEMACHINE_H
#define RM_MTR_STATEMACHINE_H

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Drive modes (state) */
#define     MTR_MODE_INIT               (0x00)
#define     MTR_MODE_DRIVE              (0x01)
#define     MTR_MODE_STOP               (0x02)
#define     MTR_SIZE_STATE              (3)                     /* Number of state */

/* Drive mode events */
#define     MTR_EVENT_STOP              (0x00)
#define     MTR_EVENT_DRIVE             (0x01)
#define     MTR_EVENT_ERROR             (0x02)
#define     MTR_EVENT_RESET             (0x03)
#define     MTR_SIZE_EVENT              (4)                     /* Number of event */

/* State machine error flags */
#define     MTR_STATEMACHINE_ERROR_NONE             (0x00)      /* None error flag */
#define     MTR_STATEMACHINE_ERROR_EVENTOUTBOUND    (0x01)      /* The event index is out of bound */
#define     MTR_STATEMACHINE_ERROR_STATEOUTBOUND    (0x02)      /* The state index is out of bound */
#define     MTR_STATEMACHINE_ERROR_ACTIONEXCEPTION  (0x04)      /* The action function returns failure */

/***********************************************************************************************************************
Global structures / type definitions
***********************************************************************************************************************/
/* State machine data structure */
typedef struct
{
    uint8_t       u1_status;                                    /* The current system status */
    uint8_t       u1_status_next;                               /* The next system status */
    uint16_t      u2_status_error;                              /* The error flags of state machine */
    uint8_t       u2_crnt_event;                                /* The current event index */
}st_mtr_statemachine_t;

typedef uint8_t (* mtr_action_t)(st_mtr_statemachine_t * p_state_machine, void * p_params);

/***********************************************************************************************************************
Global function definitions
***********************************************************************************************************************/
void mtr_statemachine_init (st_mtr_statemachine_t * p_state_machine);
void mtr_statemachine_reset (st_mtr_statemachine_t * p_state_machine);
uint8_t mtr_statemachine_event (st_mtr_statemachine_t * p_state_machine, void * p_object, uint8_t u1_event);
uint8_t mtr_statemachine_get_status (st_mtr_statemachine_t * p_state_machine);
uint8_t   mtr_act_none (st_mtr_statemachine_t * p_state_machine, void * p_param);
uint8_t   mtr_act_init (st_mtr_statemachine_t * p_state_machine, void * p_param);
uint8_t   mtr_act_error (st_mtr_statemachine_t * p_state_machine, void * p_param);
uint8_t   mtr_act_drive (st_mtr_statemachine_t * p_state_machine, void * p_param);
uint8_t   mtr_act_stop (st_mtr_statemachine_t * p_state_machine, void * p_params);

#endif /* RM_MTR_STATEMACHINE_H */
