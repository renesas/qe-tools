/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : rm_mtr_common.h
* Description : This header includes common definitions
***********************************************************************************************************************/
/**********************************************************************************************************************
* Version : 1.00
*
***********************************************************************************************************************/
/* guard against multiple inclusion */
#ifndef RM_MTR_COMMON_H
#define RM_MTR_COMMON_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>

/**********************************************************************************************************************
* Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Value for calculation */
#define     MTR_TWOPI                   (2 * 3.14159265359f)      /* 2*pi */
#define     MTR_TWOPI_60                (MTR_TWOPI / 60)          /* 2*pi/60 */
#define     MTR_SQRT_3                  (1.7320508f)              /* sqrt(3) */
#define     MTR_SQRT_2_3                (0.8164966f)              /* sqrt(2/3) */

/* Rotational direction */
#define     MTR_CW                      (1)                       /* Clockwise */
#define     MTR_CCW                     (-1)                      /* Counter-clockwise */

/* NOP wait cnt */
#define     MTR_WAIT_CNT_3US            (20)                      /* Wait 3us */
#define     MTR_WAIT_CNT_5US            (30)                      /* Wait 5us */
#define     MTR_WAIT_CNT_20US           (80)                      /* Wait 20us */
#define     MTR_WAIT_CNT_300US          (1500)                    /* Wait 300us */

/* ADC bit */
#define     MTR_ADC_12BIT               (12)                      /* 12 bit ADC */

#endif /* RM_MTR_COMMON_H */
