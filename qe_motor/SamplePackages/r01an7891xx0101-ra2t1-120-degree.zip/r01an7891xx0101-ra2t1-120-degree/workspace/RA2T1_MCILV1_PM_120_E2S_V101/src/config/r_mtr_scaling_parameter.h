/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025, 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_scaling_parameter.h
* Description : Definitons for per-unit system
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.06.2023 1.00
***********************************************************************************************************************/

#ifndef R_MTR_SCALING_PARAMETER_H
#define R_MTR_SCALING_PARAMETER_H

/**********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <math.h>
#include "r_mtr_common.h"
#include "r_mtr_config.h"

#include "r_mtr_inverter_parameter.h"

/**********************************************************************************************************************
* Typedef definitions
***********************************************************************************************************************/

/**********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Created date : 2025/06/27 */
/*================================*/
/*    Fixed Point Scale Factor    */
/*================================*/
#define FP_SF_VOLTAGE           (822226302)                   /* (IP_VDC_RANGE*PU_SF_VOLTAGE) * (1<<MTR_Q_VOLTAGE) */
#define FP_SF_CURRENT           (3919632764)                  /* (IP_CURRENT_RANGE*PU_SF_CURRENT) * (1<<MTR_Q_CURRENT) */

/*=======================*/
/*    Base Quantities    */
/*=======================*/
#define PU_BASE_CURRENT_A       (MP_RATED_CURRENT)                              /* Base quantity for current */
#define PU_BASE_VOLTAGE_V       (IP_INPUT_V)                                    /* Base quantity for voltage */
#define PU_BASE_FREQ_Hz         (MTR_TWOPI*CP_MAX_SPEED_RPM*MP_POLE_PAIRS/60)   /* Base quantity for frequency */
#define PU_BASE_ANGLE_Rad       (1.0f)                                          /* Base quantity for angle (DO NOT CHANGE) */

/*============================*/
/*    General scale factor    */
/*============================*/
#define PU_SF_CURRENT           (1.0f / PU_BASE_CURRENT_A)                  /* Current scale factor */
#define PU_SF_VOLTAGE           (1.0f / PU_BASE_VOLTAGE_V)                  /* Voltage scale factor */
#define PU_SF_AFREQ             (1.0f / PU_BASE_FREQ_Hz)                    /* Frequency scale factor */
#define PU_SF_ANGLE             (1.0f / PU_BASE_ANGLE_Rad)                  /* Angular frequency scale factor */

#define PU_SF_TIME              (PU_SF_ANGLE / PU_SF_AFREQ)                 /* Time scale factor */
#define PU_SF_RES               (PU_SF_VOLTAGE / PU_SF_CURRENT)             /* Impedance(resistance) scale factor */
#define PU_SF_IND               (PU_SF_RES / PU_SF_AFREQ)                   /* Inductance scale factor */
#define PU_SF_BEMF_CONST        (PU_SF_VOLTAGE / PU_SF_AFREQ)               /* Induced voltage constant scale factor */
#define PU_SF_INERTIA           (PU_SF_BEMF_CONST*PU_SF_CURRENT / (MP_POLE_PAIRS*MP_POLE_PAIRS*PU_SF_AFREQ*PU_SF_AFREQ))/* Inertia scale factor */
#define PU_SF_D1_DIV_P2M        (PU_SF_CURRENT / PU_SF_AFREQ)               /* 1st order friction coefficient term scale factor */
#define PU_SF_RPM_RAD           (1.0f / CP_MAX_SPEED_RPM)                   /* Speed scale factor (rpm to pu) */
#define PU_SF_RAD_RPM           (CP_MAX_SPEED_RPM)                          /* Speed scale factor (pu to rpm) */

#if (MTRCONF_CONTROL_MODE == CURRENT)
/*===========================================*/
/*    Current regulator gain scale factor    */
/*===========================================*/
#define PU_SF_ACR_KP            (PU_SF_RES)/* Proportional gain scale factor of current controller */
#define PU_SF_ACR_KIDT          (PU_SF_RES)/* Integral gain scale factor of current controller */

/*==============================================*/
/*    Auto speed regulator gain scale factor    */
/*==============================================*/
#define PU_SF_ASR_KP            (PU_SF_CURRENT / PU_SF_AFREQ)    /* Proportional gain scale factor of speed controller */
#define PU_SF_ASR_KIDT          (PU_SF_CURRENT / PU_SF_AFREQ)    /* Integral gain scale factor of speed controller */
#endif

#if (MTRCONF_CONTROL_MODE == VOLTAGE)
#define PU_SF_ASR_KP            (PU_SF_VOLTAGE / PU_SF_AFREQ)    /* Proportional gain scale factor of speed controller */
#define PU_SF_ASR_KIDT          (PU_SF_VOLTAGE / PU_SF_AFREQ)    /* Integral gain scale factor of speed controller */
#endif

/* Basic physical quantities */
/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#define MTR_Q_ANGLE             (28)           /* Q-format of angle */
#define MTR_Q_CURRENT           (28)           /* Q-format of current */
#define MTR_Q_VOLTAGE           (28)           /* Q-format of voltage */
#define MTR_Q_AFREQ             (28)           /* Q-format of angular frequency */

#define MTR_Q_CTRL_TIME_SPEED   (30)           /* Q-format of control execution period */
#define MTR_Q_RESISTANCE        (33)           /* Q-format of resistance */
#define MTR_Q_INDUCTANCE        (34)           /* Q-format of inductance */
#define MTR_Q_BEMF_CONST        (31)           /* Q-format of back-EMF constant */
#define MTR_Q_INERTIA           (27)           /* Q-format of inertia */
#define MTR_Q_D1_DIV_P2M        (37)           /* Q-format of 1st order fric-coef / (pole pairs * pole pairs * BEMF-const) */

#if (MTRCONF_SENSOR_MODE == HALL)

#if (MTRCONF_CONTROL_MODE == CURRENT)
#define MTR_Q_ACR_KP            (32)           /* Q-format of PI proportional gain for ACR */
#define MTR_Q_ACR_KIDT          (37)           /* Q-format of PI (integral gain) * (sampling period) for ACR */
#define MTR_Q_ACR_ERR           (23)           /* Q-format of PI err for ACR */
#define MTR_Q_ACR_INTG          (12)           /* Q-format of PI Integral for ACR */
#define MTR_Q_ASR_KP            (30)           /* Q-format of PI proportional gain for ASR */
#define MTR_Q_ASR_KIDT          (38)           /* Q-format of PI (integral gain) * (sampling period) for ASR */
#define MTR_Q_ASR_ERR           (22)           /* Q-format of PI err for ASR */
#define MTR_Q_ASR_INTG          (12)           /* Q-format of PI Integral for ASR */

#endif /* #if (MTRCONF_CONTROL_MODE == CURRENT) */

#if (MTRCONF_CONTROL_MODE == VOLTAGE)
#define MTR_Q_ASR_KP            (33)           /* Q-format of PI proportional gain for ASR */
#define MTR_Q_ASR_KIDT          (36)           /* Q-format of PI (integral gain) * (sampling period) for ASR */
#define MTR_Q_ASR_ERR           (25)           /* Q-format of PI err for ASR */
#define MTR_Q_ASR_INTG          (12)           /* Q-format of PI Integral for ASR */

/* Number of bits to right shift, V = (KP * omega) >> (rsft) */
#define RSFT_AFREQ_KP_2VOLTAGE    (MTR_Q_ASR_KP + MTR_Q_AFREQ - MTR_Q_VOLTAGE)
/* Number of bits to right shift, V = (KIDT * omega) >> (rsft) */
#define RSFT_AFREQ_KIDT_2VOLTAGE  (MTR_Q_ASR_KIDT + MTR_Q_AFREQ - MTR_Q_VOLTAGE)
/* Number of bits to right shift, V = (flux * omega) >> (rsft) */
#define RSFT_AFREQ_BEMF_CONST_2VOLTAGE  (MTR_Q_BEMF_CONST + MTR_Q_AFREQ - MTR_Q_VOLTAGE)

#endif

#endif /* #if (MTRCONF_SENSOR_MODE == HALL) */

#if (MTRCONF_SENSOR_MODE == LESS)

#if (MTRCONF_CONTROL_MODE == CURRENT)
#define MTR_Q_ACR_KP            (33)           /* Q-format of PI proportional gain for ACR */
#define MTR_Q_ACR_KIDT          (38)           /* Q-format of PI (integral gain) * (sampling period) for ACR */
#define MTR_Q_ACR_ERR           (22)           /* Q-format of PI err for ACR */
#define MTR_Q_ACR_INTG          (12)           /* Q-format of PI Integral for ACR */
#define MTR_Q_ASR_KP            (30)           /* Q-format of PI proportional gain for ASR */
#define MTR_Q_ASR_KIDT          (38)           /* Q-format of PI (integral gain) * (sampling period) for ASR */
#define MTR_Q_ASR_ERR           (22)           /* Q-format of PI err for ASR */
#define MTR_Q_ASR_INTG          (12)           /* Q-format of PI Integral for ASR */
#endif
#if (MTRCONF_CONTROL_MODE == VOLTAGE)
#define MTR_Q_ASR_KP            (34)           /* Q-format of PI proportional gain for ASR */
#define MTR_Q_ASR_KIDT          (36)           /* Q-format of PI (integral gain) * (sampling period) for ASR */
#define MTR_Q_ASR_ERR           (25)           /* Q-format of PI err for ASR */
#define MTR_Q_ASR_INTG          (12)           /* Q-format of PI Integral for ASR */

/* Number of bits to right shift, V = (KP * omega) >> (rsft) */
#define RSFT_AFREQ_KP_2VOLTAGE    (MTR_Q_ASR_KP + MTR_Q_AFREQ - MTR_Q_VOLTAGE)
/* Number of bits to right shift, V = (KIDT * omega) >> (rsft) */
#define RSFT_AFREQ_KIDT_2VOLTAGE  (MTR_Q_ASR_KIDT + MTR_Q_AFREQ - MTR_Q_VOLTAGE)
/* Number of bits to right shift, V = (flux * omega) >> (rsft) */
#define RSFT_AFREQ_BEMF_CONST_2VOLTAGE  (MTR_Q_BEMF_CONST + MTR_Q_AFREQ - MTR_Q_VOLTAGE)
#endif

#endif /* #if (MTRCONF_SENSOR_MODE == LESS) */

/* Speed conversion */
/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#define MTR_SPEED_CALC_BASE_SHIFT (13)         /* Speed conversion factor shift value */

#if (MTR_Q_ANGLE !=  28 )
#error Angle Q must be a  28 
#endif

#endif /* R_MTR_SCALING_PARAMETER_H */
