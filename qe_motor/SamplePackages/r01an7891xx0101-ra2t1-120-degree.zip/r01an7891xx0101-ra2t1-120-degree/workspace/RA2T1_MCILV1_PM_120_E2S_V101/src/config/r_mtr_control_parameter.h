/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025, 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_control_parameter.h
* Description : Definitions of default control parameters
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.06.2023 1.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MTR_CONTROL_PARAMETER_H
#define R_MTR_CONTROL_PARAMETER_H

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Target control parameter definitions */
/* Target Motor name : R42BLD30L3_24V */
/* Created date : 2025/06/27 */
#ifdef CP_R42BLD30L3_24V
#define     CP_PWM_TIMER_FREQ             (32.0f)      /* PWM timer frequency [MHz] */
#define     CP_TRG_TIMER_FREQ             (32.0f)      /* TRG timer frequency [MHz] */
#define     CP_CARRIER_FREQ               (20.0f)      /* PWM carrier wave frequency [kHz] */
#define     CP_TRX_TIMER_FREQ             (32.0f)      /* TRX timer frequency [MHz] */
#define     CP_SPEED_CALC_TIMER_FREQ      (32000.0f)     /* TAU1 timer frequency [kHz] */
#define     CP_SPEED_CTRL_PERIOD          (0.001f)     /* Control period for speed loop [sec] */
#define     CP_AD_TRG_DEFAULT_CNT         (32.0f)     /* A/D trigger default count */
#define     CP_MAX_SPEED_RPM              (2900)       /* Max speed [rpm] */
#define     CP_SPEED_LIMIT_RPM            (3262.5f)       /* Over speed limit [rpm] */
#define     CP_OC_LIMIT                   (3.955f)      /* Over current limit */
#define     CP_OFFSET_CALC_CNT            (512)         /* Number of current offset averaging times */
#define     CP_OFFSET_CALC_ST_WAIT_CNT    (100)        /* Offset calculation stable waiting time */

#if (MTRCONF_SENSOR_MODE == HALL)
#define     CP_HALL2OL_REV_SPEED_RPM      (500)        /* Hall effect sensor control to open-loop change speed [rpm] */

#if (MTRCONF_CONTROL_MODE == CURRENT)
#define     CP_MIN_SPEED_RPM              (100)        /* Minimum speed [rpm] */
#define     CP_LIMIT_V                    (0.29f)          /* Minimum voltage */
#define     CP_RAMP_LIMIT_SPEED_RPM_HALL  (9.306984f)  /* Limit of acceleration [rpm/ms] */
#define     CP_ACR_NF_HZ                  (500)        /* Current PI natural frequency */
#define     CP_ASR_NF_HZ                  (9.99f)       /* Speed PI natural frequency */
#define     CP_ACR_DEADBAND_LSB           (0.5f)       /* Deadband of current PI calculation [LSB] */
#define     CP_ASR_DEADBAND_LSB           (0.5f)       /* Deadband of speed PI calculation [LSB] */
#define     CP_ASR_KI_AUG                 (8)          /* Augmentation rate for integral part of ASR */
#define     CP_RAMP_LIMIT_CURRENT         (0.043821f)  /* Step of current change [A/ms] */
#define     CP_START_REF_IDC              (0.05f)      /* Start reference DC link current [A] */
#endif

#if (MTRCONF_CONTROL_MODE == VOLTAGE)
#define     CP_MIN_SPEED_RPM              (200)        /* Minimum speed [rpm] */
#define     CP_LIMIT_V                    (1.0f)          /* Minimum voltage */
#define     CP_RAMP_LIMIT_SPEED_RPM_HALL  (9.306984f)  /* Limit of acceleration [rpm/ms] */
#define     CP_ASR_OMEGA_HZ               (20)         /* Speed PI natural frequency */
#define     CP_ASR_ZETA                   (0.5f)          /* Speed PI damping factor */
#define     CP_ASR_DEADBAND_LSB           (1)       /* Deadband of speed PI calculation [LSB] */
#define     CP_RAMP_LIMIT_V_HALL          (0.29f)      /* Limit of rate of voltage change [V/ms] */
#define     CP_START_REF_V                (0.29f)          /* Start reference voltage [V] */
#endif

#endif // #if (MTRCONF_SENSOR_MODE == HALL)

#if (MTRCONF_SENSOR_MODE == LESS)
#define     CP_MIN_SPEED_RPM              (300)        /* Minimum speed [rpm] */
#define     CP_AD_TRG_LIMIT_CNT           (100.0f)     /* A/D trigger 0 minimum count */
#define     CP_AD_TRG_DUTY_THRESHOLD_CNT  (1800.0f)    /* PWM duty threshold */
#define     CP_AD_TRG_ADJUST_UP_CNT       (300.0f)     /* Adjustment count of A/D trigger for ascending non-energized phase voltage */
#define     CP_AD_TRG_ADJUST_DOWN_CNT     (300.0f)     /* Adjustment count of A/D trigger for descending non-energized phase voltage */
#define     CP_AD_TRG_DIFF_CNT            (150.0f)     /* Count difference of A/D between previous carrier and current carrier */
#define     CP_OL2CL_SPEED_RPM            (500)        /* Open-loop to sensorless control change speed [rpm] */
#define     CP_OL2CL_SPEED_RAMP_RPM       (2)          /* Acceleration at translating to PI control [rpm/ms] */
#define     CP_CL2OL_SPEED_MARGIN         (80)         /* Speed margin from sensorless control to open-loop */
#define     CP_OL2CL_ZC_CNT               (3)          /* Number of zerocross to cange in sensorless control */
#define     CP_SKIP_SPIKE_NOISE           (8)          /* Avoid spike noise at switching */

#if (MTRCONF_CONTROL_MODE == CURRENT)
#define     CP_LIMIT_V                    (1.2f)          /* Minimum voltage */
#define     CP_RAMP_LIMIT_SPEED_RPM_LESS  (9.306984f)  /* Limit of acceleration [rpm/ms] */
#define     CP_ACR_NF_HZ                  (300)        /* Current PI natural frequency */
#define     CP_ASR_NF_HZ                  (10.67f)       /* Speed PI natural frequency */
#define     CP_ACR_DEADBAND_LSB           (0.5f)       /* Deadband of current PI calculation [LSB] */
#define     CP_ASR_DEADBAND_LSB           (0.5f)       /* Deadband of speed PI calculation [LSB] */
#define     CP_ASR_KI_AUG                 (8)          /* Augmentation rate for integral part of ASR */
#define     CP_RAMP_LIMIT_CURRENT         (0.043821f)  /* Step of current change [A/ms] */
#define     CP_DRAW_IN_REF_IDC            (1.13f)      /* DC link current reference at draw-in [A] */
#define     CP_OL_REF_IDC                 (0.07f)      /* Open-loop start reference DC link current [A] */
#endif

#if (MTRCONF_CONTROL_MODE == VOLTAGE)
#define     CP_LIMIT_V                    (1.56f)          /* Minimum voltage */
#define     CP_RAMP_LIMIT_SPEED_RPM_LESS  (9.306984f)  /* Limit of acceleration [rpm/ms] */
#define     CP_ASR_OMEGA_HZ               (20)         /* Speed PI natural frequency */
#define     CP_ASR_ZETA                   (0.4f)          /* Speed PI damping factor */
#define     CP_ASR_DEADBAND_LSB           (1)       /* Deadband of speed PI calculation [LSB] */
#define     CP_RAMP_LIMIT_V_LESS          (0.13f)      /* Limit of rate of voltage change [V/ms] */
#define     CP_DRAW_IN_REF_V              (1.49f)      /* Voltage reference at draw-in [V] */
#define     CP_OL_REF_V                   (0.3f)       /* Open-loop start reference voltage [V] */
#endif


#endif // #if (MTRCONF_SENSOR_MODE == LESS)

#endif

#endif /* R_MTR_CONTROL_PARAMETER_H */
