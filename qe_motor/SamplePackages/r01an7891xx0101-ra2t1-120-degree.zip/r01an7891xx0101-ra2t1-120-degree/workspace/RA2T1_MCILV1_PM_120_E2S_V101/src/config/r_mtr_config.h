/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_mtr_config.h
* Description  : Compile-time configurations
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 01.06.2023 1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MTR_CONFIG_H
#define R_MTR_CONFIG_H

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Created date : 2025/06/27 */
/*
 * Hardware system configurations
 */
#define  IP_MCK         /* Inverter */
#define  MP_R42BLD30L3_24V           /* Motor */
#define  CP_R42BLD30L3_24V           /* Motor */

/* Defines the selected sensor mode and control mode for the project
* - SENSORLESS_CURRENT - sensorless mode, current control mode
* - SENSORLESS_VOLTAGE - sensorless mode, voltage control mode
* - HALL_CURRENT - hall-effect sensor mode, current control mode
* - HALL_VOLTAGE - hall-effect sensor mode, voltage control mode
*/
#define SENSORLESS_CURRENT (0)
#define SENSORLESS_VOLTAGE (1)
#define HALL_CURRENT (2)
#define HALL_VOLTAGE (3)

#define  MTRCONF_MODE               (SENSORLESS_CURRENT)

/* Defines the PWM chopping pattern
 * - NON_COMPLEMENTARY
 * - COMPLEMENTARY
 */
#define  NON_COMPLEMENTARY          (0)
#define  COMPLEMENTARY              (1)
#define  MTRCONF_PWM_MODE           (COMPLEMENTARY)

/* Select preparation method for start-up
* - PS_IPD_SAL     : IPD for salient motor
* - PS_IPD_NON_SAL : IPD for non-salient motor
* - PS_IPD_UNKNOWN : IPD without saliency information
* - PS_DRAW_IN     : Draw-in
*/
#define  PS_IPD_SAL                (0)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define  PS_IPD_NON_SAL            (1)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define  PS_IPD_UNKNOWN            (2)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */
#define  PS_DRAW_IN                (3)      /* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS Macro!! */

#define  PS_METHOD                 (3)

/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
/* Selection of sensor used for control
* - HALL : Hall sensor
* - LESS : Sensorless
*/
#define HALL (0)
#define LESS (1)

/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
/* Defines the control mode
* - VOLTAGE : Voltage mode
* - CURRENT : Current mode
*/
#define VOLTAGE (0)
#define CURRENT (1)

/* WARNING: DO NOT CHANGE ANY DEFINITION IN THIS SECTION!! */
#if (MTRCONF_MODE == SENSORLESS_CURRENT)
    #define MTRCONF_SENSOR_MODE (LESS)
    #define MTRCONF_CONTROL_MODE (CURRENT)
#elif (MTRCONF_MODE == SENSORLESS_VOLTAGE)
    #define MTRCONF_SENSOR_MODE (LESS)
    #define MTRCONF_CONTROL_MODE (VOLTAGE)
#elif (MTRCONF_MODE == HALL_CURRENT)
    #define MTRCONF_SENSOR_MODE (HALL)
    #define MTRCONF_CONTROL_MODE (CURRENT)
#elif (MTRCONF_MODE == HALL_VOLTAGE)
    #define MTRCONF_SENSOR_MODE (HALL)
    #define MTRCONF_CONTROL_MODE (VOLTAGE)
#endif

/*
 * Hardware system configurations file include
 */
#include "r_mtr_motor_parameter.h"
#include "r_mtr_control_parameter.h"
#include "r_mtr_inverter_parameter.h"
#include "r_mtr_scaling_parameter.h"

#endif /* R_MTR_CONFIG_H */
