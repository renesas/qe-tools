################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA6T3_MCILV1_SPM_ENCD_FOC_TUNER_E2S_V120/src/application/rmw/ICS2_RA6T3.o C:/Workspace/RA6T3_MCILV1_SPM_ENCD_FOC_TUNER_E2S_V120/src/application/identification/rmw_tuner_library.o

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_position

