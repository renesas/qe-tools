################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Users/a5089652/e2_studio/workspace/work_v_6_2_rc0/work_v_6_2/release/RA6T2_MCB2_MCILV1_SPM_ENCD_FOC_E2S_V100/src/application/rmw/ICS2_RA6T2.o

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_position

