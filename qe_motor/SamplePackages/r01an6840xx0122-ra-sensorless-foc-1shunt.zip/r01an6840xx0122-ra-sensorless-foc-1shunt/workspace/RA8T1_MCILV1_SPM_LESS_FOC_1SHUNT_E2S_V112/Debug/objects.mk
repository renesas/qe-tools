################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA8T1_MCILV1_SPM_LESS_FOC_1SHUNT_E2S_V112/src/application/rmw/ICS2_RA8T1.o

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_estimate

