/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_filter.h
* Description : A definitions of the processing of filters
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_FILTER_H
#define R_MOTOR_FILTER_H

/******************************************************************************
* Global function definitions
******************************************************************************/
float       motor_filter_lpff(float, float, float);                /* LPF process */
float       motor_filter_limitf(float, float, float);              /* Limit with maximum limit value and minimum limit value */
int16_t     motor_filter_limit(int16_t, int16_t, int16_t);         /* Limit with maximum limit value and minimum limit value */
float       motor_filter_upper_limitf(float, float);               /* Limit with maximum limit value */
int16_t     motor_filter_upper_limit(int16_t, int16_t);            /* Limit with maximum limit value */
float       motor_filter_lower_limitf(float, float);               /* Limit with minimum limit value */
int16_t     motor_filter_lower_limit(int16_t, int16_t);            /* Limit with minimum limit value */
float       motor_filter_limitf_abs(float, float);                 /* Limit with absolute value */
int16_t     motor_filter_limit_abs(int16_t, int16_t);              /* Limit with absolute value */

#endif /* R_MOTOR_FILTER_H */
