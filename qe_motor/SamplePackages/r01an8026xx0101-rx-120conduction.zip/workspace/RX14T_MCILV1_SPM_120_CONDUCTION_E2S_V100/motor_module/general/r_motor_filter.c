/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_filter.c
* Description : The processing of filters
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/

#include <math.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_filter.h"

/******************************************************************************
* Function Name : motor_filter_lpff
* Description   : LPF prosess
* Arguments     : f4_lpf_input      - LPF input value,
*               : f4_pre_lpf_output - Previous LPF output value,
*               : f4_lpf_k          - LPF parameter
* Return Value  : LPF output value
******************************************************************************/
float motor_filter_lpff(float f4_lpf_input, float f4_pre_lpf_output, float f4_lpf_k)
{
    float f4_temp;

    f4_temp = f4_pre_lpf_output + f4_lpf_k * (f4_lpf_input - f4_pre_lpf_output);

    return (f4_temp);
} /* End of function motor_filter_lpff */

/******************************************************************************
* Function Name : motor_filter_limitf
* Description   : Limit with max limit value and minimum limit value
* Arguments     : f4_value - Target value,
*               : f4_max   - Max limit value,
*               : f4_min   - Minimum limit value
* Return Value  : limited target value
******************************************************************************/
float motor_filter_limitf(float f4_value, float f4_max, float f4_min)
{
    float f4_temp;

    f4_temp = f4_value;

    if (f4_value > f4_max)
    {
        f4_temp = f4_max;
    }
    else if (f4_value < f4_min)
    {
        f4_temp = f4_min;
    }
    else
    {
        /* Do nothing */
    }

    return (f4_temp);
} /* End of function motor_filter_limitf */

/******************************************************************************
* Function Name : motor_filter_limit
* Description   : Limit with max limit value and minimum limit value
* Arguments     : s2_value - Target value,
*               : s2_max   - Max limit value,
*               : s2_min   - Minimum limit value
* Return Value  : limited target value
******************************************************************************/
int16_t motor_filter_limit(int16_t s2_value, int16_t s2_max, int16_t s2_min)
{
    int16_t s2_temp;

    s2_temp = s2_value;

    if (s2_value > s2_max)
    {
        s2_temp = s2_max;
    }
    else if (s2_value < s2_min)
    {
        s2_temp = s2_min;
    }
    else
    {
        /* Do nothing */
    }

    return (s2_temp);
} /* End of function motor_filter_limit */

/******************************************************************************
* Function Name : motor_filter_upper_limitf
* Description   : Limit with max limit value
* Arguments     : f4_value - Target value
*                 f4_max - Max limit value
* Return Value  : limited target value
******************************************************************************/
float motor_filter_upper_limitf(float f4_value, float f4_max)
{
    float f4_temp;

    f4_temp = f4_value;

    if (f4_value > f4_max)
    {
        f4_temp = f4_max;
    }

    return (f4_temp);
} /* End of function motor_filter_upper_limitf */

/******************************************************************************
* Function Name : motor_filter_upper_limit
* Description   : Limit with max limit value
* Arguments     : s2_value - Target value
*                 s2_max - Max limit value
* Return Value  : limited target value
******************************************************************************/
int16_t motor_filter_upper_limit(int16_t s2_value, int16_t s2_max)
{
    int16_t s2_temp;

    s2_temp = s2_value;

    if (s2_value > s2_max)
    {
        s2_temp = s2_max;
    }

    return (s2_temp);
} /* End of function motor_filter_upper_limit */

/******************************************************************************
* Function Name : motor_filter_lower_limitf
* Description   : Limit with minimum limit value
* Arguments     : f4_value - Target value
*                 f4_min - Minimum limit value
* Return Value  : limited target value
******************************************************************************/
float motor_filter_lower_limitf(float f4_value, float f4_min)
{
    float f4_temp;

    f4_temp = f4_value;

    if (f4_value < f4_min)
    {
        f4_temp = f4_min;
    }

    return (f4_temp);
} /* End of function motor_filter_lower_limitf */

/******************************************************************************
* Function Name : motor_filter_lower_limit
* Description   : Limit with minimum limit value
* Arguments     : s2_value - Target value
*                 s2_min - Minimum limit value
* Return Value  : limited target value
******************************************************************************/
int16_t motor_filter_lower_limit(int16_t s2_value, int16_t s2_min)
{
    int16_t s2_temp;

    s2_temp = s2_value;

    if (s2_value < s2_min)
    {
        s2_temp = s2_min;
    }

    return (s2_temp);
} /* End of function motor_filter_lower_limit */

/******************************************************************************
* Function Name : motor_filter_limitf_abs
* Description   : Limit with absolute value
* Arguments     : f4_value - Target value
*                 f4_limit_value - Limit value
* Return Value  : limited value
******************************************************************************/
float motor_filter_limitf_abs(float f4_value, float f4_limit_value)
{
    float f4_temp0;

    f4_temp0 = fabsf(f4_value);
    if (f4_temp0 > f4_limit_value)
    {
        f4_value = copysignf(f4_limit_value, f4_value);
    }

    return (f4_value);
} /* End of function motor_filter_limitf_abs */

/******************************************************************************
* Function Name : motor_filter_limit_abs
* Description   : Limit with absolute value
* Arguments     : s2_value - Target value
*                 s2_limit_value - Limit value
* Return Value  : limited value
******************************************************************************/
int16_t motor_filter_limit_abs(int16_t s2_value, int16_t s2_limit_value)
{
    int16_t s2_temp0;

    s2_temp0 = s2_value;

    if (s2_value > s2_limit_value)
    {
        s2_temp0 = s2_limit_value;
    }
    else if (s2_value < - s2_limit_value)
    {
        s2_temp0 = - s2_limit_value;
    }
    else
    {
        /* Do nothing */
    }

    return (s2_temp0);
} /* End of function motor_filter_limit_abs */
