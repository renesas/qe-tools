/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_120_conduction_api.c
* Description : The processing of accessing driver
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/


#include <math.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"
#include "r_motor_120_conduction_manager.h"

/***********************************************************************************************************************
* Global variables
***********************************************************************************************************************/
st_120_conduction_control_t g_st_120_conduction;

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
extern volatile uint8_t       g_u1_hall_intr_cnt;                     /* hall interrupt counter for start speed calculation */

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_Open
* Description   : Open hall 120 degree Control module
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_Open(void)
{

    R_MOTOR_DRIVER_Open();
    R_MOTOR_SENSOR_Open();
    R_MOTOR_SPEED_Open();


    /* Store the address of the module instance in a structure and connect the module to be used */
    g_st_120_conduction.p_st_speed          = &g_st_speed;
    g_st_120_conduction.p_st_sensor         = &g_st_sensor;
    g_st_120_conduction.p_st_driver         = &g_st_driver;

    motor_120_conduction_default_init(&g_st_120_conduction);

    /****** for ICS ******/
    g_u1_enable_write = 0;
    /*********************/
    g_u1_hall_intr_cnt = 0;

} /* End of function R_MOTOR_120_CONDUCTION_Open */

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_Close
* Description   : Close hall 120 degree Control module
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_Close(void)
{
    R_MOTOR_DRIVER_Close();
    R_MOTOR_SENSOR_Close();
    R_MOTOR_SPEED_Close();
    motor_120_conduction_reset(&g_st_120_conduction);
} /* End of function R_MOTOR_120_CONDUCTION_Close */

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_Reset
* Description   : Reset hall 120 degree Control module
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_Reset(void)
{
    motor_120_conduction_reset(&g_st_120_conduction);

} /* End of function R_MOTOR_120_CONDUCTION_Reset */

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_ParameterUpdate
* Description   : Update parameter for hall 120 degree Control
* Arguments     : p_st_120_conduction     - The pointer to the motor control management data structure
*                 p_st_120_conduction_cfg - The pointer to the motor control management config structure
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_ParameterUpdate(st_120_conduction_control_t *p_st_120_conduction, const st_120_conduction_cfg_t *p_st_120_conduction_cfg)
{
    p_st_120_conduction->u1_direction       = p_st_120_conduction_cfg->u1_direction;
    p_st_120_conduction->u1_hall_wait_cnt   = p_st_120_conduction_cfg->u1_hall_wait_cnt;
    p_st_120_conduction->st_motor.u2_mtr_pp = p_st_120_conduction_cfg->u2_mtr_p;
    p_st_120_conduction->f4_inv_offset_calc = 1.0f / (float)p_st_120_conduction_cfg->u2_offset_calc_time;
    p_st_120_conduction->f4_rpm_rad         = p_st_120_conduction_cfg->f4_rpm_rad;
} /* End of function R_MOTOR_120_CONDUCTION_ParameterUpdate */

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_MotorStart
* Description   : Start to drive motor
* Arguments     : p_st_120_conduction     - The pointer to the motor control management data structure
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_MotorStart(void)
{
    motor_120_conduction_statemachine_event(STATEMACHINE_EVENT_RUN);
} /* End of function R_MOTOR_120_CONDUCTION_MotorStart */

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_MotorStop
* Description   : Stop to drive motor
* Arguments     : p_st_120_conduction     - The pointer to the motor control management data structure
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_MotorStop(void)
{
    motor_120_conduction_statemachine_event(STATEMACHINE_EVENT_STOP);
} /* End of function R_MOTOR_120_CONDUCTION_MotorStop */

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_MotorReset
* Description   : Error cancel
* Arguments     : p_st_120_conduction     - The pointer to the motor control management data structure
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_MotorReset(void)
{
    motor_120_conduction_statemachine_event(STATEMACHINE_EVENT_RESET);
} /* End of function R_MOTOR_120_CONDUCTION_MotorReset */

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_ErrorSet
* Description   : Set error
* Arguments     : p_st_120_conduction     - The pointer to the motor control management data structure
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_ErrorSet(void)
{
    motor_120_conduction_statemachine_event(STATEMACHINE_EVENT_ERROR);
} /* End of function R_MOTOR_120_CONDUCTION_ErrorSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_H120_CONDUCTION_StatusGet
* Description   : Get status of motor control system
* Arguments     : none
* Return Value  : motor status
***********************************************************************************************************************/
uint8_t R_MOTOR_120_CONDUCTION_StatusGet(void)
{

    uint8_t u1_motor_status;

    u1_motor_status = motor_120_conduction_statemachine_status_get();

    return(u1_motor_status);
} /* End of function R_MOTOR_120_CONDUCTION_StatusGet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_ErrorStatusGet
* Description   : Get current error status
* Arguments     : p_st_120_conduction     - The pointer to the motor control management data structure
* Return Value  : Error status
***********************************************************************************************************************/
uint16_t R_MOTOR_120_CONDUCTION_ErrorStatusGet(st_120_conduction_control_t *p_st_120_conduction)
{
    uint16_t u2_error_status;

    u2_error_status = p_st_120_conduction->u2_error_status;
    return(u2_error_status);
} /* End of function R_MOTOR_120_CONDUCTION_ErrorStatusGet */

#if defined(SENSOR_CFG_CONTROL_HALL)
/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_SpeedInterrupt
* Description   : Speed control interrupt handler
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_SpeedInterrupt(void)
{
    st_speed_input_t  st_speed_input;
    st_sensor_input_t st_sensor_input;

    if (STATEMACHINE_STATE_RUN == g_st_120_conduction.u1_mode_system)
    {
        /*==================================*/
        /*     RUN Mode State Management    */
        /*==================================*/
        switch (g_st_120_conduction.u2_run_mode)
        {
            /*===================*/
            /*     Init State    */
            /*===================*/
            case MOTOR_MODE_INIT:
                /* When Offset Calibration finished & Motor stopped, Motor Control starts. */
                if ((MTR_FLG_SET == g_st_120_conduction.u1_flag_offset_calc) && (MTR_FLG_CLR == g_st_120_conduction.u1_flg_wait_stop))
                {
                    st_sensor_input.u2_run_mode    = g_st_120_conduction.u2_run_mode;
                    st_sensor_input.u1_mode_system = g_st_120_conduction.u1_mode_system;
                    st_sensor_input.u2_pwm_duty    = g_st_120_conduction.u2_pwm_duty;
                    R_MOTOR_SENSOR_ParameterSet(g_st_120_conduction.p_st_sensor,&st_sensor_input); // hall parameter set
                    st_speed_input.u2_run_mode     = g_st_120_conduction.u2_run_mode;
                    st_speed_input.f4_speed_rad    = g_st_120_conduction.f4_speed_rad;
                    R_MOTOR_SPEED_ParameterSet(g_st_120_conduction.p_st_speed, &st_speed_input);   // speed parameter set

                    R_MOTOR_SPEED_VoltageStateSet(VOLTAGE_STATE_CONST);
                    R_MOTOR_SPEED_SpeedCyclic(g_st_120_conduction.p_st_speed); /* set voltage reference */

                    R_MOTOR_SPEED_ParameterGet(g_st_120_conduction.p_st_speed, &g_st_120_conduction.st_speed_output);
                    g_st_120_conduction.f4_v_ref = g_st_120_conduction.st_speed_output.f4_v_ref;

                    g_st_120_conduction.u2_pwm_duty = motor_120_conduction_pwm_duty_calc(&g_st_120_conduction);    /* set start PWM duty */
                    st_sensor_input.u2_run_mode    = g_st_120_conduction.u2_run_mode;
                    st_sensor_input.u1_mode_system = g_st_120_conduction.u1_mode_system;
                    st_sensor_input.u2_pwm_duty    = g_st_120_conduction.u2_pwm_duty;
                    R_MOTOR_SENSOR_ParameterSet(g_st_120_conduction.p_st_sensor,&st_sensor_input); // hall parameter set
                    st_speed_input.u2_run_mode     = g_st_120_conduction.u2_run_mode;
                    st_speed_input.f4_speed_rad    = g_st_120_conduction.f4_speed_rad;
                    R_MOTOR_SPEED_ParameterSet(g_st_120_conduction.p_st_speed, &st_speed_input);   // speed parameter set


                    R_MOTOR_DRIVER_PWMControlStart(g_st_120_conduction.p_st_driver);
clrpsw_i();  /* interrupt disable */
                    R_MOTOR_SENSOR_PatternSet(g_st_120_conduction.p_st_sensor);        /* set voltage pattern in normal drive mode*/
setpsw_i();  /* interrupt enable */
                    g_st_120_conduction.u2_run_mode = MOTOR_MODE_BOOT;

                    st_sensor_input.u2_run_mode    = g_st_120_conduction.u2_run_mode;
                    st_sensor_input.u1_mode_system = g_st_120_conduction.u1_mode_system;
                    st_sensor_input.u2_pwm_duty    = g_st_120_conduction.u2_pwm_duty;
                    R_MOTOR_SENSOR_ParameterSet(g_st_120_conduction.p_st_sensor,&st_sensor_input); // hall parameter set
                    st_speed_input.u2_run_mode     = g_st_120_conduction.u2_run_mode;
                    st_speed_input.f4_speed_rad    = g_st_120_conduction.f4_speed_rad;
                    R_MOTOR_SPEED_ParameterSet(g_st_120_conduction.p_st_speed, &st_speed_input);   // speed parameter set

                }
            break;

            /*===================*/
            /*     Boot State    */
            /*===================*/
            case MOTOR_MODE_BOOT:

                R_MOTOR_SENSOR_ParameterGet(g_st_120_conduction.p_st_sensor, &g_st_120_conduction.st_sensor_output);
                g_st_120_conduction.f4_speed_rad    = g_st_120_conduction.st_sensor_output.f4_speed_rad;
                g_st_120_conduction.u2_error_status = g_st_120_conduction.st_sensor_output.u2_error_status;
                st_speed_input.u2_run_mode  = g_st_120_conduction.u2_run_mode;
                st_speed_input.f4_speed_rad = g_st_120_conduction.f4_speed_rad;
                R_MOTOR_SPEED_ParameterSet(g_st_120_conduction.p_st_speed, &st_speed_input);   // speed parameter set

                /* wait the speed become over minimum speed */
                if (g_st_120_conduction.f4_speed_rad >= (MOTOR_CFG_MIN_SPEED_RPM * g_st_120_conduction.f4_rpm_rad))
                {
                    g_st_120_conduction.u2_run_mode = MOTOR_MODE_DRIVE;  /* change to normal(PI) control mode */
                    g_st_120_conduction.u2_ctrl_conf = MOTOR_CONTROL_SPEED;       /* control configuration is changed. */

                    st_sensor_input.u2_run_mode    = g_st_120_conduction.u2_run_mode;
                    st_sensor_input.u1_mode_system = g_st_120_conduction.u1_mode_system;
                    st_sensor_input.u2_pwm_duty    = g_st_120_conduction.u2_pwm_duty;
                    R_MOTOR_SENSOR_ParameterSet(g_st_120_conduction.p_st_sensor,&st_sensor_input); // hall parameter set
                    st_speed_input.u2_run_mode     = g_st_120_conduction.u2_run_mode;
                    st_speed_input.f4_speed_rad    = g_st_120_conduction.f4_speed_rad;
                    R_MOTOR_SPEED_ParameterSet(g_st_120_conduction.p_st_speed, &st_speed_input);   // speed parameter set

                }

                R_MOTOR_SPEED_RefSpeedSet(g_st_120_conduction.p_st_speed);     /* set speed reference */
                R_MOTOR_SPEED_SpeedCyclic(g_st_120_conduction.p_st_speed); /* set voltage reference */

                R_MOTOR_SENSOR_ParameterGet(g_st_120_conduction.p_st_sensor, &g_st_120_conduction.st_sensor_output);
                g_st_120_conduction.f4_speed_rad    = g_st_120_conduction.st_sensor_output.f4_speed_rad;
                g_st_120_conduction.u2_error_status = g_st_120_conduction.st_sensor_output.u2_error_status;
                st_speed_input.u2_run_mode  = g_st_120_conduction.u2_run_mode;
                st_speed_input.f4_speed_rad = g_st_120_conduction.f4_speed_rad;
                R_MOTOR_SPEED_ParameterSet(g_st_120_conduction.p_st_speed, &st_speed_input);   // speed parameter set



            break;

            /*========================================*/
            /*     Normal Drive (PI Control) State    */
            /*========================================*/
            case MOTOR_MODE_DRIVE:
                st_sensor_input.u2_run_mode    = g_st_120_conduction.u2_run_mode;
                st_sensor_input.u1_mode_system = g_st_120_conduction.u1_mode_system;
                st_sensor_input.u2_pwm_duty    = g_st_120_conduction.u2_pwm_duty;
                R_MOTOR_SENSOR_ParameterSet(g_st_120_conduction.p_st_sensor,&st_sensor_input); // hall parameter set
                st_speed_input.u2_run_mode     = g_st_120_conduction.u2_run_mode;
                st_speed_input.f4_speed_rad    = g_st_120_conduction.f4_speed_rad;
                R_MOTOR_SPEED_ParameterSet(g_st_120_conduction.p_st_speed, &st_speed_input);   // speed parameter set


                R_MOTOR_SPEED_RefSpeedSet(g_st_120_conduction.p_st_speed);     /* set speed reference */
                R_MOTOR_SPEED_SpeedCyclic(g_st_120_conduction.p_st_speed); /* set voltage reference */

                R_MOTOR_SPEED_ParameterGet(g_st_120_conduction.p_st_speed, &g_st_120_conduction.st_speed_output);
                g_st_120_conduction.f4_v_ref = g_st_120_conduction.st_speed_output.f4_v_ref;

                g_st_120_conduction.u2_pwm_duty = motor_120_conduction_pwm_duty_calc(&g_st_120_conduction);  /* set PWM duty */

                motor_120_conduction_speed_rad_set(&g_st_120_conduction);
                motor_120_conduction_mode_set(&g_st_120_conduction);

                break;

            default:
                    /* Do Nothing */
                break;
        }
    }
} /* End of function R_MOTOR_120_CONDUCTION_SpeedInterrupt */
#elif defined(SENSOR_CFG_CONTROL_LESS)
/******************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_SpeedInterrupt
* Description   : CMT0 interrupt (Period:1ms)
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_120_CONDUCTION_SpeedInterrupt(void)
{
    st_speed_input_t  st_speed_input;
    st_sensor_input_t st_sensor_input;

setpsw_i();                                                 /* interrupt enable */
    if (STATEMACHINE_STATE_RUN == g_st_120_conduction.u1_mode_system)
    {
        /*** set reference ***/
        switch (g_st_120_conduction.u2_run_mode)
        {
            case MOTOR_MODE_INIT:
                if (MTR_FLG_SET_2 == g_st_120_conduction.u1_flag_offset_calc)
                {
                    g_st_120_conduction.u2_run_mode = MOTOR_MODE_BOOT;
                    motor_120_conduction_mode_set(&g_st_120_conduction);
                    R_MOTOR_SPEED_DrawInFlagSet(MOTOR_CFG_DRAW_IN_1ST_TIME);
                    R_MOTOR_DRIVER_PWMControlStart(g_st_120_conduction.p_st_driver);
                }
            break;

            case MOTOR_MODE_BOOT:
                /* speed rad set */
                R_MOTOR_SENSOR_ParameterGet(g_st_120_conduction.p_st_sensor, &g_st_120_conduction.st_sensor_output);
                g_st_120_conduction.f4_speed_rad    = g_st_120_conduction.st_sensor_output.f4_speed_rad;
                g_st_120_conduction.u2_error_status = g_st_120_conduction.st_sensor_output.u2_error_status;
                st_speed_input.u2_run_mode  = g_st_120_conduction.u2_run_mode;
                st_speed_input.f4_speed_rad = g_st_120_conduction.f4_speed_rad;
                R_MOTOR_SPEED_ParameterSet(g_st_120_conduction.p_st_speed, &st_speed_input);   // speed parameter set


                R_MOTOR_SPEED_RefSpeedSet(g_st_120_conduction.p_st_speed);                   /* set speed reference */
                R_MOTOR_SPEED_SpeedCyclic(g_st_120_conduction.p_st_speed);                 /* set voltage reference */
                R_MOTOR_SPEED_ParameterGet(g_st_120_conduction.p_st_speed, &g_st_120_conduction.st_speed_output);
                g_st_120_conduction.f4_v_ref = g_st_120_conduction.st_speed_output.f4_v_ref;
                g_st_120_conduction.u2_pwm_duty = motor_120_conduction_pwm_duty_calc(&g_st_120_conduction);  /* set PWM duty */
                if (VOLTAGE_STATE_OPENLOOP == R_MOTOR_SPEED_VoltageStateGet())
                {
                    g_st_120_conduction.u2_pwm_duty = 0;
                    g_st_120_conduction.u2_run_mode = MOTOR_MODE_DRIVE;

                }
                /* run mode ,pwm_duty set */
                st_sensor_input.u2_run_mode    = g_st_120_conduction.u2_run_mode;
                st_sensor_input.u1_mode_system = g_st_120_conduction.u1_mode_system;
                st_sensor_input.u2_pwm_duty    = g_st_120_conduction.u2_pwm_duty;
                R_MOTOR_SENSOR_ParameterSet(g_st_120_conduction.p_st_sensor,&st_sensor_input); // hall parameter set


                /* rotor phase draw-in */
                if(MTR_CW == g_st_120_conduction.u1_direction)
                {
                    if(MOTOR_CFG_DRAW_IN_1ST_TIME == R_MOTOR_SPEED_DrawInFlagGet())
                    {
                        R_MOTOR_SENSOR_OutputPatternSet(g_st_120_conduction.p_st_sensor,SENSOR_PATTERN_CW_W_U);
                    }
                    else if(MOTOR_CFG_DRAW_IN_2ND_TIME == R_MOTOR_SPEED_DrawInFlagGet())
                    {
                        R_MOTOR_SENSOR_OutputPatternSet(g_st_120_conduction.p_st_sensor,SENSOR_PATTERN_CW_W_V);
                    }
                }
                else if(MTR_CCW == g_st_120_conduction.u1_direction)
                {
                    if(MOTOR_CFG_DRAW_IN_1ST_TIME == R_MOTOR_SPEED_DrawInFlagGet())
                    {
                        R_MOTOR_SENSOR_OutputPatternSet(g_st_120_conduction.p_st_sensor,SENSOR_PATTERN_CW_V_W);
                    }
                    else if(MOTOR_CFG_DRAW_IN_2ND_TIME == R_MOTOR_SPEED_DrawInFlagGet())
                    {
                        R_MOTOR_SENSOR_OutputPatternSet(g_st_120_conduction.p_st_sensor,SENSOR_PATTERN_CW_U_W);
                    }
                }
            break;

            case MOTOR_MODE_DRIVE:
                /* speed rad set */
                R_MOTOR_SENSOR_ParameterGet(g_st_120_conduction.p_st_sensor, &g_st_120_conduction.st_sensor_output);
                g_st_120_conduction.f4_speed_rad    = g_st_120_conduction.st_sensor_output.f4_speed_rad;
                g_st_120_conduction.u2_error_status = g_st_120_conduction.st_sensor_output.u2_error_status;
                st_speed_input.u2_run_mode  = g_st_120_conduction.u2_run_mode;
                st_speed_input.f4_speed_rad = g_st_120_conduction.f4_speed_rad;
                R_MOTOR_SPEED_ParameterSet(g_st_120_conduction.p_st_speed, &st_speed_input);   // speed parameter set

                R_MOTOR_SPEED_RefSpeedSet(g_st_120_conduction.p_st_speed);                   /* set speed reference */
                R_MOTOR_SPEED_SpeedCyclic(g_st_120_conduction.p_st_speed);                 /* set voltage reference */

                if (VOLTAGE_STATE_PI_OUTPUT == R_MOTOR_SPEED_VoltageStateGet())
                {
                    R_MOTOR_SPEED_ParameterGet(g_st_120_conduction.p_st_speed, &g_st_120_conduction.st_speed_output);
                    g_st_120_conduction.f4_v_ref = g_st_120_conduction.st_speed_output.f4_v_ref;
                    g_st_120_conduction.u2_pwm_duty = motor_120_conduction_pwm_duty_calc(&g_st_120_conduction);  /* set PWM duty */
                    /* pwm duty set */
                    st_sensor_input.u2_run_mode    = g_st_120_conduction.u2_run_mode;
                    st_sensor_input.u1_mode_system = g_st_120_conduction.u1_mode_system;
                    st_sensor_input.u2_pwm_duty    = g_st_120_conduction.u2_pwm_duty;
                    R_MOTOR_SENSOR_ParameterSet(g_st_120_conduction.p_st_sensor,&st_sensor_input); // hall parameter set
                }
            break;

            default:
                /* Do Nothing */
            break;
        }
    }
} /* End of function R_MOTOR_120_CONDUCTION_SpeedInterrupt */

#endif

#if defined(SENSOR_CFG_CONTROL_HALL)
/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_CarrierInterrupt
* Description   : Carrier control interrupt handler
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_CarrierInterrupt(void)
{
    /*============================*/
    /*     current detection      */
    /*============================*/
    R_MOTOR_DRIVER_BldcAnalogGet(&g_st_driver,
                                 &g_st_120_conduction.f4_iu_ad,
                                 &g_st_120_conduction.f4_iv_ad,
                                 &g_st_120_conduction.f4_iw_ad,
                                 &g_st_120_conduction.f4_vdc_ad
                                 );


    /*** current offset calculation ***/
    if (MTR_FLG_CLR == g_st_120_conduction.u1_flag_offset_calc)
    {
        g_st_120_conduction.u2_cnt_adjust++;
        if (g_st_120_conduction.u2_cnt_adjust >= g_st_120_conduction.u2_offset_calc_time)
        {
            /* Offset measurement finished. */
            g_st_120_conduction.u1_flag_offset_calc = MTR_FLG_SET;
            g_st_120_conduction.f4_offset_iu = g_st_120_conduction.f4_sum_iu_ad * g_st_120_conduction.f4_inv_offset_calc;
            g_st_120_conduction.f4_offset_iv = g_st_120_conduction.f4_sum_iv_ad * g_st_120_conduction.f4_inv_offset_calc;
            g_st_120_conduction.f4_offset_iw = g_st_120_conduction.f4_sum_iw_ad * g_st_120_conduction.f4_inv_offset_calc;
        }
        else
        {
            /* Offset data measurement (All summarize) */
            g_st_120_conduction.f4_sum_iu_ad += g_st_120_conduction.f4_iu_ad;
            g_st_120_conduction.f4_sum_iv_ad += g_st_120_conduction.f4_iv_ad;
            g_st_120_conduction.f4_sum_iw_ad += g_st_120_conduction.f4_iw_ad;
        }
    }

    /*** current offset adjustment ***/
    g_st_120_conduction.f4_iu_ad = g_st_120_conduction.f4_iu_ad - g_st_120_conduction.f4_offset_iu;
    g_st_120_conduction.f4_iv_ad = g_st_120_conduction.f4_iv_ad - g_st_120_conduction.f4_offset_iv;
    g_st_120_conduction.f4_iw_ad = g_st_120_conduction.f4_iw_ad - g_st_120_conduction.f4_offset_iw;

    /*============================*/
    /*         check error        */
    /*============================*/
    motor_120_conduction_error_check();

    /*============================*/
    /*       wait motor stop      */
    /*============================*/
    motor_120_conduction_wait_motor_stop(&g_st_120_conduction);

} /* End of function R_MOTOR_120_CONDUCTION_CarrierInterrupt */
#elif defined(SENSOR_CFG_CONTROL_LESS)
/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_CarrierInterrupt
* Description   : Carrier control interrupt handler
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_CarrierInterrupt(void)
{
    uint8_t u1_flag_voltage_ref;
    uint8_t u1_bemf_signal;
    st_sensor_input_t st_sensor_input;
setpsw_i();
    /*============================*/
    /*     current detection      */
    /*============================*/
    R_MOTOR_DRIVER_BldcAnalogGet(&g_st_driver,
                                 &g_st_120_conduction.f4_iu_ad,
                                 &g_st_120_conduction.f4_iv_ad,
                                 &g_st_120_conduction.f4_iw_ad,
                                 &g_st_120_conduction.f4_vdc_ad,
                                 &g_st_120_conduction.f4_vu_ad,
                                 &g_st_120_conduction.f4_vv_ad,
                                 &g_st_120_conduction.f4_vw_ad
                                 );

    /*** current offset calculation ***/
    if (MTR_FLG_CLR == g_st_120_conduction.u1_flag_offset_calc)
    {
        if (g_st_120_conduction.u2_cnt_adjust  >= g_st_120_conduction.u2_offset_calc_time)
        {
            g_st_120_conduction.f4_offset_iu = g_st_120_conduction.f4_sum_iu_ad * g_st_120_conduction.f4_inv_offset_calc;
            g_st_120_conduction.f4_offset_iv = g_st_120_conduction.f4_sum_iv_ad * g_st_120_conduction.f4_inv_offset_calc;
            g_st_120_conduction.f4_offset_iw = g_st_120_conduction.f4_sum_iw_ad * g_st_120_conduction.f4_inv_offset_calc;
        }
        else
        {
            g_st_120_conduction.f4_sum_iu_ad += g_st_120_conduction.f4_iu_ad;
            g_st_120_conduction.f4_sum_iv_ad += g_st_120_conduction.f4_iv_ad;
            g_st_120_conduction.f4_sum_iw_ad += g_st_120_conduction.f4_iw_ad;
        }
    }

    /*** current offset adjustment ***/
    g_st_120_conduction.f4_iu_ad = g_st_120_conduction.f4_iu_ad - g_st_120_conduction.f4_offset_iu;
    g_st_120_conduction.f4_iv_ad = g_st_120_conduction.f4_iv_ad - g_st_120_conduction.f4_offset_iv;
    g_st_120_conduction.f4_iw_ad = g_st_120_conduction.f4_iw_ad - g_st_120_conduction.f4_offset_iw;

    /*============================*/
    /*         check error        */
    /*============================*/
    motor_120_conduction_error_check();
    /*============================*/
    /*     voltage detection      */
    /*============================*/

    /*** voltage offset calculation ***/
    if (MTR_FLG_SET_2 != g_st_120_conduction.u1_flag_offset_calc)
    {
        if (g_st_120_conduction.u2_cnt_adjust >= g_st_120_conduction.u2_offset_calc_time)
        {
            if(MTR_FLG_CLR == g_st_120_conduction.u1_flag_offset_calc)
            {
                g_st_120_conduction.u1_flag_offset_calc = MTR_FLG_SET;
                g_st_120_conduction.f4_offset_off_vu = g_st_120_conduction.f4_sum_vu_ad * g_st_120_conduction.f4_inv_offset_calc;
                g_st_120_conduction.f4_offset_off_vv = g_st_120_conduction.f4_sum_vv_ad * g_st_120_conduction.f4_inv_offset_calc;
                g_st_120_conduction.f4_offset_off_vw = g_st_120_conduction.f4_sum_vw_ad * g_st_120_conduction.f4_inv_offset_calc;
                g_st_120_conduction.f4_sum_vu_ad = 0;
                g_st_120_conduction.f4_sum_vv_ad = 0;
                g_st_120_conduction.f4_sum_vw_ad = 0;
                R_MOTOR_DRIVER_PWMControlStart(g_st_120_conduction.p_st_driver);
                g_st_120_conduction.u2_cnt_adjust = 0;

            }
            else if(MTR_FLG_SET == g_st_120_conduction.u1_flag_offset_calc)
            {
                g_st_120_conduction.u1_flag_offset_calc = MTR_FLG_SET_2;
                g_st_120_conduction.f4_offset_vu = g_st_120_conduction.f4_sum_vu_ad * g_st_120_conduction.f4_inv_offset_calc;
                g_st_120_conduction.f4_offset_vv = g_st_120_conduction.f4_sum_vv_ad * g_st_120_conduction.f4_inv_offset_calc;
                g_st_120_conduction.f4_offset_vw = g_st_120_conduction.f4_sum_vw_ad * g_st_120_conduction.f4_inv_offset_calc;
                R_MOTOR_DRIVER_PWMControlStop(g_st_120_conduction.p_st_driver);
            }
        }
        else
        {
            g_st_120_conduction.f4_sum_vu_ad += g_st_120_conduction.f4_vu_ad;
            g_st_120_conduction.f4_sum_vv_ad += g_st_120_conduction.f4_vv_ad;
            g_st_120_conduction.f4_sum_vw_ad += g_st_120_conduction.f4_vw_ad;
        }
        g_st_120_conduction.u2_cnt_adjust++;
    }
    else
    {
        /*** voltage offset adjustment ***/
        if (STATEMACHINE_STATE_RUN == g_st_120_conduction.u1_mode_system)
        {
            g_st_120_conduction.f4_vu_ad = g_st_120_conduction.f4_vu_ad - g_st_120_conduction.f4_offset_vu;
            g_st_120_conduction.f4_vv_ad = g_st_120_conduction.f4_vv_ad - g_st_120_conduction.f4_offset_vv;
            g_st_120_conduction.f4_vw_ad = g_st_120_conduction.f4_vw_ad - g_st_120_conduction.f4_offset_vw;
        }
        else
        {
            g_st_120_conduction.f4_vu_ad = g_st_120_conduction.f4_vu_ad - g_st_120_conduction.f4_offset_off_vu;
            g_st_120_conduction.f4_vv_ad = g_st_120_conduction.f4_vv_ad - g_st_120_conduction.f4_offset_off_vv;
            g_st_120_conduction.f4_vw_ad = g_st_120_conduction.f4_vw_ad - g_st_120_conduction.f4_offset_off_vw;
        }
    }

    /*** calculate neutral voltage ***/
    g_st_120_conduction.f4_vn_ad = (g_st_120_conduction.f4_vu_ad + g_st_120_conduction.f4_vv_ad + g_st_120_conduction.f4_vw_ad) / 3;

    /*============================*/
    /*      control motor         */
    /*============================*/
    if (STATEMACHINE_STATE_RUN == g_st_120_conduction.u1_mode_system)
    {
        u1_flag_voltage_ref = R_MOTOR_SPEED_VoltageStateGet();
        /*** starting by openloop ***/
        if (VOLTAGE_STATE_OPENLOOP == u1_flag_voltage_ref)
        {
            R_MOTOR_SPEED_ParameterGet(g_st_120_conduction.p_st_speed, &g_st_120_conduction.st_speed_output);
            g_st_120_conduction.f4_v_ref = g_st_120_conduction.st_speed_output.f4_v_ref;

            g_st_120_conduction.u2_pwm_duty = motor_120_conduction_pwm_duty_calc(&g_st_120_conduction);  /* set PWM duty */

            st_sensor_input.u2_run_mode    = g_st_120_conduction.u2_run_mode;
            st_sensor_input.u1_mode_system = g_st_120_conduction.u1_mode_system;
            st_sensor_input.u2_pwm_duty    = g_st_120_conduction.u2_pwm_duty;
            R_MOTOR_SENSOR_ParameterSet(g_st_120_conduction.p_st_sensor,&st_sensor_input); // hall parameter set

            R_MOTOR_SENSOR_StartOpenLoop(g_st_120_conduction.p_st_sensor,g_st_120_conduction.p_st_speed->f4_ref_speed_rad_ctrl);
        }

        /*** detect zerocross ***/
        if(VOLTAGE_STATE_OPENLOOP == u1_flag_voltage_ref || VOLTAGE_STATE_PI_OUTPUT == u1_flag_voltage_ref)
        {
            u1_bemf_signal = motor_120_conduction_generate_pattern(g_st_120_conduction.f4_vu_ad, g_st_120_conduction.f4_vv_ad, g_st_120_conduction.f4_vw_ad, g_st_120_conduction.f4_vn_ad);
            R_MOTOR_SENSOR_AngleShiftSet(g_st_120_conduction.p_st_sensor,u1_bemf_signal);                 /* set shift value */
        }

        if (VOLTAGE_STATE_PI_OUTPUT == u1_flag_voltage_ref)
        {
            R_MOTOR_SENSOR_ShiftAngle(g_st_120_conduction.p_st_sensor);
        }
    }

    /*** wait motor stop ***/
    motor_120_conduction_wait_motor_stop(&g_st_120_conduction);
} /* End of function R_MOTOR_120_CONDUCTION_CarrierInterrupt */
#endif

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_OverCurrentInterrupt
* Description   : Over current error interrupt handler
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_OverCurrentInterrupt(void)
{
    R_MOTOR_120_CONDUCTION_ErrorSet();
    g_st_120_conduction.u2_error_status |= MOTOR_ERROR_OVER_CURRENT_HW;     /* error status update : over current error */
    R_Config_POE_Stop();                                /* Stop the POE3 module */
    R_Config_POE_Start();                               /* Start the POE3 module*/

} /* End of function R_MOTOR_120_CONDUCTION_OverCurrentInterrupt */

/***********************************************************************************************************************
* Function Name : R_MOTOR_120_CONDUCTION_HallInterrupt
* Description   : Hall sensor interrupt handler
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_120_CONDUCTION_HallInterrupt(void)
{
    if (g_u1_hall_intr_cnt < (g_st_120_conduction.u1_hall_wait_cnt + 1))
    {
        g_u1_hall_intr_cnt++;
    }
    /* timeout error check */
    if ((STATEMACHINE_STATE_RUN == g_st_120_conduction.u1_mode_system) && (MOTOR_MODE_INIT != g_st_120_conduction.u2_run_mode))
                                                        /* check system & run mode */
    {
        R_MOTOR_SENSOR_TimerCountClear();
    }

    if (MTR_FLG_SET == g_st_120_conduction.u1_flg_wait_stop)           /* waiting for motor stop */
    {
        g_st_120_conduction.u2_cnt_wait_stop = SENSOR_CFG_HALL_STOP_WAIT_CNT;
    }
    else
    {
       if (STATEMACHINE_STATE_RUN == g_st_120_conduction.u1_mode_system)      /* check system mode */
       {
           R_MOTOR_SENSOR_PatternSet(g_st_120_conduction.p_st_sensor);        /* set voltage pattern in normal drive mode*/
           R_MOTOR_SENSOR_ParameterGet(g_st_120_conduction.p_st_sensor,&g_st_120_conduction.st_sensor_output);
           g_st_120_conduction.u2_error_status |= g_st_120_conduction.st_sensor_output.u2_error_status;
       }
    }
} /* End of function R_MOTOR_120_CONDUCTION_HallInterrupt */





