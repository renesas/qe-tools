/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_120_conduction_statemachine.h
* Description : A definitions of the processing of a motor control layer
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_120_CONDUCTION_STATEMACHINE_H
#define R_MOTOR_120_CONDUCTION_STATEMACHINE_H

/******************************************************************************
* Macro definitions
******************************************************************************/

#define     MTR_ICS_DECIMATION          (4)                 /* ICS decimation count */

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    uint8_t       u1_status;                        /* The current system status */
    uint16_t      u2_error_status;                  /* The error flags of state machine */
} st_statemachine_t;

/******************************************************************************
* Macro definitions for sequence control
******************************************************************************/

/* system mode */
#define     STATEMACHINE_STATE_STOP           (0x00)
#define     STATEMACHINE_STATE_RUN            (0x01)
#define     STATEMACHINE_STATE_ERROR          (0x02)
#define     STATEMACHINE_STATE_SIZE           (3)                 /* number of state */

/* event */
#define     STATEMACHINE_EVENT_STOP              (0x00)
#define     STATEMACHINE_EVENT_RUN               (0x01)
#define     STATEMACHINE_EVENT_ERROR             (0x02)
#define     STATEMACHINE_EVENT_RESET             (0x03)
#define     STATEMACHINE_EVENT_SIZE              (4)                 /* number of event */


/******************************************************************************
* Global function definitions
******************************************************************************/
/* for sequence control */
void    motor_120_conduction_statemachine_event(uint8_t);        /* Change motor state and select action */
uint8_t motor_120_conduction_statemachine_status_get(void);           /* get status of motor control system */

#endif /* R_MOTOR_120_CONDUCTION_STATEMACHINE_H */
