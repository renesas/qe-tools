/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_120_conduction_manager.h
* Description : A definitions of the general motor control function
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_120_CONDUCTION_MANAGER_H
#define R_MOTOR_120_CONDUCTION_MANAGER_H

/******************************************************************************
* Global function definitions
******************************************************************************/
void     motor_120_conduction_default_init(st_120_conduction_control_t *p_st_120_conduction);
void     motor_120_conduction_reset(st_120_conduction_control_t *p_st_120_conduction);
void     motor_120_conduction_decide_direction(st_120_conduction_control_t *p_st_120_conduction);
void     motor_h120_conduction_error_process(st_120_conduction_control_t *p_st_120_conduction,uint16_t u2_error_flag);
uint16_t motor_120_conduction_pwm_duty_calc(st_120_conduction_control_t *p_st_120_conduction);
void     motor_120_conduction_wait_motor_stop(st_120_conduction_control_t *p_st_120_conduction);   /* Wait for motor stop */
void     motor_120_conduction_mode_set(st_120_conduction_control_t *p_st_120_conduction);
void     motor_120_conduction_v_ref_get(st_120_conduction_control_t *p_st_120_conduction);
void     motor_120_conduction_speed_rad_set(st_120_conduction_control_t *p_st_120_conduction);
uint8_t  motor_120_conduction_generate_pattern(float vu_ad, float vv_ad, float vw_ad, float vn_ad);

#endif /* R_MOTOR_120_CONDUCTION_MANAGER_H */
