/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_120_conduction_action.c
* Description : The processing of a motor control layer
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/
/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/


#include <machine.h>

#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"
#include "r_motor_120_conduction_manager.h"

/******************************************************************************
* Exported global variables
******************************************************************************/

/****** for ICS ******/

/*********************/
/******************************************************************************
* Function Name : motor_120_conduction_act_active
* Description   : Processing for motor control start
* Arguments     : u1_state - state
* Return Value  : u1_state - state
******************************************************************************/
uint8_t motor_120_conduction_act_active(uint8_t u1_state)
{
    volatile uint8_t *u1_flg_wait_stop;

    u1_flg_wait_stop = &g_st_120_conduction.u1_flg_wait_stop;

    while (MTR_FLG_SET == *u1_flg_wait_stop)
    {
        /* waiting for motor stop */
    }
    if (STATEMACHINE_STATE_ERROR == g_st_120_conduction.u1_mode_system)         /* check system mode */
    {
        u1_state = STATEMACHINE_STATE_ERROR;                     /* system mode update : error mode */
    }

    return (u1_state);
} /* End of function motor_120_conduction_act_active */

/******************************************************************************
* Function Name : motor_120_conduction_act_inactive
* Description   : Processing for motor control stop
* Arguments     : u1_state - state
* Return Value  : u1_state - state
******************************************************************************/
uint8_t motor_120_conduction_act_inactive(uint8_t u1_state)
{
    g_st_120_conduction.u2_cnt_wait_stop = SENSOR_CFG_HALL_STOP_WAIT_CNT;
    g_st_120_conduction.u1_flg_wait_stop = MTR_FLG_SET;
    R_MOTOR_DRIVER_PWMControlStop(&g_st_driver);               /* PWM output disable, CMT1 stop,
                                                                  motor output port is off for motor control stop */
    g_st_120_conduction.u2_run_mode = MOTOR_MODE_INIT;         /* next start from INIT State. */
    g_st_120_conduction.p_st_speed->u1_flag_speed_ref = SPEED_STATE_ZERO_CONST;
    g_st_120_conduction.p_st_speed->u1_flag_voltage_ref = VOLTAGE_STATE_ZERO_CONST;

    motor_120_conduction_reset(&g_st_120_conduction);

    return (u1_state);
} /* End of function motor_120_conduction_act_inactive */

/******************************************************************************
* Function Name : motor_120_conduction_act_none
* Description   : Do nothing
* Arguments     : u1_state - state
* Return Value  : u1_state - state
******************************************************************************/
uint8_t motor_120_conduction_act_none(uint8_t u1_state)
{
    /* Do Nothing */
    return (u1_state);
} /* End of function motor_120_conduction_act_none */

/******************************************************************************
* Function Name : motor_120_conduction_act_reset
* Description   : Processing for motor control reset
* Arguments     : u1_state - state
* Return Value  : u1_state - state
******************************************************************************/
uint8_t motor_120_conduction_act_reset(uint8_t u1_state)
{

    motor_120_conduction_default_init(&g_st_120_conduction);

    return (u1_state);
} /* End of function motor_120_conduction_act_reset */

/******************************************************************************
* Function Name : motor_120_conduction_act_error
* Description   : Processing when detecting an error
* Arguments     : u1_state - state
* Return Value  : u1_state - state
******************************************************************************/
uint8_t motor_120_conduction_act_error(uint8_t u1_state)
{
    g_st_120_conduction.u2_cnt_wait_stop = SENSOR_CFG_HALL_STOP_WAIT_CNT;
    g_st_120_conduction.u1_flg_wait_stop = MTR_FLG_SET;
    R_MOTOR_DRIVER_PWMControlStop(&g_st_driver);         /* PWM output disable, CMT1 stop,
                                                            motor output port is off for motor control stop */
    g_st_120_conduction.u2_run_mode = MOTOR_MODE_INIT;   /* next start from INIT state. */

    return (u1_state);
} /* End of function motor_120_conduction_act_error */


