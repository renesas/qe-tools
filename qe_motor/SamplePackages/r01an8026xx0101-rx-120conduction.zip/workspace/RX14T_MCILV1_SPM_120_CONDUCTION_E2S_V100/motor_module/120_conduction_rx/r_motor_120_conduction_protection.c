/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_120_conduction_protection.c
* Description : General motor control function
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/

#include <machine.h>
#include <math.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"

/******************************************************************************
* Exported global variables
******************************************************************************/

/******************************************************************************
* Function Name : motor_120_conduction_over_voltage_error_check
* Description   : Over voltage error check
* Arguments     : f4_vdc - Vdc value
*                 f4_overvoltage_limit - over voltage limit value
* Return Value  : error status
******************************************************************************/
uint16_t motor_120_conduction_over_voltage_error_check(float f4_vdc, float f4_overvoltage_limit)
{
    uint16_t u2_temp0;

    u2_temp0 = MOTOR_ERROR_NONE;

    if (f4_vdc > f4_overvoltage_limit)
    {
        u2_temp0 = MOTOR_ERROR_OVER_VOLTAGE;                           /* over voltage error */
    }

    return (u2_temp0);
} /* End of function motor_120_conduction_over_voltage_error_check */

/******************************************************************************
* Function Name : motor_120_conduction_low_voltage_error_check
* Description   : Under voltage error check
* Arguments     : f4_vdc - Vdc value
*                 f4_undervoltage_limit - under voltage limit value
* Return Value  : error status
******************************************************************************/
uint16_t motor_120_conduction_low_voltage_error_check(float f4_vdc, float f4_lowvoltage_limit)
{
    uint16_t u2_temp0;

    u2_temp0 = MOTOR_ERROR_NONE;

    if (f4_vdc < f4_lowvoltage_limit)
    {
        u2_temp0 = MOTOR_ERROR_LOW_VOLTAGE;                          /* under voltage error */
    }

    return (u2_temp0);
} /* End of function motor_120_conduction_low_voltage_error_check */

/******************************************************************************
* Function Name : motor_120_conduction_over_speed_error_check
* Description   : Over speed error check
* Arguments     : f4_speed_rad       - Speed [rad/s],
*               : f4_speed_limit_rad - Over speed limit value [rad/s]
* Return Value  : error status
******************************************************************************/
uint16_t motor_120_conduction_over_speed_error_check(float f4_speed_rad, float f4_speed_limit_rad)
{
    float    f4_temp0;
    uint16_t u2_temp0;

    u2_temp0 = MOTOR_ERROR_NONE;

    f4_temp0 = fabsf(f4_speed_rad);
    if (f4_temp0 > f4_speed_limit_rad)
    {
        u2_temp0 = MOTOR_ERROR_OVER_SPEED;                             /* over speed error */
    }

    return (u2_temp0);
} /* End of function motor_120_conduction_over_speed_error_check */

/******************************************************************************
* Function Name : motor_120_conduction_over_current_error_check
* Description   : Over current error check
* Arguments     : f4_iu, f4_iv, f4_iw - UVW phase current [A],
*               : f4_overcurrent_limit - Over current limit value [A]
* Return Value  : error status
******************************************************************************/
uint16_t motor_120_conduction_over_current_error_check(float f4_iu, float f4_iv, float f4_iw, float f4_overcurrent_limit)
{
    float    f4_temp0;
    uint16_t u2_temp0;

    u2_temp0 = MOTOR_ERROR_NONE;                                       /* initialize */

    f4_temp0 = fabsf(f4_iu);
    if (f4_temp0 > f4_overcurrent_limit)
    {
        u2_temp0 = MOTOR_ERROR_OVER_CURRENT_SW;                           /* over current error */
    }

    f4_temp0 = fabsf(f4_iv);
    if (f4_temp0 > f4_overcurrent_limit)
    {
        u2_temp0 = MOTOR_ERROR_OVER_CURRENT_SW;                           /* over current error */
    }

    f4_temp0 = fabsf(f4_iw);
    if (f4_temp0 > f4_overcurrent_limit)
    {
        u2_temp0 = MOTOR_ERROR_OVER_CURRENT_SW;                           /* over current error */
    }

    return (u2_temp0);
} /* End of function motor_120_conduction_over_current_error_check */

/******************************************************************************
* Function Name : motor_120_conduction_timeout_error_check
* Description   : Check timeout error
* Arguments     : f4_cnt_timeout - timeout counter
*                 f4_timeout_limit - timeout value
* Return Value  : error status
******************************************************************************/
uint16_t motor_120_conduction_timeout_error_check(float f4_cnt_timeout, float f4_timeout_limit)
{
    uint16_t u2_temp0;

    u2_temp0 = MOTOR_ERROR_NONE;

    if (f4_cnt_timeout > f4_timeout_limit)
    {
#if defined(SENSOR_CFG_CONTROL_HALL)
        u2_temp0 = MOTOR_ERROR_HALL_TIMEOUT;                           /* hall timeout error */
#elif defined(SENSOR_CFG_CONTROL_LESS)
        u2_temp0 = MOTOR_ERROR_BEMF_TIMEOUT;                           /* bemf timeout error */
#endif
    }

    return (u2_temp0);
} /* End of function motor_120_conduction_timeout_error_check */

/******************************************************************************
* Function Name : motor_120_conduction_error_check
* Description   : Check error status
* Arguments     : none
* Return Value  : none
******************************************************************************/
void motor_120_conduction_error_check(void)
{
    /*==================================*/
    /*     sensor module error get      */
    /*==================================*/
    R_MOTOR_SENSOR_ParameterGet(g_st_120_conduction.p_st_sensor,&g_st_120_conduction.st_sensor_output);
    g_st_120_conduction.u2_error_status |= g_st_120_conduction.st_sensor_output.u2_error_status;

    /*==================================*/
    /*     over current error check     */
    /*==================================*/
    g_st_120_conduction.u2_error_status |= motor_120_conduction_over_current_error_check(g_st_120_conduction.f4_iu_ad, g_st_120_conduction.f4_iv_ad, g_st_120_conduction.f4_iw_ad,
            MOTOR_COMMON_CFG_OVERCURRENT_LIMIT);

    /*================================*/
    /*   over voltage error check     */
    /*================================*/
    g_st_120_conduction.u2_error_status |= motor_120_conduction_over_voltage_error_check(g_st_120_conduction.f4_vdc_ad, INVERTER_CFG_OVERVOLTAGE_LIMIT);

    /*================================*/
    /*   under voltage error check    */
    /*================================*/
    g_st_120_conduction.u2_error_status |= motor_120_conduction_low_voltage_error_check(g_st_120_conduction.f4_vdc_ad, INVERTER_CFG_UNDERVOLTAGE_LIMIT);

    /*================================*/
    /*   over speed error check       */
    /*================================*/
#if defined(SENSOR_CFG_CONTROL_HALL)
    if ((STATEMACHINE_STATE_RUN == g_st_120_conduction.u1_mode_system) && (MOTOR_MODE_DRIVE == g_st_120_conduction.u2_run_mode))
    {
        g_st_120_conduction.u2_error_status |= motor_120_conduction_over_speed_error_check(g_st_120_conduction.f4_speed_rad, MOTOR_COMMON_SPEED_LIMIT_RAD);
    }
#elif defined(SENSOR_CFG_CONTROL_LESS)
    if (VOLTAGE_STATE_PI_OUTPUT == R_MOTOR_SPEED_VoltageStateGet())
    {
        g_st_120_conduction.u2_error_status |= motor_120_conduction_over_speed_error_check(g_st_120_conduction.f4_speed_rad, MOTOR_COMMON_SPEED_LIMIT_RAD);
    }
#endif
    /*=========================================================*/
    /*     timeout error check (undetected hall interrupt)     */
    /*=========================================================*/
    /* check run mode */
#if defined(SENSOR_CFG_CONTROL_HALL)
    /* check run mode */
    if ((STATEMACHINE_STATE_RUN == g_st_120_conduction.u1_mode_system) && (MOTOR_MODE_INIT != g_st_120_conduction.u2_run_mode))
    {
        R_MOTOR_SENSOR_TimerCountUp();
        g_st_120_conduction.u2_error_status |= motor_120_conduction_timeout_error_check(R_MOTOR_SENSOR_TimerCountGet(), SENSOR_CFG_TIMEOUT_CNT);
    }
    else
    {
        R_MOTOR_SENSOR_TimerCountClear();
    }
#elif defined(SENSOR_CFG_CONTROL_LESS)
    if (VOLTAGE_STATE_PI_OUTPUT== R_MOTOR_SPEED_VoltageStateGet())
    {
        if (STATEMACHINE_STATE_RUN == g_st_120_conduction.u1_mode_system)            /* check system mode */
        {
            R_MOTOR_SENSOR_TimerCountUp();
        }
        else
        {
            R_MOTOR_SENSOR_TimerCountClear();
        }
        g_st_120_conduction.u2_error_status |= motor_120_conduction_timeout_error_check(R_MOTOR_SENSOR_TimerCountGet(), SENSOR_CFG_TIMEOUT_CNT);
    }
#endif

    if ((MOTOR_ERROR_NONE != g_st_120_conduction.u2_error_status) && (STATEMACHINE_STATE_ERROR != g_st_120_conduction.u1_mode_system))
    {
        R_MOTOR_120_CONDUCTION_ErrorSet();
    }
} /* End of function motor_120_conduction_error_check */

