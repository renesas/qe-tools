/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_120_conduction_manager.c
* Description : General motor control function
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/

#include <machine.h>
#include <math.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"
#include "r_motor_120_conduction_manager.h"

/******************************************************************************
* Exported global variables
******************************************************************************/
extern volatile uint8_t       g_u1_hall_intr_cnt;                     /* hall interrupt counter for start speed calculation */

/******************************************************************************
* Function Name : motor_120_conduction_default_init
* Description   : Initializes motor drive modules with default configuration
* Arguments     : p_st_120_conduction - the pointer to the motor control management data structure
* Return Value  : none
******************************************************************************/
void motor_120_conduction_default_init(st_120_conduction_control_t *p_st_120_conduction)
{
    st_motor_driver_cfg_t   st_driver_cfg;
    st_sensor_cfg_t         st_sensor_cfg;
    st_speed_cfg_t          st_speed_cfg;

    p_st_120_conduction->u1_direction              = MTR_CW;
    p_st_120_conduction->u2_hall_timer_cnt         = 0;
    p_st_120_conduction->f4_overcurrent_limit      = MOTOR_COMMON_CFG_OVERCURRENT_LIMIT;
    p_st_120_conduction->f4_overvoltage_limit      = INVERTER_CFG_OVERVOLTAGE_LIMIT;
    p_st_120_conduction->f4_undervoltage_limit     = INVERTER_CFG_UNDERVOLTAGE_LIMIT;
    p_st_120_conduction->f4_overspeed_limit_rad    = MOTOR_COMMON_SPEED_LIMIT_RAD;
    p_st_120_conduction->u2_hall_timeout_cnt_limit = SENSOR_CFG_TIMEOUT_CNT;
    p_st_120_conduction->u1_flg_wait_stop          = MTR_FLG_CLR;
    p_st_120_conduction->u2_cnt_wait_stop          = SENSOR_CFG_HALL_STOP_WAIT_CNT;
    p_st_120_conduction->u1_hall_wait_cnt          = SENSOR_CFG_HALL_WAIT_SPEED_CALC;
    p_st_120_conduction->f4_rpm_rad                = MTR_RPM2RAD;   /* [rpm]->[rad/s] */

    // Driver module update
    st_driver_cfg.ADCDataGet                       = DRIVER_CFG_FUNC_ADC_DATA_GET;
    st_driver_cfg.ChangeOutputPattern              = DRIVER_CFG_FUNC_CHANGE_PATTERN;
    st_driver_cfg.PWMOutputStart                   = DRIVER_CFG_FUNC_PWM_OUTPUT_START;
    st_driver_cfg.PWMOutputStop                    = DRIVER_CFG_FUNC_PWM_OUTPUT_STOP;
    st_driver_cfg.FreerunTimerStart                = DRIVER_CFG_FUNC_FREERUN_TIMER_START;
    st_driver_cfg.FreerunTimerStop                 = DRIVER_CFG_FUNC_FREERUN_TIMER_STOP;
    st_driver_cfg.FreerunTimerSet                  = DRIVER_CFG_FUNC_FREERUN_TIMERCNT_SET;
    st_driver_cfg.FreerunTimerGet                  = DRIVER_CFG_FUNC_FREERUN_TIMERCNT_GET;
    st_driver_cfg.HallUEnable                      = DRIVER_CFG_HALL_FUNC_INT_U_START;
    st_driver_cfg.HallVEnable                      = DRIVER_CFG_HALL_FUNC_INT_V_START;
    st_driver_cfg.HallWEnable                      = DRIVER_CFG_HALL_FUNC_INT_W_START;
    st_driver_cfg.HallUDisable                     = DRIVER_CFG_HALL_FUNC_INT_U_STOP;
    st_driver_cfg.HallVDisable                     = DRIVER_CFG_HALL_FUNC_INT_V_STOP;
    st_driver_cfg.HallWDisable                     = DRIVER_CFG_HALL_FUNC_INT_W_STOP;
    R_MOTOR_DRIVER_ParameterUpdate(g_st_120_conduction.p_st_driver , &st_driver_cfg);

    // Speed module update
    st_speed_cfg.f4_rpm_rad                        = p_st_120_conduction->f4_rpm_rad;   /* [rpm]->[rad/s] */
    st_speed_cfg.f4_ref_speed_rad                  = 0;                                 /* reference speed [rpm]->[rad/s] */
    /* speed PI gain */
    st_speed_cfg.f4_kp_speed                       = SPEED_CFG_SPEED_PI_KP;
    st_speed_cfg.f4_ki_speed                       = SPEED_CFG_SPEED_PI_KI;
    st_speed_cfg.f4_limit_speed_change             = SPEED_CFG_SPEED_CHANGE_LIMIT;    /* speed ref change limit */
    st_speed_cfg.f4_start_refv                     = MOTOR_CFG_START_REF_VOLTAGE;
    R_MOTOR_SPEED_ParameterUpdate(g_st_120_conduction.p_st_speed , &st_speed_cfg);

    /* Sensor module update */
    st_sensor_cfg.f4_speed_lpf_k                   = SPEED_CFG_SPEED_LPF_K;
    st_sensor_cfg.u1_hall_wait_cnt                 = SENSOR_CFG_HALL_WAIT_SPEED_CALC;
    R_MOTOR_SENSOR_ParameterUpdate(g_st_120_conduction.p_st_sensor , &st_sensor_cfg);

    motor_120_conduction_reset(&g_st_120_conduction);

    p_st_120_conduction->u2_sensor_conf            = 0;
    p_st_120_conduction->u2_method_conf            = 0;
    p_st_120_conduction->u2_ctrl_conf              = 0;

} /* End of function motor_120_conduction_default_init */

/******************************************************************************
* Function Name : motor_120_conduction_reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : p_st_120_conduction - the pointer to the motor control management data structure
* Return Value  : none
******************************************************************************/
void motor_120_conduction_reset(st_120_conduction_control_t *p_st_120_conduction)
{

    p_st_120_conduction->u1_mode_system = STATEMACHINE_STATE_STOP;  /* system mode update : stop mode */
    p_st_120_conduction->u2_run_mode = MOTOR_MODE_INIT;
    p_st_120_conduction->u2_error_status = MOTOR_ERROR_NONE;
    p_st_120_conduction->f4_v_ref = 0.0f;
    p_st_120_conduction->f4_vdc_ad = 0.0f;
    p_st_120_conduction->f4_iu_ad = 0.0f;
    p_st_120_conduction->f4_iv_ad = 0.0f;
    p_st_120_conduction->f4_iw_ad = 0.0f;
    p_st_120_conduction->f4_offset_iu = 0.0f;
    p_st_120_conduction->f4_offset_iv = 0.0f;
    p_st_120_conduction->f4_offset_iw = 0.0f;
    p_st_120_conduction->f4_sum_iu_ad = 0.0f;
    p_st_120_conduction->f4_sum_iv_ad = 0.0f;
    p_st_120_conduction->f4_sum_iw_ad = 0.0f;
#if defined(SENSOR_CFG_CONTROL_LESS)
    p_st_120_conduction->f4_vu_ad = 0;
    p_st_120_conduction->f4_vv_ad = 0;
    p_st_120_conduction->f4_vw_ad = 0;
    p_st_120_conduction->f4_vn_ad = 0;
    p_st_120_conduction->f4_offset_vu = 0;
    p_st_120_conduction->f4_offset_vv = 0;
    p_st_120_conduction->f4_offset_vw = 0;
    p_st_120_conduction->f4_offset_off_vu = 0;
    p_st_120_conduction->f4_offset_off_vv = 0;
    p_st_120_conduction->f4_offset_off_vw = 0;
    p_st_120_conduction->f4_sum_vu_ad = 0;
    p_st_120_conduction->f4_sum_vv_ad = 0;
    p_st_120_conduction->f4_sum_vw_ad = 0;
#endif
    p_st_120_conduction->u2_offset_calc_time = CURRENT_CFG_OFFSET_CALC_TIME;
    p_st_120_conduction->u1_flag_offset_calc = MTR_FLG_CLR;
    p_st_120_conduction->f4_inv_offset_calc = 1.0f / (float)CURRENT_CFG_OFFSET_CALC_TIME;
    p_st_120_conduction->u2_cnt_adjust = 0;
    p_st_120_conduction->u2_pwm_duty = 0;

    p_st_120_conduction->st_speed_output.f4_v_ref = 0.0f;

    p_st_120_conduction->st_sensor_output.f4_speed_rad = 0.0f;
    p_st_120_conduction->st_sensor_output.u2_error_status = MOTOR_ERROR_NONE;

    /****** for ICS ******/
    g_u1_enable_write = 0;
    /*********************/
    g_u1_hall_intr_cnt = 0;

    R_MOTOR_SENSOR_Reset();
    R_MOTOR_SPEED_Reset();

    motor_120_conduction_mode_set(p_st_120_conduction);
    motor_120_conduction_speed_rad_set(p_st_120_conduction);
} /* End of function motor_120_conduction_reset */

/******************************************************************************
* Function Name : motor_120_conduction_decide_direction
* Description   : Decide direction
* Arguments     : p_st_120_conduction - the pointer to the motor control management data structure
* Return Value  : none
******************************************************************************/
void motor_120_conduction_decide_direction(st_120_conduction_control_t *p_st_120_conduction)
{
    /* no use */
} /* End of function motor_120_conduction_decide_direction */

/******************************************************************************
* Function Name : motor_120_conduction_error_process
* Description   : Sets error flags and trigger error event when u2_error_flag is not zero
* Arguments     : p_st_120_conduction - the pointer to the motor control management data structure
*                 u2_error_flag - error code
* Return Value  : none
******************************************************************************/
void motor_120_conduction_error_process(st_120_conduction_control_t *p_st_120_conduction,uint16_t u2_error_flag)
{
    if (MOTOR_ERROR_NONE != u2_error_flag)
    {
        p_st_120_conduction->u2_error_status |= u2_error_flag;
        motor_120_conduction_statemachine_event(STATEMACHINE_EVENT_ERROR);
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_120_conduction_error_process */


/******************************************************************************
* Function Name : motor_120_conduction_pwm_duty_calc
* Description   : Calcuration PWM
* Arguments     : p_st_120_conduction - the pointer to the motor control management data structure
* Return Value  : duty
******************************************************************************/
uint16_t motor_120_conduction_pwm_duty_calc(st_120_conduction_control_t *p_st_120_conduction)
{
    float    f4_temp;
    uint16_t u2_pwm_duty;

    f4_temp = (p_st_120_conduction->f4_v_ref * MOTOR_COMMON_NDT_CARRIER_SET) / p_st_120_conduction->f4_vdc_ad;
    u2_pwm_duty = (uint16_t)(f4_temp + MOTOR_COMMON_DEADTIME_SET);

    return(u2_pwm_duty);
} /* End of function motor_120_conduction_pwm_duty_calc */

/******************************************************************************
* Function Name : motor_120_conduction_wait_motor_stop
* Description   : Wait for motor stop
* Arguments     : p_st_120_conduction - the pointer to the motor control management data structure
* Return Value  : none
******************************************************************************/
void motor_120_conduction_wait_motor_stop(st_120_conduction_control_t *p_st_120_conduction)
{
    /*** wait motor stop ***/
    if (MTR_FLG_SET == p_st_120_conduction->u1_flg_wait_stop)                 /* waiting for motor stop */
    {
#if defined(SENSOR_CFG_CONTROL_HALL)
        p_st_120_conduction->u2_cnt_wait_stop--;
        if (0 == p_st_120_conduction->u2_cnt_wait_stop)                       /* motor stop detect counter */
        {
            p_st_120_conduction->u1_flg_wait_stop = MTR_FLG_CLR;
        }
#elif defined(SENSOR_CFG_CONTROL_LESS)
        if (MOTOR_CFG_STOP_BEMF > p_st_120_conduction->f4_vn_ad)
        {
            p_st_120_conduction->u1_flg_wait_stop = MTR_FLG_CLR;
        }

#endif
    }
} /* End of function motor_120_conduction_wait_motor_stop */

/******************************************************************************
* Function Name : motor_120_conduction_mode_set
* Description   : Set run_mode, system_mode, duty to speed and sensor module
* Arguments     : p_st_120_conduction - the pointer to the motor control management data structure
* Return Value  : none
******************************************************************************/
void motor_120_conduction_mode_set(st_120_conduction_control_t *p_st_120_conduction)
{
    st_sensor_input_t st_sensor_input;
    st_speed_input_t  st_speed_input;

    st_sensor_input.u2_run_mode = p_st_120_conduction->u2_run_mode;
    st_sensor_input.u1_mode_system = p_st_120_conduction->u1_mode_system;
    st_sensor_input.u2_pwm_duty = p_st_120_conduction->u2_pwm_duty;
    R_MOTOR_SENSOR_ParameterSet(p_st_120_conduction->p_st_sensor,&st_sensor_input); // hall parameter set

    st_speed_input.u2_run_mode  = p_st_120_conduction->u2_run_mode;
    st_speed_input.f4_speed_rad = p_st_120_conduction->f4_speed_rad;
    R_MOTOR_SPEED_ParameterSet(p_st_120_conduction->p_st_speed, &st_speed_input);   // speed parameter set
} /* End of function motor_120_conduction_mode_set */

/******************************************************************************
* Function Name : motor_120_conduction_v_ref_get
* Description   : Get v_ref from speed module
* Arguments     : p_st_120_conduction - the pointer to the motor control management data structure
* Return Value  : none
******************************************************************************/
void motor_120_conduction_v_ref_get(st_120_conduction_control_t *p_st_120_conduction)
{

    R_MOTOR_SPEED_ParameterGet(p_st_120_conduction->p_st_speed, &p_st_120_conduction->st_speed_output);
    p_st_120_conduction->f4_v_ref = p_st_120_conduction->st_speed_output.f4_v_ref;

} /* End of function motor_120_conduction_v_ref_get */

/******************************************************************************
* Function Name : motor_120_conduction_speed_rad_set
* Description   : Set speed_rad to speed module
* Arguments     : p_st_120_conduction - the pointer to the motor control management data structure
* Return Value  : none
******************************************************************************/
void motor_120_conduction_speed_rad_set(st_120_conduction_control_t *p_st_120_conduction)
{
    st_speed_input_t st_speed_input;

    R_MOTOR_SENSOR_ParameterGet(p_st_120_conduction->p_st_sensor, &p_st_120_conduction->st_sensor_output);
    p_st_120_conduction->f4_speed_rad = p_st_120_conduction->st_sensor_output.f4_speed_rad;
    p_st_120_conduction->u2_error_status = p_st_120_conduction->st_sensor_output.u2_error_status;

    st_speed_input.u2_run_mode  = p_st_120_conduction->u2_run_mode;
    st_speed_input.f4_speed_rad = p_st_120_conduction->f4_speed_rad;
    R_MOTOR_SPEED_ParameterSet(p_st_120_conduction->p_st_speed, &st_speed_input);   // speed parameter set
} /* End of function motor_120_conduction_speed_rad_set */


#if defined(SENSOR_CFG_CONTROL_LESS)
/******************************************************************************
* Function Name : motor_120_conduction_generate_pattern
* Description   : Generate voltage pattern
* Arguments     : vu_ad, vv_ad, vw_ad - UVW phase voltage [V],
*               : vn_ad - Neutral voltage[V]
* Return Value  : voltage pattern
******************************************************************************/
uint8_t motor_120_conduction_generate_pattern(float vu_ad, float vv_ad, float vw_ad, float vn_ad)
{
    uint8_t u1_temp;

    u1_temp = 0;        /* initialize temporary variable */

    /*=========================================================*/
    /*     compare voltages of 3 phases to neutral voltage     */
    /*                                                         */
    /*     g_u1_bemf_signal b7:b3 - don't use                  */
    /*                      b2    - U phase                    */
    /*                      b1    - V phase                    */
    /*                      b0    - W phase                    */
    /*=========================================================*/
    if (vu_ad > vn_ad)
    {
        u1_temp |= 0x04;
    }
    else
    {
        u1_temp &= ~0x04;
    }

    if (vv_ad > vn_ad)
    {
        u1_temp |= 0x02;
    }
    else
    {
        u1_temp &= ~0x02;
    }

    if (vw_ad > vn_ad)
    {
        u1_temp |= 0x01;
    }
    else
    {
        u1_temp &= ~0x01;
    }

    return (u1_temp);
} /* End of function motor_120_conduction_generate_pattern */

#endif

