/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_120_conduction_action.h
* Description : A definitions of the processing of a motor control layer
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_120_CONDUCTION_ACTION_H
#define R_MOTOR_120_CONDUCTION_ACTION_H


/******************************************************************************
* Global function definitions
******************************************************************************/
/* for sequence control */
uint8_t  motor_120_conduction_act_active(uint8_t u1_state);   /* Processing for motor control start */
uint8_t  motor_120_conduction_act_inactive(uint8_t u1_state); /* Processing for motor control stop */
uint8_t  motor_120_conduction_act_none(uint8_t u1_state);     /* Do nothing */
uint8_t  motor_120_conduction_act_reset(uint8_t u1_state);    /* Processing for motor control reset */
uint8_t  motor_120_conduction_act_error(uint8_t u1_state);    /* Processing when detecting an error */
#endif /* R_MOTOR_120_CONDUCTION_ACTION_H */
