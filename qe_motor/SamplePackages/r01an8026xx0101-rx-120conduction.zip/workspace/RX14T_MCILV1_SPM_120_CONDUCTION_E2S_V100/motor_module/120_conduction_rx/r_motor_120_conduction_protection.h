/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_120_conduction_protection.h
* Description : A definitions of the general motor control function
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_120_CONDUCTION_PROTECTION_H
#define R_MOTOR_120_CONDUCTION_PROTECTION_H

/******************************************************************************
* Global function definitions
******************************************************************************/
uint16_t    motor_120_conduction_over_voltage_error_check(float, float);  /* Over voltage error check */
uint16_t    motor_120_conduction_low_voltage_error_check(float, float);   /* Under voltage error check */
uint16_t    motor_120_conduction_over_speed_error_check(float, float);    /* Over speed error check */
uint16_t    motor_120_conduction_over_current_error_check(float, float, float, float);
                                                                          /* Over current error check */
uint16_t    motor_120_conduction_timeout_error_check(float, float);       /* Check hall interrupt timeout error */
void        motor_120_conduction_error_check(void);                       /* Check error status */
void        motor_120_conduction_over_current_interrupt(void);            /* Over Current (POE) Interrupt function*/
#endif /* R_MOTOR_120_CONDUCTION_PROTECTION_H */
