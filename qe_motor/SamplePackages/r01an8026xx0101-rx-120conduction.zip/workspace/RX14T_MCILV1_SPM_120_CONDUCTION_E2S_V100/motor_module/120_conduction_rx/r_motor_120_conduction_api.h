/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_120_conduction_api.h
* Description : A definitions of the processing of a motor control layer
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_120_CONDUCTION_API_H
#define R_MOTOR_120_CONDUCTION_API_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_motor_module_cfg.h"
#include "r_motor_120_conduction_statemachine.h"
#include "r_motor_driver.h"

/******************************************************************************
* Macro definitions
******************************************************************************/
/* run mode */
#define     MOTOR_MODE_INIT               (0x00)
#define     MOTOR_MODE_BOOT               (0x01)
#define     MOTOR_MODE_DRIVE              (0x02)
#define     MOTOR_MODE_ANALYSIS           (0x03)
#define     MOTOR_MODE_TUNE               (0x04)

/* error status */
#define     MOTOR_ERROR_NONE              (0x0000)
#define     MOTOR_ERROR_OVER_CURRENT_HW   (0x0001)
#define     MOTOR_ERROR_OVER_VOLTAGE      (0x0002)
#define     MOTOR_ERROR_OVER_SPEED        (0x0004)
#define     MOTOR_ERROR_HALL_TIMEOUT      (0x0008)
#define     MOTOR_ERROR_BEMF_TIMEOUT      (0x0010)
#define     MOTOR_ERROR_HALL_PATTERN      (0x0020)
#define     MOTOR_ERROR_BEMF_PATTERN      (0x0040)
#define     MOTOR_ERROR_LOW_VOLTAGE       (0x0080)
#define     MOTOR_ERROR_OVER_CURRENT_SW   (0x0100)
#define     MOTOR_ERROR_UNKNOWN           (0xffff)

/* sensor */
#define     MOTOR_SENSOR_LESS             (0x01)
#define     MOTOR_SENSOR_HALL             (0x02)
#define     MOTOR_SENSOR_ENCD             (0x04)
#define     MOTOR_SENSOR_RESO             (0x08)

/* method */
#define     MOTOR_METHOD_FOC              (0x00)
#define     MOTOR_METHOD_180              (0x01)
#define     MOTOR_METHOD_WIDE             (0x02)
#define     MOTOR_METHOD_120              (0x03)

/* control */
#define     MOTOR_CONTROL_CURRENT         (0x01)
#define     MOTOR_CONTROL_SPEED           (0x02)
#define     MOTOR_CONTROL_POSITION        (0x04)
#define     MOTOR_CONTROL_TORQUE          (0x08)
#define     MOTOR_CONTROL_VOLTAGE         (0x10)


/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
#if defined(SENSOR_CFG_CONTROL_HALL)
/* Motor parameter structure */
typedef struct
{
    uint8_t     u1_mode_system;                        /* system mode */
    uint16_t    u2_run_mode;                           /* run mode */
    uint16_t    u2_error_status;                       /* error status */
    float       f4_vdc_ad;
    float       f4_v_ref;
    float       f4_start_refv;
    float       f4_iu_ad;
    float       f4_iv_ad;
    float       f4_iw_ad;
    float       f4_offset_iu;
    float       f4_offset_iv;
    float       f4_offset_iw;
    float       f4_sum_iu_ad;
    float       f4_sum_iv_ad;
    float       f4_sum_iw_ad;
    float       f4_inv_offset_calc;
    uint16_t    u2_offset_calc_time;
    uint8_t     u1_flag_offset_calc;
    uint16_t    u2_cnt_adjust;
    uint8_t     u1_direction;
    uint16_t    u2_hall_timer_cnt;
    float       f4_overcurrent_limit;
    float       f4_overvoltage_limit;
    float       f4_undervoltage_limit;
    float       f4_overspeed_limit_rad;
    uint16_t    u2_hall_timeout_cnt_limit;
    uint16_t    u2_pwm_duty;
    float       f4_speed_rad;
    float       f4_rpm_rad;
    uint8_t     u1_flg_wait_stop;
    uint16_t    u2_cnt_wait_stop; //sensor
    uint8_t     u1_hall_wait_cnt;

    st_speed_output_t       st_speed_output;
    st_sensor_output_t st_sensor_output;

    /* Sub-modules */
    st_motor_parameter_t    st_motor;         /* Motor parameters structure */

    /* Other-modules */
    st_motor_driver_t       * p_st_driver;
    st_speed_control_t      * p_st_speed;    /* Speed control structure */
    st_sensor_t             * p_st_sensor;   /* Encoder control structure */

    // rmw info
    uint16_t    u2_sensor_conf;
    uint16_t    u2_method_conf;
    uint16_t    u2_ctrl_conf;

} st_120_conduction_control_t;

typedef struct
{
    uint8_t     u1_hall_wait_cnt;
    uint16_t    u2_offset_calc_time;
    uint16_t    u2_mtr_p;
    uint8_t     u1_direction;
    float       f4_rpm_rad;
}st_120_conduction_cfg_t;

#elif defined(SENSOR_CFG_CONTROL_LESS)

typedef struct
{
    uint8_t     u1_mode_system;                     /* system mode */
    uint16_t    u2_run_mode;                        /* run mode */
    uint16_t    u2_error_status;                    /* error status */
    float       f4_vdc_ad;                          /* bus voltage */
    float       f4_v_ref;                           /* voltage reference (output of speed PI control) */
    float       f4_start_refv;                      /* reference voltage for BOOT Mode */

    /* Sensor less only start */
    float       f4_vu_ad;                           /* U phase voltage */
    float       f4_vv_ad;                           /* V phase voltage */
    float       f4_vw_ad;                           /* W phase voltage */
    float       f4_vn_ad;                           /* neutral voltage */
    float       f4_offset_vu;                       /* offset U phase voltage */
    float       f4_offset_vv;                       /* offset V phase voltage */
    float       f4_offset_vw;                       /* offset W phase voltage */
    float       f4_offset_off_vu;                   /* offset U phase voltage for PWM output disable */
    float       f4_offset_off_vv;                   /* offset V phase voltage for PWM output disable */
    float       f4_offset_off_vw;                   /* offset W phase voltage for PWM output disable */
    float       f4_sum_vu_ad;                       /* U phase voltage sum */
    float       f4_sum_vv_ad;                       /* V phase voltage sum */
    float       f4_sum_vw_ad;                       /* W phase voltage sum */
    uint8_t     u1_flag_draw_in;                    /* draw in a initial position */
    /* Sensor less only end */

    float       f4_iu_ad;                           /* U phase current */
    float       f4_iv_ad;                           /* V phase current */
    float       f4_iw_ad;                           /* W phase current */
    float       f4_offset_iu;                       /* offset U phase current */
    float       f4_offset_iv;                       /* offset V phase current */
    float       f4_offset_iw;                       /* offset W phase current */
    float       f4_sum_iu_ad;                       /* U phase voltage sum */
    float       f4_sum_iv_ad;                       /* V phase voltage sum  */
    float       f4_sum_iw_ad;                       /* W phase voltage sum */
    float       f4_inv_offset_calc;                 /* the inverse of u2_offset_calc_time */
    uint16_t    u2_offset_calc_time;                /* offset calculation time */
    uint8_t     u1_flag_offset_calc;                /* offset calculation mode flag */
    uint16_t    u2_cnt_adjust;                      /* adjust counter value */

    uint8_t     u1_direction;                       /* rotational direction (0:CW ,1:CCW) */
    uint16_t    u2_hall_timer_cnt;
    float       f4_overcurrent_limit;               /* no use */
    float       f4_overvoltage_limit;               /* no use */
    float       f4_undervoltage_limit;              /* no use */
    float       f4_overspeed_limit_rad;             /* no use */
    uint16_t    u2_hall_timeout_cnt_limit;          /* no use */

    uint16_t    u2_pwm_duty;                        /* PWM duty */
    float       f4_speed_rad;                       /* motor speed */
    float       f4_rpm_rad;                         /* [rpm]->[rad/s] */
    uint8_t     u1_flg_wait_stop;                   /* flag for waiting for motor stop */
    uint16_t    u2_cnt_wait_stop;                   /* motor stop detect counter */
    uint8_t     u1_hall_wait_cnt;                   /* wait counts of hall interrupts for speed calculation */

    st_speed_output_t       st_speed_output;
    st_sensor_output_t      st_sensor_output;

    /* Sub-modules */
    st_motor_parameter_t    st_motor;               /* Motor parameters structure */

    /* Other-modules */
    st_motor_driver_t       * p_st_driver;
    st_speed_control_t      * p_st_speed;           /* Speed control structure */
    st_sensor_t             * p_st_sensor;          /* Encoder control structure */

    // rmw info
    uint16_t    u2_sensor_conf;                     /* sensor number */
    uint16_t    u2_method_conf;                     /* method number */
    uint16_t    u2_ctrl_conf;                       /* control target number */

} st_120_conduction_control_t;

typedef struct
{
    uint8_t     u1_hall_wait_cnt;                   /* wait counts of hall interrupts for speed calculation */
    uint16_t    u2_offset_calc_time;                /* offset calculation time */
    uint16_t    u2_mtr_p;                           /* motor pole pairs */
    uint8_t     u1_direction;                       /* rotational direction (0:CW ,1:CCW) */
    float       f4_rpm_rad;                         /* [rpm]->[rad/s] */
}st_120_conduction_cfg_t;

#endif


/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
extern st_120_conduction_control_t g_st_120_conduction;

/******************************************************************************
* Global function definitions
******************************************************************************/
void     R_MOTOR_120_CONDUCTION_Open(void);
void     R_MOTOR_120_CONDUCTION_Close(void);
void     R_MOTOR_120_CONDUCTION_Reset(void);
void     R_MOTOR_120_CONDUCTION_ParameterUpdate(st_120_conduction_control_t *p_st_120_conduction, const st_120_conduction_cfg_t *p_st_120_conduction_cfg);
void     R_MOTOR_120_CONDUCTION_MotorStart(void);
void     R_MOTOR_120_CONDUCTION_MotorStop(void);
void     R_MOTOR_120_CONDUCTION_MotorReset(void);
void     R_MOTOR_120_CONDUCTION_ErrorSet(void);
uint8_t  R_MOTOR_120_CONDUCTION_StatusGet(void);
uint16_t R_MOTOR_120_CONDUCTION_ErrorStatusGet(st_120_conduction_control_t *p_st_120_conduction);
void     R_MOTOR_120_CONDUCTION_SpeedInterrupt(void);
void     R_MOTOR_120_CONDUCTION_CarrierInterrupt(void);
void     R_MOTOR_120_CONDUCTION_OverCurrentInterrupt(void);
void     R_MOTOR_120_CONDUCTION_HallInterrupt(void);


#endif /* R_MOTOR_120_CONDUCTION_API_H */
