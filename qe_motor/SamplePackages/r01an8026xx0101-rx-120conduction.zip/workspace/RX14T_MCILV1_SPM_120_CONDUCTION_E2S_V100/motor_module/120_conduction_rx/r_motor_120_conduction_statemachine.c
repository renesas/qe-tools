/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_120_conduction_statemachine.c
* Description : The processing of a motor control layer
******************************************************************************/
/******************************************************************************
* History : 11.05.2021  Ver.1.00
******************************************************************************/
/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/
#include <machine.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"
#include "r_motor_120_conduction_action.h"

/******************************************************************************
* Exported global variables
******************************************************************************/

static const volatile uint8_t    g_u1_def_state[STATEMACHINE_EVENT_SIZE][STATEMACHINE_STATE_SIZE] = {
/*    state              0:STATEMACHINE_STATE_STOP, 1:STATEMACHINE_STATE_RUN,  2:STATEMACHINE_STATE_ERROR */
/* event   */
/* 0:STATEMACHINE_EVENT_STOP  */{ STATEMACHINE_STATE_STOP,  STATEMACHINE_STATE_STOP,  STATEMACHINE_STATE_ERROR     },
/* 1:STATEMACHINE_EVENT_RUN   */{ STATEMACHINE_STATE_RUN,   STATEMACHINE_STATE_RUN,   STATEMACHINE_STATE_ERROR     },
/* 2:STATEMACHINE_EVENT_ERROR */{ STATEMACHINE_STATE_ERROR, STATEMACHINE_STATE_ERROR, STATEMACHINE_STATE_ERROR     },
/* 3:STATEMACHINE_EVENT_RESET */{ STATEMACHINE_STATE_STOP,  STATEMACHINE_STATE_ERROR, STATEMACHINE_STATE_STOP  },};

static uint8_t (* gp_u1_def_action[STATEMACHINE_EVENT_SIZE][STATEMACHINE_STATE_SIZE])(uint8_t u1_state) = {
/*    state              0:STATEMACHINE_STATE_STOP, 1:STATEMACHINE_STATE_RUN,  2:STATEMACHINE_STATE_ERROR */
/* event */
/* 0:STATEMACHINE_EVENT_STOP  */{ motor_120_conduction_act_none,    motor_120_conduction_act_inactive, motor_120_conduction_act_none  },
/* 1:STATEMACHINE_EVENT_RUN   */{ motor_120_conduction_act_active,  motor_120_conduction_act_none,     motor_120_conduction_act_none  },
/* 2:STATEMACHINE_EVENT_ERROR */{ motor_120_conduction_act_error,   motor_120_conduction_act_error,    motor_120_conduction_act_none  },
/* 3:STATEMACHINE_EVENT_RESET */{ motor_120_conduction_act_reset,   motor_120_conduction_act_error,    motor_120_conduction_act_reset },};

/******************************************************************************
* Function Name : motor_120_conduction_statemachine_event
* Description   : Change motor state and select action
* Arguments     : u1_event - event
* Return Value  : none
******************************************************************************/
void motor_120_conduction_statemachine_event(uint8_t u1_event)
{

    if (STATEMACHINE_EVENT_SIZE <= u1_event)                    /* check unknown event */
    {
        g_st_120_conduction.u1_mode_system = STATEMACHINE_STATE_ERROR;          /* system mode update : error mode */
        g_st_120_conduction.u2_error_status = MOTOR_ERROR_UNKNOWN;      /* error status update : unknown error */
    }
    else if (STATEMACHINE_STATE_SIZE <= g_st_120_conduction.u1_mode_system)    /* check unknown state */
    {
        g_st_120_conduction.u1_mode_system = STATEMACHINE_STATE_ERROR;          /* system mode update : error mode */
        g_st_120_conduction.u2_error_status = MOTOR_ERROR_UNKNOWN;      /* error status update : unknown error */
    }
    else
    {
        /* change motor state and select action */
        g_st_120_conduction.u1_mode_system = (gp_u1_def_action[u1_event][g_st_120_conduction.u1_mode_system])
            (g_u1_def_state[u1_event][g_st_120_conduction.u1_mode_system]);
    }
} /* End of function motor_120_conduction_statemachine_event */

/******************************************************************************
* Function Name : motor_120_conduction_statemachine_status_get
* Description   : Get status of motor control system
* Arguments     : none
* Return Value  : motor status
******************************************************************************/
uint8_t motor_120_conduction_statemachine_status_get(void)
{
    uint8_t u1_mode_system;

    u1_mode_system = g_st_120_conduction.u1_mode_system;

    return (u1_mode_system);
} /* End of function motor_120_conduction_statemachine_status_get */

