/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_module_cfg.h
* Description : Definitions of parameters used in control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 31.03.2022 Ver.1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MOTOR_MODULE_CFG_H
#define R_MOTOR_MODULE_CFG_H

/***********************************************************************************************************************
* Switch definitions
***********************************************************************************************************************/
/*
 * Switch for select sensor type
 */
#define     SENSOR_CFG_CONTROL_HALL
// #define     SENSOR_CFG_CONTROL_LESS

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_motor_common.h"
#include "r_motor_targetmotor_cfg.h"
#include "r_motor_inverter_cfg.h"
#include "r_app_rmw.h"
#include "r_app_board_ui.h"
#include "r_motor_filter.h"
#include "r_motor_pi_control.h"
#include "r_motor_sensor.h"
#include "r_motor_sensor_api.h"
#include "r_motor_speed.h"
#include "r_motor_speed_api.h"
#include "r_motor_120_conduction_api.h"
#include "r_motor_120_conduction_statemachine.h"
#include "r_motor_120_conduction_protection.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/*
 * for MCU
 */
#define     MOTOR_MCU_CFG_PWM_TIMER_FREQ              (CG_CONFIG_MOTOR_PWM_TIMER_FREQ)  /* PWM timer frequency [MHz] */
#define     MOTOR_MCU_CFG_CARRIER_FREQ                (CG_CONFIG_MOTOR_CARRIER_FREQ)    /* carrier wave frequency [kHz] */
#define     MOTOR_MCU_CFG_AD_FREQ                     (CG_MOTOR_MCU_CFG_AD_FREQ)        /* A/D frequency [MHz] */
#define     MOTOR_MCU_CFG_AD_SAMPLING_CYCLE           (10.5f)                           /* Sampling time(tSPL) [cycle] */
#define     MOTOR_MCU_CFG_AD12BIT_DATA                (CG_MOTOR_CFG_MAX_AD_DATA)        /* A/D 12Bit data */
#define     MOTOR_MCU_CFG_ADC_OFFSET                  (0x7FF)            /* A/D offset */
#define     MOTOR_CFG_MAX_SPEED_RPM                   (2400)             /* maximum limit speed [rpm] (mechanical angle) */
#if defined(SENSOR_CFG_CONTROL_HALL)
#define     MOTOR_CFG_MIN_SPEED_RPM                   (550)              /* minimum limit speed [rpm] (mechanical angle) */
#elif defined(SENSOR_CFG_CONTROL_LESS)
#define     MOTOR_CFG_MIN_SPEED_RPM                   (1000)             /* minimum limit speed [rpm] (mechanical angle) */
#endif
#define     MOTOR_CFG_MARGIN_SPEED                    (50.0f)            /* margin speed [rpm] (mechanical angle) */
#define     MOTOR_CFG_MARGIN_MIN_SPEED                (MOTOR_CFG_MIN_SPEED_RPM - MOTOR_CFG_MARGIN_SPEED)
                                                                         /* min speed (include margin) [rpm] (mechanical angle) */

/****** Macro of current control*****/
#if defined(SENSOR_CFG_CONTROL_HALL)
#define     CURRENT_CFG_OFFSET_CALC_TIME              (512.0f)           /* Current offset calculation time */
#elif defined(SENSOR_CFG_CONTROL_LESS)
#define     CURRENT_CFG_OFFSET_CALC_TIME              (20000)            /* Current offset calculation time */
#endif

/***** Macro of speed control *****/
#define     SPEED_CFG_SPEED_LIMIT_RPM                 (3000)             /* over speed limit [rpm] */


/*
 *  other
 */
/* PWM pattern */
#define     SENSOR_OUTPUT_PATTERN_FIRST60       (1)                      /* enable First 60 degree PWM */
#define     SENSOR_OUTPUT_PATTERN_FIRST60_COMP  (0)                      /* disable Complementary First 60 degree PWM */

#define     MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT  (1.5f)
#define     MOTOR_COMMON_CFG_OVERCURRENT_LIMIT        (MOTOR_CFG_NOMINAL_CURRENT_RMS * MTR_SQRT_2 * MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT)
                                                                         /* Over current limit [A] */
#define     MOTOR_COMMON_DEADTIME_SET                 ((uint16_t)(INVERTER_CFG_DEADTIME * MOTOR_MCU_CFG_PWM_TIMER_FREQ))
                                                                         /* setting value of deadtime */
#define     MOTOR_COMMON_CARRIER_SET_BASE             ((uint16_t)((MOTOR_MCU_CFG_PWM_TIMER_FREQ * 1000 / MOTOR_MCU_CFG_CARRIER_FREQ / 2) + MOTOR_COMMON_DEADTIME_SET))
                                                                         /* max setting value of carrier period */
#define     MOTOR_COMMON_NDT_CARRIER_SET              ((uint16_t)(MOTOR_COMMON_CARRIER_SET_BASE - MOTOR_COMMON_DEADTIME_SET))
                                                                         /* no dead time of "MOTOR_COMMON_CARRIER_SET_BASE" */
#define     MOTOR_COMMON_CURRENT_SCALING              (INVERTER_CFG_CURRENT_RANGE / MOTOR_MCU_CFG_AD12BIT_DATA)  /* for current scaling */
#define     MOTOR_COMMON_VDC_SCALING                  (INVERTER_CFG_VDC_RANGE / MOTOR_MCU_CFG_AD12BIT_DATA) /* for vdc scaling */
#define     MOTOR_COMMON_SPEED_TCNT                   (CMT1.CMCNT)       /* free run timer for speed calculation */
#define     MOTOR_COMMON_SPEED_LIMIT_RAD              (SPEED_CFG_SPEED_LIMIT_RPM * MTR_RPM2RAD)
                                                                         /* over speed limit [rad/s] (electrical) */
#if defined(SENSOR_CFG_CONTROL_HALL)
#define     SPEED_CFG_SPEED_PI_DECIMATION             (0)                /* speed PI control decimation counter */
#define     SPEED_CFG_SPEED_PI_KP                     (0.02f)            /* speed PI proportional gain */
#define     SPEED_CFG_SPEED_PI_KI                     (0.0005f)          /* speed PI integral gain */
#elif defined(SENSOR_CFG_CONTROL_LESS)
#define     SPEED_CFG_SPEED_PI_DECIMATION             (1)                /* speed PI control decimation counter */
#define     SPEED_CFG_SPEED_PI_KP                     (0.02f)            /* speed PI proportional gain */
#define     SPEED_CFG_SPEED_PI_KI                     (0.004f)           /* speed PI integral gain */
#endif

#define     SPEED_CFG_SPEED_PI_I_LIMIT_V              (24.0f)            /* speed PI integral term limit [V] */
#define     SPEED_CFG_SPEED_CALC_BASE                 (MTR_TWOPI * 6000000) /* 2pi * CMT1 timer frequency(48/8 [MHz]) */
                                                                         /* SPEED_CFG_SPEED_CALC_BASE / CMT1 timer value = speed[rad/s] */
#define     SPEED_CFG_SPEED_LPF_K                     (1.0f)             /* speed LPF gain */

#if defined(SENSOR_CFG_CONTROL_HALL)
#define     SPEED_CFG_SPEED_CHANGE_LIMIT              (0.2f)             /* speed ref change limit [rad/s] */
#define     MOTOR_CFG_MAX_OUTPUT_VOLTAGE              (20.0f)            /* max output voltage [v] */
#define     MOTOR_CFG_MIN_OUTPUT_VOLTAGE              (3.0f)             /* min output voltage [v] */
#elif defined(SENSOR_CFG_CONTROL_LESS)
#define     SPEED_CFG_SPEED_CHANGE_LIMIT              (0.2f * MTR_RPM2RAD ) /* speed ref change limit [rad/s] */
#define     MOTOR_CFG_MAX_OUTPUT_VOLTAGE              (20.0f)            /* max output voltage [v] */
#define     MOTOR_CFG_MIN_OUTPUT_VOLTAGE              (5.0f)             /* min output voltage [v] */
#endif

#define     MOTOR_CFG_START_REF_VOLTAGE               (5.8f)             /* start voltage [V] */

#if defined(SENSOR_CFG_CONTROL_LESS)
#define     MOTOR_CFG_MAX_BOOT_VOLTAGE                (8.0f)             /* max output voltage for BOOT MODE [v] */
#define     MOTOR_CFG_SHIFT_ADJUST                    (0)                /* value of angle shift adjusting */
#define     MOTOR_CFG_STOP_BEMF                       (2.0f)             /* value of stop motor BEMF (U+V+W) */
#endif
#if defined(SENSOR_CFG_CONTROL_HALL)
#define     SENSOR_CFG_TIMEOUT_CNT                    (4000)             /* undetected time = 200ms SENSOR_CFG_HALL_TIMEOUT_CNT * 50[us]  */
#elif defined(SENSOR_CFG_CONTROL_LESS)
#define     SENSOR_CFG_TIMEOUT_CNT                    (2000)             /* undetected time = 100ms SENSOR_CFG_HALL_TIMEOUT_CNT * 50[us] */
#endif
#define     SENSOR_CFG_HALL_STOP_WAIT_CNT             (4000)             /* Stop judge time = SENSOR_CFG_HALL_STOP_WAIT_CNT * 50[us] */

#define     SENSOR_CFG_HALL_WAIT_SPEED_CALC           (12)               /* Wait Speed Calculation still Hall interrupts become this counts */

#define     DRIVER_CFG_FUNC_PWM_OUTPUT_START          (R_Config_MOTOR_StartTimerCtrl)
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_STOP           (R_Config_MOTOR_StopTimerCtrl)
#define     DRIVER_CFG_FUNC_ADC_DATA_GET              (R_Config_MOTOR_AdcGetConvVal)
#define     DRIVER_CFG_FUNC_CHANGE_PATTERN            (R_Config_MOTOR_Change_Pattern)
#define     DRIVER_CFG_FUNC_FREERUN_TIMER_START       (R_Config_CMT1_Start)
#define     DRIVER_CFG_FUNC_FREERUN_TIMER_STOP        (R_Config_CMT1_Stop)
#define     DRIVER_CFG_FUNC_FREERUN_TIMERCNT_SET      (R_Config_CMT1_Set_Cmcnt)
#define     DRIVER_CFG_FUNC_FREERUN_TIMERCNT_GET      (R_Config_CMT1_Get_Cmcnt)
#define     DRIVER_CFG_HALL_FUNC_INT_U_START          (R_Config_ICU_IRQ0_Start)
#define     DRIVER_CFG_HALL_FUNC_INT_V_START          (R_Config_ICU_IRQ1_Start)
#define     DRIVER_CFG_HALL_FUNC_INT_W_START          (R_Config_ICU_IRQ6_Start)
#define     DRIVER_CFG_HALL_FUNC_INT_U_STOP           (R_Config_ICU_IRQ0_Stop)
#define     DRIVER_CFG_HALL_FUNC_INT_V_STOP           (R_Config_ICU_IRQ1_Stop)
#define     DRIVER_CFG_HALL_FUNC_INT_W_STOP           (R_Config_ICU_IRQ6_Stop)

#if defined(SENSOR_CFG_CONTROL_LESS)
#define     MOTOR_CFG_DRAW_IN_1ST_TIME        (1)                    /* draw in a initial position of the 1st time */
#define     MOTOR_CFG_DRAW_IN_2ND_TIME        (2)                    /* draw in a initial position of the 2nd time */
#define     MOTOR_CFG_BOOT_REF_VOLTAGE        (3.0f)                 /* voltage reference when zero speed [V] */
#define     MOTOR_CFG_VOLTAGE_UP_TIME         (128)                  /* time to increase v [ms] */
#define     MOTOR_CFG_VOLTAGE_UP_STEP         (MOTOR_CFG_BOOT_REF_VOLTAGE/MOTOR_CFG_VOLTAGE_UP_TIME)  /* addition value of v */
#define     MOTOR_CFG_VOLTAGE_CONST_TIME      (64)                   /* voltage constant time] */
#define     MOTOR_CFG_OL_START_RPM            (150)                  /* start speed [rpm] */
#define     MOTOR_CFG_OL_MODE1_CHANGE_RPM     (300)                  /* to mode2 change speed [rpm] */
#define     MOTOR_CFG_OL_MODE2_CHANGE_RPM     (600)                  /* to mode3 change speed [rpm] */
#define     MOTOR_CFG_OL_MODE1_RATE_RPM       (0.25f)                /* increase rate of reference speed [rpm/control period] */
#define     MOTOR_CFG_OL_MODE2_RATE_RPM       (0.40f)                /* increase rate of reference speed [rpm/control period] */
#define     MOTOR_CFG_OL_START_RAD            (150 * MTR_RPM2RAD)    /* start speed [rad] */
#define     MOTOR_CFG_OL_MODE1_CHANGE_RAD     (185 * MTR_RPM2RAD)    /* to mode2 change speed [rad] */
#define     MOTOR_CFG_OL_MODE2_CHANGE_RAD     (1000 * MTR_RPM2RAD)   /* to mode3 change speed [rad] */
#define     MOTOR_CFG_OL_START_REFV           (3.0f)                 /* start reference voltage [v] */
#define     MOTOR_CFG_OL_MODE1_RATE_RAD       (0.25f * MTR_RPM2RAD)  /* increase rate of reference speed [rad/control period] */
#define     MOTOR_CFG_OL_MODE2_RATE_REFV      (0.00285f)             /* increase rate of reference voltage [v/control period] */
#define     MOTOR_CFG_OL_MODE2_RATE_RAD       (0.71f * MTR_RPM2RAD)  /* increase rate of reference speed [rad/control period] */
#define     MOTOR_CFG_OL_MODE3_RATE_REFV      (0.002f)               /* increase rate of reference voltage [v/control period] */
#define     MOTOR_CFG_OL_MODE3_MAX_REFV       (6.5f)                 /* openloop max voltage [v]*/
#define     MOTOR_CFG_OL_PATTERN_SET_CALC     ((MOTOR_MCU_CFG_CARRIER_FREQ*1000*MTR_TWOPI/6)/MOTOR_CFG_POLE_PAIRS) /* elec -> machine */

#endif

#endif /* R_MOTOR_MODULE_CFG_H */
