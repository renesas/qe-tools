/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_inverter_parameter.h
* Description : Definitions of inverter board parameters
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 31.03.2022 Ver.1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MOTOR_INVERTER_CFG_H
#define R_MOTOR_INVERTER_CFG_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
#define MOTOR_COMMON_CFG_BOARD_MCILV        /* Inverter: MCILV */

/***********************************************************************************************************************
* Target Inverter Define
***********************************************************************************************************************/
/* Target Inverter definitions */
#ifdef MOTOR_COMMON_CFG_BOARD_MCILV
#define     INVERTER_CFG_DEADTIME             (1.0f)          /* Deadtime [us] */
#define     INVERTER_CFG_CURRENT_RANGE        (25.0f)         /* For current scaling range (-12.5[A] ~ 12.5[A]) */
#define     INVERTER_CFG_VDC_RANGE            (111.38f)       /* For Vdc scaling range (0[V] ~ 111.38[V]) */
#define     INVERTER_CFG_INPUT_V              (24.0f)         /* Input DC voltage [V] */
#define     INVERTER_CFG_CURRENT_LIMIT        (16.7f)         /* Current limit[A] for the inverter board */
#define     INVERTER_CFG_OVERVOLTAGE_LIMIT    (60.0f)         /* Over voltage limit [V] */
#define     INVERTER_CFG_UNDERVOLTAGE_LIMIT   (8.0f)          /* Under voltage limit [V] */
#define     INVERTER_CFG_ADC_REF_VOLTAGE      (5.0f)          /* adc reference voltage [V] */
#endif
#endif /* R_MOTOR_INVERTER_CFG_H */
