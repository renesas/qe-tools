/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_driver.h
* Description : A definitions of the general motor control function
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/
/* guard against multiple inclusion */
#ifndef R_MOTOR_DRIVER_H
#define R_MOTOR_DRIVER_H


/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
#if defined(SENSOR_CFG_CONTROL_HALL)
typedef struct
{
    /* The function pointer for AdcGetConvVal function in motor component */
    void (*ADCDataGet)(r_mtr_adc_tb * mtr_ad_data);

    /* The function pointer for hall pattern change function in motor component */
    uint8_t (*ChangeOutputPattern)(uint8_t pattern,uint16_t u2_pwm_duty);

    /* The function pointer for StopTimerCtrl function in motor component */
    void (*PWMOutputStop)(void);

    /* The function pointer for StartTimerCtrl function in motor component */
    void (*PWMOutputStart)(void);

    void (*FreerunTimerStart)(void);
    void (*FreerunTimerStop)(void);
    void (*FreerunTimerSet)(unsigned short u2_cmcnt);
    uint16_t (*FreerunTimerGet)(void);
    void (*HallUEnable)(void);
    void (*HallVEnable)(void);
    void (*HallWEnable)(void);
    void (*HallUDisable)(void);
    void (*HallVDisable)(void);
    void (*HallWDisable)(void);

} st_motor_driver_t;

typedef struct
{
    /* The function pointer for AdcGetConvVal function in motor component */
    void (*ADCDataGet)(r_mtr_adc_tb * mtr_ad_data);

    /* The function pointer for hall pattern change function in motor component */
    uint8_t (*ChangeOutputPattern)(uint8_t pattern,uint16_t u2_pwm_duty);

    /* The function pointer for StopTimerCtrl function in motor component */
    void (*PWMOutputStop)(void);

    /* The function pointer for StartTimerCtrl function in motor component */
    void (*PWMOutputStart)(void);

    void (*PwmOutputStart)(void);
    void (*PwmOutputStop)(void);
    void (*FreerunTimerStart)(void);
    void (*FreerunTimerStop)(void);
    void (*FreerunTimerSet)(unsigned short u2_cmcnt);
    uint16_t (*FreerunTimerGet)(void);
    void (*HallUEnable)(void);
    void (*HallVEnable)(void);
    void (*HallWEnable)(void);
    void (*HallUDisable)(void);
    void (*HallVDisable)(void);
    void (*HallWDisable)(void);

} st_motor_driver_cfg_t;
#elif defined(SENSOR_CFG_CONTROL_LESS)
typedef struct
{
    /* The function pointer for AdcGetConvVal function in motor component */
    void (*ADCDataGet)(r_mtr_adc_tb * mtr_ad_data);

    /* The function pointer for hall pattern change function in motor component */
    uint8_t (*ChangeOutputPattern)(uint8_t pattern,uint16_t u2_pwm_duty);

    /* The function pointer for StopTimerCtrl function in motor component */
    void (*PWMOutputStop)(void);

    /* The function pointer for StartTimerCtrl function in motor component */
    void (*PWMOutputStart)(void);

    void (*FreerunTimerStart)(void);
    void (*FreerunTimerStop)(void);
    void (*FreerunTimerSet)(unsigned short u2_cmcnt);
    uint16_t (*FreerunTimerGet)(void);
    void (*HallUEnable)(void);
    void (*HallVEnable)(void);
    void (*HallWEnable)(void);
    void (*HallUDisable)(void);
    void (*HallVDisable)(void);
    void (*HallWDisable)(void);

} st_motor_driver_t;

typedef struct
{
    /* The function pointer for AdcGetConvVal function in motor component */
    void (*ADCDataGet)(r_mtr_adc_tb * mtr_ad_data);

    /* The function pointer for hall pattern change function in motor component */
    uint8_t (*ChangeOutputPattern)(uint8_t pattern,uint16_t u2_pwm_duty);

    /* The function pointer for StopTimerCtrl function in motor component */
    void (*PWMOutputStop)(void);

    /* The function pointer for StartTimerCtrl function in motor component */
    void (*PWMOutputStart)(void);

    void (*PwmOutputStart)(void);
    void (*PwmOutputStop)(void);
    void (*FreerunTimerStart)(void);
    void (*FreerunTimerStop)(void);
    void (*FreerunTimerSet)(unsigned short u2_cmcnt);
    uint16_t (*FreerunTimerGet)(void);
    void (*HallUEnable)(void);
    void (*HallVEnable)(void);
    void (*HallWEnable)(void);
    void (*HallUDisable)(void);
    void (*HallVDisable)(void);
    void (*HallWDisable)(void);

} st_motor_driver_cfg_t;

#endif

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
extern st_motor_driver_t g_st_driver;


/******************************************************************************
* Global function definitions
******************************************************************************/
void R_MOTOR_DRIVER_Open(void);
void R_MOTOR_DRIVER_Close(void);
void R_MOTOR_DRIVER_ParameterUpdate(st_motor_driver_t * p_st_driver,
                                    const st_motor_driver_cfg_t * p_st_driver_cfg);
#if defined(SENSOR_CFG_CONTROL_HALL)
void R_MOTOR_DRIVER_BldcAnalogGet(st_motor_driver_t * p_st_driver,
                                  float * p_f4_iu_ad,
                                  float * p_f4_iv_ad,
                                  float * p_f4_iw_ad,
                                  float * p_f4_vdc_ad);
#elif defined(SENSOR_CFG_CONTROL_LESS)
void R_MOTOR_DRIVER_BldcAnalogGet(st_motor_driver_t * p_st_driver,
                                  float * p_f4_iu_ad,
                                  float * p_f4_iv_ad,
                                  float * p_f4_iw_ad,
                                  float * p_f4_vdc_ad,
                                  float * p_f4_vu_ad,
                                  float * p_f4_vv_ad,
                                  float * p_f4_vw_ad);
#endif
void R_MOTOR_DRIVER_PWMControlStop(st_motor_driver_t * p_st_driver);
void R_MOTOR_DRIVER_PWMControlStart(st_motor_driver_t * p_st_driver);
uint16_t R_MOTOR_DRIVER_OutputPatternChange(st_motor_driver_t * p_st_driver,uint8_t u1_pattern, uint16_t u2_pwm_duty);

#endif /* R_MOTOR_DRIVER_H */
