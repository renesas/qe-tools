/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_driver.c
* Description : General motor control function
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/

#include <machine.h>
#include <math.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"

st_motor_driver_t g_st_driver;


/******************************************************************************
* Function Name : R_MOTOR_DRIVER_Open
* Description   : Open a motor driver instance
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_DRIVER_Open(void)
{

} /* End of function R_MOTOR_DRIVER_Open */

/******************************************************************************
* Function Name : R_MOTOR_DRIVER_Close
* Description   : Close driver module
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_DRIVER_Close(void)
{

} /* End of function R_MOTOR_DRIVER_Close */

/******************************************************************************
* Function Name : R_MOTOR_DRIVER_ParameterUpdate
* Description   : Update the motor driver parameter
* Arguments     : p_st_driver -     The pointer to the motor driver structure
*                 p_st_driver_cfg - The pointer to the motor driver configuration parameter structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_DRIVER_ParameterUpdate(st_motor_driver_t * p_st_driver,
                                    const st_motor_driver_cfg_t * p_st_driver_cfg)
{
    p_st_driver->ADCDataGet           = p_st_driver_cfg->ADCDataGet;
    p_st_driver->ChangeOutputPattern  = p_st_driver_cfg->ChangeOutputPattern;
    p_st_driver->PWMOutputStart       = p_st_driver_cfg->PWMOutputStart;
    p_st_driver->PWMOutputStop        = p_st_driver_cfg->PWMOutputStop;

    p_st_driver->FreerunTimerStart    = p_st_driver_cfg->FreerunTimerStart;
    p_st_driver->FreerunTimerStop     = p_st_driver_cfg->FreerunTimerStop;
    p_st_driver->FreerunTimerSet      = p_st_driver_cfg->FreerunTimerSet;
    p_st_driver->FreerunTimerGet      = p_st_driver_cfg->FreerunTimerGet;
    p_st_driver->HallUEnable          = p_st_driver_cfg->HallUEnable;
    p_st_driver->HallVEnable          = p_st_driver_cfg->HallVEnable;
    p_st_driver->HallWEnable          = p_st_driver_cfg->HallWEnable;
    p_st_driver->HallUDisable         = p_st_driver_cfg->HallUDisable;
    p_st_driver->HallVDisable         = p_st_driver_cfg->HallVDisable;
    p_st_driver->HallWDisable         = p_st_driver_cfg->HallWDisable;

} /* End of function R_MOTOR_DRIVER_ParameterUpdate */
#if defined(SENSOR_CFG_CONTROL_HALL)
/******************************************************************************
* Function Name : R_MOTOR_DRIVER_BldcAnalogGet
* Description   : Get the current and bus voltage
* Arguments     : p_st_driver - The pointer to the motor driver structure
*                 p_f4_iu_ad  - U phase current A/D conversion value (pointer)
*                 p_f4_iv_ad  - V phase current A/D conversion value (pointer)
*                 p_f4_iw_ad  - W phase current A/D conversion value (pointer)
*                 p_f4_vdc_ad - Bus voltage A/D conversion value (pointer)
* Return Value  : none
******************************************************************************/
void R_MOTOR_DRIVER_BldcAnalogGet(st_motor_driver_t * p_st_driver,
                                  float * p_f4_iu_ad,
                                  float * p_f4_iv_ad,
                                  float * p_f4_iw_ad,
                                  float * p_f4_vdc_ad)
{
    float f4_temp_vdc;
    float f4_temp_iu, f4_temp_iv, f4_temp_iw;
    r_mtr_adc_tb mtr_ad_data;

    p_st_driver->ADCDataGet(&mtr_ad_data);

    f4_temp_vdc = (float)mtr_ad_data.u2_vdc_ad;
    f4_temp_vdc = f4_temp_vdc * MOTOR_COMMON_VDC_SCALING;             /* Vdc */

    *p_f4_vdc_ad = f4_temp_vdc;

    f4_temp_iu = (float)mtr_ad_data.u2_iu_ad;
    f4_temp_iv = (float)mtr_ad_data.u2_iv_ad;
    f4_temp_iw = (float)mtr_ad_data.u2_iw_ad;

    f4_temp_iu = f4_temp_iu - MOTOR_MCU_CFG_ADC_OFFSET;
    f4_temp_iv = f4_temp_iv - MOTOR_MCU_CFG_ADC_OFFSET;
    f4_temp_iw = f4_temp_iw - MOTOR_MCU_CFG_ADC_OFFSET;

    *p_f4_iu_ad = - f4_temp_iu * MOTOR_COMMON_CURRENT_SCALING;                  /* U-phase current */
    *p_f4_iv_ad = - f4_temp_iv * MOTOR_COMMON_CURRENT_SCALING;                  /* V-phase current */
    *p_f4_iw_ad = - f4_temp_iw * MOTOR_COMMON_CURRENT_SCALING;                  /* W-phase current */

} /* End of function R_MOTOR_DRIVER_BldcAnalogGet */
#elif defined(SENSOR_CFG_CONTROL_LESS)
/******************************************************************************
* Function Name : R_MOTOR_DRIVER_BldcAnalogGet
* Description   : Get the current and bus voltage
* Arguments     : p_st_driver - The pointer to the motor driver structure
*                 p_f4_iu_ad  - U phase current A/D conversion value (pointer)
*                 p_f4_iv_ad  - V phase current A/D conversion value (pointer)
*                 p_f4_iw_ad  - W phase current A/D conversion value (pointer)
*                 p_f4_vdc_ad - Bus voltage A/D conversion value (pointer)
*                 p_f4_vu_ad  - U phase voltage A/D conversion value (pointer)
*                 p_f4_vv_ad  - V phase voltage A/D conversion value (pointer)
*                 p_f4_vw_ad  - W phase voltage A/D conversion value (pointer)
* Return Value  : none
******************************************************************************/
void R_MOTOR_DRIVER_BldcAnalogGet(st_motor_driver_t * p_st_driver,
                                  float * p_f4_iu_ad,
                                  float * p_f4_iv_ad,
                                  float * p_f4_iw_ad,
                                  float * p_f4_vdc_ad,
                                  float * p_f4_vu_ad,
                                  float * p_f4_vv_ad,
                                  float * p_f4_vw_ad)
{
    float f4_temp_vdc;
    float f4_temp_iu, f4_temp_iv, f4_temp_iw;
    float f4_temp_vu, f4_temp_vv, f4_temp_vw;
    r_mtr_adc_tb mtr_ad_data;

    p_st_driver->ADCDataGet(&mtr_ad_data);

    f4_temp_vdc = (float)mtr_ad_data.u2_vdc_ad;
    f4_temp_vdc = f4_temp_vdc * MOTOR_COMMON_VDC_SCALING;             /* Vdc */

    *p_f4_vdc_ad = f4_temp_vdc;

    f4_temp_iu = (float)mtr_ad_data.u2_iu_ad;
    f4_temp_iv = (float)mtr_ad_data.u2_iv_ad;
    f4_temp_iw = (float)mtr_ad_data.u2_iw_ad;

    f4_temp_iu = f4_temp_iu - MOTOR_MCU_CFG_ADC_OFFSET;
    f4_temp_iv = f4_temp_iv - MOTOR_MCU_CFG_ADC_OFFSET;
    f4_temp_iw = f4_temp_iw - MOTOR_MCU_CFG_ADC_OFFSET;

    *p_f4_iu_ad = - f4_temp_iu * MOTOR_COMMON_CURRENT_SCALING;                  /* U-phase current */
    *p_f4_iv_ad = - f4_temp_iv * MOTOR_COMMON_CURRENT_SCALING;                  /* V-phase current */
    *p_f4_iw_ad = - f4_temp_iw * MOTOR_COMMON_CURRENT_SCALING;                  /* W-phase current */

    f4_temp_vu = (float)mtr_ad_data.u2_vphase_u_ad;
    f4_temp_vv = (float)mtr_ad_data.u2_vphase_v_ad;
    f4_temp_vw = (float)mtr_ad_data.u2_vphase_w_ad;

    *p_f4_vu_ad = f4_temp_vu * MOTOR_COMMON_VDC_SCALING;
    *p_f4_vv_ad = f4_temp_vv * MOTOR_COMMON_VDC_SCALING;
    *p_f4_vw_ad = f4_temp_vw * MOTOR_COMMON_VDC_SCALING;

} /* End of function R_MOTOR_DRIVER_BldcAnalogGet */

#endif

/***********************************************************************************************************************
* Function Name : R_MOTOR_DRIVER_PWMControlStop
* Description   : Stop PWM outputs
* Arguments     : p_st_driver - The pointer to the motor driver structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_DRIVER_PWMControlStop(st_motor_driver_t * p_st_driver)
{
    p_st_driver->PWMOutputStop();
#if defined(SENSOR_CFG_CONTROL_HALL)
    p_st_driver->HallUDisable();
    p_st_driver->HallVDisable();
    p_st_driver->HallWDisable();
#endif
    p_st_driver->FreerunTimerStop();

} /* End of function R_MOTOR_DRIVER_PWMControlStop */

/***********************************************************************************************************************
* Function Name : R_MOTOR_DRIVER_PWMControlStart
* Description   : Start PWM outputs
* Arguments     : p_st_driver - The pointer to the motor driver structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_DRIVER_PWMControlStart(st_motor_driver_t * p_st_driver)
{

    p_st_driver->PWMOutputStart();
    p_st_driver->FreerunTimerSet(0);
    p_st_driver->FreerunTimerStart();
#if defined(SENSOR_CFG_CONTROL_HALL)
    p_st_driver->HallUEnable();
    p_st_driver->HallVEnable();
    p_st_driver->HallWEnable();
#endif
} /* End of function R_MOTOR_DRIVER_PWMControlStart */

/***********************************************************************************************************************
* Function Name : R_MOTOR_DRIVER_OutputPatternChange
* Description   : Change hall pattern
* Arguments     : p_st_driver - The pointer to the motor driver structure
*                 u1_pattern  - hall pattern
*                 u2_pwm_duty - pwm duty
* Return Value  : None
***********************************************************************************************************************/
uint16_t R_MOTOR_DRIVER_OutputPatternChange(st_motor_driver_t * p_st_driver,uint8_t u1_pattern, uint16_t u2_pwm_duty)
{
    uint16_t u2_result;

    u2_result = p_st_driver->ChangeOutputPattern(u1_pattern, u2_pwm_duty);
    if(MOTOR_ERROR_NONE != u2_result)
    {
#if defined(SENSOR_CFG_CONTROL_HALL)
        u2_result = MOTOR_ERROR_HALL_PATTERN;
#elif defined(SENSOR_CFG_CONTROL_LESS)
        u2_result = MOTOR_ERROR_BEMF_PATTERN;
#endif
    }
    return(u2_result);
} /* End of function R_MOTOR_DRIVER_OutputPatternChange */

