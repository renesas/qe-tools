/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_sensor.c
* Description : The processing of a motor control layer
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/
/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/
#include <machine.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_app_rmw.h"
#include "r_motor_module_cfg.h"


/******************************************************************************
* Exported global variables
******************************************************************************/


/****** for ICS ******/

/*********************/
volatile uint8_t    g_u1_hall_intr_cnt;                        /* hall interrupt counter for start speed calculation */


/******************************************************************************
* Function Name : motor_sensor_output_pattern_change
* Description   : Change voltage pattern
* Arguments     : pattern - Voltage pattern
* Return Value  : none
******************************************************************************/
void  motor_sensor_output_pattern_change(uint8_t pattern)
{
    uint16_t u2_pwm_duty;
    uint16_t u2_result;

    /*========================*/
    /* PWM output arm setting */
    /*========================*/
    /* In case of "Upper arm is PWM" */
    if ((SENSOR_UP_PWM_VN_ON <= pattern && SENSOR_WP_PWM_VN_ON >= pattern) ||
        (SENSOR_U_PWM_VN_ON <= pattern && SENSOR_W_PWM_VN_ON >= pattern))
    {
        u2_pwm_duty = MOTOR_COMMON_CARRIER_SET_BASE - g_st_sensor.u2_pwm_duty;
    }
    /* In case of "Lower arm is PWM" */
    else if ((SENSOR_UP_ON_VN_PWM <= pattern && SENSOR_WP_ON_VN_PWM >= pattern) ||
             (SENSOR_UP_ON_V_PWM <= pattern && SENSOR_WP_ON_V_PWM >= pattern))
    {
        u2_pwm_duty = g_st_sensor.u2_pwm_duty;
    }
    else
    {
        /* Do Nothing */
    }
    u2_result = R_MOTOR_DRIVER_OutputPatternChange(&g_st_driver,pattern, u2_pwm_duty);
    if(MOTOR_ERROR_NONE != u2_result)
    {
        g_st_sensor.u2_error_status |= u2_result;
    }
} /* End of function motor_sensor_output_pattern_change */

#if defined(SENSOR_CFG_CONTROL_HALL)
/******************************************************************************
* Function Name : motor_sensor_speed_calc
* Description   : Calculate motor speed (Hall)
* Arguments     : p_st_sensor - The pointer to the sensor control structure
* Return Value  : none
******************************************************************************/
void motor_sensor_speed_calc(st_sensor_t *p_st_sensor)
{

    uint16_t u2_temp;
    float    f4_temp_speed_rad;

    /* get value of timer counter (CMT1) */
    p_st_sensor->u2_hall_timer_cnt = MOTOR_COMMON_SPEED_TCNT;
    u2_temp = p_st_sensor->u2_hall_timer_cnt - p_st_sensor->u2_pre_hall_timer_cnt;

    /* calculate timer count in 360 degrees */
    /*** average 6 times of motor speed timer ***/
    p_st_sensor->s4_timer_cnt_ave -= p_st_sensor->u2_timer_cnt_buf[p_st_sensor->u2_timer_cnt_num];
    p_st_sensor->u2_timer_cnt_buf[p_st_sensor->u2_timer_cnt_num] = u2_temp;
    p_st_sensor->s4_timer_cnt_ave += u2_temp;

    p_st_sensor->u2_timer_cnt_num++;
    if (p_st_sensor->u2_timer_cnt_num > 5)
    {
        p_st_sensor->u2_timer_cnt_num = 0;
    }

    /*** calculate motor speed ***/
    /* check start calculation */
    if ((MOTOR_MODE_INIT != p_st_sensor->u2_run_mode) && (g_u1_hall_intr_cnt > p_st_sensor->u1_hall_wait_cnt))
    {
        /* Avoid zero divide */
        if (p_st_sensor->s4_timer_cnt_ave != 0)
        {
            f4_temp_speed_rad = (SPEED_CFG_SPEED_CALC_BASE / p_st_sensor->s4_timer_cnt_ave) / MOTOR_CFG_POLE_PAIRS; /* */
        }
        p_st_sensor->f4_speed_rad = motor_filter_lpff(f4_temp_speed_rad, p_st_sensor->f4_speed_rad, p_st_sensor->f4_speed_lpf_k);
    }

    p_st_sensor->u2_pre_hall_timer_cnt = p_st_sensor->u2_hall_timer_cnt;     /* keep timer counter value */

} /* End of function motor_sensor_speed_calc */
#elif defined(SENSOR_CFG_CONTROL_LESS)
/******************************************************************************
* Function Name : motor_sensor_speed_calc
* Description   : Calculate motor speed(Sensor less)
* Arguments     : p_st_sensor - The pointer to the sensor control structure
* Return Value  : none
******************************************************************************/
void motor_sensor_speed_calc(st_sensor_t *p_st_sensor)
{
    uint16_t u2_temp;
    float    f4_temp_speed_rad;

    p_st_sensor->u2_bemf_timer_cnt = MOTOR_COMMON_SPEED_TCNT;                  /* get value of timer counter (CMT1) */

    u2_temp = (p_st_sensor->u2_bemf_timer_cnt - p_st_sensor->u2_pre_bemf_timer_cnt);
                                                               /* calculate timer count in 60 degrees */

    /*** average 6 times of motor speed timer ***/
    p_st_sensor->s4_timer_cnt_ave -= p_st_sensor->u2_timer_cnt_buf[p_st_sensor->u2_timer_cnt_num];
    p_st_sensor->u2_timer_cnt_buf[p_st_sensor->u2_timer_cnt_num] = u2_temp;
    p_st_sensor->s4_timer_cnt_ave += u2_temp;

    p_st_sensor->u2_timer_cnt_num++;
    if (p_st_sensor->u2_timer_cnt_num > 5)
    {
        p_st_sensor->u2_timer_cnt_num = 0;
    }

    /*** calculate motor speed ***/
    f4_temp_speed_rad = (SPEED_CFG_SPEED_CALC_BASE / p_st_sensor->s4_timer_cnt_ave) / MOTOR_CFG_POLE_PAIRS;
    p_st_sensor->f4_speed_rad = motor_filter_lpff(f4_temp_speed_rad, p_st_sensor->f4_speed_rad, p_st_sensor->f4_speed_lpf_k);

    p_st_sensor->u2_pre_bemf_timer_cnt = p_st_sensor->u2_bemf_timer_cnt;     /* keep timer counter value */
} /* End of function motor_sensor_speed_calc */
#endif

/******************************************************************************
* Function Name : motor_sensor_reset
* Description   : Initialize variables when motor control start
* Arguments     : none
* Return Value  : none
******************************************************************************/
void motor_sensor_reset(void)
{

    g_st_sensor.u2_error_status        = MOTOR_ERROR_NONE;
    g_st_sensor.u1_v_pattern           = 0;
    g_st_sensor.u2_pre_hall_timer_cnt  = 0;
    g_st_sensor.u2_hall_timer_cnt      = 0;
    g_st_sensor.s4_timer_cnt_ave       = 0;
    g_st_sensor.u2_timer_cnt_buf[0]    = 0;
    g_st_sensor.u2_timer_cnt_buf[1]    = 0;
    g_st_sensor.u2_timer_cnt_buf[2]    = 0;
    g_st_sensor.u2_timer_cnt_buf[3]    = 0;
    g_st_sensor.u2_timer_cnt_buf[4]    = 0;
    g_st_sensor.u2_timer_cnt_buf[5]    = 0;
    g_st_sensor.u2_timer_cnt_num       = 0;
    g_st_sensor.u1_hall_signal         = 0;
    g_st_sensor.u2_pwm_duty            = 0;
    g_st_sensor.f4_speed_rad           = 0.0f;
#if defined(SENSOR_CFG_CONTROL_LESS)
    g_st_sensor.u1_v_pattern_num       = 0;
    g_st_sensor.u1_bemf_signal         = 0;
    g_st_sensor.u1_pre_bemf_signal     = 0;
    g_st_sensor.u1_flag_pattern_change = MTR_FLG_CLR;
    g_st_sensor.u1_ol_signal           = 0;
    g_st_sensor.u2_ol_pattern_set      = 0;
    g_st_sensor.u2_cnt_ol_pattern_set  = 0;
    g_st_sensor.u2_bemf_timer_cnt      = 0;
    g_st_sensor.u2_pre_bemf_timer_cnt  = 0;
    g_st_sensor.u2_cnt_carrier         = 0;
    g_st_sensor.u2_pre_cnt_carrier     = 0;
    g_st_sensor.u2_angle_shift_cnt     = 0;

#endif
    g_u1_hall_intr_cnt = 0;

} /* End of function motor_sensor_reset */

/******************************************************************************
* Function Name : motor_sensor_output_pattern_first60
* Description   : Set voltage pattern first 60 degree PWM
* Arguments     : p_st_sensor - The pointer to the sensor control structure
*                 u1_signal   - signal
* Return Value  : none
******************************************************************************/
void motor_sensor_output_pattern_first60(st_sensor_t *p_st_sensor, uint8_t u1_signal)
{
    /*** set voltage pattern ***/
    if (MTR_CW == p_st_sensor->u1_direction)                          /* check rotational direction */
    {
        switch (u1_signal)
        {
            case SENSOR_PATTERN_CW_W_V:                           /* from W phase to V phase */
                p_st_sensor->u1_v_pattern = SENSOR_WP_ON_VN_PWM;
            break;

            case SENSOR_PATTERN_CW_U_V:                           /* from U phase to V phase */
                p_st_sensor->u1_v_pattern = SENSOR_UP_PWM_VN_ON;
            break;

            case SENSOR_PATTERN_CW_U_W:                           /* from U phase to W phase */
                p_st_sensor->u1_v_pattern = SENSOR_UP_ON_WN_PWM;
            break;

            case SENSOR_PATTERN_CW_V_W:                           /* from V phase to W phase */
                p_st_sensor->u1_v_pattern = SENSOR_VP_PWM_WN_ON;
            break;

            case SENSOR_PATTERN_CW_V_U:                           /* from V phase to U phase */
                p_st_sensor->u1_v_pattern = SENSOR_VP_ON_UN_PWM;
            break;

            case SENSOR_PATTERN_CW_W_U:                           /* from W phase to U phase */
                p_st_sensor->u1_v_pattern = SENSOR_WP_PWM_UN_ON;
            break;

            default:                                           /* hall signal pattern error */
                p_st_sensor->u1_v_pattern = SENSOR_PATTERN_ERROR;
            break;
        }
    }
    else if (MTR_CCW == p_st_sensor->u1_direction)                    /* check rotational direction */
    {
        switch (u1_signal)
        {
            case SENSOR_PATTERN_CCW_W_V:                          /* from W phase to V phase */
                p_st_sensor->u1_v_pattern = SENSOR_WP_PWM_VN_ON;
            break;

            case SENSOR_PATTERN_CCW_W_U:                          /* from W phase to U phase */
                p_st_sensor->u1_v_pattern = SENSOR_WP_ON_UN_PWM;
            break;

            case SENSOR_PATTERN_CCW_V_U:                          /* from V phase to U phase */
                p_st_sensor->u1_v_pattern = SENSOR_VP_PWM_UN_ON;
            break;

            case SENSOR_PATTERN_CCW_V_W:                          /* from V phase to W phase */
                p_st_sensor->u1_v_pattern = SENSOR_VP_ON_WN_PWM;
            break;

            case SENSOR_PATTERN_CCW_U_W:                          /* from U phase to W phase */
                p_st_sensor->u1_v_pattern = SENSOR_UP_PWM_WN_ON;
            break;

            case SENSOR_PATTERN_CCW_U_V:                          /* from U phase to V phase */
                p_st_sensor->u1_v_pattern = SENSOR_UP_ON_VN_PWM;
            break;

            default:                                           /* hall signal pattern error */
                p_st_sensor->u1_v_pattern = SENSOR_PATTERN_ERROR;
            break;
        }
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_sensor_output_pattern_first60 */

/******************************************************************************
* Function Name : motor_sensor_output_pattern_first60comp
* Description   : Set voltage pattern complementary first 60 degree PWM
* Arguments     : p_st_sensor - The pointer to the sensor control structure
*                 u1_signal   - signal
* Return Value  : none
******************************************************************************/
void motor_sensor_output_pattern_first60comp(st_sensor_t *p_st_sensor, uint8_t u1_signal)
{
    /*** set voltage pattern ***/
    if (MTR_CW == p_st_sensor->u1_direction)                          /* check rotational direction */
    {
        switch (u1_signal)
        {
            case SENSOR_PATTERN_CW_W_V:                           /* from W phase to V phase */
                p_st_sensor->u1_v_pattern = SENSOR_WP_ON_V_PWM;
            break;

            case SENSOR_PATTERN_CW_U_V:                           /* from U phase to V phase */
                p_st_sensor->u1_v_pattern = SENSOR_U_PWM_VN_ON;
            break;

            case SENSOR_PATTERN_CW_U_W:                           /* from U phase to W phase */
                p_st_sensor->u1_v_pattern = SENSOR_UP_ON_W_PWM;
            break;

            case SENSOR_PATTERN_CW_V_W:                           /* from V phase to W phase */
                p_st_sensor->u1_v_pattern = SENSOR_V_PWM_WN_ON;
            break;

            case SENSOR_PATTERN_CW_V_U:                           /* from V phase to U phase */
                p_st_sensor->u1_v_pattern = SENSOR_VP_ON_U_PWM;
            break;

            case SENSOR_PATTERN_CW_W_U:                           /* from W phase to U phase */
                p_st_sensor->u1_v_pattern = SENSOR_W_PWM_UN_ON;
            break;

            default:                                           /* hall signal pattern error */
                p_st_sensor->u1_v_pattern = SENSOR_PATTERN_ERROR;
            break;
        }
    }
    else if (MTR_CCW == p_st_sensor->u1_direction)                    /* check rotational direction */
    {
        switch (u1_signal)
        {
            case SENSOR_PATTERN_CCW_W_V:                          /* from W phase to V phase */
                p_st_sensor->u1_v_pattern = SENSOR_W_PWM_VN_ON;
            break;

            case SENSOR_PATTERN_CCW_W_U:                          /* from W phase to U phase */
                p_st_sensor->u1_v_pattern = SENSOR_WP_ON_U_PWM;
            break;

            case SENSOR_PATTERN_CCW_V_U:                          /* from V phase to U phase */
                p_st_sensor->u1_v_pattern = SENSOR_V_PWM_UN_ON;
            break;

            case SENSOR_PATTERN_CCW_V_W:                          /* from V phase to W phase */
                p_st_sensor->u1_v_pattern = SENSOR_VP_ON_W_PWM;
            break;

            case SENSOR_PATTERN_CCW_U_W:                          /* from U phase to W phase */
                p_st_sensor->u1_v_pattern = SENSOR_U_PWM_WN_ON;
            break;

            case SENSOR_PATTERN_CCW_U_V:                          /* from U phase to V phase */
                p_st_sensor->u1_v_pattern = SENSOR_UP_ON_V_PWM;
            break;

            default:                                           /* hall signal pattern error */
                p_st_sensor->u1_v_pattern = SENSOR_PATTERN_ERROR;
            break;
        }
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_sensor_output_pattern_first60comp */

#if defined(SENSOR_CFG_CONTROL_LESS)
/******************************************************************************
* Function Name : motor_sensor_ol_signal_set
* Description   : Set voltage pattern for open loop
* Arguments     : p_st_sensor - The pointer to the sensor control structure
* Return Value  : none
******************************************************************************/
void motor_sensor_ol_signal_set(st_sensor_t *p_st_sensor)
{
    /* sequence of changing 6 voltage patterns */
    p_st_sensor->u1_v_pattern_num++;
    if (p_st_sensor->u1_v_pattern_num > 6)
    {
        p_st_sensor->u1_v_pattern_num = 1;
    }
    p_st_sensor->u1_ol_signal = p_st_sensor->u1_v_pattern_ol[p_st_sensor->u1_direction][p_st_sensor->u1_v_pattern_num];
} /* End of function motor_sensor_ol_signal_set */
#endif

/******************************************************************************
* Function Name : motor_sensor_output_pattern_set
* Description   : Set voltage pattern
* Arguments     : p_st_sensor - The pointer to the sensor control structure
*                 u1_signal - signal pattern
* Return Value  : none
******************************************************************************/
void motor_sensor_output_pattern_set(st_sensor_t *p_st_sensor, uint8_t u1_signal)
{
    p_st_sensor->u2_cnt_timeout = 0;

    /*** set voltage pattern ***/
#if SENSOR_OUTPUT_PATTERN_FIRST60
    motor_sensor_output_pattern_first60(p_st_sensor,u1_signal);
#elif SENSOR_OUTPUT_PATTERN_FIRST60_COMP
    motor_sensor_output_pattern_first60comp(p_st_sensor,u1_signal);
#endif
} /* End of function motor_sensor_output_pattern_set */

#if defined(SENSOR_CFG_CONTROL_LESS)
/******************************************************************************
* Function Name : motor_sensor_angle_shift_set
* Description   : set adjust shift value for pattern change
* Arguments     : p_st_sensor - The pointer to the sensor control structure
* Return Value  : none
******************************************************************************/
void motor_sensor_angle_shift_set(st_sensor_t *p_st_sensor)
{
    uint16_t u2_temp;

    /* calculate count of 30 degrees */
    u2_temp = (p_st_sensor->u2_pre_cnt_carrier + p_st_sensor->u2_cnt_carrier) >> 2;

    p_st_sensor->u2_angle_shift_cnt = u2_temp - p_st_sensor->s2_angle_shift_adjust;
                                                               /* adjust to count of shift degrees */

    p_st_sensor->u2_pre_cnt_carrier = p_st_sensor->u2_cnt_carrier;           /* keep previous carrier count */

    p_st_sensor->u2_cnt_carrier = 0;
} /* End of function motor_sensor_angle_shift_set */
#endif
