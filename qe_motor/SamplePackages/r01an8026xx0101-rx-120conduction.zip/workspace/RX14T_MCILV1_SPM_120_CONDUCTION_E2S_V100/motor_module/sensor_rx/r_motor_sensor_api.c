/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_speed_api.c
* Description : The processing of accessing driver
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/
#include <math.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"

st_sensor_t g_st_sensor;

/******************************************************************************
* Exported global variables
******************************************************************************/


/******************************************************************************
* Function Name : R_MOTOR_SENSOR_Open
* Description   : Open  sensor module
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_Open(void)
{

    g_st_sensor.u1_hall_wait_cnt      = SENSOR_CFG_HALL_WAIT_SPEED_CALC;
    g_st_sensor.f4_speed_lpf_k        = SPEED_CFG_SPEED_LPF_K;
    g_st_sensor.u1_direction          = MTR_CW;

#if defined(SENSOR_CFG_CONTROL_LESS)
    g_st_sensor.u1_v_pattern_ol[0][0] = 0;
    g_st_sensor.u1_v_pattern_ol[0][1] = SENSOR_PATTERN_CW_U_W;
    g_st_sensor.u1_v_pattern_ol[0][2] = SENSOR_PATTERN_CW_V_W;
    g_st_sensor.u1_v_pattern_ol[0][3] = SENSOR_PATTERN_CW_V_U;
    g_st_sensor.u1_v_pattern_ol[0][4] = SENSOR_PATTERN_CW_W_U;
    g_st_sensor.u1_v_pattern_ol[0][5] = SENSOR_PATTERN_CW_W_V;
    g_st_sensor.u1_v_pattern_ol[0][6] = SENSOR_PATTERN_CW_U_V;
    g_st_sensor.u1_v_pattern_ol[1][0] = 0;
    g_st_sensor.u1_v_pattern_ol[1][1] = SENSOR_PATTERN_CCW_W_V;
    g_st_sensor.u1_v_pattern_ol[1][2] = SENSOR_PATTERN_CCW_W_U;
    g_st_sensor.u1_v_pattern_ol[1][3] = SENSOR_PATTERN_CCW_V_U;
    g_st_sensor.u1_v_pattern_ol[1][4] = SENSOR_PATTERN_CCW_V_W;
    g_st_sensor.u1_v_pattern_ol[1][5] = SENSOR_PATTERN_CCW_U_W;
    g_st_sensor.u1_v_pattern_ol[1][6] = SENSOR_PATTERN_CCW_U_V;
    g_st_sensor.s2_angle_shift_adjust = MOTOR_CFG_SHIFT_ADJUST;
#endif
    /* sensor module data initialize */
    motor_sensor_reset();

} /* End of function R_MOTOR_SENSOR_Open */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_Close
* Description   : Close sensor module
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_Close(void)
{
    /* sensor module data initialize */
    motor_sensor_reset();
} /* End of function R_MOTOR_SENSOR_Close */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_Reset
* Description   : Reset sensor module
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_Reset(void)
{
    /* sensor module data initialize */
    motor_sensor_reset();
} /* End of function R_MOTOR_SENSOR_Reset */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_ParameterSet
* Description   : Set parameter for sensor module
* Arguments     : p_st_sensor       - The pointer to the sensor control structure
*                 p_st_sensor_input - The pointer to the sensor control input structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_ParameterSet(st_sensor_t *p_st_sensor,st_sensor_input_t *p_st_sensor_input)
{
    p_st_sensor->u1_mode_system = p_st_sensor_input->u1_mode_system;
    p_st_sensor->u2_run_mode    = p_st_sensor_input->u2_run_mode;
    p_st_sensor->u2_pwm_duty    = p_st_sensor_input->u2_pwm_duty;
} /* End of function R_MOTOR_SENSOR_ParameterSet */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_ParameterGet
* Description   : Get parameter for sensor module
* Arguments     : p_st_sensor      - The pointer to the sensor control structure
*                 p_st_sensor_output - The pointer to the sensor control output structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_ParameterGet(st_sensor_t *p_st_sensor,st_sensor_output_t *p_st_sensor_output)
{
    p_st_sensor_output->u2_error_status  = p_st_sensor->u2_error_status;
    p_st_sensor_output->f4_speed_rad     = p_st_sensor->f4_speed_rad;
} /* End of function R_MOTOR_SENSOR_ParameterGet */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_ParameterUpdate
* Description   : Update parameter for sensor module
* Arguments     : p_st_sensor   - The pointer to the sensor control structure
*                 p_st_sensor_cfg - The pointer to the sensor control config structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_ParameterUpdate(st_sensor_t *p_st_sensor,const st_sensor_cfg_t *p_st_sensor_cfg)
{
    p_st_sensor->f4_speed_lpf_k   = p_st_sensor_cfg->f4_speed_lpf_k;
    p_st_sensor->u1_hall_wait_cnt = p_st_sensor_cfg->u1_hall_wait_cnt;
} /* End of function R_MOTOR_SENSOR_ParameterUpdate */


/******************************************************************************
* Function Name : R_MOTOR_SENSOR_PatternSet
* Description   : Set output pattern
* Arguments     : p_st_sensor   - The pointer to the sensor control structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_PatternSet(st_sensor_t *p_st_sensor)
{

    motor_sensor_speed_calc(p_st_sensor);                         /* speed calculation */

    /*** get hall signal ***/
    p_st_sensor->u1_hall_signal  = MTR_PORT_HALL_U << 2;
    p_st_sensor->u1_hall_signal |= MTR_PORT_HALL_V << 1;
    p_st_sensor->u1_hall_signal |= MTR_PORT_HALL_W;

    /*** set voltage pattern ***/
    motor_sensor_output_pattern_set(p_st_sensor, p_st_sensor->u1_hall_signal);

    if (STATEMACHINE_STATE_RUN == p_st_sensor->u1_mode_system)                /* check system mode */
    {
        motor_sensor_output_pattern_change(p_st_sensor->u1_v_pattern);       /* change voltage pattern */

    }
} /* End of function R_MOTOR_SENSOR_PatternSet */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_DirectionSet
* Description   : Set rotation direction
* Arguments     : dir - rotational direction
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_DirectionSet(uint8_t dir)
{
    g_st_sensor.u1_direction = dir;
} /* End of function R_MOTOR_SENSOR_DirectionSet */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_DirectionGet
* Description   : Get rotation direction
* Arguments     : none
* Return Value  : rotational direction
******************************************************************************/
uint8_t R_MOTOR_SENSOR_DirectionGet(void)
{
    uint8_t u1_direction;

    u1_direction = g_st_sensor.u1_direction;

    return (u1_direction);
} /* End of function R_MOTOR_SENSOR_DirectionGet */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_TimerCountGet
* Description   : Get timer counter
* Arguments     : none
* Return Value  : Sensor Timeout timer counter
******************************************************************************/
uint16_t R_MOTOR_SENSOR_TimerCountGet(void)
{
    uint16_t   u2_return_val;

    u2_return_val = g_st_sensor.u2_cnt_timeout;

    return(u2_return_val);
} /* End of function R_MOTOR_SENSOR_TimerCountGet */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_TimerCountUp
* Description   : Sensor Timeout timer count up
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_TimerCountUp(void)
{
    if(SENSOR_CFG_TIMEOUT_CNT>= g_st_sensor.u2_cnt_timeout)
    {
        g_st_sensor.u2_cnt_timeout++;
    }
} /* End of function R_MOTOR_SENSOR_TimerCountUp */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_TimerCountClear
* Description   : Sensor Timeout timer counter clear
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_TimerCountClear(void)
{
    g_st_sensor.u2_cnt_timeout = 0;;
} /* End of function R_MOTOR_SENSOR_TimerCountClear */

#if defined(SENSOR_CFG_CONTROL_LESS)
/******************************************************************************
* Function Name : R_MOTOR_SENSOR_StartOpenLoop
* Description   : start by open loop
* Arguments     : p_st_sensor - The pointer to the sensor control structure
*                 f4_ref_speed_rad_ctrl - reference speed
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_StartOpenLoop(st_sensor_t *p_st_sensor,float f4_ref_speed_rad_ctrl)
{

    p_st_sensor->u2_ol_pattern_set = (uint16_t)(MOTOR_CFG_OL_PATTERN_SET_CALC / f4_ref_speed_rad_ctrl);
    if (p_st_sensor->u2_cnt_ol_pattern_set++ > p_st_sensor->u2_ol_pattern_set)
    {
        /* PWM duty set and pattern change */
        motor_sensor_ol_signal_set(p_st_sensor);
        motor_sensor_output_pattern_set(p_st_sensor, p_st_sensor->u1_ol_signal);
        if (STATEMACHINE_STATE_ERROR != p_st_sensor->u1_mode_system)            /* check system mode */
        {
            motor_sensor_output_pattern_change(p_st_sensor->u1_v_pattern);        /* change voltage pattern */
        }
        p_st_sensor->u2_cnt_ol_pattern_set = 0;
    }
} /* End of function R_MOTOR_SENSOR_StartOpenLoop */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_AngleShiftSet
* Description   : set adjust shift value for pattern change
* Arguments     : p_st_sensor -  The pointer to the sensor control structuree
*                 u1_bemf_signal - bemf signal
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_AngleShiftSet(st_sensor_t *p_st_sensor, uint8_t u1_bemf_signal)
{

    p_st_sensor->u2_cnt_carrier++;
    p_st_sensor->u1_pre_bemf_signal = p_st_sensor->u1_bemf_signal;  /* keep previous pattern */
    p_st_sensor->u1_bemf_signal = u1_bemf_signal;
    R_MOTOR_SENSOR_CheckPattern(p_st_sensor);

    /*** change_pattern ***/
    if (MTR_FLG_SET == p_st_sensor->u1_flag_pattern_change)
    {
        motor_sensor_speed_calc(p_st_sensor);
        motor_sensor_angle_shift_set(p_st_sensor);                 /* set shift value */
        p_st_sensor->u1_flag_pattern_change = MTR_FLG_CLR;
    }
} /* End of function R_MOTOR_SENSOR_AngleShiftSet */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_CheckPattern
* Description   : check voltage pattern
* Arguments     : p_st_sensor -  The pointer to the sensor control structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_CheckPattern(st_sensor_t *p_st_sensor)
{
    uint16_t u2_temp;

    if (p_st_sensor->u1_bemf_signal != p_st_sensor->u1_pre_bemf_signal)      /* check changed signal */
    {
        /* calculate three quarters previous count of carrier interrupt */
        u2_temp = (p_st_sensor->u2_pre_cnt_carrier * 3) >> 2;

        if (p_st_sensor->u2_cnt_carrier > u2_temp)                    /* check carrier count */
        {
            p_st_sensor->u1_flag_pattern_change = MTR_FLG_SET;
        }
        else
        {
            p_st_sensor->u1_bemf_signal = p_st_sensor->u1_pre_bemf_signal;   /* invalid changed signal */
        }
    }
} /* End of function R_MOTOR_SENSOR_CheckPattern */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_ShiftAngle
* Description   : Count shift value from zero cross to pattern change
* Arguments     : p_st_sensor -  The pointer to the sensor control structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_ShiftAngle(st_sensor_t *p_st_sensor)
{
    if (p_st_sensor->u2_cnt_carrier == p_st_sensor->u2_angle_shift_cnt)      /* check count of shift degrees */
    {
        motor_sensor_output_pattern_set(p_st_sensor, p_st_sensor->u1_bemf_signal);           /* change voltage pattern */
        if (STATEMACHINE_STATE_ERROR != p_st_sensor->u1_mode_system)            /* check system mode */
        {
            motor_sensor_output_pattern_change(p_st_sensor->u1_v_pattern);        /* change voltage pattern */
        }
    }
} /* End of function R_MOTOR_SENSOR_ShiftAngle */

/******************************************************************************
* Function Name : R_MOTOR_SENSOR_OutputPatternSet
* Description   : Set voltage pattern
* Arguments     : p_st_sensor -  The pointer to the sensor control structure
*                 u1_signal - signal pattern
* Return Value  : none
******************************************************************************/
void R_MOTOR_SENSOR_OutputPatternSet(st_sensor_t *p_st_sensor, uint8_t u1_signal)
{
    motor_sensor_output_pattern_set(p_st_sensor,u1_signal);
    motor_sensor_output_pattern_change(p_st_sensor->u1_v_pattern);
} /* End of function R_MOTOR_SENSOR_OutputPatternSet */
#endif

