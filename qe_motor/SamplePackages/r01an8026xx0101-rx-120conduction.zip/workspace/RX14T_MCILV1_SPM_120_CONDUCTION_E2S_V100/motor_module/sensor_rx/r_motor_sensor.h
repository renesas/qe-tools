/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_sensor.h
* Description : A definitions of the processing of a motor control layer
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_SENSOR_H
#define R_MOTOR_SENSOR_H

/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/
#include "r_motor_sensor_api.h"

/******************************************************************************
* Macro definitions
******************************************************************************/
/* value of hall sensor (CW) */
#define     SENSOR_PATTERN_CW_V_U          (2)                 /* V phase to U phase */
#define     SENSOR_PATTERN_CW_W_U          (3)                 /* W phase to U phase */
#define     SENSOR_PATTERN_CW_W_V          (1)                 /* W phase to V phase */
#define     SENSOR_PATTERN_CW_U_V          (5)                 /* U phase to V phase */
#define     SENSOR_PATTERN_CW_U_W          (4)                 /* U phase to W phase */
#define     SENSOR_PATTERN_CW_V_W          (6)                 /* V phase to W phase */

/* value of hall sensor (CCW) */
#if defined(SENSOR_CFG_CONTROL_HALL)
#define     SENSOR_PATTERN_CCW_V_U         (5)                 /* V phase to U phase */
#define     SENSOR_PATTERN_CCW_V_W         (1)                 /* V phase to W phase */
#define     SENSOR_PATTERN_CCW_U_W         (3)                 /* U phase to W phase */
#define     SENSOR_PATTERN_CCW_U_V         (2)                 /* U phase to V phase */
#define     SENSOR_PATTERN_CCW_W_V         (6)                 /* W phase to V phase */
#define     SENSOR_PATTERN_CCW_W_U         (4)                 /* W phase to U phase */
#elif defined(SENSOR_CFG_CONTROL_LESS)
#define     SENSOR_PATTERN_CCW_V_U         (3)                 /* V phase to U phase */
#define     SENSOR_PATTERN_CCW_V_W         (2)                 /* V phase to W phase */
#define     SENSOR_PATTERN_CCW_U_W         (6)                 /* U phase to W phase */
#define     SENSOR_PATTERN_CCW_U_V         (4)                 /* U phase to V phase */
#define     SENSOR_PATTERN_CCW_W_V         (5)                 /* W phase to V phase */
#define     SENSOR_PATTERN_CCW_W_U         (1)                 /* W phase to U phase */
#endif
/* voltage pattern */
#define     SENSOR_PATTERN_ERROR           (0)                 /* pattern error */
#define     SENSOR_UP_PWM_VN_ON            (1)                 /* Up(PWM) to Vn(on) */
#define     SENSOR_UP_PWM_WN_ON            (2)                 /* Up(PWM) to Wn(on) */
#define     SENSOR_VP_PWM_UN_ON            (3)                 /* Vp(PWM) to Un(on) */
#define     SENSOR_VP_PWM_WN_ON            (4)                 /* Vp(PWM) to Wn(on) */
#define     SENSOR_WP_PWM_UN_ON            (5)                 /* Wp(PWM) to Un(on) */
#define     SENSOR_WP_PWM_VN_ON            (6)                 /* Wp(PWM) to Vn(on) */
#define     SENSOR_UP_ON_VN_PWM            (7)                 /* Up(on) to Vn(PWM) */
#define     SENSOR_UP_ON_WN_PWM            (8)                 /* Up(on) to Wn(PWM) */
#define     SENSOR_VP_ON_UN_PWM            (9)                 /* Vp(on) to Un(PWM) */
#define     SENSOR_VP_ON_WN_PWM            (10)                /* Vp(on) to Wn(PWM) */
#define     SENSOR_WP_ON_UN_PWM            (11)                /* Wp(on) to Un(PWM) */
#define     SENSOR_WP_ON_VN_PWM            (12)                /* Wp(on) to Vn(PWM) */

#define     SENSOR_U_PWM_VN_ON             (13)                /* U(PWM) to Vn(on) */
#define     SENSOR_U_PWM_WN_ON             (14)                /* U(PWM) to Wn(on) */
#define     SENSOR_V_PWM_UN_ON             (15)                /* V(PWM) to Un(on) */
#define     SENSOR_V_PWM_WN_ON             (16)                /* V(PWM) to Wn(on) */
#define     SENSOR_W_PWM_UN_ON             (17)                /* W(PWM) to Un(on) */
#define     SENSOR_W_PWM_VN_ON             (18)                /* W(PWM) to Vn(on) */
#define     SENSOR_UP_ON_V_PWM             (19)                /* Up(on) to V(PWM) */
#define     SENSOR_UP_ON_W_PWM             (20)                /* Up(on) to W(PWM) */
#define     SENSOR_VP_ON_U_PWM             (21)                /* Vp(on) to U(PWM) */
#define     SENSOR_VP_ON_W_PWM             (22)                /* Vp(on) to W(PWM) */
#define     SENSOR_WP_ON_U_PWM             (23)                /* Wp(on) to U(PWM) */
#define     SENSOR_WP_ON_V_PWM             (24)                /* Wp(on) to V(PWM) */

/******************************************************************************
* Global function definitions
******************************************************************************/
void     motor_sensor_output_pattern_change(uint8_t pattern);             /* Change hall pattern */
void     motor_sensor_speed_calc(st_sensor_t *);                          /* Calculate motor speed */
void     motor_sensor_reset(void);                                        /* Initialize variables when motor control start */
void     motor_sensor_output_pattern_first60(st_sensor_t *, uint8_t);     /* Set voltage pattern first 60 degree PWM */
void     motor_sensor_output_pattern_first60comp(st_sensor_t *, uint8_t); /* Set voltage pattern complementary first 60 degree PWM */
void     motor_sensor_output_pattern_set(st_sensor_t *p_st_sensor, uint8_t u1_signal);
#if defined(SENSOR_CFG_CONTROL_LESS)
void     motor_sensor_ol_signal_set(st_sensor_t *p_st_sensor);
void     motor_sensor_angle_shift_set(st_sensor_t *p_st_sensor);
#endif
#endif /* R_MOTOR_SENSOR_H */
