/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_sensor_api.h
* Description : A definitions of the processing of accessing driver
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_SENSOR_API_H
#define R_MOTOR_SENSOR_API_H

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
#if defined(SENSOR_CFG_CONTROL_HALL)
typedef struct
{
    uint8_t  u1_mode_system;                     /* system mode */
    uint16_t u2_run_mode;                        /* run mode */
    uint16_t u2_error_status;                    /* error status */
    uint8_t  u1_v_pattern;
    uint16_t u2_pre_hall_timer_cnt;
    uint16_t u2_hall_timer_cnt;
    int32_t  s4_timer_cnt_ave;                   /* counts for 360 degrees */
    uint16_t u2_timer_cnt_buf[6];                /* counts for 60 degrees */
    uint16_t u2_timer_cnt_num;                   /* array element number before 360 degrees */
    uint8_t  u1_hall_signal;
    uint8_t  u1_hall_wait_cnt;
    uint8_t  u1_direction;
    uint16_t u2_pwm_duty;
    float    f4_speed_rad;
    float    f4_speed_lpf_k;                     /* error status */
    uint16_t u2_cnt_timeout;                     /* Sensor Timeout timercounter */
}st_sensor_t;

typedef struct
{
    float    f4_speed_rad;
    uint16_t u2_error_status;
}st_sensor_output_t;

typedef struct
{
  uint8_t  u1_mode_system;
  uint16_t u2_run_mode;
  uint16_t u2_pwm_duty;
}st_sensor_input_t;


typedef struct
{
    float    f4_speed_lpf_k;
    uint8_t  u1_hall_wait_cnt;
}st_sensor_cfg_t;
#elif defined(SENSOR_CFG_CONTROL_LESS)
typedef struct
{
    uint8_t     u1_mode_system;                     /* system mode */
    uint16_t    u2_run_mode;                        /* run mode */
    uint16_t    u2_error_status;                    /* error status */
    uint8_t     u1_v_pattern;
    uint16_t    u2_pre_hall_timer_cnt;
    uint16_t    u2_hall_timer_cnt;
    int32_t     s4_timer_cnt_ave;                   /* counts for 360 degrees */
    uint16_t    u2_timer_cnt_buf[6];                /* counts for 60 degrees */
    uint16_t    u2_timer_cnt_num;                   /* array element number before 360 degrees */
    uint8_t     u1_hall_signal;
    uint8_t     u1_hall_wait_cnt;
    uint8_t     u1_direction;
    uint16_t    u2_pwm_duty;
    float       f4_speed_rad;
    float       f4_speed_lpf_k;                     /* speed LPF parameter */
    uint16_t    u2_cnt_timeout;                     /* Sensor Timeout timercounter */

    uint8_t     u1_v_pattern_num;                   /* selecting pattern number for openloop drive */
    uint8_t     u1_bemf_signal;                     /* pattern of BEMF */
    uint8_t     u1_pre_bemf_signal;                 /* previous pattern of BEMF */
    uint8_t     u1_flag_pattern_change;             /* pattern change flag */
    uint8_t     u1_v_pattern_ol[2][7];              /* array of voltage pattern for openloop drive */
    uint8_t     u1_ol_signal;                       /* pattern of BEMF */
    uint16_t    u2_ol_pattern_set;                  /* openloop frequency */
    uint16_t    u2_cnt_ol_pattern_set;              /* counter for openloop pattern change */
    uint16_t    u2_bemf_timer_cnt;                  /* value of timer counter (CMT1) */
    uint16_t    u2_pre_bemf_timer_cnt;              /* previous value of timer counter (CMT1) */
    uint16_t    u2_cnt_carrier;                     /* counter for carrier interrupt */
    uint16_t    u2_pre_cnt_carrier;                 /* previous carrier interrupt count */
    uint16_t    u2_angle_shift_cnt;                 /* shift degrees count */
    uint16_t    s2_angle_shift_adjust;              /* adjusting angle */

}st_sensor_t;

typedef struct
{
    float       f4_speed_rad;
    uint16_t    u2_error_status;
}st_sensor_output_t;

typedef struct
{
    uint8_t     u1_mode_system;
    uint16_t    u2_run_mode;
    uint16_t    u2_pwm_duty;
}st_sensor_input_t;

typedef struct
{
    float      f4_speed_lpf_k;
    uint8_t    u1_hall_wait_cnt;
}st_sensor_cfg_t;

#endif


/******************************************************************************
* Exported global variables
******************************************************************************/
extern st_sensor_t g_st_sensor;

/******************************************************************************
* Global function definitions
******************************************************************************/
void R_MOTOR_SENSOR_Open(void);
void R_MOTOR_SENSOR_Close(void);
void R_MOTOR_SENSOR_Reset(void);
void R_MOTOR_SENSOR_ParameterSet(st_sensor_t *p_st_sensor,st_sensor_input_t *p_st_sensor_input);
void R_MOTOR_SENSOR_ParameterGet(st_sensor_t *p_st_sensor,st_sensor_output_t *p_st_sensor_output);
void R_MOTOR_SENSOR_ParameterUpdate(st_sensor_t *p_st_sensor,const st_sensor_cfg_t *p_st_sensor_cfg);
void R_MOTOR_SENSOR_PatternSet(st_sensor_t *p_st_sensor);
void R_MOTOR_SENSOR_DirectionSet(uint8_t dir);      /* set rotation direction */
uint8_t R_MOTOR_SENSOR_DirectionGet(void);          /* get rotation direction */
uint16_t R_MOTOR_SENSOR_TimerCountGet(void);
void R_MOTOR_SENSOR_TimerCountUp(void);
void R_MOTOR_SENSOR_TimerCountClear(void);

#if defined(SENSOR_CFG_CONTROL_LESS)
void R_MOTOR_SENSOR_StartOpenLoop(st_sensor_t *p_st_sensor,float f4_ref_speed_rad_ctrl);
void R_MOTOR_SENSOR_AngleShiftSet(st_sensor_t *p_st_sensor, uint8_t u1_bemf_signal);
void R_MOTOR_SENSOR_CheckPattern(st_sensor_t *p_st_sensor);
void R_MOTOR_SENSOR_ShiftAngle(st_sensor_t *p_st_sensor);
void R_MOTOR_SENSOR_OutputPatternSet(st_sensor_t *p_st_sensor, uint8_t u1_signal);


#endif

#endif /* R_MOTOR_SENSOR_API_H */
