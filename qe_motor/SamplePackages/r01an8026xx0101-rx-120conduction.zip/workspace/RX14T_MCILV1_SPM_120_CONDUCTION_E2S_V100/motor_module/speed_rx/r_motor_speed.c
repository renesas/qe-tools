/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_speed.c
* Description : The interrupt handler
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/
/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/

#include <machine.h>
#include <math.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"

/******************************************************************************
* Interrupt vector define
******************************************************************************/

/******************************************************************************
* Exported global variables
******************************************************************************/

/******************************************************************************
* Private variables and functions
******************************************************************************/

/******************************************************************************
* Function Name : motor_speed_reset
* Description   : Initialize variables when motor control start
* Arguments     : none
* Return Value  : none
******************************************************************************/
void motor_speed_reset(void)
{
    g_st_speed.u1_cnt_speed_pi = 0;
    g_st_speed.u1_flag_speed_ref     = SPEED_STATE_ZERO_CONST;
    g_st_speed.u1_flag_voltage_ref   = VOLTAGE_STATE_ZERO_CONST;
    g_st_speed.f4_ref_speed_rad_ctrl = 0.0f;
    g_st_speed.u2_run_mode = MOTOR_MODE_INIT;
#if defined(SENSOR_CFG_CONTROL_LESS)
    g_st_speed.u2_cnt_adj_v = 0;
#endif
} /* End of function motor_speed_reset */
