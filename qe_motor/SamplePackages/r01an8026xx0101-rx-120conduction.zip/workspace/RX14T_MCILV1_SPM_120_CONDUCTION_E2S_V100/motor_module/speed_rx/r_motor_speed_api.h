/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_speed_api.h
* Description : A definitions of the processing of accessing driver
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_SPEED_API_H
#define R_MOTOR_SPEED_API_H

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* voltage reference status */
#define     VOLTAGE_STATE_ZERO_CONST            (0)
#define     VOLTAGE_STATE_UP                    (1)
#define     VOLTAGE_STATE_CONST                 (2)
#define     VOLTAGE_STATE_OPENLOOP              (3)
#define     VOLTAGE_STATE_PI_OUTPUT             (4)
/* speed reference status */
#define     SPEED_STATE_ZERO_CONST              (0)
#define     SPEED_STATE_OPENLOOP_1              (1)
#define     SPEED_STATE_OPENLOOP_2              (2)
#define     SPEED_STATE_OPENLOOP_3              (3)
#define     SPEED_STATE_SPEED_CHANGE            (4)

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
/* Motor parameter structure */
typedef struct
{
    uint16_t    u2_mtr_pp;                        /* Pole pairs */
    float       f4_mtr_r;                         /* Resistance [ohm] */
    float       f4_mtr_ld;                        /* Inductance for d-axis [H] */
    float       f4_mtr_lq;                        /* Inductance for q-axis [H] */
    float       f4_mtr_m;                         /* Magnet flux [Wb] */
    float       f4_mtr_j;                         /* Rotor inertia [kgm^2] */
    float       f4_nominal_current_rms;           /* Nominal current [Arms] */
} st_motor_parameter_t;

#if defined(SENSOR_CFG_CONTROL_HALL)
typedef struct
{
    uint16_t u2_run_mode;            /* run mode */
    float    f4_v_ref;               /* voltage reference (output of speed PI control) */
    uint8_t  u1_cnt_speed_pi;        /* counter for period of speed PI control */
    uint8_t  u1_flag_speed_ref;      /* speed reference flag */
    uint8_t  u1_flag_voltage_ref;    /* voltage reference flag */
    float    f4_ref_speed_rad;       /* motor speed reference */
    float    f4_ref_speed_rad_ctrl;  /* motor speed reference for speed PI control */
    float    f4_speed_rad;           /* motor speed */
    float    f4_kp_speed;            /* proportional gain for speed PI control */
    float    f4_ki_speed;            /* integral gain for speed PI control */
    float    f4_limit_speed_change;  /* speed ref change limit */
    float    f4_ilim_v;              /* integral part limit */
    float    f4_start_refv;          /* Hall */
    float    f4_rpm_rad;             /* [rpm]->[rad/s] */
    mtr_pi_ctrl_t        st_pi_speed;
    st_motor_parameter_t st_motor;
}st_speed_control_t;

typedef struct
{

    float    f4_ref_speed_rad;       /* motor speed reference */
    float    f4_kp_speed;            /* proportional gain for speed PI control */
    float    f4_ki_speed;            /* integral gain for speed PI control */
    float    f4_limit_speed_change;  /* speed ref change limit */
    float    f4_start_refv;          /* Hall */
    float    f4_rpm_rad;             /* [rpm]->[rad/s] */
}st_speed_cfg_t;

typedef struct
{
    uint16_t u2_run_mode;            /* run mode */
    float    f4_speed_rad;           /* motor speed */
}st_speed_input_t;

typedef struct
{
    float    f4_v_ref;               /* voltage reference (output of speed PI control) */
}st_speed_output_t;
#elif defined(SENSOR_CFG_CONTROL_LESS)
typedef struct
{
    uint16_t    u2_run_mode;            /* run mode */
    float       f4_v_ref;               /* voltage reference (output of speed PI control) */
    uint8_t     u1_cnt_speed_pi;        /* counter for period of speed PI control */
    uint8_t     u1_flag_speed_ref;      /* speed reference flag */
    uint8_t     u1_flag_voltage_ref;    /* voltage reference flag */
    float       f4_ref_speed_rad;       /* motor speed reference */
    float       f4_ref_speed_rad_ctrl;  /* motor speed reference for speed PI control */
    float       f4_speed_rad;           /* motor speed */
    float       f4_kp_speed;            /* proportional gain for speed PI control */
    float       f4_ki_speed;            /* integral gain for speed PI control */
    float       f4_limit_speed_change;  /* speed ref change limit */
    float       f4_ilim_v;              /* integral part limit */
    float       f4_start_refv;          /* Hall */
    float       f4_rpm_rad;             /* [rpm]->[rad/s] */

    float       f4_boot_ref_v;                      /* voltage reference when zero speed [V] */
    uint16_t    u2_v_up_time;                       /* voltage lamping time */
    float       f4_v_up_step;                       /* addition value of v */
    uint16_t    u2_v_const_time;                    /* voltage constant adjust time value [ms] */
    uint16_t    u2_cnt_adj_v;                       /* voltage lamping count adjust */
    uint8_t     u1_flag_draw_in;                    /* draw in a initial position */
    int16_t     s2_ol_start_rad;                    /* start speed [rad/sec] */
    int16_t     s2_ol_mode1_change_rad;             /* to mode2 change speed [rad/sec] */
    int16_t     s2_ol_mode2_change_rad;             /* to mode3 change speed [rad/sec] */
    float       f4_ol_start_refv;                   /* start reference voltage [v] */
    float       f4_ol_mode1_rate_rad;               /* increase rate of reference speed [rad/control period] */
    float       f4_ol_mode2_rate_refv;              /* increase rate of reference voltage [v/control period] */
    float       f4_ol_mode2_rate_rad;               /* increase rate of reference speed [rad/control period] */
    float       f4_ol_mode3_rate_refv;              /* increase rate of reference voltage [v/control period] */
    float       f4_ol_mode3_max_refv;               /* openloop max voltage [v]*/

    mtr_pi_ctrl_t        st_pi_speed;
    st_motor_parameter_t st_motor;
}st_speed_control_t;

typedef struct
{

    float       f4_ref_speed_rad;       /* motor speed reference */
    float       f4_kp_speed;            /* proportional gain for speed PI control */
    float       f4_ki_speed;            /* integral gain for speed PI control */
    float       f4_limit_speed_change;  /* speed ref change limit */
    float       f4_start_refv;          /* Hall */
    float       f4_rpm_rad;             /* [rpm]->[rad/s] */

    float       f4_boot_ref_v;                      /* voltage reference when zero speed [V] */
    uint16_t    u2_v_up_time;                       /* voltage lamping time */
    uint16_t    u2_v_const_time;                    /* voltage constant adjust time value [ms] */
    int16_t     s2_ol_start_rad;                    /* start speed [rad/sec] */
    int16_t     s2_ol_mode1_change_rad;             /* to mode2 change speed [rad/sec] */
    int16_t     s2_ol_mode2_change_rad;             /* to mode3 change speed [rad/sec] */
    float       f4_ol_start_refv;                   /* start reference voltage [v] */
    float       f4_ol_mode1_rate_rad;               /* increase rate of reference speed [rad/control period] */
    float       f4_ol_mode2_rate_refv;              /* increase rate of reference voltage [v/control period] */
    float       f4_ol_mode2_rate_rad;               /* increase rate of reference speed [rad/control period] */
    float       f4_ol_mode3_rate_refv;              /* increase rate of reference voltage [v/control period] */
    float       f4_ol_mode3_max_refv;               /* openloop max voltage [v]*/

}st_speed_cfg_t;

typedef struct
{
    uint16_t    u2_run_mode;            /* run mode */
    float       f4_speed_rad;           /* motor speed */
}st_speed_input_t;

typedef struct
{
    float       f4_v_ref;               /* voltage reference (output of speed PI control) */
}st_speed_output_t;

#endif

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
extern st_speed_control_t g_st_speed;

/******************************************************************************
* Global function definitions
******************************************************************************/
void    R_MOTOR_SPEED_Open(void);
void    R_MOTOR_SPEED_Close(void);
void    R_MOTOR_SPEED_Reset(void);
void    R_MOTOR_SPEED_ParameterSet(st_speed_control_t * p_st_speed, const st_speed_input_t * p_st_speed_input);
void    R_MOTOR_SPEED_ParameterGet(st_speed_control_t * p_st_speed, st_speed_output_t * p_st_speed_output);
void    R_MOTOR_SPEED_ParameterUpdate(st_speed_control_t * p_st_speed, const st_speed_cfg_t * p_st_speed_cfg);
void    R_MOTOR_SPEED_SpeedCyclic(st_speed_control_t *p_st_speed);
void    R_MOTOR_SPEED_RefSpeedSet(st_speed_control_t *p_st_speed);
void    R_MOTOR_SPEED_RefSpeedRpmToRad(int16_t);    /* set speed reference */
void    R_MOTOR_SPEED_VoltageStateSet(uint8_t u1_vol_state);

#if defined(SENSOR_CFG_CONTROL_LESS)
uint8_t R_MOTOR_SPEED_VoltageStateGet(void);
void    R_MOTOR_SPEED_DrawInFlagSet(uint8_t u1_draw_in_flg);
uint8_t R_MOTOR_SPEED_DrawInFlagGet(void);
#endif

#endif /* R_MOTOR_SPEED_API_H */
