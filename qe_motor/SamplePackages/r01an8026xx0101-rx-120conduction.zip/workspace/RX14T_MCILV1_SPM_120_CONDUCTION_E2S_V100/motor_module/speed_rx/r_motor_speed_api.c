/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_motor_speed_api.c
* Description : The processing of accessing driver
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/
#include <math.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"

st_speed_control_t g_st_speed;

/******************************************************************************
* Exported global variables
******************************************************************************/


/******************************************************************************
* Function Name : R_MOTOR_SPEED_Open
* Description   : Open speed module
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_Open(void)
{
    g_st_speed.f4_v_ref               = 0.0f;

    g_st_speed.f4_kp_speed            = SPEED_CFG_SPEED_PI_KP;
    g_st_speed.f4_ki_speed            = SPEED_CFG_SPEED_PI_KI;
    g_st_speed.f4_limit_speed_change  = SPEED_CFG_SPEED_CHANGE_LIMIT;
    g_st_speed.f4_ilim_v              = SPEED_CFG_SPEED_PI_I_LIMIT_V;
    g_st_speed.st_pi_speed.f4_ilimit  = g_st_speed.f4_ilim_v;
    g_st_speed.f4_rpm_rad             = MTR_RPM2RAD;
    g_st_speed.f4_speed_rad           = 0.0f;
    g_st_speed.f4_ref_speed_rad       = 0.0f;
    g_st_speed.st_pi_speed.f4_err     = 0.0f;
    g_st_speed.st_pi_speed.f4_refi    = 0.0f;
#if defined(SENSOR_CFG_CONTROL_LESS)
    g_st_speed.f4_boot_ref_v          = MOTOR_CFG_BOOT_REF_VOLTAGE;
    g_st_speed.u2_v_up_time           = MOTOR_CFG_VOLTAGE_UP_TIME;
    g_st_speed.f4_v_up_step           = MOTOR_CFG_VOLTAGE_UP_STEP;
    g_st_speed.u2_v_const_time        = MOTOR_CFG_VOLTAGE_CONST_TIME;
    g_st_speed.s2_ol_start_rad        = MOTOR_CFG_OL_START_RAD;
    g_st_speed.s2_ol_mode1_change_rad = MOTOR_CFG_OL_MODE1_CHANGE_RAD;
    g_st_speed.s2_ol_mode2_change_rad = MOTOR_CFG_OL_MODE2_CHANGE_RAD;
    g_st_speed.f4_ol_start_refv       = MOTOR_CFG_OL_START_REFV;
    g_st_speed.f4_ol_mode1_rate_rad   = MOTOR_CFG_OL_MODE1_RATE_RAD;
    g_st_speed.f4_ol_mode2_rate_refv  = MOTOR_CFG_OL_MODE2_RATE_REFV;
    g_st_speed.f4_ol_mode2_rate_rad   = MOTOR_CFG_OL_MODE2_RATE_RAD;
    g_st_speed.f4_ol_mode3_rate_refv  = MOTOR_CFG_OL_MODE3_RATE_REFV;
    g_st_speed.f4_ol_mode3_max_refv   = MOTOR_CFG_OL_MODE3_MAX_REFV;
#endif

    motor_speed_reset();
} /* End of function R_MOTOR_SPEED_Open */

/******************************************************************************
* Function Name : R_MOTOR_SPEED_Close
* Description   : Close speed module
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_Close(void)
{
    motor_speed_reset();
} /* End of function R_MOTOR_SPEED_Close */

/******************************************************************************
* Function Name : R_MOTOR_SPEED_Reset
* Description   : Reset speed module
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_Reset(void)
{
    motor_speed_reset();
} /* End of function R_MOTOR_SPEED_Reset */

/******************************************************************************
* Function Name : R_MOTOR_SPEED_ParameterSet
* Description   : Set parameter for speed module
* Arguments     : p_st_speed - The pointer to the speed control structure
*                 p_st_speed_input - The pointer to the speed control input structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_ParameterSet(st_speed_control_t * p_st_speed, const st_speed_input_t * p_st_speed_input)
{
    p_st_speed->u2_run_mode           = p_st_speed_input->u2_run_mode;
    p_st_speed->f4_speed_rad          = p_st_speed_input->f4_speed_rad;
} /* End of function R_MOTOR_SPEED_ParameterSet */

/******************************************************************************
* Function Name : R_MOTOR_SPEED_ParameterGet
* Description   : Get parameter for speed modul
* Arguments     : p_st_speed - The pointer to the speed control structure
*                 p_st_speed_output - The pointer to the speed control output structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_ParameterGet(st_speed_control_t * p_st_speed, st_speed_output_t * p_st_speed_output)
{
    p_st_speed_output->f4_v_ref         = p_st_speed->f4_v_ref;
} /* End of function R_MOTOR_SPEED_ParameterGet */

/******************************************************************************
* Function Name : R_MOTOR_SPEED_ParameterUpdate
* Description   : Update parameter for speed module
* Arguments     : p_st_speed - The pointer to the speed control structure
*                 p_st_speed_input -The pointer to the speed control config structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_ParameterUpdate(st_speed_control_t * p_st_speed, const st_speed_cfg_t * p_st_speed_cfg)
{

    p_st_speed->f4_rpm_rad             = p_st_speed_cfg->f4_rpm_rad;
    p_st_speed->f4_ref_speed_rad       = p_st_speed_cfg->f4_ref_speed_rad;
    p_st_speed->f4_kp_speed            = p_st_speed_cfg->f4_kp_speed;
    p_st_speed->f4_ki_speed            = p_st_speed_cfg->f4_ki_speed;
    p_st_speed->f4_limit_speed_change  = p_st_speed_cfg->f4_limit_speed_change;
    p_st_speed->f4_start_refv          = p_st_speed_cfg->f4_start_refv;

    p_st_speed->st_pi_speed.f4_kp      = p_st_speed->f4_kp_speed;
    p_st_speed->st_pi_speed.f4_ki      = p_st_speed->f4_ki_speed;
#if defined(SENSOR_CFG_CONTROL_LESS)
    p_st_speed->f4_boot_ref_v          = p_st_speed_cfg->f4_boot_ref_v;
    p_st_speed->u2_v_up_time           = p_st_speed_cfg->u2_v_up_time;

    p_st_speed->f4_v_up_step           = p_st_speed->f4_boot_ref_v / p_st_speed->u2_v_up_time;

    p_st_speed->u2_v_const_time        = p_st_speed_cfg->u2_v_const_time;
    p_st_speed->s2_ol_start_rad        = p_st_speed_cfg->s2_ol_start_rad;
    p_st_speed->s2_ol_mode1_change_rad = p_st_speed_cfg->s2_ol_mode1_change_rad;
    p_st_speed->s2_ol_mode2_change_rad = p_st_speed_cfg->s2_ol_mode2_change_rad;
    p_st_speed->f4_ol_start_refv       = p_st_speed_cfg->f4_ol_start_refv;
    p_st_speed->f4_ol_mode1_rate_rad   = p_st_speed_cfg->f4_ol_mode1_rate_rad;
    p_st_speed->f4_ol_mode2_rate_refv  = p_st_speed_cfg->f4_ol_mode2_rate_refv;
    p_st_speed->f4_ol_mode2_rate_rad   = p_st_speed_cfg->f4_ol_mode2_rate_rad;
    p_st_speed->f4_ol_mode3_rate_refv  = p_st_speed_cfg->f4_ol_mode3_rate_refv;
    p_st_speed->f4_ol_mode3_max_refv   = p_st_speed_cfg->f4_ol_mode3_max_refv;
#endif
} /* End of function R_MOTOR_SPEED_ParameterUpdate */

#if defined(SENSOR_CFG_CONTROL_HALL)
/******************************************************************************
* Function Name : R_MOTOR_SPEED_Cyclic
* Description   : Set voltage reference
* Arguments     : p_st_speed - The pointer to the speed control structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_SpeedCyclic(st_speed_control_t *p_st_speed)
{
    float f4_temp;

    switch (p_st_speed->u1_flag_voltage_ref)
    {
        case VOLTAGE_STATE_CONST:
            /* Set start reference voltage(constant) */
            p_st_speed->f4_v_ref = p_st_speed->f4_start_refv;
            if (MOTOR_MODE_DRIVE == p_st_speed->u2_run_mode)
            {
                /* Set PI control parameter for start */
                p_st_speed->st_pi_speed.f4_refi = p_st_speed->f4_start_refv;
                p_st_speed->u1_flag_voltage_ref = VOLTAGE_STATE_PI_OUTPUT;
            }
        break;

        case VOLTAGE_STATE_PI_OUTPUT:
            /*** PI control ***/
            p_st_speed->u1_cnt_speed_pi++;
            if (SPEED_CFG_SPEED_PI_DECIMATION < p_st_speed->u1_cnt_speed_pi)   /* check PI period  */
            {
                p_st_speed->u1_cnt_speed_pi = 0;

                p_st_speed->st_pi_speed.f4_err = p_st_speed->f4_ref_speed_rad_ctrl - p_st_speed->f4_speed_rad;
                f4_temp = motor_pi_ctrl(&p_st_speed->st_pi_speed);

                /*** limit voltage ***/
                p_st_speed->f4_v_ref = motor_filter_limitf(f4_temp, MOTOR_CFG_MAX_OUTPUT_VOLTAGE, MOTOR_CFG_MIN_OUTPUT_VOLTAGE);
            }
        break;

        default:
            /* Do nothing */
        break;
    }
} /* End of function R_MOTOR_SPEED_SpeedCyclic */
#elif defined(SENSOR_CFG_CONTROL_LESS)
/******************************************************************************
* Function Name : R_MOTOR_SPEED_SpeedCyclic
* Description   : Set voltage reference
* Arguments     : p_st_speed - The pointer to the speed control structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_SpeedCyclic(st_speed_control_t *p_st_speed)
{
    float f4_temp;
    float f4_v_ref_buff;

    f4_v_ref_buff = p_st_speed->f4_v_ref;

    switch (p_st_speed->u1_flag_voltage_ref)
    {
        case VOLTAGE_STATE_ZERO_CONST:
            f4_v_ref_buff = 0;
            if (MOTOR_MODE_BOOT == p_st_speed->u2_run_mode)
            {
                p_st_speed->u1_flag_voltage_ref = VOLTAGE_STATE_UP;
            }
        break;

        case VOLTAGE_STATE_UP:
            f4_temp = f4_v_ref_buff + p_st_speed->f4_v_up_step;
            if (p_st_speed->f4_boot_ref_v <= f4_v_ref_buff)
            {
                f4_temp = p_st_speed->f4_boot_ref_v;
                p_st_speed->u1_flag_voltage_ref = VOLTAGE_STATE_CONST;
            }
            /*** limit voltage ***/
            f4_v_ref_buff = motor_filter_upper_limitf(f4_temp, MOTOR_CFG_MAX_BOOT_VOLTAGE);
        break;

        case VOLTAGE_STATE_CONST:
            p_st_speed->u2_cnt_adj_v++;
            f4_temp = p_st_speed->f4_boot_ref_v;
            if (p_st_speed->u2_v_const_time <= p_st_speed->u2_cnt_adj_v)
            {
                if(MOTOR_CFG_DRAW_IN_1ST_TIME == p_st_speed->u1_flag_draw_in)
                {
                    f4_temp = 0;
                    p_st_speed->u2_cnt_adj_v = 0;
                    p_st_speed->u1_flag_draw_in = MOTOR_CFG_DRAW_IN_2ND_TIME;
                    p_st_speed->u1_flag_voltage_ref = VOLTAGE_STATE_UP;
                }
                else if(MOTOR_CFG_DRAW_IN_2ND_TIME == p_st_speed->u1_flag_draw_in)
                {
                    f4_temp = p_st_speed->f4_ol_start_refv;
                    p_st_speed->u2_cnt_adj_v = 0;
                    p_st_speed->u1_flag_draw_in = 0;
                    p_st_speed->u1_flag_voltage_ref = VOLTAGE_STATE_OPENLOOP;
                }
            }
            /*** limit voltage ***/
            f4_v_ref_buff = motor_filter_upper_limitf(f4_temp, MOTOR_CFG_MAX_BOOT_VOLTAGE);
        break;

        case VOLTAGE_STATE_OPENLOOP:
            if (SPEED_STATE_OPENLOOP_2 == p_st_speed->u1_flag_speed_ref)
            {
                f4_v_ref_buff += p_st_speed->f4_ol_mode2_rate_refv;
            }
            else if (SPEED_STATE_OPENLOOP_3 == p_st_speed->u1_flag_speed_ref)
            {
                f4_v_ref_buff += p_st_speed->f4_ol_mode3_rate_refv;
                if (f4_v_ref_buff >= p_st_speed->f4_ol_mode3_max_refv)
                {
                    f4_v_ref_buff = p_st_speed->f4_ol_mode3_max_refv;
                    p_st_speed->st_pi_speed.f4_refi = f4_v_ref_buff;    /* integral part default set */
                    p_st_speed->u1_flag_voltage_ref = VOLTAGE_STATE_PI_OUTPUT;
                }
            }
        break;

        case VOLTAGE_STATE_PI_OUTPUT:
            /*** PI control ***/
            p_st_speed->u1_cnt_speed_pi++;
            if (SPEED_CFG_SPEED_PI_DECIMATION < p_st_speed->u1_cnt_speed_pi)
                                                               /* check PI period  */
            {
                p_st_speed->u1_cnt_speed_pi = 0;

                p_st_speed->st_pi_speed.f4_err = p_st_speed->f4_ref_speed_rad_ctrl - p_st_speed->f4_speed_rad;
                f4_temp = motor_pi_ctrl(&p_st_speed->st_pi_speed);

                /*** limit voltage ***/
                f4_v_ref_buff = motor_filter_limitf(f4_temp, MOTOR_CFG_MAX_OUTPUT_VOLTAGE, MOTOR_CFG_MIN_OUTPUT_VOLTAGE);
            }
        break;

        default:
                /* Do Nothing */
        break;
    }

    p_st_speed->f4_v_ref = f4_v_ref_buff;
} /* End of function R_MOTOR_SPEED_SpeedCyclic */
#endif

#if defined(SENSOR_CFG_CONTROL_HALL)
/******************************************************************************
* Function Name : R_MOTOR_SPEED_RefSpeedSet
* Description   : Set speed reference
* Arguments     : p_st_speed - The pointer to the speed control structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_RefSpeedSet(st_speed_control_t *p_st_speed)
{

    float f4_ref_speed_rad_buff;

    f4_ref_speed_rad_buff = p_st_speed->f4_ref_speed_rad_ctrl;

    switch (p_st_speed->u1_flag_speed_ref)
    {
        case SPEED_STATE_ZERO_CONST:
            if (MOTOR_MODE_DRIVE == p_st_speed->u2_run_mode)
            {
                /* Set PI control parameter for start */
                f4_ref_speed_rad_buff = p_st_speed->f4_speed_rad;
                p_st_speed->u1_flag_speed_ref = SPEED_STATE_SPEED_CHANGE;
            }
        break;

        case SPEED_STATE_SPEED_CHANGE:
            if (p_st_speed->f4_ref_speed_rad > f4_ref_speed_rad_buff)
            {
                f4_ref_speed_rad_buff += p_st_speed->f4_limit_speed_change;
                f4_ref_speed_rad_buff = motor_filter_upper_limitf(f4_ref_speed_rad_buff, p_st_speed->f4_ref_speed_rad);
            }
            else if (p_st_speed->f4_ref_speed_rad < f4_ref_speed_rad_buff)
            {
                f4_ref_speed_rad_buff -= p_st_speed->f4_limit_speed_change;
                f4_ref_speed_rad_buff = motor_filter_lower_limitf(f4_ref_speed_rad_buff, p_st_speed->f4_ref_speed_rad);
            }
            else
            {
                /* Do nothing */
            }
        break;

        default:
                /* Do nothing */
        break;
    }

    p_st_speed->f4_ref_speed_rad_ctrl = f4_ref_speed_rad_buff;
} /* End of function R_MOTOR_SPEED_RefSpeedSet */
#elif defined(SENSOR_CFG_CONTROL_LESS)
/******************************************************************************
* Function Name : R_MOTOR_SPEED_RefSpeedSet
* Description   : Set speed reference
* Arguments     : p_st_speed - The pointer to the speed control structure
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_RefSpeedSet(st_speed_control_t *p_st_speed)
{
    float f4_ref_speed_rad_buff;

    f4_ref_speed_rad_buff = p_st_speed->f4_ref_speed_rad_ctrl;

    switch (p_st_speed->u1_flag_speed_ref)
    {
        case SPEED_STATE_ZERO_CONST:
            /* voltage constant, frequency zero */
            f4_ref_speed_rad_buff = 0;
            if (VOLTAGE_STATE_OPENLOOP == p_st_speed->u1_flag_voltage_ref)
            {
                f4_ref_speed_rad_buff = p_st_speed->s2_ol_start_rad;
                p_st_speed->u1_flag_speed_ref = SPEED_STATE_OPENLOOP_1;
            }
        break;

        case SPEED_STATE_OPENLOOP_1:
            /* voltage constant, frequency variable */
            f4_ref_speed_rad_buff += p_st_speed->f4_ol_mode1_rate_rad;
            if (f4_ref_speed_rad_buff > p_st_speed->s2_ol_mode1_change_rad)
            {
                p_st_speed->u1_flag_speed_ref = SPEED_STATE_OPENLOOP_2;
            }
        break;

        case SPEED_STATE_OPENLOOP_2:
            /* voltage variable, frequency variable */
            f4_ref_speed_rad_buff += p_st_speed->f4_ol_mode2_rate_rad;
            if (f4_ref_speed_rad_buff > p_st_speed->s2_ol_mode2_change_rad)
            {
                p_st_speed->u1_flag_speed_ref = SPEED_STATE_OPENLOOP_3;
            }
        break;

        case SPEED_STATE_OPENLOOP_3:
            /* voltage variable, frequency constant */
            if (VOLTAGE_STATE_PI_OUTPUT == p_st_speed->u1_flag_voltage_ref)
            {
                p_st_speed->u1_flag_speed_ref = SPEED_STATE_SPEED_CHANGE;
            }
        break;

        case SPEED_STATE_SPEED_CHANGE:
            if (p_st_speed->f4_ref_speed_rad > f4_ref_speed_rad_buff)
            {
                f4_ref_speed_rad_buff += p_st_speed->f4_limit_speed_change;
                f4_ref_speed_rad_buff = motor_filter_upper_limitf(f4_ref_speed_rad_buff, p_st_speed->f4_ref_speed_rad);
            }
            else if (p_st_speed->f4_ref_speed_rad < f4_ref_speed_rad_buff)
            {
                f4_ref_speed_rad_buff -= p_st_speed->f4_limit_speed_change;
                f4_ref_speed_rad_buff = motor_filter_upper_limitf(f4_ref_speed_rad_buff, p_st_speed->f4_ref_speed_rad);
            }
        break;

        default:
                /* Do Nothing */
        break;
    }

    p_st_speed->f4_ref_speed_rad_ctrl = f4_ref_speed_rad_buff;
} /* End of function R_MOTOR_SPEED_RefSpeedSet */
#endif

/******************************************************************************
* Function Name : R_MOTOR_SPEED_RefSpeedRpmToRad
* Description   : Set speed reference
* Arguments     : ref_speed - speed reference [rpm]
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_RefSpeedRpmToRad(int16_t ref_speed)
{

    g_st_speed.f4_ref_speed_rad = g_st_speed.f4_rpm_rad * (float)ref_speed;

} /* End of function R_MOTOR_SPEED_RefSpeedRpmToRad */

/******************************************************************************
* Function Name : R_MOTOR_SPEED_VoltageStateSet
* Description   : Set voltage status
* Arguments     : u1_vol_ref_flg - VOLTAGE_STATE_xxx
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_VoltageStateSet(uint8_t u1_vol_state)
{
    g_st_speed.u1_flag_voltage_ref = u1_vol_state;
} /* End of function R_MOTOR_SPEED_VoltageStateSet */

#if defined(SENSOR_CFG_CONTROL_LESS)
/******************************************************************************
* Function Name : R_MOTOR_SPEED_VoltageStateGet
* Description   : Set voltage status
* Arguments     : none
* Return Value  : VOLTAGE_STATE_xxx
******************************************************************************/
uint8_t R_MOTOR_SPEED_VoltageStateGet(void)
{
    uint8_t u1_vol_state;

    u1_vol_state = g_st_speed.u1_flag_voltage_ref;

    return(u1_vol_state);
} /* End of function R_MOTOR_SPEED_VoltageStateGet */

/******************************************************************************
* Function Name : R_MOTOR_SPEED_DrawInFlagSet
* Description   : Set draw in flag
* Arguments     : u1_draw_in_flg - draw in flag
* Return Value  : none
******************************************************************************/
void R_MOTOR_SPEED_DrawInFlagSet(uint8_t u1_draw_in_flg)
{
    g_st_speed.u1_flag_draw_in = u1_draw_in_flg;
} /* End of function R_MOTOR_SPEED_DrawInFlagSet */

/******************************************************************************
* Function Name : R_MOTOR_SPEED_DrawInFlagGet
* Description   : Get draw in flag
* Arguments     : none
* Return Value  : draw in flag
******************************************************************************/
uint8_t R_MOTOR_SPEED_DrawInFlagGet(void)
{
    uint8_t u1_draw_in_flg;

    u1_draw_in_flg = g_st_speed.u1_flag_draw_in;

    return(u1_draw_in_flg);
} /* End of function R_MOTOR_SPEED_DrawInFlagGet */

#endif

