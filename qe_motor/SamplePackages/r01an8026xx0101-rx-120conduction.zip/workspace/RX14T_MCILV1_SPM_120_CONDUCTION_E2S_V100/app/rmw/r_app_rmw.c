/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_app_rmw.c
* Description : Processes of a user interface (tool)
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 31.03.2022 Ver.1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <machine.h>
#include <stdlib.h>
/* Main associated header file */
#include "r_app_main.h"
#include "r_motor_module_cfg.h"

/***********************************************************************************************************************
* Global variables
***********************************************************************************************************************/
uint16_t    g_u2_conf_hw   = 0x0101;        /* 0000000100000001b */
uint16_t    g_u2_conf_sw   = 0x00C1;        /* 0000000011000001b */
uint16_t    g_u2_conf_tool = 0x0200;        /* 0000001000000000b */
uint8_t     gui_u1_active_gui;
uint16_t    g_u2_conf_sw_ver;

st_rmw_param_buffer_t   g_st_rmw_input_buffer;      /* Structure for ICS input */
uint8_t     g_u1_update_param_flag = MTR_FLG_CLR;   /* Update commands and configurations flag */

uint8_t  com_u1_sw_userif;                     /* user interface sw */
uint8_t  g_u1_sw_userif;                       /* user interface sw */
uint8_t  com_u1_system_mode;                   /* system mode */
uint8_t  g_u1_system_mode;                     /* system mode */
uint8_t  com_u1_enable_write;                  /* ICS write enable flag */
uint8_t  g_u1_enable_write;                    /* ICS write enable flag */

int16_t  com_s2_ref_speed_rpm;                 /* motor speed reference [rpm] (electrical) */
float    com_f4_kp_speed;                      /* proportional gain for speed PI control */
float    com_f4_ki_speed;                      /* integral gain for speed PI control */
float    com_f4_speed_lpf_k;                   /* speed LPF parameter */
uint16_t com_u2_mtr_p;                         /* motor pole pairs */
float    com_f4_limit_speed_change;            /* speed ref change limit [rpm] */
uint16_t com_u2_offset_calc_time;              /* current offset calculation time */
float    com_f4_start_refv;                    /* reference voltage for BOOT Mode */
uint8_t  com_u1_hall_wait_cnt;                 /* wait counts of hall interrupts for speed calculation */

#if defined(SENSOR_CFG_CONTROL_LESS)

int16_t  com_s2_ol_start_rpm;                  /* start speed [rpm]*/
int16_t  com_s2_ol_mode1_change_rpm;           /* to mode2 change speed [rpm] */
int16_t  com_s2_ol_mode2_change_rpm;           /* to mode3 change speed [rpm] */
float    com_f4_ol_start_refv;                 /* start reference voltage [v] */
float    com_f4_ol_mode1_rate_rpm;             /* increase rate of reference speed [rpm/control period] */
float    com_f4_ol_mode2_rate_refv;            /* increase rate of reference voltage [v/control period] */
float    com_f4_ol_mode2_rate_rpm;             /* increase rate of reference speed [rpm/control period] */
float    com_f4_ol_mode3_rate_refv;            /* increase rate of reference voltage [v/control period] */
float    com_f4_ol_mode3_max_refv;             /* openloop max voltage [v] */
float    com_f4_boot_ref_v;                    /* voltage reference when zero speed [V] */
uint16_t com_u2_v_up_time;                     /*voltage lamping time */
uint16_t com_u2_v_const_time;                  /* voltage constant adjust time value [ms] */
#endif

/***********************************************************************************************************************
* Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
extern st_120_conduction_control_t g_st_120_conduction;


/***********************************************************************************************************************
 Private global variables and functions
 **********************************************************************************************************************/
static uint8_t  s_u1_cnt_ics = 0;           /* Counter for period of calling "scope_watchpoint" */
static void r_app_rmw_system_mode(void);
static void r_app_rmw_check_com_input(void);
static void r_app_rmw_update_params(void);
static void r_app_rmw_update_command(void);

/***********************************************************************************************************************
* Function Name : r_app_rmw_ui_init
* Description   : Initialize variables for Analyzer interface
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_ui_init(void)
{

    com_u1_sw_userif           = MAIN_UI_RMW;
    g_u1_sw_userif             = MAIN_UI_RMW;
    com_u1_system_mode         = STATEMACHINE_STATE_STOP;
    g_u1_system_mode           = STATEMACHINE_STATE_STOP;

    com_u2_mtr_p               = MOTOR_CFG_POLE_PAIRS;
    com_s2_ref_speed_rpm       = 0;
    com_f4_kp_speed            = SPEED_CFG_SPEED_PI_KP;
    com_f4_ki_speed            = SPEED_CFG_SPEED_PI_KI;
    com_f4_speed_lpf_k         = SPEED_CFG_SPEED_LPF_K;
    com_f4_limit_speed_change  = SPEED_CFG_SPEED_CHANGE_LIMIT;

    com_u2_offset_calc_time    = CURRENT_CFG_OFFSET_CALC_TIME;
    com_f4_start_refv          = MOTOR_CFG_START_REF_VOLTAGE;
    com_u1_hall_wait_cnt       = SENSOR_CFG_HALL_WAIT_SPEED_CALC;
    com_u1_enable_write        = 0;
    g_u1_enable_write          = 0;

#if defined(SENSOR_CFG_CONTROL_LESS)

    com_s2_ol_start_rpm        = MOTOR_CFG_OL_START_RPM;
    com_s2_ol_mode1_change_rpm = MOTOR_CFG_OL_MODE1_CHANGE_RPM;
    com_s2_ol_mode2_change_rpm = MOTOR_CFG_OL_MODE2_CHANGE_RPM;
    com_f4_ol_start_refv       = MOTOR_CFG_OL_START_REFV;
    com_f4_ol_mode1_rate_rpm   = MOTOR_CFG_OL_MODE1_RATE_RPM;
    com_f4_ol_mode2_rate_refv  = MOTOR_CFG_OL_MODE2_RATE_REFV;
    com_f4_ol_mode2_rate_rpm   = MOTOR_CFG_OL_MODE2_RATE_RPM;
    com_f4_ol_mode3_rate_refv  = MOTOR_CFG_OL_MODE3_RATE_REFV;
    com_f4_ol_mode3_max_refv   = MOTOR_CFG_OL_MODE3_MAX_REFV;
    com_f4_boot_ref_v          = MOTOR_CFG_BOOT_REF_VOLTAGE;
    com_u2_v_up_time           = MOTOR_CFG_VOLTAGE_UP_TIME;
    com_u2_v_const_time        = MOTOR_CFG_VOLTAGE_CONST_TIME;
#endif

    /* ICS Input are set to same value. */
    g_st_rmw_input_buffer.u2_mtr_p               = com_u2_mtr_p;
    g_st_rmw_input_buffer.s2_ref_speed           = 0;
    g_st_rmw_input_buffer.f4_kp_speed            = com_f4_kp_speed;
    g_st_rmw_input_buffer.f4_ki_speed            = com_f4_ki_speed;
    g_st_rmw_input_buffer.f4_speed_lpf_k         = com_f4_speed_lpf_k;
    g_st_rmw_input_buffer.f4_limit_speed_change  = com_f4_limit_speed_change;
    g_st_rmw_input_buffer.u2_offset_calc_time    = com_u2_offset_calc_time;
    g_st_rmw_input_buffer.u1_hall_wait_cnt       = com_u1_hall_wait_cnt;
    g_st_rmw_input_buffer.f4_start_refv          = com_f4_start_refv;
#if defined(SENSOR_CFG_CONTROL_LESS)
    g_st_rmw_input_buffer.s2_ol_start_rpm        = com_s2_ol_start_rpm;        /* start speed [rpm]*/
    g_st_rmw_input_buffer.s2_ol_mode1_change_rpm = com_s2_ol_mode1_change_rpm; /* to mode2 change speed [rpm] */
    g_st_rmw_input_buffer.s2_ol_mode2_change_rpm = com_s2_ol_mode2_change_rpm; /* to mode3 change speed [rpm] */
    g_st_rmw_input_buffer.f4_ol_start_refv       = com_f4_ol_start_refv;       /* start reference voltage [v] */
    g_st_rmw_input_buffer.f4_ol_mode1_rate_rpm   = com_f4_ol_mode1_rate_rpm;   /* increase rate of reference speed [rpm/control period] */
    g_st_rmw_input_buffer.f4_ol_mode2_rate_refv  = com_f4_ol_mode2_rate_refv;  /* increase rate of reference voltage [v/control period] */
    g_st_rmw_input_buffer.f4_ol_mode2_rate_rpm   = com_f4_ol_mode2_rate_rpm;   /* increase rate of reference speed [rpm/control period] */
    g_st_rmw_input_buffer.f4_ol_mode3_rate_refv  = com_f4_ol_mode3_rate_refv;  /* increase rate of reference voltage [v/control period] */
    g_st_rmw_input_buffer.f4_ol_mode3_max_refv   = com_f4_ol_mode3_max_refv;   /* openloop max voltage [v] */
    g_st_rmw_input_buffer.f4_boot_ref_v          = com_f4_boot_ref_v;          /* voltage reference when zero speed [V] */
    g_st_rmw_input_buffer.u2_v_up_time           = com_u2_v_up_time;           /*voltage lamping time */
    g_st_rmw_input_buffer.u2_v_const_time        = com_u2_v_const_time;        /* voltage constant adjust time value [ms] */

#endif

} /* End of function r_app_rmw_ui_init */


/***********************************************************************************************************************
* Function Name : r_app_rmw_ui_mainloop
* Description   : RMW communication main-loop process
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_ui_mainloop(void)
{

    r_app_rmw_system_mode();

} /* End of function r_app_rmw_ui_mainloop */


/***********************************************************************************************************************
* Function Name : r_app_rmw_copy_com_to_buffer
* Description   : Set com variables to "tool" input buffer
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_copy_com_to_buffer(void)
{
    r_app_rmw_check_com_input();

    if (com_u1_enable_write == g_u1_enable_write)
    {

        /* motor pole pairs */
        g_st_rmw_input_buffer.u2_mtr_p = com_u2_mtr_p;

        /* speed PI gain */
        g_st_rmw_input_buffer.f4_kp_speed = com_f4_kp_speed;
        g_st_rmw_input_buffer.f4_ki_speed = com_f4_ki_speed;

        /* speed LPF parameter */
        g_st_rmw_input_buffer.f4_speed_lpf_k  = com_f4_speed_lpf_k;

        /* speed ref change limit */
        g_st_rmw_input_buffer.f4_limit_speed_change = com_f4_limit_speed_change;

        /* current offset calculation time */
        g_st_rmw_input_buffer.u2_offset_calc_time = com_u2_offset_calc_time;

        /* Reference Voltage for Boot mode */
        g_st_rmw_input_buffer.f4_start_refv = com_f4_start_refv;

        /* Wait counts of Hall Interrupts for Start Speed Calculation */
        g_st_rmw_input_buffer.u1_hall_wait_cnt = com_u1_hall_wait_cnt;

#if defined(SENSOR_CFG_CONTROL_LESS)
        g_st_rmw_input_buffer.s2_ol_start_rpm        = com_s2_ol_start_rpm;        /* start speed [rpm]*/
        g_st_rmw_input_buffer.s2_ol_mode1_change_rpm = com_s2_ol_mode1_change_rpm; /* to mode2 change speed [rpm] */
        g_st_rmw_input_buffer.s2_ol_mode2_change_rpm = com_s2_ol_mode2_change_rpm; /* to mode3 change speed [rpm] */
        g_st_rmw_input_buffer.f4_ol_start_refv       = com_f4_ol_start_refv;       /* start reference voltage [v] */
        g_st_rmw_input_buffer.f4_ol_mode1_rate_rpm   = com_f4_ol_mode1_rate_rpm;   /* increase rate of reference speed [rpm/control period] */
        g_st_rmw_input_buffer.f4_ol_mode2_rate_refv  = com_f4_ol_mode2_rate_refv;  /* increase rate of reference voltage [v/control period] */
        g_st_rmw_input_buffer.f4_ol_mode2_rate_rpm   = com_f4_ol_mode2_rate_rpm;   /* increase rate of reference speed [rpm/control period] */
        g_st_rmw_input_buffer.f4_ol_mode3_rate_refv  = com_f4_ol_mode3_rate_refv;  /* increase rate of reference voltage [v/control period] */
        g_st_rmw_input_buffer.f4_ol_mode3_max_refv   = com_f4_ol_mode3_max_refv;   /* openloop max voltage [v] */
        g_st_rmw_input_buffer.f4_boot_ref_v          = com_f4_boot_ref_v;          /* voltage reference when zero speed [V] */
        g_st_rmw_input_buffer.u2_v_up_time           = com_u2_v_up_time;           /*voltage lamping time */
        g_st_rmw_input_buffer.u2_v_const_time        = com_u2_v_const_time;        /* voltage constant adjust time value [ms] */
#endif

        g_u1_update_param_flag = MTR_FLG_SET;
        g_u1_enable_write ^= 1;                                 /* change every time 0 and 1 */

    }

} /* End of function r_app_rmw_copy_com_to_buffer */

/***********************************************************************************************************************
* Function Name : r_app_rmw_interrupt_handler
* Description   : Process for ICS(Analyzer)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_interrupt_handler(void)
{
    s_u1_cnt_ics++;

    /* Decimation of ICS call */
    if (ICS_DECIMATION < s_u1_cnt_ics)
    {
        s_u1_cnt_ics = 0;
        ics2_watchpoint();        /* Call ICS */
    }

    /* Update commands and configurations when trigger flag is set */
    if (1 == g_u1_update_param_flag)
    {
        r_app_rmw_update_params();
        g_u1_update_param_flag = MTR_FLG_CLR;
    }
    else
    {
        if(MAIN_UI_RMW == g_u1_sw_userif)
        {
            r_app_rmw_update_command();
        }
    }
} /* End of function r_app_rmw_interrupt_handler */

/***********************************************************************************************************************
* Function Name : r_app_rmw_system_mode
* Description   : Process system mode command
* Arguments     : None
* Return Value  : None
************************************************************************************************************************/
static void r_app_rmw_system_mode(void)
{
    int16_t s2_temp;

    /*============================*/
    /*        Execute event       */
    /*============================*/
    s2_temp = com_u1_system_mode;
    if (g_u1_system_mode != s2_temp)
    {
        if (s2_temp >= STATEMACHINE_EVENT_SIZE)
        {
            com_u1_system_mode = g_u1_system_mode;
        }
        else
        {
            g_u1_system_mode = s2_temp;
            switch (g_u1_system_mode)
            {
                case STATEMACHINE_EVENT_STOP:
                    R_MOTOR_120_CONDUCTION_MotorStop();
                break;

                case STATEMACHINE_EVENT_RUN:
                    R_MOTOR_120_CONDUCTION_MotorStart();
                break;

                case STATEMACHINE_EVENT_RESET:
                    R_MOTOR_120_CONDUCTION_MotorReset();
                break;

                default:
                    /* Do nothing */
                break;
            }
        }
    }

    g_u1_motor_status = R_MOTOR_120_CONDUCTION_StatusGet();   /* get status of motor control system */

    if (STATEMACHINE_EVENT_RESET == g_u1_system_mode)
    {
        if (STATEMACHINE_STATE_STOP == g_u1_motor_status)
        {
            software_init();                                    /* initialize private global variables
                                                                   for reset event */
        }
        else if (STATEMACHINE_STATE_ERROR == g_u1_motor_status)
        {
            g_u1_system_mode   = STATEMACHINE_STATE_ERROR;
            com_u1_system_mode = STATEMACHINE_STATE_ERROR;
        }
        else
        {
            /* Do nothing */
        }
    }


} /* End of function r_app_rmw_system_mode */

/***********************************************************************************************************************
* Function Name : r_app_rmw_check_com_input
* Description   : Check com variables
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_rmw_check_com_input(void)
{

    /**************************/
    /*    limit variables     */
    /**************************/
    if(0 > com_s2_ref_speed_rpm)
    {
        com_s2_ref_speed_rpm = -motor_filter_limit(abs(com_s2_ref_speed_rpm), g_s2_max_speed, g_s2_min_speed);
    }
    else
    {
        com_s2_ref_speed_rpm = motor_filter_limit(abs(com_s2_ref_speed_rpm), g_s2_max_speed, g_s2_min_speed);
    }

} /* End of function r_app_rmw_check_com_input */

/**********************************************************************************************************************
 * Function Name: r_app_rmw_update_params
 * Description  : Apply parameters in buffer through API
 * Arguments    : None
 * Return Value : None
 *********************************************************************************************************************/
static void r_app_rmw_update_params(void)
{
    st_rmw_param_buffer_t *p_st_rmw_input = &g_st_rmw_input_buffer;

    st_sensor_cfg_t         st_sensor_cfg;
    st_speed_cfg_t          st_speed_cfg;
    st_120_conduction_cfg_t st_120_conduction_cfg;
    float                   f4_rpm_rad;

    // Manager module update
    st_120_conduction_cfg.u2_mtr_p            = p_st_rmw_input->u2_mtr_p;               /* motor pole pairs */
    st_120_conduction_cfg.u2_offset_calc_time = p_st_rmw_input->u2_offset_calc_time;    /* current offset calculation time */
    st_120_conduction_cfg.u1_hall_wait_cnt    = p_st_rmw_input->u1_hall_wait_cnt;       /*  */
    f4_rpm_rad                                = MTR_TWOPI / 60;   /* [rpm]->[rad/s] (machine)*/
    st_120_conduction_cfg.f4_rpm_rad          = f4_rpm_rad;                             /*  */
    R_MOTOR_120_CONDUCTION_ParameterUpdate(&g_st_120_conduction, &st_120_conduction_cfg);

    // Speed module update
    st_speed_cfg.f4_rpm_rad            = f4_rpm_rad;   /* [rpm]->[rad/s] */
    st_speed_cfg.f4_ref_speed_rad      = (float)p_st_rmw_input->s2_ref_speed * st_speed_cfg.f4_rpm_rad; /* [rpm]->[rad/s] */
    /* speed PI gain */
    st_speed_cfg.f4_kp_speed           = p_st_rmw_input->f4_kp_speed;
    st_speed_cfg.f4_ki_speed           = p_st_rmw_input->f4_ki_speed;
    st_speed_cfg.f4_limit_speed_change = p_st_rmw_input->f4_limit_speed_change;    /* speed ref change limit */
    st_speed_cfg.f4_start_refv         = p_st_rmw_input->f4_start_refv;

#if defined(SENSOR_CFG_CONTROL_LESS)
    st_speed_cfg.f4_boot_ref_v          = p_st_rmw_input->f4_boot_ref_v;
    st_speed_cfg.u2_v_up_time           = p_st_rmw_input->u2_v_up_time;

    st_speed_cfg.u2_v_const_time        = p_st_rmw_input->u2_v_const_time;

    st_speed_cfg.s2_ol_start_rad        = p_st_rmw_input->s2_ol_start_rpm * f4_rpm_rad;
    st_speed_cfg.s2_ol_mode1_change_rad = p_st_rmw_input->s2_ol_mode1_change_rpm * f4_rpm_rad;
    st_speed_cfg.s2_ol_mode2_change_rad = p_st_rmw_input->s2_ol_mode2_change_rpm * f4_rpm_rad;
    st_speed_cfg.f4_ol_start_refv       = p_st_rmw_input->f4_ol_start_refv;
    st_speed_cfg.f4_ol_mode1_rate_rad   = p_st_rmw_input->f4_ol_mode1_rate_rpm * f4_rpm_rad;
    st_speed_cfg.f4_ol_mode2_rate_refv  = p_st_rmw_input->f4_ol_mode2_rate_refv;
    st_speed_cfg.f4_ol_mode2_rate_rad   = p_st_rmw_input->f4_ol_mode2_rate_rpm * f4_rpm_rad;
    st_speed_cfg.f4_ol_mode3_rate_refv  = p_st_rmw_input->f4_ol_mode3_rate_refv;
    st_speed_cfg.f4_ol_mode3_max_refv   = p_st_rmw_input->f4_ol_mode3_max_refv;
#endif
    R_MOTOR_SPEED_ParameterUpdate(g_st_120_conduction.p_st_speed , &st_speed_cfg);

    // Sensor module update
    st_sensor_cfg.f4_speed_lpf_k         = p_st_rmw_input->f4_speed_lpf_k;    /* speed LPF parameter */
    st_sensor_cfg.u1_hall_wait_cnt       = p_st_rmw_input->u1_hall_wait_cnt;
    R_MOTOR_SENSOR_ParameterUpdate(g_st_120_conduction.p_st_sensor , &st_sensor_cfg);

} /* End of function r_app_rmw_update_params */
/***********************************************************************************************************************
* Function Name : r_app_rmw_update_command
* Description   : Update commands without copying to buffer or update trigger
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_rmw_update_command(void)
{
int16_t  s2_ref_speed;
uint8_t  u1_direction;

    if( 0 > com_s2_ref_speed_rpm )
     {
          u1_direction = MTR_CCW;
    }
    else
    {
          u1_direction = MTR_CW;
    }
    s2_ref_speed = abs(com_s2_ref_speed_rpm);
    R_MOTOR_SPEED_RefSpeedRpmToRad(s2_ref_speed);            /* set speed reference */

    if (R_MOTOR_SENSOR_DirectionGet() != u1_direction )
    {
        R_MOTOR_120_CONDUCTION_MotorStop();
        g_u1_system_mode   = STATEMACHINE_STATE_STOP;
    }
    g_st_120_conduction.u1_direction = u1_direction;
    R_MOTOR_SENSOR_DirectionSet(u1_direction);

} /* End of function r_app_rmw_update_command */

