/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_app_main.c
* Description : The main function and the processing of an application layer
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/******************************************************************************
* Includes <System Includes> , "Project Includes"
******************************************************************************/
#include <machine.h>
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"
#include "r_app_main.h"

#include "ICS2_RX14T.h"

/******************************************************************************
* Private & global variables and functions
******************************************************************************/
int16_t  g_s2_max_speed;                       /* max speed [rpm] (mechanical) */
int16_t  g_s2_min_speed;                       /* min speed [rpm] (mechanical) */
int16_t  g_s2_margin_min_speed;                /* min speed (include margin) [rpm] (mechanical)*/
int16_t  g_s2_ref_speed;                       /* speed reference */
uint8_t  g_u1_rot_dir;                         /* rotational direction */
uint8_t  g_u1_motor_status;                    /* motor status */
uint8_t  g_u1_reset_req;                       /* reset request flag */
uint8_t  g_u1_sw1_cnt;                         /* sw1 counter */
uint8_t  g_u1_sw2_cnt;                         /* sw2 counter */
uint8_t  g_u1_stop_req;                        /* stop request flag */

/******************************************************************************
* Private functions
******************************************************************************/
static void     r_app_main_ui_mainloop(void);           /* User interface control routine */
static void     r_app_main_init_motor_ctrl(void);       /* Initialize motor control instance */
static void     r_app_main_start_motor_ctrl(void);      /* Start motor control */

/*** DTC table for ICS ***/
#pragma section DTCTBL
unsigned long dtc_table[256];
#pragma section
/*************************/

/******************************************************************************
* Function Name : main
* Description   : Initialization and main routine
* Arguments     : none
* Return Value  : none
******************************************************************************/
void main(void)
{
clrpsw_i();                                                     /* interrupt disable */

    /****** for ICS ******/
    ics2_init((void*)dtc_table, ICS_SCI_CH_SELECT, ICS_INT_LEVEL, ICS_BRR, ICS_INT_MODE);
                                                                /* initialize ICS */
    /* Initialize open motor control instance */
    r_app_main_init_motor_ctrl();
    software_init();                                            /* initialize private global variables */

setpsw_i();                                                     /* interrupt enable */

    /* Start peripheral functions */
    r_app_main_start_motor_ctrl();

    /*** main routine ***/
    while (1)
    {
        r_app_main_ui_mainloop();

        R_Config_IWDT_Restart();                                /* watch dog timer clear */
    }
} /* End of function main */

/***********************************************************************************************************************
* Function Name : r_app_main_ui_mainloop
* Description   : User interface control routine
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_main_ui_mainloop(void)
{
    /*============================*/
    /*        Get ICS value       */
    /*============================*/
    r_app_rmw_copy_com_to_buffer();

    /*============================*/
    /*   User interface switch    */
    /*============================*/
    if (g_u1_sw_userif != com_u1_sw_userif)
    {
        g_u1_sw_userif = com_u1_sw_userif;
        if (MAIN_UI_RMW == g_u1_sw_userif)
        {
            g_u1_system_mode = (int16_t)g_u1_motor_status;
        }
    }

    /*============================*/
    /*        Execute event       */
    /*============================*/
    if (MAIN_UI_BOARD == g_u1_sw_userif)
    {
        r_app_board_ui_mainloop();                                         /* user interface control routine */
    }
    else if (MAIN_UI_RMW == g_u1_sw_userif)
    {
        r_app_rmw_ui_mainloop();                                           /* user interface using RMW */
    }
    else
    {
        /* Do nothing */
    }
    /*============================*/
    /*         LED control        */
    /*============================*/
    g_u1_motor_status = R_MOTOR_120_CONDUCTION_StatusGet();   /* get status of motor control system */
    r_app_board_ui_led_control(g_u1_motor_status);
} /* End of function r_app_main_ui_mainloop */

/***********************************************************************************************************************
* Function Name : r_app_main_init_motor_ctrl
* Description   : Open motor control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_main_init_motor_ctrl(void)
{
    /* Create a Motor Instance */
    R_MOTOR_120_CONDUCTION_Open();
} /* End of function r_app_main_init_motor_ctrl */

/***********************************************************************************************************************
* Function Name : r_app_main_start_motor_ctrl
* Description   : Start motor control
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_main_start_motor_ctrl(void)
{
    R_Config_MOTOR_StartTimerCount();
    R_Config_MOTOR_StartAD();
} /* End of function r_app_main_start_motor_ctrl */

/******************************************************************************
* Function Name : software_init
* Description   : Initialize private global variables
* Arguments     : none
* Return Value  : none
******************************************************************************/
void software_init(void)
{
    g_s2_max_speed = MOTOR_CFG_MAX_SPEED_RPM;
    g_s2_min_speed = MOTOR_CFG_MIN_SPEED_RPM;
    g_s2_margin_min_speed = MOTOR_CFG_MARGIN_MIN_SPEED;
    g_s2_ref_speed = 0;
    g_u1_rot_dir = MTR_CW;
    g_u1_motor_status = STATEMACHINE_STATE_STOP;
    g_u1_reset_req = MTR_FLG_CLR;
    g_u1_sw1_cnt = 0;
    g_u1_sw2_cnt = 0;
    g_u1_stop_req = MTR_FLG_SET;

    r_app_rmw_ui_init();

} /* End of function software_init */
