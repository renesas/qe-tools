/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/******************************************************************************
* File Name   : r_app_board_ui_ctrl.h
* Description : A definitions of the processing of a H/W control layer
******************************************************************************/
/******************************************************************************
* History : 31.03.2022  Ver.1.00
******************************************************************************/

/* guard against multiple inclusion */
#ifndef R_APP_BOARD_UI_CTRL_H
#define R_APP_BOARD_UI_CTRL_H
/******************************************************************************
* Global function definitions
******************************************************************************/
uint16_t    r_app_board_ui_get_vr1(void);                  /* get A/D converted value of VR1 */
uint8_t     r_app_board_ui_get_sw1(void);                  /* get state of SW1 */
uint8_t     r_app_board_ui_get_sw2(void);                  /* get state of SW2 */
void        r_app_board_ui_led1_on(void);                  /* turn on LED1 */
void        r_app_board_ui_led2_on(void);                  /* turn on LED2 */
void        r_app_board_ui_led3_on(void);                  /* turn on LED3 */
void        r_app_board_ui_led1_off(void);                 /* turn off LED1 */
void        r_app_board_ui_led2_off(void);                 /* turn off LED2 */
void        r_app_board_ui_led3_off(void);                 /* turn off LED3 */
#endif /* R_APP_BOARD_UI_CTRL_H */
