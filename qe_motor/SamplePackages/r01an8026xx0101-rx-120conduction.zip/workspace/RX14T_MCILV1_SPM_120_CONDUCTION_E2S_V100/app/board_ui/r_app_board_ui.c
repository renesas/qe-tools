/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_app_board_ui.c
* Description : Processes of user interface on inverter board
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 31.03.2022 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_app_board_ui.h"
#include "r_app_board_ui_ctrl.h"
#include "r_motor_120_conduction_api.h"

/***********************************************************************************************************************
* Private & global variables and functions
***********************************************************************************************************************/
static uint8_t  s_u1_sw_cnt        = 0;         /* Counter to remove chattering */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_mainloop
* Description   : User interface using board UI
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_board_ui_mainloop(void)
{
    int16_t s2_temp;
    uint8_t u1_temp_sw_signal;

    /*======================*/
    /*     mode control     */
    /*======================*/
    g_u1_motor_status = R_MOTOR_120_CONDUCTION_StatusGet();   /* get status of motor control system */

    if (STATEMACHINE_STATE_STOP == g_u1_motor_status)                 /* check motor status */
    {
        u1_temp_sw_signal = r_app_board_ui_get_sw1();
        if ((MTR_FLG_SET == r_app_board_ui_remove_sw_chattering(u1_temp_sw_signal, BOARD_SW1_ON)) &&
            (MTR_FLG_SET != g_u1_stop_req)) /* Check SW1 */
        {
            R_MOTOR_120_CONDUCTION_MotorStart(); /* Execute reset event */
        }
    }
    else if (STATEMACHINE_STATE_RUN == g_u1_motor_status)              /* check motor status */
    {

        u1_temp_sw_signal = r_app_board_ui_get_sw1();
        if ((MTR_FLG_SET == r_app_board_ui_remove_sw_chattering(u1_temp_sw_signal, BOARD_SW1_OFF)) ||
            (MTR_FLG_CLR != g_u1_stop_req)) /* Check SW1 */
        {
            R_MOTOR_120_CONDUCTION_MotorStop(); /* Execute reset event */
        }
    }
    else if (STATEMACHINE_STATE_ERROR == g_u1_motor_status)               /* check motor status */
    {
        /***** system reset when SW2 change from ON to OFF *****/
        u1_temp_sw_signal = r_app_board_ui_get_sw2();
        if ((MTR_FLG_CLR == g_u1_reset_req) &&
            (MTR_FLG_SET == r_app_board_ui_remove_sw_chattering(u1_temp_sw_signal, BOARD_SW2_ON)))
        {
            g_u1_reset_req = MTR_FLG_SET;
        }
        else if ((MTR_FLG_SET == g_u1_reset_req) &&
                 (MTR_FLG_SET == r_app_board_ui_remove_sw_chattering(u1_temp_sw_signal, BOARD_SW2_OFF)))
         {
             g_u1_reset_req = MTR_FLG_CLR;
             R_MOTOR_120_CONDUCTION_MotorReset(); /* Execute reset event */
         }
         else
         {
             /* Do nothing */
         }
    }
    else
    {
        /* Do Nothing */
    }

    /*=============================*/
    /*     set speed reference     */
    /*=============================*/
    s2_temp = (MOTOR_MCU_CFG_ADC_OFFSET - r_app_board_ui_get_vr1()) * BOARD_VR1_SCALING_SPEED;  /* read speed reference from VR1 */
    s2_temp = motor_filter_limit_abs(s2_temp, g_s2_max_speed);

    /***********************************************************/
    /* speed check                                             */
    /* 550 <= s2_temp          : start rotation (CW)           */
    /* s2_temp <= -550         : start rotation (CCW)          */
    /* -500 <= s2_temp <= 500 : stop                           */
    /* others                   : rotation with constant speed */
    /***********************************************************/
    if (s2_temp >= g_s2_min_speed)
    {
        g_u1_stop_req = MTR_FLG_CLR;
        g_u1_rot_dir = MTR_CW;                                  /* rotational direction is CW */
    }
    else if (s2_temp <= -g_s2_min_speed)
    {
        g_u1_stop_req = MTR_FLG_CLR;                            /* clear stop request flag */
        g_u1_rot_dir = MTR_CCW;                                 /* rotational direction is CCW */
        s2_temp = -s2_temp;                                     /* sign change */
    }
    else if ((s2_temp <= (g_s2_margin_min_speed)) && (s2_temp >= (-g_s2_margin_min_speed)))
    {
        g_u1_stop_req = MTR_FLG_SET;                            /* set stop request flag */
    }
    else
    {
        if (STATEMACHINE_STATE_RUN == g_u1_motor_status)        /* check motor status */
        {
            s2_temp = g_s2_min_speed;                           /* min speed (constant) */
        }
    }

    /* rotation direction */
    if (R_MOTOR_SENSOR_DirectionGet() != g_u1_rot_dir)
    {
        motor_120_conduction_statemachine_event(STATEMACHINE_EVENT_STOP);   /* execute stop event */
    }

    R_MOTOR_SENSOR_DirectionSet(g_u1_rot_dir);                  /* set rotational direction */
    g_s2_ref_speed = s2_temp;
    R_MOTOR_SPEED_RefSpeedRpmToRad(g_s2_ref_speed);             /* set speed reference */


} /* End of function r_app_board_ui_mainloop */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_led_control
* Description   : Set LED pattern depend on motor status
* Arguments     : u1_motor_status - Motor control status
* Return Value  : None
***********************************************************************************************************************/
void r_app_board_ui_led_control(uint8_t u1_motor_status)
{
    /***** LED control *****/
    if (STATEMACHINE_STATE_STOP == u1_motor_status)         /* Check motor status */
    {
        r_app_board_ui_led1_off();                          /* LED1 off */
        r_app_board_ui_led2_off();                          /* LED2 off */
        r_app_board_ui_led3_off();                          /* LED3 off */
    }
    else if (STATEMACHINE_STATE_RUN == u1_motor_status)     /* Check motor status */
    {
        r_app_board_ui_led1_on();                           /* LED1 on */
        r_app_board_ui_led2_off();                          /* LED2 off */
    }
    else if (STATEMACHINE_STATE_ERROR == u1_motor_status)   /* Check motor status */
    {
        r_app_board_ui_led1_off();                          /* LED1 off */
        r_app_board_ui_led2_on();                           /* LED2 on */
        r_app_board_ui_led3_off();                          /* LED3 off */
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function r_app_board_ui_led_control */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_remove_sw_chattering
* Description   : Get switch status with removing chattering
* Arguments     : u1_sw - Board interface switch signal
*                 u1_on_off - Detected status (ON/OFF)
* Return Value  : u1_remove_chattering_flg - Detection result
***********************************************************************************************************************/
uint8_t r_app_board_ui_remove_sw_chattering(uint8_t u1_sw, uint8_t u1_on_off)
{
    uint8_t u1_remove_chattering_flg;

    u1_remove_chattering_flg = MTR_FLG_CLR;
    if (u1_on_off == u1_sw)
    {
        s_u1_sw_cnt++;
        if (BOARD_CHATTERING_CNT < s_u1_sw_cnt)
        {
            u1_remove_chattering_flg = MTR_FLG_SET;
            s_u1_sw_cnt = 0;
        }
    }
    else
    {
        s_u1_sw_cnt = 0;
    }

    return (u1_remove_chattering_flg);
} /* End of function r_app_board_ui_remove_sw_chattering */
