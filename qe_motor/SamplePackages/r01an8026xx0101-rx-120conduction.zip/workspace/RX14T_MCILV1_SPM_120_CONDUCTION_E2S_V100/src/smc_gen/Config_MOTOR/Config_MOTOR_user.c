/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_MOTOR_user.c
* Component Version: 1.1.0
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_MOTOR.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_MOTOR.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_motor_120_conduction_api.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_Create_UserInit
* Description  : This function adds user code after initializing the MTU channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_Create_UserInit(void)
{
    /* Start user code for user init. Do not edit comment generated here */
    /* Add A/D conversion channel */
    S12AD1.ADANSA0.WORD |= _0008_MTR_AD_AN103_USED;
    /* Setting A/D conversion time */
    S12AD.ADSSTR0  = (0x0AU);
    S12AD.ADSSTR1  = (0x0AU);
    S12AD.ADSSTR2  = (0x0AU);
    S12AD.ADSSTR4  = (0x0AU);
    S12AD.ADSSTR5  = (0x0AU);
    S12AD1.ADSSTR2 = (0x0AU);
    S12AD1.ADSSTR3 = (0x0AU);
    S12AD1.ADSSTR7 = (0x0AU);
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_MOTOR_ad_interrupt
* Description  : This function is S12ADI interrupt service routine
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

#if FAST_INTERRUPT_VECTOR == VECT_S12AD_S12ADI
#pragma interrupt r_Config_MOTOR_ad_interrupt(vect=VECT(S12AD,S12ADI),fint)
#else
#pragma interrupt r_Config_MOTOR_ad_interrupt(vect=VECT(S12AD,S12ADI))
#endif
static void r_Config_MOTOR_ad_interrupt(void)
{
    /* Start user code for r_Config_MOTOR_ad_interrupt-1. Do not edit comment generated here */
    R_MOTOR_120_CONDUCTION_CarrierInterrupt();
    r_app_rmw_interrupt_handler();
    /* End user code. Do not edit comment generated here */
    
    /* Start user code for r_Config_MOTOR_ad_interrupt-2. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
