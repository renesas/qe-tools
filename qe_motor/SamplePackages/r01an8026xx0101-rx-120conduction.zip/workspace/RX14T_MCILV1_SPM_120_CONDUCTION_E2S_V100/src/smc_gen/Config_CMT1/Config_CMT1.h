/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_CMT1.h
* Component Version: 2.3.0
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_CMT1.
***********************************************************************************************************************/

#ifndef CFG_Config_CMT1_H
#define CFG_Config_CMT1_H

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_cmt.h"

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define CMT1_PCLK_COUNTER_DIVISION          (8)

/* Compare Match Constant Register (CMCOR) */
#define _FFFF_CMT1_CMCOR_VALUE              (0xFFFFU)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void R_Config_CMT1_Create(void);
void R_Config_CMT1_Create_UserInit(void);
void R_Config_CMT1_Start(void);
void R_Config_CMT1_Stop(void);
/* Start user code for function. Do not edit comment generated here */
void R_Config_CMT1_Set_Cmcnt(unsigned short u2_cmcnt);
unsigned short R_Config_CMT1_Get_Cmcnt(void);
/* End user code. Do not edit comment generated here */
#endif
