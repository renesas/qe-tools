/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_CMT1.c
* Component Version: 2.3.0
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_CMT1.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_CMT1.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_CMT1_Create
* Description  : This function initializes the CMT1 channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_CMT1_Create(void)
{
    /* Cancel CMT stop state in LPC */
    MSTP(CMT1) = 0U;

    /* Set control registers */
    CMT1.CMCR.WORD = _0000_CMT_CMCR_CLOCK_PCLK8 | _0080_CMT_CMCR_DEFAULT;

    /* Set compare match register */
    CMT1.CMCOR = _FFFF_CMT1_CMCOR_VALUE;

    R_Config_CMT1_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_CMT1_Start
* Description  : This function starts the CMT1 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_CMT1_Start(void)
{
    /* Start CMT1 count */
    CMT.CMSTR0.BIT.STR1 = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_CMT1_Stop
* Description  : This function stop the CMT1 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_CMT1_Stop(void)
{
    /* Stop CMT1 count */
    CMT.CMSTR0.BIT.STR1 = 0U;
}

/* Start user code for adding. Do not edit comment generated here */
/***********************************************************************************************************************
* Function Name: R_Config_CMT1_Set_Cmcnt
* Description  : This function sets cmcmt
* Arguments    : Write value
* Return Value : None
***********************************************************************************************************************/
void R_Config_CMT1_Set_Cmcnt(unsigned short u2_cmcnt)
{
    /* Stop CMT1 count */
	CMT1.CMCNT = u2_cmcnt;
}
/***********************************************************************************************************************
* Function Name: R_Config_CMT1_Get_Cmcnt
* Description  : This function sets cmcmt
* Arguments    : None
* Return Value : get value
***********************************************************************************************************************/
unsigned short R_Config_CMT1_Get_Cmcnt(void)
{
    /* Stop CMT1 count */
	return(CMT1.CMCNT);
}
/* End user code. Do not edit comment generated here */
