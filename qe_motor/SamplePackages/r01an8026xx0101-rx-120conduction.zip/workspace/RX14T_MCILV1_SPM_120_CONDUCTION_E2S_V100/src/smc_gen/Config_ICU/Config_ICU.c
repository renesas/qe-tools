/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_ICU.c
* Component Version: 2.3.0
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_ICU.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_ICU.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_ICU_Create
* Description  : This function initializes the ICU module
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_Create(void)
{
    /* Disable IRQ interrupts */
    ICU.IER[0x08].BYTE = 0x00U;

    /* Disable software interrupt */
    IEN(ICU,SWINT) = 0U;

    /* Disable IRQ digital filter */
    ICU.IRQFLTE0.BYTE &= ~(_01_ICU_IRQ0_FILTER_ENABLE | _02_ICU_IRQ1_FILTER_ENABLE | _40_ICU_IRQ6_FILTER_ENABLE);

    /* Set IRQ digital filter sampling clock */
    ICU.IRQFLTC0.BIT.FCLKSEL0 = _0002_ICU_IRQ_FILTER_PCLK_32;
    ICU.IRQFLTC0.BIT.FCLKSEL1 = _0002_ICU_IRQ_FILTER_PCLK_32;
    ICU.IRQFLTC0.BIT.FCLKSEL6 = _0002_ICU_IRQ_FILTER_PCLK_32;

    /* Set IRQ0 pin */
    MPC.P92PFS.BYTE = 0x40U;
    PORT9.PDR.BYTE &= 0xFBU;
    PORT9.PMR.BYTE &= 0xFBU;

    /* Set IRQ1 pin */
    MPC.P93PFS.BYTE = 0x40U;
    PORT9.PDR.BYTE &= 0xF7U;
    PORT9.PMR.BYTE &= 0xF7U;

    /* Set IRQ6 pin */
    MPC.P90PFS.BYTE = 0x40U;
    PORT9.PDR.BYTE &= 0xFEU;
    PORT9.PMR.BYTE &= 0xFEU;

    /* Set IRQ detection type */
    ICU.IRQCR[0].BYTE = _0C_ICU_IRQ_EDGE_BOTH;
    IR(ICU,IRQ0) = 0U;
    ICU.IRQCR[1].BYTE = _0C_ICU_IRQ_EDGE_BOTH;
    IR(ICU,IRQ1) = 0U;
    ICU.IRQCR[6].BYTE = _0C_ICU_IRQ_EDGE_BOTH;
    IR(ICU,IRQ6) = 0U;

    /* Enable IRQ digital filter */
    ICU.IRQFLTE0.BYTE |= (_01_ICU_IRQ0_FILTER_ENABLE | _02_ICU_IRQ1_FILTER_ENABLE | _40_ICU_IRQ6_FILTER_ENABLE);

    /* Set IRQ priority level */
    IPR(ICU,IRQ0) = _0D_ICU_PRIORITY_LEVEL13;
    IPR(ICU,IRQ1) = _0D_ICU_PRIORITY_LEVEL13;
    IPR(ICU,IRQ6) = _0D_ICU_PRIORITY_LEVEL13;

    R_Config_ICU_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ0_Start
* Description  : This function enables IRQ0 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ0_Start(void)
{
    /* Enable IRQ0 interrupt */
    IEN(ICU,IRQ0) = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ0_Stop
* Description  : This function disables IRQ0 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ0_Stop(void)
{
    /* Disable IRQ0 interrupt */
    IEN(ICU,IRQ0) = 0U;
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ1_Start
* Description  : This function enables IRQ1 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ1_Start(void)
{
    /* Enable IRQ1 interrupt */
    IEN(ICU,IRQ1) = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ1_Stop
* Description  : This function disables IRQ1 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ1_Stop(void)
{
    /* Disable IRQ1 interrupt */
    IEN(ICU,IRQ1) = 0U;
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ6_Start
* Description  : This function enables IRQ6 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ6_Start(void)
{
    /* Enable IRQ6 interrupt */
    IEN(ICU,IRQ6) = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ6_Stop
* Description  : This function disables IRQ6 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ6_Stop(void)
{
    /* Disable IRQ6 interrupt */
    IEN(ICU,IRQ6) = 0U;
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
