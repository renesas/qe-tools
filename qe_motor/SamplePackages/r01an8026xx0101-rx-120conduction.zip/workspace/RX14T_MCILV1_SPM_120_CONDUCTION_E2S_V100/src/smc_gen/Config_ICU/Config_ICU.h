/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_ICU.h
* Component Version: 2.3.0
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_ICU.
***********************************************************************************************************************/

#ifndef CFG_Config_ICU_H
#define CFG_Config_ICU_H

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_icu.h"

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void R_Config_ICU_Create(void);
void R_Config_ICU_Create_UserInit(void);
void R_Config_ICU_IRQ0_Start(void);
void R_Config_ICU_IRQ0_Stop(void);
void R_Config_ICU_IRQ1_Start(void);
void R_Config_ICU_IRQ1_Stop(void);
void R_Config_ICU_IRQ6_Start(void);
void R_Config_ICU_IRQ6_Stop(void);
/* Start user code for function. Do not edit comment generated here */
#define     MTR_PORT_HALL_U         (PORT9.PIDR.BIT.B2)         /* input port of hall sensor(HU) */
#define     MTR_PORT_HALL_V         (PORT9.PIDR.BIT.B3)         /* input port of hall sensor(HV) */
#define     MTR_PORT_HALL_W         (PORT9.PIDR.BIT.B0)         /* input port of hall sensor(HW) */
/* End user code. Do not edit comment generated here */
#endif
