/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_POE.c
* Component Version: 1.11.0
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_POE.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_POE.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_POE_Create
* Description  : This function initializes the POE3 module
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_POE_Create(void)
{
    /* Output level control setting */
    POE.OCSR1.WORD = _0000_POE_OCE1_DISABLE;
    POE.OCSR3.WORD = _0000_POE_OCE3_DISABLE;

    /* Port output enable control setting */
    POE.POECR2.WORD = _0000_POE_POECR2_CLEAR;

    /* Set mask of POE11# signal */
    POE.IMCR4.BYTE = _00_POE_NO_MASK;

    /* Input level control/status for POE8# */
    POE.ICSR3.WORD = _0000_POE_POE8E_DISABLE;

    /* Input level control/status for POE10# */
    POE.ICSR4.WORD = _0000_POE_POE10E_DISABLE;

    /* Input level control/status for POE11# */
    POE.ICSR5.WORD = _0000_POE_POE11M_SEL_DEFAULT | _0100_POE_PIE5_ENABLE | _0200_POE_POE11E_ENABLE | 
                     _0000_POE_POE11_INV_DISABLE;

    /* Input level control/status for POE12# */
    POE.ICSR7.WORD = _0000_POE_POE12E_DISABLE;

    /* Stopped oscillation detection control setting */
    POE.ICSR6.WORD = _0000_POE_OSTSTE_DISABLE;

    /* Set POE3 interrupt priority level */
    IPR(POE,OEI1) = _0F_POE_PRIORITY_LEVEL15;

    /* Set POE11# pin */
    MPC.P30PFS.BYTE = 0x07U;
    PORT3.PMR.BYTE |= 0x01U;

    R_Config_POE_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_POE_Start
* Description  : This function starts the POE3 module
*                Note that this function is empty if no interrupt is configured for POE
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_POE_Start(void)
{
    /* Enable POE interrupts in ICU */
    IEN(POE,OEI4) = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_POE_Stop
* Description  : This function stops the POE3 module
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_POE_Stop(void)
{
    /* Disable POE interrupts in ICU */
    IEN(POE,OEI4) = 0U;

    /* Clear POE0F flag */
    if (1U == POE.ICSR1.BIT.POE0F)
    {
        POE.ICSR1.BIT.POE0F = 0U;
    }

    /* Clear POE8F flag */
    if (1U == POE.ICSR3.BIT.POE8F)
    {
        POE.ICSR3.BIT.POE8F = 0U;
    }

    /* Clear POE10F flag */
    if (1U == POE.ICSR4.BIT.POE10F)
    {
        POE.ICSR4.BIT.POE10F = 0U;
    }

    /* Clear POE11F flag */
    if (1U == POE.ICSR5.BIT.POE11F)
    {
        POE.ICSR5.BIT.POE11F = 0U;
    }

    /* Clear POE12F flag */
    if (1U == POE.ICSR7.BIT.POE12F)
    {
        POE.ICSR7.BIT.POE12F = 0U;
    }

    /* Clear output short flag 1 */
    if (1U == POE.OCSR1.BIT.OSF1)
    {
        POE.OCSR1.BIT.OSF1 = 0U;
    }

    /* Clear output short flag 3 */
    if (1U == POE.OCSR3.BIT.OSF3)
    {
        POE.OCSR3.BIT.OSF3 = 0U;
    }

    /* Clear OSTST High-Impedance flag */
    if (1U == POE.ICSR6.BIT.OSTSTF)
    {
        POE.ICSR6.BIT.OSTSTF = 0U;
    }
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
