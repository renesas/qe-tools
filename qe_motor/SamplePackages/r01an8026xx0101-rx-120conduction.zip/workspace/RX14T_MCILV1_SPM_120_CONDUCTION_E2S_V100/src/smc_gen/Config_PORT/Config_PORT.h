/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_PORT.h
* Component Version: 2.4.1
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_PORT.
***********************************************************************************************************************/

#ifndef CFG_Config_PORT_H
#define CFG_Config_PORT_H

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_port.h"

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void R_Config_PORT_Create(void);
void R_Config_PORT_Create_UserInit(void);
/* Start user code for function. Do not edit comment generated here */
#define     MTR_PORT_SW1            (PORTD.PIDR.BIT.B7)         /* input port of SW1 */
#define     MTR_PORT_SW2            (PORTE.PIDR.BIT.B2)         /* input port of SW2 */

#define     MTR_PORT_LED1           (PORTD.PODR.BIT.B3)         /* output port of LED1 */
#define     MTR_PORT_LED2           (PORTD.PODR.BIT.B4)         /* output port of LED2 */
#define     MTR_PORT_LED3           (PORTB.PODR.BIT.B6)         /* output port of LED3 */

#define     MTR_LED_ON              (0)                         /* active level of LED */
#define     MTR_LED_OFF             (1)                         /* inactive level of LED */

uint8_t R_Config_PORT_GetSW1(void);
uint8_t R_Config_PORT_GetSW2(void);
void R_Config_PORT_Led1_on(void);
void R_Config_PORT_Led2_on(void);
void R_Config_PORT_Led3_on(void);
void R_Config_PORT_Led1_off(void);
void R_Config_PORT_Led2_off(void);
void R_Config_PORT_Led3_off(void);
/* End user code. Do not edit comment generated here */
#endif
