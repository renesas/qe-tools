/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_app_mcu.c
* Description : MCU depend application layer functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 31.01.2025 1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_app_mcu.h"
#include "r_motor_driver_hal.h"

/***********************************************************************************************************************
* Private functions
***********************************************************************************************************************/
static uint8_t  s_u1_cnt_ics = 0;               /* Counter for period of calling "scope_watchpoint" */

/***********************************************************************************************************************
* Function Name : r_app_hal_init
* Description   : Initialize and Set up peripheral function
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_hal_init(void)
{
    adc_status_t status;

    R_POEG_Open(g_poeg0.p_ctrl, g_poeg0.p_cfg);

    /* GPT Output Disable to prevent gate on */
    R_Config_MOTOR_StopTimerCtrl();

    /* Start GPT */
    R_GPT_THREE_PHASE_Open(&g_three_phase0_ctrl, &g_three_phase0_cfg); /* Motor control */

    R_GPT_THREE_PHASE_Stop(&g_three_phase0_ctrl);
    R_GPT_THREE_PHASE_Reset(&g_three_phase0_ctrl);

    R_GPT_THREE_PHASE_Start(&g_three_phase0_ctrl);

    /* Start AGT (speed control timer) */
    R_AGT_Open(&g_timer3_ctrl, &g_timer3_cfg);
    R_AGT_Stop(&g_timer3_ctrl);
    R_AGT_Reset(&g_timer3_ctrl);
    R_BSP_SoftwareDelay(30, BSP_DELAY_UNITS_MICROSECONDS); /* Interrupt Occurrence Timing Adjustment */
    R_AGT_Start(&g_timer3_ctrl);

    /* Start ADC module */
    R_ADC_B_Open(&g_adc0_ctrl, &g_adc0_cfg);
    R_ADC_B_ScanCfg(&g_adc0_ctrl, &g_adc0_scan_cfg);

    /* Wait for calibration to complete */
    R_ADC_B_Calibrate(&g_adc0_ctrl, NULL);
    status.state = ADC_STATE_CALIBRATION_IN_PROGRESS;

    while (ADC_STATE_IDLE != status.state)
    {
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
        R_ADC_B_StatusGet(&g_adc0_ctrl, &status);
    }

    R_ADC_B_ScanStart(&g_adc0_ctrl);

    /* Watchdog timer start */
    R_IWDT_Open(&g_wdt0_ctrl, &g_wdt0_cfg);
    R_IWDT_Refresh(&g_wdt0_ctrl);
} /* End of function r_app_hal_init */

/***********************************************************************************************************************
* Function Name : r_app_rmw_hw_init
* Description   : Initialize rmw module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_hw_init(void)
{
    ics2_init(ICS_SCI1_P400_P401, ICS_BRR, ICS_INT_MODE);
} /* End of function r_app_rmw_hw_init */

/***********************************************************************************************************************
* Function Name : r_app_main_loop
* Description   : Main loop of motor control
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_main_loop(void)
{
    poeg_status_t st_status;
    uint32_t u4_status;

    R_POEG_StatusGet(g_poeg0.p_ctrl, &st_status);
    u4_status = st_status.state & POEG_STATE_PIN_DISABLE_REQUEST_ACTIVE;
    if (POEG_STATE_PIN_DISABLE_REQUEST_ACTIVE != u4_status)
    {
        R_BSP_IrqEnable(g_poeg0_ctrl.p_cfg->irq);
    }

    /* Watchdog timer refresh */
    R_IWDT_Refresh(&g_wdt0_ctrl);
} /* End of function r_app_main_loop */

/***********************************************************************************************************************
* Function Name : r_app_pwm_highz_reset
* Description   : Reset poeg flag
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_pwm_highz_reset(void)
{
    R_BSP_IrqDisable(g_poeg0.p_cfg->irq);
    R_POEG_Reset(g_poeg0.p_ctrl);
} /* End of function r_app_pwm_highz_reset */

/***********************************************************************************************************************
* Function Name : r_app_rmw_watchpoint
* Description   : Call ICS
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_watchpoint(void)
{
    s_u1_cnt_ics++;

    /* Decimation of ICS call */
    if (ICS_DECIMATION < s_u1_cnt_ics)
    {
        s_u1_cnt_ics = 0;

        /* Call ICS */
        ics2_watchpoint();
    }
} /* End of function r_app_rmw_watchpoint */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_get_vr1
* Description   : Get A/D converted value of VR1
* Arguments     : None
* Return Value  : A/D converted value of VR1
***********************************************************************************************************************/
uint16_t r_app_board_ui_get_vr1(void)
{
    uint16_t u2_temp0;

    R_ADC_B_Read(&g_adc0_ctrl, MTR_ADCH_VR1, &u2_temp0);

    return (u2_temp0);
} /* End of function r_app_board_ui_get_vr1 */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_get_sw1
* Description   : Get state of SW1
* Arguments     : None
* Return Value  : State of SW1
***********************************************************************************************************************/
uint8_t r_app_board_ui_get_sw1(void)
{
    uint8_t u1_temp0;

    R_IOPORT_PinRead(&g_ioport_ctrl, MTR_PORT_SW1, &u1_temp0);

    return (u1_temp0);
} /* End of function r_app_board_ui_get_sw1 */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_get_sw2
* Description   : Get state of SW2
* Arguments     : None
* Return Value  : State of SW2
***********************************************************************************************************************/
uint8_t r_app_board_ui_get_sw2(void)
{
    uint8_t u1_temp0;

    R_IOPORT_PinRead(&g_ioport_ctrl, MTR_PORT_SW2, &u1_temp0);

    return (u1_temp0);
} /* End of function r_app_board_ui_get_sw2 */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_led1_on
* Description   : Turn on LED1
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_board_ui_led1_on(void)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, MTR_PORT_LED1, MTR_LED_ON);
} /* End of function r_app_board_ui_led1_on */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_led2_on
* Description   : Turn on LED2
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_board_ui_led2_on(void)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, MTR_PORT_LED2, MTR_LED_ON);
} /* End of function r_app_board_ui_led2_on */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_led1_off
* Description   : Turn off LED1
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_board_ui_led1_off(void)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, MTR_PORT_LED1, MTR_LED_OFF);
} /* End of function r_app_board_ui_led1_off */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_led2_off
* Description   : Turn off LED2
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_board_ui_led2_off(void)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, MTR_PORT_LED2, MTR_LED_OFF);
} /* End of function r_app_board_ui_led2_off */
