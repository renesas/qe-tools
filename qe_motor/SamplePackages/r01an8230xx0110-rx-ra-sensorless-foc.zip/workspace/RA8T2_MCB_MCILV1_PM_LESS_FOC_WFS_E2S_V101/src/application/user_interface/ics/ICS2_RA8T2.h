











#ifndef __ICS2_RA8T2_H__
#define __ICS2_RA8T2_H__

#define ICS_SCI0_P609_P610     (0x01U)
#define ICS_SCI1_P400_P401     (0x11U)
#define ICS_SCI1_P707_P706     (0x12U)
#define ICS_SCI4_P415_P414     (0x41U)
#define ICS_SCI6_P301_P302     (0x61U)
#define ICS_SCI6_PC14_PC13     (0x62U)
#define ICS_SCI7_P809_P808     (0x71U)
#define ICS_SCI9_P209_P208     (0x91U)

/* Buil-in Only */
#define ICS_SCI9_PA12_PA14     (0x9FU)

void     ics2_init(uint8_t port, uint8_t speed, uint8_t mode);
void     ics2_watchpoint(void);
uint32_t ics2_version(void);

#endif /* __ICS2_RA8T2_H__ */
