################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA8T1_MCB_MCILV1_PM_LESS_FOC_WFS_E2S_V101/src/application/user_interface/ics/ICS2_RA8T1.o

LIBS := -lr_motor_current_bemf_observer -lr_motor_current_stall_detection -lr_motor_current_trq_vib_comp -lr_motor_current_volt_err_comp -lr_motor_sensorless_vector_flyingstart -lr_motor_speed_fluxwkn -lr_motor_speed_opl_damp_ctrl -lr_motor_speed_opl2less

