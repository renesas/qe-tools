/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : mtr_main.c
* Description : The main function and the processes of motor control application layer
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 31.01.2025 1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "mtr_main.h"
#include "r_mtr_ics.h"
#include "r_system_manager_api.h"
#include "r_app_mcu.h"
#include "r_app_board_ui.h"

/***********************************************************************************************************************
* Global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
* Private functions
***********************************************************************************************************************/
static void     r_app_main_ui_mainloop(void);           /* User interface control routine */

/***********************************************************************************************************************
* Function Name : mtr_init
* Description   : Initialization for Motor Control
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_init(void)
{
    /* LED off */
    r_app_board_ui_led_control(STATEMACHINE_STATE_STOP);

    /* Initialize ICS for RMW */
    r_app_rmw_hw_init();

    /* Create a System manager Instance */
    R_SYSTEM_MANAGER_Open();

    /* FSP initialize */
    r_app_hal_init();

    /* Initialize private global variables */
    r_app_rmw_ui_init();

} /* End of function mtr_init() */

/***********************************************************************************************************************
* Function Name : mtr_main
* Description   : Main routine for Motor Control
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_main(void)
{
    /* Copy communication variables to buffer */
    r_app_rmw_copy_com_to_buffer();

    /* Main process for user interface */
    r_app_main_ui_mainloop();

    /* Main loop process */
    r_app_main_loop();
} /* End of function mtr_main */

/***********************************************************************************************************************
* Function Name : r_app_main_ui_mainloop
* Description   : User interface control routine
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_main_ui_mainloop(void)
{
    uint8_t u1_temp;
    uint8_t u1_motor_status;

    /*============================*/
    /*   User interface switch    */
    /*============================*/
    u1_temp = com_u1_sw_userif;

    if (g_u1_sw_userif != u1_temp)
    {
        if (u1_temp >= MAIN_UI_SIZE)
        {
            com_u1_sw_userif = g_u1_sw_userif;
        }
        else
        {
            g_u1_sw_userif = u1_temp;

            if (MAIN_UI_RMW == g_u1_sw_userif)
            {
                /* Get status of motor control system */
                u1_motor_status  = R_SYSTEM_MANAGER_MotorStatusGet();
                g_u1_system_mode = u1_motor_status;
            }
            else
            {
                /* Do Nothing */
            }
        }
    }

    /*============================*/
    /*        Execute event       */
    /*============================*/
    if (MAIN_UI_RMW == g_u1_sw_userif)
    {
        /* Main process for ICS UI */
        r_app_rmw_ui_mainloop();
    }
    else if (MAIN_UI_BOARD == g_u1_sw_userif)
    {
        /* Main process for board UI */
        r_app_board_ui_mainloop();
    }
    else
    {
        /* Do Nothing */
    }

    /*============================*/
    /*         LED control        */
    /*============================*/
    u1_motor_status = R_SYSTEM_MANAGER_MotorStatusGet(); /* Get status of motor control system */
    r_app_board_ui_led_control(u1_motor_status);
} /* End of function r_app_main_ui_mainloop */
