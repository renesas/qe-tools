/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_GPT0.h
* Component Version: 1.5.2
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_GPT0.
***********************************************************************************************************************/

#ifndef CFG_Config_GPT0_H
#define CFG_Config_GPT0_H

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_gpt.h"

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define GPT0_PCLK_COUNTER_DIVISION                      (1)
#define _00000BB8_GPT0_CYCLE_VALUE                      (0x00000BB8UL) /* GPT0 cycle register value */
#define _00000000_GPT0_INIT_COUNT                       (0x00000000UL) /* GPT0 initial counter value */
#define _000005DC_GPT0_COMP_MATCH_A_VALUE               (0x000005DCUL) /* GPT0 compare match A value */
#define _00000064_GPT0_COMP_MATCH_D_VALUE               (0x00000064UL) /* GPT0 compare match D value */
#define _00000064_GPT0_COMP_MATCH_F_VALUE               (0x00000064UL) /* GPT0 compare match F value */
#define _00000001_GPT0_AD_REQUEST_A_VALUE               (0x00000001UL) /* GPT0 A/D request A value */
#define _00000078_GPT0_DEADTIME_UP_VALUE                (0x00000078UL) /* GPT0 upcount dead time value */

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void R_Config_GPT0_Create(void);
void R_Config_GPT0_Create_UserInit(void);
void R_Config_GPT0_Start(void);
void R_Config_GPT0_Stop(void);
void R_Config_GPT0_Software_Clear(void);
/* Start user code for function. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#endif
