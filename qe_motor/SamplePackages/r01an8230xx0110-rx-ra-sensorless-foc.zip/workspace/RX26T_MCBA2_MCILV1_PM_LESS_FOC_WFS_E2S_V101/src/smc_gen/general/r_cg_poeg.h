/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : r_cg_poeg.h
* Version          : 1.0.101
* Device(s)        : R5F526TFCxFP
* Description      : General header file for POEG peripheral.
***********************************************************************************************************************/

#ifndef POEG_H
#define POEG_H

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/
/*
    POEG Group n Setting Register (POEGGn) (n = A to D)
*/
/* Port Input Detection Enable (PIDE) */
#define _00000000_POEG_GTETRG_DETECT_DISABLE     (0x00000000UL) /* Detection of GTETRGn pin input is disabled */
#define _00000010_POEG_GTETRG_DETECT_ENABLE      (0x00000010UL) /* Detection of GTETRGn pin input is enabled */
/* GPT Output Stop Request Enable (IOCE) */
#define _00000000_POEG_GPT_DETECT_DISABLE        (0x00000000UL) /* Detection of GPT pin output is disabled */
#define _00000020_POEG_GPT_DETECT_ENABLE         (0x00000020UL) /* Detection of GPT pin output is enabled */
/* Enable Stopping Output on Stopping of Oscillation (OSTPE) */
#define _00000000_POEG_OST_DETECT_DISABLE        (0x00000000UL) /* Detection of stopping of oscillation is disabled */
#define _00000040_POEG_OST_DETECT_ENABLE         (0x00000040UL) /* Detection of stopping of oscillation is enabled */
/* CMPC_0 Enable (CDRE0) */
#define _00000000_POEG_CMPC0_DETECT_DISABLE      (0x00000000UL) /* Comparator edge detection 0 is disabled */
#define _00000100_POEG_CMPC0_DETECT_ENABLE       (0x00000100UL) /* Comparator edge detection 0 is enabled */
/* CMPC_1 Enable (CDRE1) */
#define _00000000_POEG_CMPC1_DETECT_DISABLE      (0x00000000UL) /* Comparator edge detection 1 is disabled */
#define _00000200_POEG_CMPC1_DETECT_ENABLE       (0x00000200UL) /* Comparator edge detection 1 is enabled */
/* CMPC_2 Enable (CDRE2) */
#define _00000000_POEG_CMPC2_DETECT_DISABLE      (0x00000000UL) /* Comparator edge detection 2 is disabled */
#define _00000400_POEG_CMPC2_DETECT_ENABLE       (0x00000400UL) /* Comparator edge detection 2 is enabled */
/* CMPC_3 Enable (CDRE3) */
#define _00000000_POEG_CMPC3_DETECT_DISABLE      (0x00000000UL) /* Comparator edge detection 3 is disabled */
#define _00000800_POEG_CMPC3_DETECT_ENABLE       (0x00000800UL) /* Comparator edge detection 3 is enabled */
/* CMPC_4 Enable (CDRE4) */
#define _00000000_POEG_CMPC4_DETECT_DISABLE      (0x00000000UL) /* Comparator edge detection 4 is disabled */
#define _00001000_POEG_CMPC4_DETECT_ENABLE       (0x00001000UL) /* Comparator edge detection 4 is enabled */
/* CMPC_5 Enable (CDRE5) */
#define _00000000_POEG_CMPC5_DETECT_DISABLE      (0x00000000UL) /* Comparator edge detection 5 is disabled */
#define _00002000_POEG_CMPC5_DETECT_ENABLE       (0x00002000UL) /* Comparator edge detection 5 is enabled */
/* Noise Filter Clock Select (NFPSC) */
#define _00000000_POEG_NFPSC_CLOCK_DIVISION0     (0x00000000UL) /* Set this bit to 0 in combination
                                                                   with the NFCS bits */
#define _01000000_POEG_NFPSC_CLOCK_DIVISION1     (0x01000000UL) /* Set this bit to 1 in combination
                                                                   with the NFCS bits */
/* Input Edge or Level Detection Select (ELSEL) */
#define _00000000_POEG_ELSEL_LEVEL_DETECTION     (0x00000000UL) /* Level detection */
#define _02000000_POEG_ELSEL_EDGE_DETECTION      (0x02000000UL) /* Edge detection */
/* Noise Filter Sampling Count Select (NFSN) */
#define _00000000_POEG_NFSN_SAMPLING_3TIMES      (0x00000000UL) /* 3 times */
#define _04000000_POEG_NFSN_SAMPLING_4TIMES      (0x04000000UL) /* 4 times */
#define _08000000_POEG_NFSN_SAMPLING_5TIMES      (0x08000000UL) /* 5 times */
#define _0C000000_POEG_NFSN_SAMPLING_6TIMES      (0x0C000000UL) /* 6 times */
/* GTETRGn Input Inverting (INV) */
#define _00000000_POEG_GTETRG_INVERT_DISABLE     (0x00000000UL) /* Input on the GTETRGn pin is not inverted */
#define _10000000_POEG_GTETRG_INVERT_ENABLE      (0x10000000UL) /* Input on the GTETRGn pin is inverted */
/* Noise filter Enable (NFEN) */
#define _00000000_POEG_NOISEFILTER_DISABLE       (0x00000000UL) /* Noise filter on the GETRGn pin is disabled */
#define _20000000_POEG_NOISEFILTER_ENABLE        (0x20000000UL) /* Noise filter on the GETRGn pin is enabled */
/* Noise filter Clock Select (NFCS) */
#define _00000000_POEG_NOISEFILTER_PLCK_GPT      (0x00000000UL) /* Samples per PCLK_GPTn clock (n = A to D) */
#define _40000000_POEG_NOISEFILTER_PCLK_GPT8     (0x40000000UL) /* Samples per PCLK_GPTn/8 clock (n = A to D) */
#define _80000000_POEG_NOISEFILTER_PCLK_GPT32    (0x80000000UL) /* Samples per PCLK_GPTn/32 clock (n = A to D) */
#define _C0000000_POEG_NOISEFILTER_PCLK_GPT128   (0xC0000000UL) /* Samples per PCLK_GPTn/128 clock (n = A to D) */
#define _00000000_POEG_NOISEFILTER_PLCK_GPT2     (0x00000000UL) /* Samples per PCLK_GPTn/2 clock (n = A to D) */
#define _40000000_POEG_NOISEFILTER_PCLK_GPT4     (0x40000000UL) /* Samples per PCLK_GPTn/4 clock (n = A to D) */
#define _80000000_POEG_NOISEFILTER_PCLK_GPT16    (0x80000000UL) /* Samples per PCLK_GPTn/16 clock (n = A to D) */
#define _C0000000_POEG_NOISEFILTER_PCLK_GPT64    (0xC0000000UL) /* Samples per PCLK_GPTn/64 clock (n = A to D) */

/*
    POEG Group n Input Control Register (POEGICRn) (n = A to D)
*/
/* Output Disable Request Disabling Signal Select (MSEL) */
#define _00000000_POEG_MSEL_NOTDISABLE_REQUEST   (0x00000000UL) /* Request to disable output are not disabled */
#define _00000001_POEG_MSEL_DISABLE_GTIOC0A      (0x00000001UL) /* GTIOC0A signal controls requests to disable output */
#define _00000002_POEG_MSEL_DISABLE_GTIOC0B      (0x00000002UL) /* GTIOC0B signal controls requests to disable output */
#define _00000003_POEG_MSEL_DISABLE_GTIOC1A      (0x00000003UL) /* GTIOC1A signal controls requests to disable output */
#define _00000004_POEG_MSEL_DISABLE_GTIOC1B      (0x00000004UL) /* GTIOC1B signal controls requests to disable output */
#define _00000005_POEG_MSEL_DISABLE_GTIOC2A      (0x00000005UL) /* GTIOC2A signal controls requests to disable output */
#define _00000006_POEG_MSEL_DISABLE_GTIOC2B      (0x00000006UL) /* GTIOC2B signal controls requests to disable output */
#define _00000007_POEG_MSEL_DISABLE_GTIOC3A      (0x00000007UL) /* GTIOC3A signal controls requests to disable output */
#define _00000008_POEG_MSEL_DISABLE_GTIOC3B      (0x00000008UL) /* GTIOC3B signal controls requests to disable output */
#define _00000009_POEG_MSEL_DISABLE_GTIOC4A      (0x00000009UL) /* GTIOC4A signal controls requests to disable output */
#define _0000000A_POEG_MSEL_DISABLE_GTIOC4B      (0x0000000AUL) /* GTIOC4B signal controls requests to disable output */
#define _0000000B_POEG_MSEL_DISABLE_GTIOC5A      (0x0000000BUL) /* GTIOC5A signal controls requests to disable output */
#define _0000000C_POEG_MSEL_DISABLE_GTIOC5B      (0x0000000CUL) /* GTIOC5B signal controls requests to disable output */
#define _0000000D_POEG_MSEL_DISABLE_GTIOC6A      (0x0000000DUL) /* GTIOC6A signal controls requests to disable output */
#define _0000000E_POEG_MSEL_DISABLE_GTIOC6B      (0x0000000EUL) /* GTIOC6B signal controls requests to disable output */
#define _0000000F_POEG_MSEL_DISABLE_GTIOC7A      (0x0000000FUL) /* GTIOC7A signal controls requests to disable output */
#define _00000010_POEG_MSEL_DISABLE_GTIOC7B      (0x00000010UL) /* GTIOC7B signal controls requests to disable output */

/*
    GPTWA Output Stopping Control Group n Write Protection Register (GTONCWPn) (n = A to D)
*/
/* Register Writing Disable (WP) */
#define _0000_POEG_WP_WRITING_ENABLE             (0x0000U) /* Writing to the GTONCCRn register is enabled
                                                              (n = A to D) */
#define _0001_POEG_WP_WRITING_DISABLE            (0x0001U) /* Writing to the GTONCCRn register is disabled
                                                              (n = A to D) */
/* Key Code (PRKEY) */
#define _A500_POEG_PRKEY_WRITING_ENABLE          (0xA500U) /* Enable writing new values to
                                                              GTONCWPn register (n = A to D) */

/*
    GPT Output Stopping Control Group n Controlling Register (GTONCCRn) (n = A to D)
*/
/* Direct Stopping Request Setting (NE) */
#define _0000_POEG_DIRSTP_DISABLE                (0x0000U) /* Set as a direct stopping request signal is disabled */
#define _0001_POEG_DIRSTP_ENABLE                 (0x0001U) /* Set as a direct stopping request signal is enabled */
/* Direct Stopping Request Selection (NFS) */
#define _0000_POEG_DIRSTP_REQ_CMPC0              (0x0000U) /* Comparator level detection 0 */
#define _0010_POEG_DIRSTP_REQ_CMPC1              (0x0010U) /* Comparator level detection 1 */
#define _0020_POEG_DIRSTP_REQ_CMPC2              (0x0020U) /* Comparator level detection 2 */
#define _0040_POEG_DIRSTP_REQ_CMPC3              (0x0040U) /* Comparator level detection 3 */
#define _0050_POEG_DIRSTP_REQ_CMPC4              (0x0050U) /* Comparator level detection 4 */
#define _0060_POEG_DIRSTP_REQ_CMPC5              (0x0060U) /* Comparator level detection 5 */
#define _0070_POEG_DIRSTP_REQ_GTETRG             (0x0070U) /* GTETRGn pin input level detection (n = A to D) */
/* Direct Stopping Request Active Sense (NFV) */
#define _0000_POEG_DIRSTP_ACTSNS_0               (0x0000U) /* Stopping output when detection signal is 0 */
#define _0100_POEG_DIRSTP_ACTSNS_1               (0x0100U) /* Stopping output when detection signal is 1 */
/* Negate Control Disabling Signal Select (MSEL) */
#define  _0000_POEG_MSEL_NEGATION_NOTDISABLE     (0x0000U) /* Control for negations is not disabled */
#define  _0800_POEG_MSEL_GTIOC0A_NEGATION        (0x0800U) /* GTIOC0A signal controls the disabling of negation */
#define  _1000_POEG_MSEL_GTIOC0B_NEGATION        (0x1000U) /* GTIOC0B signal controls the disabling of negation */
#define  _1800_POEG_MSEL_GTIOC1A_NEGATION        (0x1800U) /* GTIOC1A signal controls the disabling of negation */
#define  _2000_POEG_MSEL_GTIOC1B_NEGATION        (0x2000U) /* GTIOC1B signal controls the disabling of negation */
#define  _2800_POEG_MSEL_GTIOC2A_NEGATION        (0x2800U) /* GTIOC2A signal controls the disabling of negation */
#define  _3000_POEG_MSEL_GTIOC2B_NEGATION        (0x3000U) /* GTIOC2B signal controls the disabling of negation */
#define  _3800_POEG_MSEL_GTIOC3A_NEGATION        (0x3800U) /* GTIOC3A signal controls the disabling of negation */
#define  _4000_POEG_MSEL_GTIOC3B_NEGATION        (0x4000U) /* GTIOC3B signal controls the disabling of negation */
#define  _4800_POEG_MSEL_GTIOC4A_NEGATION        (0x4800U) /* GTIOC4A signal controls the disabling of negation */
#define  _5000_POEG_MSEL_GTIOC4B_NEGATION        (0x5000U) /* GTIOC4B signal controls the disabling of negation */
#define  _5800_POEG_MSEL_GTIOC5A_NEGATION        (0x5800U) /* GTIOC5A signal controls the disabling of negation */
#define  _6000_POEG_MSEL_GTIOC5B_NEGATION        (0x6000U) /* GTIOC5B signal controls the disabling of negation */
#define  _6800_POEG_MSEL_GTIOC6A_NEGATION        (0x6800U) /* GTIOC6A signal controls the disabling of negation */
#define  _7000_POEG_MSEL_GTIOC6B_NEGATION        (0x7000U) /* GTIOC6B signal controls the disabling of negation */
#define  _7800_POEG_MSEL_GTIOC7A_NEGATION        (0x7800U) /* GTIOC7A signal controls the disabling of negation */
#define  _8000_POEG_MSEL_GTIOC7B_NEGATION        (0x8000U) /* GTIOC7B signal controls the disabling of negation */

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
/* Start user code for function. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#endif
