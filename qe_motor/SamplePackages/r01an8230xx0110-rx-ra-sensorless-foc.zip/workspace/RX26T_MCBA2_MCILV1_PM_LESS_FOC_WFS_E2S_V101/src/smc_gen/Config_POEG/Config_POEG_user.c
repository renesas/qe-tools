/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_POEG_user.c
* Component Version: 1.11.0
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_POEG.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_POEG.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_app_mcu.h"
#include "mtr_interrupt.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_POEG_Create_UserInit
* Description  : This function adds user code after initializing the POEG module
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_POEG_Create_UserInit(void)
{
    /* Start user code for code init. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_POEG_poeggbi_interrupt
* Description  : This function is POEGGBI interrupt service routine
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void r_Config_POEG_poeggbi_interrupt(void)
{
    /* Start user code for r_Config_POEG_poeggbi_interrupt. Do not edit comment generated here */
    r_app_pwm_highz_reset();
    mtr_interrupt_hw_overcurrent();
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
