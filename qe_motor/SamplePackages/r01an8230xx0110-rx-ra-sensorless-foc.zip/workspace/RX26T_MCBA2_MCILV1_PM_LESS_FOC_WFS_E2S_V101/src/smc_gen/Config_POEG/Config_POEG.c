/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_POEG.c
* Component Version: 1.11.0
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_POEG.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_POEG.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_POEG_Create
* Description  : This function initializes the POEG module
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_POEG_Create(void)
{
    /* Cancel POEG module stop state */
    MSTP(POEG) = 0U;

    /* Set POEG group A registers */
    POEG.POEGGA.LONG = _00000000_POEG_GPT_DETECT_DISABLE | _00000000_POEG_OST_DETECT_DISABLE | 
                       _00000000_POEG_CMPC0_DETECT_DISABLE | _00000000_POEG_CMPC1_DETECT_DISABLE | 
                       _00000000_POEG_CMPC2_DETECT_DISABLE | _00000000_POEG_CMPC3_DETECT_DISABLE | 
                       _00000000_POEG_CMPC4_DETECT_DISABLE | _00000000_POEG_CMPC5_DETECT_DISABLE;
    POEG.GTONCWPA.WORD = _0000_POEG_WP_WRITING_ENABLE | _A500_POEG_PRKEY_WRITING_ENABLE;
    POEG.GTONCCRA.WORD = _0000_POEG_DIRSTP_DISABLE;
    POEG.GTONCWPA.WORD = _0001_POEG_WP_WRITING_DISABLE | _A500_POEG_PRKEY_WRITING_ENABLE;

    /* Set POEG group B registers */
    POEG.POEGGB.LONG = _00000010_POEG_GTETRG_DETECT_ENABLE | _00000000_POEG_GPT_DETECT_DISABLE | 
                       _00000000_POEG_OST_DETECT_DISABLE | _00000000_POEG_CMPC0_DETECT_DISABLE | 
                       _00000000_POEG_CMPC1_DETECT_DISABLE | _00000000_POEG_CMPC2_DETECT_DISABLE | 
                       _00000000_POEG_CMPC3_DETECT_DISABLE | _00000000_POEG_CMPC4_DETECT_DISABLE | 
                       _00000000_POEG_CMPC5_DETECT_DISABLE | _00000000_POEG_NFPSC_CLOCK_DIVISION0 | 
                       _02000000_POEG_ELSEL_EDGE_DETECTION | _00000000_POEG_NFSN_SAMPLING_3TIMES | 
                       _10000000_POEG_GTETRG_INVERT_ENABLE | _20000000_POEG_NOISEFILTER_ENABLE | 
                       _00000000_POEG_NOISEFILTER_PLCK_GPT;
    POEG.GTONCWPB.WORD = _0000_POEG_WP_WRITING_ENABLE | _A500_POEG_PRKEY_WRITING_ENABLE;
    POEG.GTONCCRB.WORD = _0000_POEG_DIRSTP_DISABLE;
    POEG.GTONCWPB.WORD = _0001_POEG_WP_WRITING_DISABLE | _A500_POEG_PRKEY_WRITING_ENABLE;

    /* Set POEG group C registers */
    POEG.POEGGC.LONG = _00000000_POEG_GPT_DETECT_DISABLE | _00000000_POEG_OST_DETECT_DISABLE | 
                       _00000000_POEG_CMPC0_DETECT_DISABLE | _00000000_POEG_CMPC1_DETECT_DISABLE | 
                       _00000000_POEG_CMPC2_DETECT_DISABLE | _00000000_POEG_CMPC3_DETECT_DISABLE | 
                       _00000000_POEG_CMPC4_DETECT_DISABLE | _00000000_POEG_CMPC5_DETECT_DISABLE;
    POEG.GTONCWPC.WORD = _0000_POEG_WP_WRITING_ENABLE | _A500_POEG_PRKEY_WRITING_ENABLE;
    POEG.GTONCCRC.WORD = _0000_POEG_DIRSTP_DISABLE;
    POEG.GTONCWPC.WORD = _0001_POEG_WP_WRITING_DISABLE | _A500_POEG_PRKEY_WRITING_ENABLE;

    /* Set POEG group D registers */
    POEG.POEGGD.LONG = _00000000_POEG_GPT_DETECT_DISABLE | _00000000_POEG_OST_DETECT_DISABLE | 
                       _00000000_POEG_CMPC0_DETECT_DISABLE | _00000000_POEG_CMPC1_DETECT_DISABLE | 
                       _00000000_POEG_CMPC2_DETECT_DISABLE | _00000000_POEG_CMPC3_DETECT_DISABLE | 
                       _00000000_POEG_CMPC4_DETECT_DISABLE | _00000000_POEG_CMPC5_DETECT_DISABLE;
    POEG.GTONCWPD.WORD = _0000_POEG_WP_WRITING_ENABLE | _A500_POEG_PRKEY_WRITING_ENABLE;
    POEG.GTONCCRD.WORD = _0000_POEG_DIRSTP_DISABLE;
    POEG.GTONCWPD.WORD = _0001_POEG_WP_WRITING_DISABLE | _A500_POEG_PRKEY_WRITING_ENABLE;

    /* Set GTETRGB pin */
    MPC.P70PFS.BYTE = 0x15U;
    PORT7.PMR.BYTE |= 0x01U;

    R_Config_POEG_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_POEG_Start
* Description  : This function starts the POEG module
*                Note that this function is empty if no interrupt is configured for POEG
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_POEG_Start(void)
{
    /* Enable POEG interrupts in ICU */
    EN(POEG,POEGGBI) = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_POEG_Stop
* Description  : This function stops the POEG module
*                Note that this function is empty if no interrupt is configured for POEG
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_POEG_Stop(void)
{
    /* Disable POEG interrupts in ICU */
    EN(POEG,POEGGBI) = 0U;
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
