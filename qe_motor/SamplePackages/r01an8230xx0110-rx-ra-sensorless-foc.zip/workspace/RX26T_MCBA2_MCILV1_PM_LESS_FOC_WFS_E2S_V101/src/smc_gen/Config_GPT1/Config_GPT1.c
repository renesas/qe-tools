/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_GPT1.c
* Component Version: 1.5.2
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_GPT1.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_GPT1.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_GPT1_Create
* Description  : This function initializes the GPT1 channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT1_Create(void)
{
    /* Cancel GPTW1 module stop state */
    MSTP(GPTW1) = 0U;

    /* Disable GPTW1 control registers write protect */
    GPTW1.GTWP.LONG = 0x0000A500UL;

    /* Set GPTW1 mode */
    GPTW1.GTCR.LONG = _00040000_GPTn_MODE_TRIANGLE_WAVE_PWM_1;

    /* Set GPTW1 count-up sources */
    GPTW1.GTUPSR.LONG = _00000000_GPTn_GTETRGA_DISABLE | _00000000_GPTn_GTETRGB_DISABLE | 
                        _00000000_GPTn_GTETRGC_DISABLE | _00000000_GPTn_GTETRGD_DISABLE | 
                        _00000000_GPTn_ELCA_INPUT_DISABLE | _00000000_GPTn_ELCB_INPUT_DISABLE | 
                        _00000000_GPTn_ELCC_INPUT_DISABLE | _00000000_GPTn_ELCD_INPUT_DISABLE | 
                        _00000000_GPTn_ELCE_INPUT_DISABLE | _00000000_GPTn_ELCF_INPUT_DISABLE | 
                        _00000000_GPTn_ELCG_INPUT_DISABLE | _00000000_GPTn_ELCH_INPUT_DISABLE;

    /* Set GPTW1 count-down sources */
    GPTW1.GTDNSR.LONG = _00000000_GPTn_GTETRGA_DISABLE | _00000000_GPTn_GTETRGB_DISABLE | 
                        _00000000_GPTn_GTETRGC_DISABLE | _00000000_GPTn_GTETRGD_DISABLE | 
                        _00000000_GPTn_ELCA_INPUT_DISABLE | _00000000_GPTn_ELCB_INPUT_DISABLE | 
                        _00000000_GPTn_ELCC_INPUT_DISABLE | _00000000_GPTn_ELCD_INPUT_DISABLE | 
                        _00000000_GPTn_ELCE_INPUT_DISABLE | _00000000_GPTn_ELCF_INPUT_DISABLE | 
                        _00000000_GPTn_ELCG_INPUT_DISABLE | _00000000_GPTn_ELCH_INPUT_DISABLE;

    /* Set external pulse width measuring function */
    GPTW1.GTUPSR.BIT.USILVL = _00000000_GPTn_EXT_LEVEL_DISABLE;
    GPTW1.GTDNSR.BIT.DSILVL = _00000000_GPTn_EXT_LEVEL_DISABLE;

    /* Set GPTW1 count direction and duty */
    GPTW1.GTUDDTYC.LONG = _00000001_GPTn_COUNT_UP | _00000002_GPTn_COUNT_DIR_FORCE | 
                          _00000000_GPTn_GTIOCnA_DUTYCYCLE_COMPARE | _00000000_GPTn_GTIOCnB_DUTYCYCLE_COMPARE;

    /* Clear GPTW1 count direction forcible set */
    GPTW1.GTUDDTYC.BIT.UDF = 0U;

    /* Set GPTW1 count clock and input capture at count stop */
    GPTW1.GTCR.LONG |= (_00000100_GPTn_NO_INPUTCAP_COUNT_STOP | _00000000_GPTn_COUNT_CLK_PCLKC);

    /* Set GPTW1 cycle */
    GPTW1.GTPR = _00000BB8_GPT1_CYCLE_VALUE;

    /* Set GPTW1 counter initial value */
    GPTW1.GTCNT = _00000000_GPT1_INIT_COUNT;

    /* Set inter channel cooperation input capture */
    GPTW1.GTICCR.LONG = _00000000_GPTn_ICAFA_DISABLE | _00000000_GPTn_ICAFB_DISABLE | _00000000_GPTn_ICAFC_DISABLE | 
                        _00000000_GPTn_ICAFD_DISABLE | _00000000_GPTn_ICAFE_DISABLE | _00000000_GPTn_ICAFF_DISABLE | 
                        _00000000_GPTn_ICAFPO_DISABLE | _00000000_GPTn_ICAFPU_DISABLE | 
                        _00000000_GPTn_ICACLK_DISABLE | _00000000_GPTn_ICBFA_DISABLE | _00000000_GPTn_ICBFB_DISABLE | 
                        _00000000_GPTn_ICBFC_DISABLE | _00000000_GPTn_ICBFD_DISABLE | _00000000_GPTn_ICBFE_DISABLE | 
                        _00000000_GPTn_ICBFF_DISABLE | _00000000_GPTn_ICBFPO_DISABLE | _00000000_GPTn_ICBFPU_DISABLE | 
                        _00000000_GPTn_ICBCLK_DISABLE;

    /* Set GPTW1 start sources */
    GPTW1.GTSSR.LONG = _00000000_GPTn_GTETRGA_DISABLE | _00000000_GPTn_GTETRGB_DISABLE | 
                       _00000000_GPTn_GTETRGC_DISABLE | _00000000_GPTn_GTETRGD_DISABLE | 
                       _00000000_GPTn_ELCA_INPUT_DISABLE | _00000000_GPTn_ELCB_INPUT_DISABLE | 
                       _00000000_GPTn_ELCC_INPUT_DISABLE | _00000000_GPTn_ELCD_INPUT_DISABLE | 
                       _00000000_GPTn_ELCE_INPUT_DISABLE | _00000000_GPTn_ELCF_INPUT_DISABLE | 
                       _00000000_GPTn_ELCG_INPUT_DISABLE | _00000000_GPTn_ELCH_INPUT_DISABLE | 
                       _80000000_GPTn_SOFTWARE_SOURCE_ENABLE;

    /* Set GPTW1 stop sources */
    GPTW1.GTPSR.LONG = _00000000_GPTn_GTETRGA_DISABLE | _00000000_GPTn_GTETRGB_DISABLE | 
                       _00000000_GPTn_GTETRGC_DISABLE | _00000000_GPTn_GTETRGD_DISABLE | 
                       _00000000_GPTn_ELCA_INPUT_DISABLE | _00000000_GPTn_ELCB_INPUT_DISABLE | 
                       _00000000_GPTn_ELCC_INPUT_DISABLE | _00000000_GPTn_ELCD_INPUT_DISABLE | 
                       _00000000_GPTn_ELCE_INPUT_DISABLE | _00000000_GPTn_ELCF_INPUT_DISABLE | 
                       _00000000_GPTn_ELCG_INPUT_DISABLE | _00000000_GPTn_ELCH_INPUT_DISABLE | 
                       _80000000_GPTn_SOFTWARE_SOURCE_ENABLE;

    /* Set GPTW1 clear sources */
    GPTW1.GTCSR.LONG = _00000000_GPTn_GTETRGA_DISABLE | _00000000_GPTn_GTETRGB_DISABLE | 
                       _00000000_GPTn_GTETRGC_DISABLE | _00000000_GPTn_GTETRGD_DISABLE | 
                       _00000000_GPTn_ELCA_INPUT_DISABLE | _00000000_GPTn_ELCB_INPUT_DISABLE | 
                       _00000000_GPTn_ELCC_INPUT_DISABLE | _00000000_GPTn_ELCD_INPUT_DISABLE | 
                       _00000000_GPTn_ELCE_INPUT_DISABLE | _00000000_GPTn_ELCF_INPUT_DISABLE | 
                       _00000000_GPTn_ELCG_INPUT_DISABLE | _00000000_GPTn_ELCH_INPUT_DISABLE | 
                       _80000000_GPTn_SOFTWARE_SOURCE_ENABLE;

    /* Set GPTW1 output stop detection */
    GPTW1.GTINTAD.LONG = _01000000_GPTn_OUTPUT_STOP_GROUPB | _00000000_GPTn_DEADTIME_OUTPUT_STOP_DISABLE | 
                         _00000000_GPTn_SIMHIGH_OUTPUT_STOP_DISABLE | _00000000_GPTn_SIMLOW_OUTPUT_STOP_DISABLE;

    /* Set GTIOC1A,GTIOC1B pin function */
    GPTW1.GTIOR.LONG = _00000003_GPTn_GTIOCA_COMP_MATCH_TOGGLE | _00000000_GPTn_GTIOCA_CYCLE_END_RETAIN | 
                       _00000000_GPTn_GTIOCA_INIT_OUT_LOW | _00000000_GPTn_GTIOCA_OUTPUT_ON_STOP_0 | 
                       _00000000_GPTn_GTIOCA_OUTPUT_ON_START_SET | _00000200_GPTn_GTIOCnA_NEG_HIZ | 
                       _00030000_GPTn_GTIOCB_COMP_MATCH_TOGGLE | _00000000_GPTn_GTIOCB_CYCLE_END_RETAIN | 
                       _00100000_GPTn_GTIOCB_INIT_OUT_HIGH | _00400000_GPTn_GTIOCB_OUTPUT_ON_STOP_1 | 
                       _00000000_GPTn_GTIOCB_OUTPUT_ON_START_SET | _02000000_GPTn_GTIOCnB_NEG_HIZ;

    /* Enable GTIOC1A,GTIOC1B pin output */
    GPTW1.GTIOR.LONG |= (_00000100_GPTn_GTIOCnA_OUTPUT_ENABLE | _01000000_GPTn_GTIOCnB_OUTPUT_ENABLE);

    /* Set GPTW1 buffer operations */
    GPTW1.GTBER.LONG = _00000000_GPTn_GTCCR_BUF_OP_ENABLE | _00000000_GPTn_GTPR_BUF_OP_ENABLE | 
                       _00000004_GPTn_GTADTR_BUF_OP_DISABLE | _00000008_GPTn_GTDV_BUF_OP_DISABLE | 
                       _00010000_GPTn_GTCCRA_BUF_SINGLE | _00040000_GPTn_GTCCRB_BUF_SINGLE | 
                       _00100000_GPTn_GTPR_BUF_SINGLE;

    /* Set GPTW1 compare match value */
    GPTW1.GTCCRA = _000005DC_GPT1_COMP_MATCH_A_VALUE;
    GPTW1.GTCCRD = _00000064_GPT1_COMP_MATCH_D_VALUE;
    GPTW1.GTCCRF = _00000064_GPT1_COMP_MATCH_F_VALUE;

    /* Set GPTW1 GTCCRA buffer value */
    GPTW1.GTCCRC = _000005DC_GPT1_COMP_MATCH_A_VALUE;

    /* Set GPTW1 GTPR buffer value */
    GPTW1.GTPBR = _00000BB8_GPT1_CYCLE_VALUE;

    /* Set GPTW1 forcible buffer transfer */
    GPTW1.GTBER.BIT.CCRSWT = 1U;

    /* Set GPTW1 dead time setting */
    GPTW1.GTDTCR.LONG = _00000001_GPTn_DEAD_TIME_ENABLE | _00000000_GPTn_GTDVU_BUF_DISABLE | 
                        _00000100_GPTn_GTDVD_VALUE_AUTO;

    /* Set GPTW1 dead time value */
    GPTW1.GTDVU = _00000078_GPT1_DEADTIME_UP_VALUE;

    /* Set GPTW1 interrupt and A/D conversion request generation */
    GPTW1.GTINTAD.LONG |= (_00000000_GPTn_ADTRB_DOWNCOUNTING_DISABLE | _00000000_GPTn_ADTRB_UPCOUNTING_DISABLE | 
                          _00000000_GPTn_ADTRA_DOWNCOUNTING_DISABLE | _00000000_GPTn_ADTRA_UPCOUNTING_DISABLE | 
                          _00000000_GPTn_GTCIV_INTERRUPT_DISABLE | _00000000_GPTn_GTCIU_INTERRUPT_DISABLE | 
                          _00000000_GPTn_GTCIF_INTERRUPT_DISABLE | _00000000_GPTn_GTCID_INTERRUPT_DISABLE | 
                          _00000000_GPTn_GTCIB_INTERRUPT_DISABLE | _00000000_GPTn_GTCIA_INTERRUPT_DISABLE);

    /* Set GPTW1 interrupt and A/D conversion request skipping */
    GPTW1.GTITC.LONG = _00000000_GPTn_GTCI_SKIP_DISABLE | _00000000_GPTn_GTCI_SKIPPING_COUNT_0;

    /* Set GPTW1 extended interrupt skipping counter control */
    GPTW1.GTEITC.LONG = _00000000_GPTn_EXT1_SKIP_DISABLE | _00000000_GPTn_EXT2_SKIP_DISABLE;

    /* Set A/D conversion start request compare match skipping function */
    GPTW1.GTADCMSC.LONG = _00000000_GPTn_ADCM1_SKIP_DISABLE | _00000000_GPTn_ADCM2_SKIP_DISABLE;

    /* Disable rising and falling edge adjustment circuit */
    GPTW0.GTWP.BIT.WP = 0U;
    HRPWM.HROCR2.BIT.HRDIS1 = 1U;

    /* Set GTIOC1A pin */
    MPC.P72PFS.BYTE = 0x14U;
    PORT7.PMR.BYTE |= 0x04U;

    /* Set GTIOC1B pin */
    MPC.P75PFS.BYTE = 0x14U;
    PORT7.PMR.BYTE |= 0x20U;

    R_Config_GPT1_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT1_Start
* Description  : This function starts the GPT1 channel counter. Note that this function is empty
*                if Count start sources setting is not enabled and no interrupt is configured for GPT1
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT1_Start(void)
{
    volatile long prev_setting = GPTW1.GTWP.LONG;

    /* Disable GPTW1 start write protect */
    GPTW1.GTWP.LONG = 0x0000A500UL;

    /* Start GPTW1 counting */
    GPTW1.GTSTR.BIT.CSTRT1 = 1U;

    /* Enable GPTW1 start write protect */
    GPTW1.GTWP.LONG |= (0x0000A502UL | prev_setting);
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT1_Stop
* Description  : This function stops the GPT1 channel counter. Note that this function is empty
*                if Count stop sources setting is not enabled and no interrupt is configured for GPT1
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT1_Stop(void)
{
    volatile long prev_setting = GPTW1.GTWP.LONG;

    /* Disable GPTW1 stop write protect */
    GPTW1.GTWP.LONG = 0x0000A500UL;

    /* Stop GPTW1 counting */
    GPTW1.GTSTP.BIT.CSTOP1 = 1U;

    /* Enable GPTW1 stop write protect */
    GPTW1.GTWP.LONG |= (0x0000A504UL | prev_setting);
}

/***********************************************************************************************************************
* Function Name: R_Config_GPT1_Software_Clear
* Description  : This function software clear the GPT1 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT1_Software_Clear(void)
{
    volatile long prev_setting = GPTW1.GTWP.LONG;

    /* Disable GPTW1 clear write protect */
    GPTW1.GTWP.LONG = 0x0000A500UL;

    /* Clear GPTW1 counter */
    GPTW1.GTCLR.BIT.CCLR1 = 1U;

    /* Enable GPTW1 clear write protect */
    GPTW1.GTWP.LONG |= (0x0000A508UL | prev_setting);
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
