/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_driver_smc.c
* Description : The processes of SMC motor driver module
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 31.01.2025 1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_smc_entry.h"
#include "r_motor_common.h"
#include "r_motor_driver.h"
#include "r_motor_driver_hal.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global functions definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_Create
* Description  : This function initialize GPT
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_MOTOR_Create(void)
{
    R_Config_GPT0_Create();
    R_Config_GPT1_Create();
    R_Config_GPT2_Create();
} /* End of function R_Config_MOTOR_Create */

/***********************************************************************************************************************
* Function Name: R_Config_StartTimerCount
* Description  : This function start timer count of GPT0, 1, 2
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_MOTOR_StartTimerCount(void)
{

    /* Disable GPTW0 start write protect */
    GPTW0.GTWP.BIT.STRWP = 0U;

    /* Start GPTW counting */
    GPTW0.GTSTR.LONG |= 0x007;

    /* Enable GPTW0 start write protect */
    GPTW0.GTWP.BIT.STRWP = 1U;
} /* End of function R_Config_MOTOR_StartTimerCount */

/***********************************************************************************************************************
* Function Name: R_Config_StopTimerCount
* Description  : This function stop timer count of GPT0, 1, 2
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_MOTOR_StopTimerCount(void)
{

    /* Disable GPTW0 start write protect */
    GPTW0.GTWP.BIT.STPWP = 0U;

    /* Stop GPTW counting */
    GPTW0.GTSTP.LONG |= 0x007;

    /* Enable GPTW0 start write protect */
    GPTW0.GTWP.BIT.STPWP = 1U;
} /* End of function R_Config_MOTOR_StopTimerCount */

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_StartTimerCtrl
* Description  : This function starts the PWM output for motor control
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_MOTOR_StartTimerCtrl(void)
{
    /* Disable start write protect */
    GPTW0.GTWP.BIT.WP = 0U;
    GPTW1.GTWP.BIT.WP = 0U;
    GPTW2.GTWP.BIT.WP = 0U;

    //Init Wp (GTIOC0A)
    PORT7.PODR.BIT.B1 = 0U; //Active High
    PORT7.PDR.BIT.B1 = 1U;
    PORT7.PMR.BIT.B1 = 1U;
    //Init Wn (GTIOC0B)
    PORT7.PODR.BIT.B4 = 0U; //Active High
    PORT7.PDR.BIT.B4 = 1U;
    PORT7.PMR.BIT.B4 = 1U;
    //Init Vp (GTIOC1A)
    PORT7.PODR.BIT.B2 = 0U; //Active High
    PORT7.PDR.BIT.B2 = 1U;
    PORT7.PMR.BIT.B2 = 1U;
    //Init Vn (GTIOC1B)
    PORT7.PODR.BIT.B5 = 0U; //Active High
    PORT7.PDR.BIT.B5 = 1U;
    PORT7.PMR.BIT.B5 = 1U;
    //Init Up (GTIOC2A)
    PORT7.PODR.BIT.B3 = 0U; //Active High
    PORT7.PDR.BIT.B3 = 1U;
    PORT7.PMR.BIT.B3 = 1U;
    //Init Un (GTIOC2B)
    PORT7.PODR.BIT.B6 = 0U; //Active High
    PORT7.PDR.BIT.B6 = 1U;
    PORT7.PMR.BIT.B6 = 1U;

    /* Enable GPT PWM output */
    GPTW0.GTIOR.LONG |= (_00000100_GPTn_GTIOCnA_OUTPUT_ENABLE | _01000000_GPTn_GTIOCnB_OUTPUT_ENABLE);
    GPTW1.GTIOR.LONG |= (_00000100_GPTn_GTIOCnA_OUTPUT_ENABLE | _01000000_GPTn_GTIOCnB_OUTPUT_ENABLE);
    GPTW2.GTIOR.LONG |= (_00000100_GPTn_GTIOCnA_OUTPUT_ENABLE | _01000000_GPTn_GTIOCnB_OUTPUT_ENABLE);

    /* Enable start write protect */
    GPTW0.GTWP.BIT.WP = 1U;
    GPTW1.GTWP.BIT.WP = 1U;
    GPTW2.GTWP.BIT.WP = 1U;
} /* End of function R_Config_MOTOR_StartTimerCtrl */

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_StopTimerCtrl
* Description  : This function stops the PWM output for motor control
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_MOTOR_StopTimerCtrl(void)
{
    /* Disable start write protect */
    GPTW0.GTWP.BIT.WP = 0U;
    GPTW1.GTWP.BIT.WP = 0U;
    GPTW2.GTWP.BIT.WP = 0U;

    /* Disable GPT PWM output */
    GPTW0.GTIOR.LONG &= ~(_00000100_GPTn_GTIOCnA_OUTPUT_ENABLE | _01000000_GPTn_GTIOCnB_OUTPUT_ENABLE);
    GPTW1.GTIOR.LONG &= ~(_00000100_GPTn_GTIOCnA_OUTPUT_ENABLE | _01000000_GPTn_GTIOCnB_OUTPUT_ENABLE);
    GPTW2.GTIOR.LONG &= ~(_00000100_GPTn_GTIOCnA_OUTPUT_ENABLE | _01000000_GPTn_GTIOCnB_OUTPUT_ENABLE);

    //Init Wp (GTIOC0A)
    PORT7.PODR.BIT.B1 = 0U; //Active High
    PORT7.PDR.BIT.B1 = 1U;
    PORT7.PMR.BIT.B1 = 0U;
    //Init Wn (GTIOC0B)
    PORT7.PODR.BIT.B4 = 0U; //Active High
    PORT7.PDR.BIT.B4 = 1U;
    PORT7.PMR.BIT.B4 = 0U;
    //Init Vp (GTIOC1A)
    PORT7.PODR.BIT.B2 = 0U; //Active High
    PORT7.PDR.BIT.B2 = 1U;
    PORT7.PMR.BIT.B2 = 0U;
    //Init Vn (GTIOC1B)
    PORT7.PODR.BIT.B5 = 0U; //Active High
    PORT7.PDR.BIT.B5 = 1U;
    PORT7.PMR.BIT.B5 = 0U;
    //Init Up (GTIOC2A)
    PORT7.PODR.BIT.B3 = 0U; //Active High
    PORT7.PDR.BIT.B3 = 1U;
    PORT7.PMR.BIT.B3 = 0U;
    //Init Un (GTIOC2B)
    PORT7.PODR.BIT.B6 = 0U; //Active High
    PORT7.PDR.BIT.B6 = 1U;
    PORT7.PMR.BIT.B6 = 0U;

    /* Enable start write protect */
    GPTW0.GTWP.BIT.WP = 1U;
    GPTW1.GTWP.BIT.WP = 1U;
    GPTW2.GTWP.BIT.WP = 1U;
} /* End of function R_Config_MOTOR_StopTimerCtrl */

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_UpdDuty
* Description  : This function updates duty cycle
* Arguments    : u2_duty_u - U phase duty register value
*                u2_duty_v - V phase duty register value
*                u2_duty_w - W phase duty register value
* Return Value : None
***********************************************************************************************************************/
void R_Config_MOTOR_UpdDuty(uint16_t u2_duty_u, uint16_t u2_duty_v, uint16_t u2_duty_w)
{
    uint32_t u4_duty_cnt_u = (uint32_t)u2_duty_u;
    uint32_t u4_duty_cnt_v = (uint32_t)u2_duty_v;
    uint32_t u4_duty_cnt_w = (uint32_t)u2_duty_w;

    uint32_t u4_duty_max_cnt = GPTW0.GTPR;
    uint32_t u4_duty_min_cnt = GPTW0.GTDVU;

    if ( u4_duty_cnt_u >= u4_duty_max_cnt)
    {
        u4_duty_cnt_u = u4_duty_max_cnt - 1U;
    }
    else if (u4_duty_cnt_u <= u4_duty_min_cnt)
    {
        u4_duty_cnt_u = u4_duty_min_cnt + 1U;
    }
    else
    {
        /* Do nothing */
    }

    if ( u4_duty_cnt_v >= u4_duty_max_cnt)
    {
        u4_duty_cnt_v = u4_duty_max_cnt - 1U;
    }
    else if (u4_duty_cnt_v <= u4_duty_min_cnt)
    {
        u4_duty_cnt_v = u4_duty_min_cnt + 1U;
    }
    else
    {
        /* Do nothing */
    }

    if ( u4_duty_cnt_w >= u4_duty_max_cnt)
    {
        u4_duty_cnt_w = u4_duty_max_cnt - 1U;
    }
    else if (u4_duty_cnt_w <= u4_duty_min_cnt)
    {
        u4_duty_cnt_w = u4_duty_min_cnt + 1U;
    }
    else
    {
        /* Do nothing */
    }

    /* Disable start write protect */
    GPTW0.GTWP.BIT.WP = 0U;
    GPTW1.GTWP.BIT.WP = 0U;
    GPTW2.GTWP.BIT.WP = 0U;

    GPTW1.GTCCRC = u4_duty_cnt_v;
    GPTW1.GTCCRE = u4_duty_cnt_v;
    GPTW0.GTCCRC = u4_duty_cnt_u;
    GPTW0.GTCCRE = u4_duty_cnt_u;
    GPTW2.GTCCRC = u4_duty_cnt_w;
    GPTW2.GTCCRE = u4_duty_cnt_w;

    /* Enable start write protect */
    GPTW0.GTWP.BIT.WP = 1U;
    GPTW1.GTWP.BIT.WP = 1U;
    GPTW2.GTWP.BIT.WP = 1U;
} /* End of function R_Config_MOTOR_UpdDuty */

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_UpdZeroDuty
* Description  : This function sets PWM zero duty
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_MOTOR_UpdZeroDuty(void)
{
    /* Disable start write protect */
    GPTW0.GTWP.BIT.WP = 0U;
    GPTW1.GTWP.BIT.WP = 0U;
    GPTW2.GTWP.BIT.WP = 0U;

    /* For GPT0 */
    GPTW0.GTUDDTYC.BIT.OADTY = 0x02;
    GPTW0.GTUDDTYC.BIT.OBDTY = 0x03;
    GPTW0.GTUDDTYC.BIT.OADTYR = 0x01;
    GPTW0.GTUDDTYC.BIT.OBDTYR = 0x01;

    /* For GPT1 */
    GPTW1.GTUDDTYC.BIT.OADTY = 0x02;
    GPTW1.GTUDDTYC.BIT.OBDTY = 0x03;
    GPTW1.GTUDDTYC.BIT.OADTYR = 0x01;
    GPTW1.GTUDDTYC.BIT.OBDTYR = 0x01;

    /* For GPT2 */
    GPTW2.GTUDDTYC.BIT.OADTY = 0x02;
    GPTW2.GTUDDTYC.BIT.OBDTY = 0x03;
    GPTW2.GTUDDTYC.BIT.OADTYR = 0x01;
    GPTW2.GTUDDTYC.BIT.OBDTYR = 0x01;

    /* Enable start write protect */
    GPTW0.GTWP.BIT.WP = 1U;
    GPTW1.GTWP.BIT.WP = 1U;
    GPTW2.GTWP.BIT.WP = 1U;
} /* End of function R_Config_MOTOR_UpdZeroDuty */

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_UpdCompareDuty
* Description  : This function sets PWM compare duty
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_Config_MOTOR_UpdCompareDuty(void)
{
    /* Disable start write protect */
    GPTW0.GTWP.BIT.WP = 0U;
    GPTW1.GTWP.BIT.WP = 0U;
    GPTW2.GTWP.BIT.WP = 0U;

    /* For GPT0 */
    GPTW0.GTUDDTYC.BIT.OADTY = 0x00;
    GPTW0.GTUDDTYC.BIT.OBDTY = 0x00;

    /* For GPT1 */
    GPTW1.GTUDDTYC.BIT.OADTY = 0x00;
    GPTW1.GTUDDTYC.BIT.OBDTY = 0x00;

    /* For GPT2 */
    GPTW2.GTUDDTYC.BIT.OADTY = 0x00;
    GPTW2.GTUDDTYC.BIT.OBDTY = 0x00;

    /* Enable start write protect */
    GPTW0.GTWP.BIT.WP = 1U;
    GPTW1.GTWP.BIT.WP = 1U;
    GPTW2.GTWP.BIT.WP = 1U;
} /* End of function R_Config_MOTOR_UpdCompareDuty */

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_AdcGetConvVal
* Description  : This function gets A/D conversion result for motor control
* Arguments    : mtr_ad_data - Buffer pointer for A/D conversion register value
* Return Value : None
***********************************************************************************************************************/
void R_Config_MOTOR_AdcGetConvVal(r_mtr_adc_tb * mtr_ad_data)
{
    /* Store ADC read data */
    mtr_ad_data->u2_iu_ad  = (uint16_t)S12AD.ADDR0;
    mtr_ad_data->u2_iv_ad  = (uint16_t)S12AD.ADDR1;
    mtr_ad_data->u2_iw_ad  = (uint16_t)S12AD.ADDR2;
    mtr_ad_data->u2_vdc_ad = (uint16_t)S12AD.ADDR3;
    mtr_ad_data->u2_vphase_u_ad = 0xFFFFU;
    mtr_ad_data->u2_vphase_v_ad = 0xFFFFU;
    mtr_ad_data->u2_vphase_w_ad = 0xFFFFU;
} /* End of function R_Config_MOTOR_AdcGetConvVal */
