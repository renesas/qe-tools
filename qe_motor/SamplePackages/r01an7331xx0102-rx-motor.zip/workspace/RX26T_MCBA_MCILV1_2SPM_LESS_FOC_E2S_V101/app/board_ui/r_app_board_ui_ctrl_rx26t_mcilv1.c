/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_app_board_ui_ctrl_rx26t_mcilv1.c
* Description : Processes of a H/W control layer(CPU and Inverter board dependence)
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 05.08.2022 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_smc_entry.h"
#include "r_app_board_ui_ctrl.h"
#include "r_motor_common.h"

/***********************************************************************************************************************
* Function Name : r_app_board_ui_get_vr1
* Description   : Get A/D converted value of VR1
* Arguments     : u1_id - Motor ID
* Return Value  : A/D converted value of VR1
***********************************************************************************************************************/
uint16_t r_app_board_ui_get_vr1(uint8_t u1_id)
{
    uint16_t ad_data = 0;

    switch (u1_id)
    {
        case MTR_ID_A:
            R_Config_S12AD2_Get_ValueResult(ADCHANNEL4, &ad_data);      /* Read from VR1 */
            break;

        case MTR_ID_B:
            R_Config_S12AD2_Get_ValueResult(ADCHANNEL3, &ad_data);      /* Read from VR2 */
            break;

        default:
            break;
    }

    return (ad_data);
} /* End of function r_app_board_ui_get_vr1 */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_get_sw1
* Description   : Get state of SW1
* Arguments     : u1_id - Motor ID
* Return Value  : State of SW1
***********************************************************************************************************************/
uint8_t r_app_board_ui_get_sw1(uint8_t u1_id)
{
    uint8_t tmp_port;

    tmp_port = R_Config_PORT_GetSW1(u1_id);

    return (tmp_port);
} /* End of function r_app_board_ui_get_sw1 */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_get_sw2
* Description   : Get state of SW2
* Arguments     : u1_id - Motor ID
* Return Value  : State of SW2
***********************************************************************************************************************/
uint8_t r_app_board_ui_get_sw2(uint8_t u1_id)
{
    uint8_t tmp_port;

    tmp_port = R_Config_PORT_GetSW2(u1_id);

    return (tmp_port);
} /* End of function r_app_board_ui_get_sw2 */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_led1_on
* Description   : Turn on LED1
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void r_app_board_ui_led1_on(uint8_t u1_id)
{
    R_Config_PORT_Led1_on(u1_id);
} /* End of function r_app_board_ui_led1_on */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_led2_on
* Description   : Turn on LED2
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void r_app_board_ui_led2_on(uint8_t u1_id)
{
    R_Config_PORT_Led2_on(u1_id);
} /* End of function r_app_board_ui_led2_on */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_led1_off
* Description   : Turn off LED1
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void r_app_board_ui_led1_off(uint8_t u1_id)
{
    R_Config_PORT_Led1_off(u1_id);
} /* End of function r_app_board_ui_led1_off */

/***********************************************************************************************************************
* Function Name : r_app_board_ui_led2_off
* Description   : Turn off LED2
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void r_app_board_ui_led2_off(uint8_t u1_id)
{
    R_Config_PORT_Led2_off(u1_id);
} /* End of function r_app_board_ui_led2_off */
