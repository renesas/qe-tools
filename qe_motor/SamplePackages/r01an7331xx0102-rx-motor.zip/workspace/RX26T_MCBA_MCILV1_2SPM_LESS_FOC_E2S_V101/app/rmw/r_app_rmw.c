/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_app_rmw.c
* Description : Processes of a user interface (tool)
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 30.10.2021 1.00
*         : 12.05.2022 1.10
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <machine.h>

/* Main associated header file */
#include "r_app_rmw.h"
#include "r_app_main.h"
#include "r_app_board_ui_ctrl.h"
#include "r_motor_module_cfg.h"
#include "r_motor_sensorless_vector_api.h"

/***********************************************************************************************************************
* Global variables
***********************************************************************************************************************/
uint16_t    g_u2_conf_hw   = 0x0008;        /* 0000000000001000b */
uint16_t    g_u2_conf_sw   = 0x0000;        /* 0000000000000000b */
uint16_t    g_u2_conf_tool = 0x0200;        /* 0000001000000000b */
uint8_t     gui_u1_active_gui;
uint16_t    g_u2_conf_sw_ver;

/***********************************************************************************************************************
* Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
/* Motor A */
st_rmw_param_buffer_t   g_st_rmw_input_buffer_a; /* Structure for ICS input */
uint8_t     g_u1_update_param_flag_a = 0;        /* Update commands and configurations flag */

/* Operation variables */
uint8_t     com_u1_system_mode_a;           /* System mode */
uint8_t     g_u1_system_mode_a;             /* System mode */
uint8_t     com_u1_enable_write_a;          /* ICS write enable flag */
uint8_t     g_u1_enable_write_a;            /* ICS write enable flag */
uint8_t     com_u1_sw_userif_a;             /* User interface switch */
uint8_t     g_u1_sw_userif_a;               /* User interface switch */

/* Offset parameters */
uint16_t    com_u2_offset_calc_time_a;      /* current offset calculation time */

/* Motor parameters */
uint16_t    com_u2_mtr_pp_a;                /* pole pairs */
float       com_f4_mtr_r_a;                 /* resistance [ohm] */
float       com_f4_mtr_ld_a;                /* d-axis inductance [H] */
float       com_f4_mtr_lq_a;                /* q-axis inductance [H] */
float       com_f4_mtr_m_a;                 /* permanent magnetic flux [Wb] */
float       com_f4_mtr_j_a;                 /* rotor inertia [kgm^2] */
float       com_f4_nominal_current_rms_a;   /* The nominal current[Arms] */
float       com_f4_max_speed_rpm_a;         /* maximum speed [rpm] (mechanical) */

/* Sensorless parameter */
uint8_t     com_u1_ctrl_loop_mode_a;        /* loop mode select */
float       com_f4_ol_ref_id_a;             /* id reference when open loop [A] */
float       com_f4_id_up_time_a;            /* time to increase id */
float       com_f4_id_down_time_a;          /* time to decrease id */
float       com_f4_id_down_speed_rpm_a;     /* The speed threshold[rpm] to ramp down the d-axis current */
float       com_f4_id_up_speed_rpm_a;       /* The speed threshold[rpm] to ramp up the d-axis current */
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
int16_t     com_s2_difference_minimum_a;    /* Minimum difference of PWM duty */
int16_t     com_s2_adjust_adc_delay_a;      /* Adjustment delay for A/D conversion */
#endif
float       com_f4_ctrl_period_a;
float       com_f4_speed_ctrl_period_a;

/* Control parameters */
/* Current control */
float       com_f4_current_omega_hz_a;      /* natural frequency for current loop [Hz] */
float       com_f4_current_zeta_a;          /* damping ratio for current loop */

/* Speed control */
float       com_f4_speed_omega_hz_a;        /* natural frequency for speed loop [Hz] */
float       com_f4_speed_zeta_a;            /* damping ratio for speed loop */
float       com_f4_speed_lpf_hz_a;          /* Natural frequency for speed LPF [Hz] */
float       com_f4_ref_speed_rpm_a;         /* motor speed reference [rpm] (mechanical) */
float       com_f4_speed_rate_limit_rpm_a;  /* limit of speed change [rpm/s] */
float       com_f4_overspeed_limit_rpm_a;   /* over speed limit [rpm] (mechanical) */

/* Optional functions */
/* Voltage error compensation */
uint8_t     com_u1_flag_volt_err_comp_use_a;/* Flags whether use voltage error compensation */

/* Flux-weakening control */
uint8_t     com_u1_flag_fluxwkn_use_a;      /* Flags whether use flux-weakening */

/* BEMF observer */
float       com_f4_e_obs_omega_hz_a;        /* Natural frequency for BEMF observer [Hz] */
float       com_f4_e_obs_zeta_a;            /* Damping ratio for BEMF observer */
float       com_f4_pll_est_omega_hz_a;      /* Natural frequency for rotor position Phase-Locked Loop [Hz] */
float       com_f4_pll_est_zeta_a;          /* Damping ratio for rotor position Phase-Locked Loop */

/* Sensor-less switch control */
uint8_t     com_u1_flag_less_switch_use_a;  /* Flags whether use sensor-less switch control*/
float       com_f4_switch_phase_err_deg_a;  /* Phase error to decide sensor-less switch timing [deg] */
float       com_f4_opl2less_sw_time_a;      /* Time to switch open-loop to sensor-less [s] */
float       com_f4_phase_err_lpf_cut_freq_a;/* Cut off frequency[Hz] of phase error LPF */

/* Open-loop damping control */
uint8_t     com_u1_flag_openloop_damping_use_a; /* Flags whether use open-loop damping control */
float       com_f4_ed_hpf_omega_a;              /* HPF cutoff frequency for ed [Hz] */
float       com_f4_ol_damping_zeta_a;           /* Damping ratio of open-loop damping control */
float       com_f4_ol_damping_fb_limit_rate_a;  /* Rate of reference speed for feedback speed limiter */

/* Motor B */
st_rmw_param_buffer_t   g_st_rmw_input_buffer_b; /* Structure for ICS input */
uint8_t     g_u1_update_param_flag_b = 0;        /* Update commands and configurations flag */

/* Operation variables */
uint8_t     com_u1_system_mode_b;           /* System mode */
uint8_t     g_u1_system_mode_b;             /* System mode */
uint8_t     com_u1_enable_write_b;          /* ICS write enable flag */
uint8_t     g_u1_enable_write_b;            /* ICS write enable flag */
uint8_t     com_u1_sw_userif_b;             /* User interface switch */
uint8_t     g_u1_sw_userif_b;               /* User interface switch */

/* Offset parameters */
uint16_t    com_u2_offset_calc_time_b;      /* current offset calculation time */

/* Motor parameters */
uint16_t    com_u2_mtr_pp_b;                /* pole pairs */
float       com_f4_mtr_r_b;                 /* resistance [ohm] */
float       com_f4_mtr_ld_b;                /* d-axis inductance [H] */
float       com_f4_mtr_lq_b;                /* q-axis inductance [H] */
float       com_f4_mtr_m_b;                 /* permanent magnetic flux [Wb] */
float       com_f4_mtr_j_b;                 /* rotor inertia [kgm^2] */
float       com_f4_nominal_current_rms_b;   /* The nominal current[Arms] */
float       com_f4_max_speed_rpm_b;         /* maximum speed [rpm] (mechanical) */

/* Sensorless parameter */
uint8_t     com_u1_ctrl_loop_mode_b;        /* loop mode select */
float       com_f4_ol_ref_id_b;             /* id reference when open loop [A] */
float       com_f4_id_up_time_b;            /* time to increase id */
float       com_f4_id_down_time_b;          /* time to decrease id */
float       com_f4_id_down_speed_rpm_b;     /* The speed threshold[rpm] to ramp down the d-axis current */
float       com_f4_id_up_speed_rpm_b;       /* The speed threshold[rpm] to ramp up the d-axis current */
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
int16_t     com_s2_difference_minimum_b;    /* Minimum difference of PWM duty */
int16_t     com_s2_adjust_adc_delay_b;      /* Adjustment delay for A/D conversion */
#endif
float       com_f4_ctrl_period_b;
float       com_f4_speed_ctrl_period_b;

/* Control parameters */
/* Current control */
float       com_f4_current_omega_hz_b;      /* natural frequency for current loop [Hz] */
float       com_f4_current_zeta_b;          /* damping ratio for current loop */

/* Speed control */
float       com_f4_speed_omega_hz_b;        /* natural frequency for speed loop [Hz] */
float       com_f4_speed_zeta_b;            /* damping ratio for speed loop */
float       com_f4_speed_lpf_hz_b;          /* Natural frequency for speed LPF [Hz] */
float       com_f4_ref_speed_rpm_b;         /* motor speed reference [rpm] (mechanical) */
float       com_f4_speed_rate_limit_rpm_b;  /* limit of speed change [rpm/s] */
float       com_f4_overspeed_limit_rpm_b;   /* over speed limit [rpm] (mechanical) */

/* Optional functions */
/* Voltage error compensation */
uint8_t     com_u1_flag_volt_err_comp_use_b;/* Flags whether use voltage error compensation */

/* Flux-weakening control */
uint8_t     com_u1_flag_fluxwkn_use_b;      /* Flags whether use flux-weakening */

/* BEMF observer */
float       com_f4_e_obs_omega_hz_b;        /* Natural frequency for BEMF observer [Hz] */
float       com_f4_e_obs_zeta_b;            /* Damping ratio for BEMF observer */
float       com_f4_pll_est_omega_hz_b;      /* Natural frequency for rotor position Phase-Locked Loop [Hz] */
float       com_f4_pll_est_zeta_b;          /* Damping ratio for rotor position Phase-Locked Loop */

/* Sensor-less switch control */
uint8_t     com_u1_flag_less_switch_use_b;  /* Flags whether use sensor-less switch control*/
float       com_f4_switch_phase_err_deg_b;  /* Phase error to decide sensor-less switch timing [deg] */
float       com_f4_opl2less_sw_time_b;      /* Time to switch open-loop to sensor-less [s] */
float       com_f4_phase_err_lpf_cut_freq_b;/* Cut off frequency[Hz] of phase error LPF */

/* Open-loop damping control */
uint8_t     com_u1_flag_openloop_damping_use_b; /* Flags whether use open-loop damping control */
float       com_f4_ed_hpf_omega_b;              /* HPF cutoff frequency for ed [Hz] */
float       com_f4_ol_damping_zeta_b;           /* Damping ratio of open-loop damping control */
float       com_f4_ol_damping_fb_limit_rate_b;  /* Rate of reference speed for feedback speed limiter */

/***********************************************************************************************************************
 Private global variables and functions
 **********************************************************************************************************************/
static uint8_t  s_u1_cnt_ics = 0;           /* Counter for period of calling "scope_watchpoint" */
static void r_app_rmw_system_mode(void);
static void r_app_rmw_check_com_input(void);
static void r_app_rmw_update_params(st_rmw_param_buffer_t *p_st_rmw_input, st_sensorless_vector_control_t *p_st_sensorless);
static void r_app_rmw_update_command(st_sensorless_vector_control_t *p_st_sensorless, float f4_ref_speed_rpm);

/***********************************************************************************************************************
* Function Name : r_app_rmw_ui_init
* Description   : Initialize variables for Analyzer interface
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_ui_init(uint8_t u1_id)
{
    switch (u1_id)
    {
        case MTR_ID_A:
            /* Operation variables */
            com_u1_system_mode_a  = STATEMACHINE_EVENT_STOP;
            g_u1_system_mode_a    = STATEMACHINE_EVENT_STOP;
            com_u1_enable_write_a = 0;
            g_u1_enable_write_a   = 0;
            com_u1_sw_userif_a    = APP_CFG_USE_UI_A;
            g_u1_sw_userif_a      = APP_CFG_USE_UI_A;

            /* Offset parameters */
            com_u2_offset_calc_time_a = CURRENT_CFG_OFFSET_CALC_TIME_A;

            /* Motor parameters */
            com_u2_mtr_pp_a              = MOTOR_CFG_POLE_PAIRS_A;
            com_f4_mtr_r_a               = MOTOR_CFG_RESISTANCE_A;
            com_f4_mtr_ld_a              = MOTOR_CFG_D_INDUCTANCE_A;
            com_f4_mtr_lq_a              = MOTOR_CFG_Q_INDUCTANCE_A;
            com_f4_mtr_m_a               = MOTOR_CFG_MAGNETIC_FLUX_A;
            com_f4_mtr_j_a               = MOTOR_CFG_ROTOR_INERTIA_A;
            com_f4_nominal_current_rms_a = MOTOR_CFG_NOMINAL_CURRENT_RMS_A;
            com_f4_max_speed_rpm_a       = MOTOR_CFG_MAX_SPEED_RPM_A;

            /* Sensorless parameter */
            com_u1_ctrl_loop_mode_a    = MOTOR_COMMON_CFG_LOOP_MODE_A;
            com_f4_ol_ref_id_a         = CURRENT_CFG_REF_ID_OPENLOOP_A;
            com_f4_id_up_time_a        = CURRENT_CFG_ID_UP_STEP_TIME_A;
            com_f4_id_down_time_a      = CURRENT_CFG_ID_DOWN_STEP_TIME_A;
            com_f4_id_down_speed_rpm_a = SENSORLESS_VECTOR_ID_DOWN_SPEED_RPM_A;
            com_f4_id_up_speed_rpm_a   = SENSORLESS_VECTOR_ID_UP_SPEED_RPM_A;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
            com_s2_difference_minimum_a = CURRENT_CFG_MIN_DIFFERENCE_DUTY_A;
            com_s2_adjust_adc_delay_a   = CURRENT_CFG_ADJUST_ADC_DELAY_A;
#endif
            com_f4_ctrl_period_a        = MOTOR_COMMON_CTRL_PERIOD_A;
            com_f4_speed_ctrl_period_a  = SPEED_CFG_CTRL_PERIOD_A;

            /* Control parameters */
            /* Current control */
            com_f4_current_omega_hz_a = CURRENT_CFG_OMEGA_A;
            com_f4_current_zeta_a     = CURRENT_CFG_ZETA_A;

            /* Speed control */
            com_f4_speed_omega_hz_a       = SPEED_CFG_OMEGA_A;
            com_f4_speed_zeta_a           = SPEED_CFG_ZETA_A;
            com_f4_speed_lpf_hz_a         = SPEED_CFG_LPF_OMEGA_A;
            com_f4_ref_speed_rpm_a        = 0.0f;
            com_f4_speed_rate_limit_rpm_a = SPEED_CFG_RATE_LIMIT_RPM_A;
            com_f4_overspeed_limit_rpm_a  = SPEED_CFG_SPEED_LIMIT_RPM_A;

            /* Optional functions */
            /* Voltage error compensation */
            com_u1_flag_volt_err_comp_use_a = CURRENT_CFG_VOLT_ERR_COMP_A;

            /* Flux-weakening control */
            com_u1_flag_fluxwkn_use_a = SPEED_CFG_FLUX_WEAKENING_A;

            /* BEMF observer */
            com_f4_e_obs_omega_hz_a   = CURRENT_CFG_E_OBS_OMEGA_A;
            com_f4_e_obs_zeta_a       = CURRENT_CFG_E_OBS_ZETA_A;
            com_f4_pll_est_omega_hz_a = CURRENT_CFG_PLL_EST_OMEGA_A;
            com_f4_pll_est_zeta_a     = CURRENT_CFG_PLL_EST_ZETA_A;

            /* Sensor-less switch control */
            com_u1_flag_less_switch_use_a   = SPEED_CFG_LESS_SWITCH_A;
            com_f4_switch_phase_err_deg_a   = SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_DEG_A;
            com_f4_opl2less_sw_time_a       = SPEED_OPL2LESS_SWITCH_TIME_A;
            com_f4_phase_err_lpf_cut_freq_a = SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_LPF_CUT_FREQ_A;

            /* Open-loop damping control */
            com_u1_flag_openloop_damping_use_a = SPEED_CFG_OPENLOOP_DAMPING_A;
            com_f4_ed_hpf_omega_a              = SPEED_OPL_DAMP_ED_HPF_OMEGA_A;
            com_f4_ol_damping_zeta_a           = SPEED_OPL_DAMP_ZETA_A;
            com_f4_ol_damping_fb_limit_rate_a  = SPEED_OPL_DAMP_FB_SPEED_LIMIT_RATE_A;

            break;

        case MTR_ID_B:
            /* Operation variables */
            com_u1_system_mode_b  = STATEMACHINE_EVENT_STOP;
            g_u1_system_mode_b    = STATEMACHINE_EVENT_STOP;
            com_u1_enable_write_b = 0;
            g_u1_enable_write_b   = 0;
            com_u1_sw_userif_b    = APP_CFG_USE_UI_B;
            g_u1_sw_userif_b      = APP_CFG_USE_UI_B;

            /* Offset parameters */
            com_u2_offset_calc_time_b = CURRENT_CFG_OFFSET_CALC_TIME_B;

            /* Motor parameters */
            com_u2_mtr_pp_b              = MOTOR_CFG_POLE_PAIRS_B;
            com_f4_mtr_r_b               = MOTOR_CFG_RESISTANCE_B;
            com_f4_mtr_ld_b              = MOTOR_CFG_D_INDUCTANCE_B;
            com_f4_mtr_lq_b              = MOTOR_CFG_Q_INDUCTANCE_B;
            com_f4_mtr_m_b               = MOTOR_CFG_MAGNETIC_FLUX_B;
            com_f4_mtr_j_b               = MOTOR_CFG_ROTOR_INERTIA_B;
            com_f4_nominal_current_rms_b = MOTOR_CFG_NOMINAL_CURRENT_RMS_B;
            com_f4_max_speed_rpm_b       = MOTOR_CFG_MAX_SPEED_RPM_B;

            /* Sensorless parameter */
            com_u1_ctrl_loop_mode_b    = MOTOR_COMMON_CFG_LOOP_MODE_B;
            com_f4_ol_ref_id_b         = CURRENT_CFG_REF_ID_OPENLOOP_B;
            com_f4_id_up_time_b        = CURRENT_CFG_ID_UP_STEP_TIME_B;
            com_f4_id_down_time_b      = CURRENT_CFG_ID_DOWN_STEP_TIME_B;
            com_f4_id_down_speed_rpm_b = SENSORLESS_VECTOR_ID_DOWN_SPEED_RPM_B;
            com_f4_id_up_speed_rpm_b   = SENSORLESS_VECTOR_ID_UP_SPEED_RPM_B;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
            com_s2_difference_minimum_b = CURRENT_CFG_MIN_DIFFERENCE_DUTY_B;
            com_s2_adjust_adc_delay_b   = CURRENT_CFG_ADJUST_ADC_DELAY_B;
#endif
            com_f4_ctrl_period_b        = MOTOR_COMMON_CTRL_PERIOD_B;
            com_f4_speed_ctrl_period_b  = SPEED_CFG_CTRL_PERIOD_B;

            /* Control parameters */
            /* Current control */
            com_f4_current_omega_hz_b = CURRENT_CFG_OMEGA_B;
            com_f4_current_zeta_b     = CURRENT_CFG_ZETA_B;

            /* Speed control */
            com_f4_speed_omega_hz_b       = SPEED_CFG_OMEGA_B;
            com_f4_speed_zeta_b           = SPEED_CFG_ZETA_B;
            com_f4_speed_lpf_hz_b         = SPEED_CFG_LPF_OMEGA_B;
            com_f4_ref_speed_rpm_b        = 0.0f;
            com_f4_speed_rate_limit_rpm_b = SPEED_CFG_RATE_LIMIT_RPM_B;
            com_f4_overspeed_limit_rpm_b  = SPEED_CFG_SPEED_LIMIT_RPM_B;

            /* Optional functions */
            /* Voltage error compensation */
            com_u1_flag_volt_err_comp_use_b = CURRENT_CFG_VOLT_ERR_COMP_B;

            /* Flux-weakening control */
            com_u1_flag_fluxwkn_use_b = SPEED_CFG_FLUX_WEAKENING_B;

            /* BEMF observer */
            com_f4_e_obs_omega_hz_b   = CURRENT_CFG_E_OBS_OMEGA_B;
            com_f4_e_obs_zeta_b       = CURRENT_CFG_E_OBS_ZETA_B;
            com_f4_pll_est_omega_hz_b = CURRENT_CFG_PLL_EST_OMEGA_B;
            com_f4_pll_est_zeta_b     = CURRENT_CFG_PLL_EST_ZETA_B;

            /* Sensor-less switch control */
            com_u1_flag_less_switch_use_b   = SPEED_CFG_LESS_SWITCH_B;
            com_f4_switch_phase_err_deg_b   = SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_DEG_B;
            com_f4_opl2less_sw_time_b       = SPEED_OPL2LESS_SWITCH_TIME_B;
            com_f4_phase_err_lpf_cut_freq_b = SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_LPF_CUT_FREQ_B;

            /* Open-loop damping control */
            com_u1_flag_openloop_damping_use_b = SPEED_CFG_OPENLOOP_DAMPING_B;
            com_f4_ed_hpf_omega_b              = SPEED_OPL_DAMP_ED_HPF_OMEGA_B;
            com_f4_ol_damping_zeta_b           = SPEED_OPL_DAMP_ZETA_B;
            com_f4_ol_damping_fb_limit_rate_b  = SPEED_OPL_DAMP_FB_SPEED_LIMIT_RATE_B;

            break;

        default:
            /* Do Nothing */
            break;
    }
} /* End of function r_app_rmw_ui_init */

/***********************************************************************************************************************
* Function Name : r_app_rmw_ui_mainloop
* Description   : RMW communication main-loop process
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_ui_mainloop(void)
{
    r_app_rmw_system_mode();
} /* End of function r_app_rmw_ui_mainloop */

/***********************************************************************************************************************
* Function Name : r_app_rmw_copy_com_to_buffer
* Description   : Set com variables to "tool" input buffer
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_copy_com_to_buffer(void)
{
    r_app_rmw_check_com_input();

    /***** When com_s2_enable_sw and g_u1_enable_write are same value, rewrite enable. *****/
    if (com_u1_enable_write_a == g_u1_enable_write_a)
    {
        /* Offset parameters */
        g_st_rmw_input_buffer_a.u2_offset_calc_time = com_u2_offset_calc_time_a;

        /* Motor parameters */
        g_st_rmw_input_buffer_a.st_motor.u2_mtr_pp              = com_u2_mtr_pp_a;
        g_st_rmw_input_buffer_a.st_motor.f4_mtr_r               = com_f4_mtr_r_a;
        g_st_rmw_input_buffer_a.st_motor.f4_mtr_ld              = com_f4_mtr_ld_a;
        g_st_rmw_input_buffer_a.st_motor.f4_mtr_lq              = com_f4_mtr_lq_a;
        g_st_rmw_input_buffer_a.st_motor.f4_mtr_m               = com_f4_mtr_m_a;
        g_st_rmw_input_buffer_a.st_motor.f4_mtr_j               = com_f4_mtr_j_a;
        g_st_rmw_input_buffer_a.st_motor.f4_nominal_current_rms = com_f4_nominal_current_rms_a;
        g_st_rmw_input_buffer_a.f4_max_speed_rpm                = com_f4_max_speed_rpm_a;

        /* Sensorless parameter */
        g_st_rmw_input_buffer_a.u1_ctrl_loop_mode    = com_u1_ctrl_loop_mode_a;
        g_st_rmw_input_buffer_a.f4_ol_ref_id         = com_f4_ol_ref_id_a;
        g_st_rmw_input_buffer_a.f4_id_up_time        = com_f4_id_up_time_a;
        g_st_rmw_input_buffer_a.f4_id_down_time      = com_f4_id_down_time_a;
        g_st_rmw_input_buffer_a.f4_id_down_speed_rpm = com_f4_id_down_speed_rpm_a;
        g_st_rmw_input_buffer_a.f4_id_up_speed_rpm   = com_f4_id_up_speed_rpm_a;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
        g_st_rmw_input_buffer_a.s2_difference_minimum = com_s2_difference_minimum_a;
        g_st_rmw_input_buffer_a.s2_adjust_adc_delay   = com_s2_adjust_adc_delay_a;
#endif
        g_st_rmw_input_buffer_a.f4_ctrl_period       = com_f4_ctrl_period_a;
        g_st_rmw_input_buffer_a.f4_speed_ctrl_period = com_f4_speed_ctrl_period_a;

        /* Control parameters */
        /* Current control */
        g_st_rmw_input_buffer_a.f4_current_omega_hz = com_f4_current_omega_hz_a;
        g_st_rmw_input_buffer_a.f4_current_zeta     = com_f4_current_zeta_a;

        /* Speed control */
        g_st_rmw_input_buffer_a.f4_speed_omega_hz       = com_f4_speed_omega_hz_a;
        g_st_rmw_input_buffer_a.f4_speed_zeta           = com_f4_speed_zeta_a;
        g_st_rmw_input_buffer_a.f4_speed_lpf_hz         = com_f4_speed_lpf_hz_a;
        g_st_rmw_input_buffer_a.f4_ref_speed_rpm        = com_f4_ref_speed_rpm_a;
        g_st_rmw_input_buffer_a.f4_speed_rate_limit_rpm = com_f4_speed_rate_limit_rpm_a;
        g_st_rmw_input_buffer_a.f4_overspeed_limit_rpm  = com_f4_overspeed_limit_rpm_a;

        /* Optional functions */
        /* Voltage error compensation */
        g_st_rmw_input_buffer_a.u1_flag_volt_err_comp_use = com_u1_flag_volt_err_comp_use_a;

        /* Flux-weakening control */
        g_st_rmw_input_buffer_a.u1_flag_fluxwkn_use = com_u1_flag_fluxwkn_use_a;

        /* BEMF observer */
        g_st_rmw_input_buffer_a.f4_e_obs_omega_hz   = com_f4_e_obs_omega_hz_a;
        g_st_rmw_input_buffer_a.f4_e_obs_zeta       = com_f4_e_obs_zeta_a;
        g_st_rmw_input_buffer_a.f4_pll_est_omega_hz = com_f4_pll_est_omega_hz_a;
        g_st_rmw_input_buffer_a.f4_pll_est_zeta     = com_f4_pll_est_zeta_a;

        /* Sensor-less switch control */
        g_st_rmw_input_buffer_a.u1_flag_less_switch_use   = com_u1_flag_less_switch_use_a;
        g_st_rmw_input_buffer_a.f4_switch_phase_err_deg   = com_f4_switch_phase_err_deg_a;
        g_st_rmw_input_buffer_a.f4_opl2less_sw_time       = com_f4_opl2less_sw_time_a;
        g_st_rmw_input_buffer_a.f4_phase_err_lpf_cut_freq = com_f4_phase_err_lpf_cut_freq_a;

        /* Open-loop damping control */
        g_st_rmw_input_buffer_a.u1_flag_openloop_damping_use = com_u1_flag_openloop_damping_use_a;
        g_st_rmw_input_buffer_a.f4_ed_hpf_omega              = com_f4_ed_hpf_omega_a;
        g_st_rmw_input_buffer_a.f4_ol_damping_zeta           = com_f4_ol_damping_zeta_a;
        g_st_rmw_input_buffer_a.f4_ol_damping_fb_limit_rate  = com_f4_ol_damping_fb_limit_rate_a;

        /* copy variables com to ICS input */
        g_u1_update_param_flag_a = 1;
        g_u1_enable_write_a     ^= 1;                   /* change every time 0 and 1 */
    }

    /***** When com_s2_enable_sw and g_u1_enable_write are same value, rewrite enable. *****/
    if (com_u1_enable_write_b == g_u1_enable_write_b)
    {
        /* Offset parameters */
        g_st_rmw_input_buffer_b.u2_offset_calc_time = com_u2_offset_calc_time_b;

        /* Motor parameters */
        g_st_rmw_input_buffer_b.st_motor.u2_mtr_pp              = com_u2_mtr_pp_b;
        g_st_rmw_input_buffer_b.st_motor.f4_mtr_r               = com_f4_mtr_r_b;
        g_st_rmw_input_buffer_b.st_motor.f4_mtr_ld              = com_f4_mtr_ld_b;
        g_st_rmw_input_buffer_b.st_motor.f4_mtr_lq              = com_f4_mtr_lq_b;
        g_st_rmw_input_buffer_b.st_motor.f4_mtr_m               = com_f4_mtr_m_b;
        g_st_rmw_input_buffer_b.st_motor.f4_mtr_j               = com_f4_mtr_j_b;
        g_st_rmw_input_buffer_b.st_motor.f4_nominal_current_rms = com_f4_nominal_current_rms_b;
        g_st_rmw_input_buffer_b.f4_max_speed_rpm                = com_f4_max_speed_rpm_b;

        /* Sensorless parameter */
        g_st_rmw_input_buffer_b.u1_ctrl_loop_mode    = com_u1_ctrl_loop_mode_b;
        g_st_rmw_input_buffer_b.f4_ol_ref_id         = com_f4_ol_ref_id_b;
        g_st_rmw_input_buffer_b.f4_id_up_time        = com_f4_id_up_time_b;
        g_st_rmw_input_buffer_b.f4_id_down_time      = com_f4_id_down_time_b;
        g_st_rmw_input_buffer_b.f4_id_down_speed_rpm = com_f4_id_down_speed_rpm_b;
        g_st_rmw_input_buffer_b.f4_id_up_speed_rpm   = com_f4_id_up_speed_rpm_b;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
        g_st_rmw_input_buffer_b.s2_difference_minimum = com_s2_difference_minimum_b;
        g_st_rmw_input_buffer_b.s2_adjust_adc_delay   = com_s2_adjust_adc_delay_b;
#endif
        g_st_rmw_input_buffer_b.f4_ctrl_period       = com_f4_ctrl_period_b;
        g_st_rmw_input_buffer_b.f4_speed_ctrl_period = com_f4_speed_ctrl_period_b;

        /* Control parameters */
        /* Current control */
        g_st_rmw_input_buffer_b.f4_current_omega_hz = com_f4_current_omega_hz_b;
        g_st_rmw_input_buffer_b.f4_current_zeta     = com_f4_current_zeta_b;

        /* Speed control */
        g_st_rmw_input_buffer_b.f4_speed_omega_hz       = com_f4_speed_omega_hz_b;
        g_st_rmw_input_buffer_b.f4_speed_zeta           = com_f4_speed_zeta_b;
        g_st_rmw_input_buffer_b.f4_speed_lpf_hz         = com_f4_speed_lpf_hz_b;
        g_st_rmw_input_buffer_b.f4_ref_speed_rpm        = com_f4_ref_speed_rpm_b;
        g_st_rmw_input_buffer_b.f4_speed_rate_limit_rpm = com_f4_speed_rate_limit_rpm_b;
        g_st_rmw_input_buffer_b.f4_overspeed_limit_rpm  = com_f4_overspeed_limit_rpm_b;

        /* Optional functions */
        /* Voltage error compensation */
        g_st_rmw_input_buffer_b.u1_flag_volt_err_comp_use = com_u1_flag_volt_err_comp_use_b;

        /* Flux-weakening control */
        g_st_rmw_input_buffer_b.u1_flag_fluxwkn_use = com_u1_flag_fluxwkn_use_b;

        /* BEMF observer */
        g_st_rmw_input_buffer_b.f4_e_obs_omega_hz   = com_f4_e_obs_omega_hz_b;
        g_st_rmw_input_buffer_b.f4_e_obs_zeta       = com_f4_e_obs_zeta_b;
        g_st_rmw_input_buffer_b.f4_pll_est_omega_hz = com_f4_pll_est_omega_hz_b;
        g_st_rmw_input_buffer_b.f4_pll_est_zeta     = com_f4_pll_est_zeta_b;

        /* Sensor-less switch control */
        g_st_rmw_input_buffer_b.u1_flag_less_switch_use   = com_u1_flag_less_switch_use_b;
        g_st_rmw_input_buffer_b.f4_switch_phase_err_deg   = com_f4_switch_phase_err_deg_b;
        g_st_rmw_input_buffer_b.f4_opl2less_sw_time       = com_f4_opl2less_sw_time_b;
        g_st_rmw_input_buffer_b.f4_phase_err_lpf_cut_freq = com_f4_phase_err_lpf_cut_freq_b;

        /* Open-loop damping control */
        g_st_rmw_input_buffer_b.u1_flag_openloop_damping_use = com_u1_flag_openloop_damping_use_b;
        g_st_rmw_input_buffer_b.f4_ed_hpf_omega              = com_f4_ed_hpf_omega_b;
        g_st_rmw_input_buffer_b.f4_ol_damping_zeta           = com_f4_ol_damping_zeta_b;
        g_st_rmw_input_buffer_b.f4_ol_damping_fb_limit_rate  = com_f4_ol_damping_fb_limit_rate_b;

        /* copy variables com to ICS input */
        g_u1_update_param_flag_b = 1;
        g_u1_enable_write_b     ^= 1;                   /* change every time 0 and 1 */
    }
} /* End of function r_app_rmw_copy_com_to_buffer */

/***********************************************************************************************************************
* Function Name : r_app_rmw_interrupt_handler
* Description   : Process for ICS(Analyzer)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_interrupt_handler(void)
{
    s_u1_cnt_ics++;

    /* Decimation of ICS call */
    if (ICS_DECIMATION < s_u1_cnt_ics)
    {
        s_u1_cnt_ics = 0;

        /* Call ICS */
        ics2_watchpoint();
    }

    /* Update commands and configurations when trigger flag is set */
    if (1 == g_u1_update_param_flag_a)
    {
        r_app_rmw_update_params(&g_st_rmw_input_buffer_a, &g_st_sensorless_vector_a);
        g_u1_update_param_flag_a = 0;
    }
    else
    {
        if (MAIN_UI_RMW == g_u1_sw_userif_a)
        {
            r_app_rmw_update_command(&g_st_sensorless_vector_a, com_f4_ref_speed_rpm_a);
        }
    }

    if (1 == g_u1_update_param_flag_b)
    {
        r_app_rmw_update_params(&g_st_rmw_input_buffer_b, &g_st_sensorless_vector_b);
        g_u1_update_param_flag_b = 0;
    }
    else
    {
        if (MAIN_UI_RMW == g_u1_sw_userif_b)
        {
            r_app_rmw_update_command(&g_st_sensorless_vector_b, com_f4_ref_speed_rpm_b);
        }
    }
} /* End of function r_app_rmw_interrupt_handler */

/**********************************************************************************************************************
* Function Name : r_app_rmw_system_mode
* Description   : Process system mode command
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_rmw_system_mode(void)
{
    uint8_t u1_temp;
    uint8_t u1_motor_status;

    /*============================*/
    /*        Execute event       */
    /*============================*/
    /* **** Motor A **** */
    u1_temp = com_u1_system_mode_a;

    if (g_u1_system_mode_a != u1_temp)
    {
        if (u1_temp >= STATEMACHINE_EVENT_SIZE)
        {
            com_u1_system_mode_a = g_u1_system_mode_a;
        }
        else
        {
            g_u1_system_mode_a = u1_temp;
            switch (g_u1_system_mode_a)
            {
                case STATEMACHINE_EVENT_STOP:
                    R_MOTOR_SENSORLESS_VECTOR_MotorStop(&g_st_sensorless_vector_a);
                break;

                case STATEMACHINE_EVENT_RUN:
                    R_MOTOR_SENSORLESS_VECTOR_MotorStart(&g_st_sensorless_vector_a);
                break;

                case STATEMACHINE_EVENT_RESET:
                    R_MOTOR_SENSORLESS_VECTOR_MotorReset(&g_st_sensorless_vector_a);
                break;

                default:
                    /* Do nothing */
                break;
            }
        }
    }

    u1_motor_status = R_MOTOR_SENSORLESS_VECTOR_StatusGet(&g_st_sensorless_vector_a);
                                                                        /* Get status of motor control system */

    if (STATEMACHINE_EVENT_RESET == g_u1_system_mode_a)
    {
        if (STATEMACHINE_STATE_STOP == u1_motor_status)
        {
            r_app_rmw_ui_init(MTR_ID_A);                    /* Initialize private global variables for reset event */
        }
        else if (STATEMACHINE_STATE_ERROR == u1_motor_status)
        {
            g_u1_system_mode_a   = STATEMACHINE_EVENT_ERROR;
            com_u1_system_mode_a = STATEMACHINE_EVENT_ERROR;
        }
        else
        {
            /* Do nothing */
        }
    }

    /* **** Motor B **** */
    u1_temp = com_u1_system_mode_b;

    if (g_u1_system_mode_b != u1_temp)
    {
        if (u1_temp >= STATEMACHINE_EVENT_SIZE)
        {
            com_u1_system_mode_b = g_u1_system_mode_b;
        }
        else
        {
            g_u1_system_mode_b = u1_temp;
            switch (g_u1_system_mode_b)
            {
                case STATEMACHINE_EVENT_STOP:
                    R_MOTOR_SENSORLESS_VECTOR_MotorStop(&g_st_sensorless_vector_b);
                break;

                case STATEMACHINE_EVENT_RUN:
                    R_MOTOR_SENSORLESS_VECTOR_MotorStart(&g_st_sensorless_vector_b);
                break;

                case STATEMACHINE_EVENT_RESET:
                    R_MOTOR_SENSORLESS_VECTOR_MotorReset(&g_st_sensorless_vector_b);
                break;

                default:
                    /* Do nothing */
                break;
            }
        }
    }

    u1_motor_status = R_MOTOR_SENSORLESS_VECTOR_StatusGet(&g_st_sensorless_vector_b);
                                                                        /* Get status of motor control system */

    if (STATEMACHINE_EVENT_RESET == g_u1_system_mode_b)
    {
        if (STATEMACHINE_STATE_STOP == u1_motor_status)
        {
            r_app_rmw_ui_init(MTR_ID_B);                    /* Initialize private global variables for reset event */
        }
        else if (STATEMACHINE_STATE_ERROR == u1_motor_status)
        {
            g_u1_system_mode_b   = STATEMACHINE_EVENT_ERROR;
            com_u1_system_mode_b = STATEMACHINE_EVENT_ERROR;
        }
        else
        {
            /* Do nothing */
        }
    }
} /* End of function r_app_rmw_system_mode */

/***********************************************************************************************************************
* Function Name : r_app_rmw_check_com_input
* Description   : Check com variables
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_rmw_check_com_input(void)
{
    float f4_temp0;

    /**************************/
    /*    limit variables     */
    /**************************/
    com_f4_ref_speed_rpm_a = motor_filter_limitf_abs(com_f4_ref_speed_rpm_a, com_f4_max_speed_rpm_a);

    /* current natural frequency limit 1Hz ~ 1000Hz */
    com_f4_current_omega_hz_a = motor_filter_limitf(com_f4_current_omega_hz_a,
                                                    APP_CFG_MAX_CURRENT_OMEGA_A,
                                                    APP_CFG_MIN_OMEGA_A);

    /* natural frequency & damping ratio for speed control loop */
    f4_temp0 = com_f4_current_omega_hz_a / APP_CFG_FREQ_BAND_LIMIT_A;
    if (f4_temp0 < com_f4_speed_omega_hz_a)
    {
        com_f4_speed_omega_hz_a = f4_temp0;

        /* speed natural frequency minimum limit 1Hz */
        com_f4_speed_omega_hz_a = motor_filter_lower_limitf(com_f4_speed_omega_hz_a, APP_CFG_MIN_OMEGA_A);
    }


    com_f4_ref_speed_rpm_b = motor_filter_limitf_abs(com_f4_ref_speed_rpm_b, com_f4_max_speed_rpm_b);

    /* current natural frequency limit 1Hz ~ 1000Hz */
    com_f4_current_omega_hz_b = motor_filter_limitf(com_f4_current_omega_hz_b,
                                                    APP_CFG_MAX_CURRENT_OMEGA_B,
                                                    APP_CFG_MIN_OMEGA_B);

    /* natural frequency & damping ratio for speed control loop */
    f4_temp0 = com_f4_current_omega_hz_b / APP_CFG_FREQ_BAND_LIMIT_B;
    if (f4_temp0 < com_f4_speed_omega_hz_b)
    {
        com_f4_speed_omega_hz_b = f4_temp0;

        /* speed natural frequency minimum limit 1Hz */
        com_f4_speed_omega_hz_b = motor_filter_lower_limitf(com_f4_speed_omega_hz_b, APP_CFG_MIN_OMEGA_B);
    }
} /* End of function r_app_rmw_check_com_input */

/**********************************************************************************************************************
 * Function Name: r_app_rmw_update_params
 * Description  : Apply parameters in buffer through API
 * Arguments    : None
 * Return Value : None
 *********************************************************************************************************************/
static void r_app_rmw_update_params(st_rmw_param_buffer_t *p_st_rmw_input,
                                        st_sensorless_vector_control_t *p_st_sensorless_vector)
{
    st_current_cfg_t           st_cur_cfg;
    st_bemf_observer_cfg_t     st_bemf_obs_cfg;
    st_speed_cfg_t             st_spd_cfg;
    st_sensorless_vector_cfg_t st_sensorless_vector_cfg;

    /* FOC configuration set */
    st_sensorless_vector_cfg.u1_flag_less_switch_use      = p_st_rmw_input->u1_flag_less_switch_use;
    st_sensorless_vector_cfg.u1_flag_openloop_damping_use = p_st_rmw_input->u1_flag_openloop_damping_use;
    st_sensorless_vector_cfg.f4_overspeed_limit_rpm       = p_st_rmw_input->f4_overspeed_limit_rpm;
    st_sensorless_vector_cfg.f4_switch_phase_err_deg      = p_st_rmw_input->f4_switch_phase_err_deg;
    st_sensorless_vector_cfg.f4_phase_err_lpf_cut_freq    = p_st_rmw_input->f4_phase_err_lpf_cut_freq;
    st_sensorless_vector_cfg.f4_id_down_speed_rpm         = p_st_rmw_input->f4_id_down_speed_rpm;
    st_sensorless_vector_cfg.f4_id_up_speed_rpm           = p_st_rmw_input->f4_id_up_speed_rpm;
    st_sensorless_vector_cfg.f4_ctrl_period               = p_st_rmw_input->f4_ctrl_period;
    st_sensorless_vector_cfg.st_motor                     = p_st_rmw_input->st_motor;
    R_MOTOR_SENSORLESS_VECTOR_ParameterUpdate(p_st_sensorless_vector, &st_sensorless_vector_cfg);

    /* Commands */
    R_MOTOR_SENSORLESS_VECTOR_CtrlTypeSet(p_st_sensorless_vector, p_st_rmw_input->u1_ctrl_loop_mode);
    R_MOTOR_SENSORLESS_VECTOR_SpeedSet(p_st_sensorless_vector, p_st_rmw_input->f4_ref_speed_rpm);

    /* Current configuration set */
    st_cur_cfg.u1_flag_volt_err_comp_use = p_st_rmw_input->u1_flag_volt_err_comp_use;
    st_cur_cfg.u2_offset_calc_time       = p_st_rmw_input->u2_offset_calc_time;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    st_cur_cfg.s2_difference_minimum     = p_st_rmw_input->s2_difference_minimum;
    st_cur_cfg.s2_adjust_adc_delay       = p_st_rmw_input->s2_adjust_adc_delay;
#endif
    st_cur_cfg.f4_ctrl_period            = p_st_rmw_input->f4_ctrl_period;
    st_cur_cfg.f4_current_omega_hz       = p_st_rmw_input->f4_current_omega_hz;
    st_cur_cfg.f4_current_zeta           = p_st_rmw_input->f4_current_zeta;
    st_cur_cfg.f4_id_up_step             = p_st_rmw_input->f4_ol_ref_id / p_st_rmw_input->f4_id_up_time;
    st_cur_cfg.f4_id_down_step           = p_st_rmw_input->f4_ol_ref_id / p_st_rmw_input->f4_id_down_time;
    st_cur_cfg.f4_iq_down_step_time_inv  = 1.0f / p_st_rmw_input->f4_id_up_time;
    st_cur_cfg.f4_ol_ref_id              = p_st_rmw_input->f4_ol_ref_id;
    st_cur_cfg.st_motor                  = p_st_rmw_input->st_motor;
    R_MOTOR_CURRENT_ParameterUpdate(p_st_sensorless_vector->p_st_cc, &st_cur_cfg);

    /* BEMF observer */
    st_bemf_obs_cfg.f4_e_obs_omega_hz   = p_st_rmw_input->f4_e_obs_omega_hz;
    st_bemf_obs_cfg.f4_e_obs_zeta       = p_st_rmw_input->f4_e_obs_zeta;
    st_bemf_obs_cfg.f4_pll_est_omega_hz = p_st_rmw_input->f4_pll_est_omega_hz;
    st_bemf_obs_cfg.f4_pll_est_zeta     = p_st_rmw_input->f4_pll_est_zeta;
    R_MOTOR_CURRENT_BEMFObserverParameterUpdate(p_st_sensorless_vector->p_st_cc, &st_bemf_obs_cfg);

    /* Speed configuration set */
    st_spd_cfg.u1_flag_fluxwkn_use         = p_st_rmw_input->u1_flag_fluxwkn_use;
    st_spd_cfg.f4_speed_ctrl_period        = p_st_rmw_input->f4_speed_ctrl_period;
    st_spd_cfg.f4_max_speed_rpm            = p_st_rmw_input->f4_max_speed_rpm;
    st_spd_cfg.f4_speed_rate_limit_rpm     = p_st_rmw_input->f4_speed_rate_limit_rpm;
    st_spd_cfg.f4_speed_omega_hz           = p_st_rmw_input->f4_speed_omega_hz;
    st_spd_cfg.f4_speed_zeta               = p_st_rmw_input->f4_speed_zeta;
    st_spd_cfg.f4_speed_lpf_hz             = p_st_rmw_input->f4_speed_lpf_hz;
    st_spd_cfg.f4_opl2less_sw_time         = p_st_rmw_input->f4_opl2less_sw_time;
    st_spd_cfg.f4_ed_hpf_omega             = p_st_rmw_input->f4_ed_hpf_omega;
    st_spd_cfg.f4_ol_damping_zeta          = p_st_rmw_input->f4_ol_damping_zeta;
    st_spd_cfg.f4_ol_damping_fb_limit_rate = p_st_rmw_input->f4_ol_damping_fb_limit_rate;
    st_spd_cfg.f4_ol_ref_id                = p_st_rmw_input->f4_ol_ref_id;
    st_spd_cfg.f4_id_down_speed_rpm        = p_st_rmw_input->f4_id_down_speed_rpm;
    st_spd_cfg.st_motor                    = p_st_rmw_input->st_motor;
    R_MOTOR_SPEED_ParameterUpdate(p_st_sensorless_vector->p_st_sc, &st_spd_cfg);
} /* End of function r_app_rmw_update_params */

/***********************************************************************************************************************
* Function Name : r_app_rmw_update_command
* Description   : Update commands without copying to buffer or update trigger
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_rmw_update_command(st_sensorless_vector_control_t *p_st_sensorless, float f4_ref_speed_rpm)
{
    if (MOTOR_LOOP_SPEED == p_st_sensorless->u1_ctrl_loop_mode)
    {
        R_MOTOR_SENSORLESS_VECTOR_SpeedSet(p_st_sensorless, f4_ref_speed_rpm);
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function r_app_rmw_update_command */
