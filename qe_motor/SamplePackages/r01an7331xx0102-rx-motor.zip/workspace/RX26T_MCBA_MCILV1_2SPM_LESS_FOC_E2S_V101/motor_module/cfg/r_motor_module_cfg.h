/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_motor_module_cfg.h
* Description  : Compile-time configurations
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 30.10.2021 1.00
*         : 12.05.2022 1.10
*         : 05.08.2022 1.20
*         : 31.01.2023 1.30
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MOTOR_MODULE_CFG_H
#define R_MOTOR_MODULE_CFG_H

#include "r_motor_common.h"
#include "r_motor_targetmotor_cfg.h"
#include "r_motor_inverter_cfg.h"
#include "r_smc_entry.h"

/* RMW output files */
#include "r_mtr_control_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/**
 * Middle ware Layer Configurations
 */

/*#define MOTOR_SHUNT_TYPE_1_SHUNT*/  /* Only use V phase current */
#define MOTOR_SHUNT_TYPE_2_SHUNT      /* Use U and W phase current */

/*
 * Software system configurations
 */
/* Motor A */
/*
 * for MCU
 */
#define     MOTOR_MCU_CFG_PWM_TIMER_FREQ_A      (CG_CONFIG_MOTOR_A_PWM_TIMER_FREQ)  /* PWM timer frequency [MHz] */
#define     MOTOR_MCU_CFG_CARRIER_FREQ_A        (CG_CONFIG_MOTOR_A_CARRIER_FREQ)    /* Carrier wave frequency [kHz] */
#define     MOTOR_MCU_CFG_INTR_DECIMATION_A     (CG_CONFIG_MOTOR_A_INTR_DECIMATION) /* Interrupt skipping number */
#define     MOTOR_MCU_CFG_AD_FREQ_A             (CG_MOTOR_MCU_CFG_AD_FREQ)          /* A/D frequency [MHz] */
#define     MOTOR_MCU_CFG_AD_SAMPLING_CYCLE_A   (6 + 39)
                                /* Scan start processing time(tD) + sample-and-hold processing time(tSPLSH) [cycle] */
#define     MOTOR_MCU_CFG_AD12BIT_DATA          (CG_MOTOR_CFG_MAX_AD_DATA)          /* A/D 12Bit data */
#define     MOTOR_MCU_CFG_ADC_OFFSET            (0x7FF)                             /* A/D offset */

#if defined(__TFU)
#define     MOTOR_MCU_CFG_TFU_OPTIMIZE_A        (MTR_ENABLE)        /* TFU Optimization */
#else
#define     MOTOR_MCU_CFG_TFU_OPTIMIZE_A        (MTR_DISABLE)
#endif


/*
 * Motor control common configurations
 */
#define MOTOR_TYPE_BLDC     /* The motor used is BLDC. */
/*#define MOTOR_TYPE_STM  *//* The motor used is STM. */

/* Select control loop mode
* - MOTOR_LOOP_SPEED(default)
*/
#define     MOTOR_COMMON_CFG_LOOP_MODE_A                (MOTOR_LOOP_SPEED)

#define     MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT    (1.5f)

#if defined(MOTOR_TYPE_BLDC)
#define     MOTOR_COMMON_CFG_IA_MAX_CALC_MULT           (MTR_SQRT_3)
#elif defined(MOTOR_TYPE_STM)
#define     MOTOR_COMMON_CFG_IA_MAX_CALC_MULT           (MTR_SQRT_2)
#endif


/*
 * for Current Module(current_rx)
 */
/* Defines whether use voltage error compensation in FOC */
#define     CURRENT_CFG_VOLT_ERR_COMP_A         (MTR_ENABLE)

/* Select modulation method
* - MOD_METHOD_SPWM
* - MOD_METHOD_SVPWM(default)
*/
#define     CURRENT_CFG_MODULATION_METHOD       (MOD_METHOD_SVPWM)
#define     CURRENT_CFG_MODULATION_METHOD_A     (MOD_METHOD_SVPWM)

#define     CURRENT_CFG_OFFSET_CALC_TIME_A      (512.0f)                /* Current offset calculation time */
#define     CURRENT_CFG_PERIOD_MAG_VALUE_A      (1.0f)
                                                        /* Period magnification value for coordinate transformation */
#define     CURRENT_CFG_PI_INTEGRAL_LIMIT_VD_A  (INVERTER_CFG_INPUT_V * 0.5f)
                                                                        /* Current PI integral term limit for vd */
#define     CURRENT_CFG_PI_INTEGRAL_LIMIT_VQ_A  (INVERTER_CFG_INPUT_V * 0.5f)
                                                                        /* Current PI integral term limit for vq */
#if (MTR_CONTROL_PARAMETER != 1)
#define     CURRENT_CFG_OMEGA_A                 (300.0f)                /* natural frequency for current loop */
#define     CURRENT_CFG_ZETA_A                  (1.0f)                  /* damping ratio for current loop */
#define     CURRENT_CFG_REF_ID_OPENLOOP_A       (0.3f)                  /* id reference when low speed [A] */
#endif /* !MTR_CONTROL_PARAMETER */
#define     CURRENT_CFG_ID_UP_STEP_TIME_A       (2560.0f)               /* Time to increase id */
#define     CURRENT_CFG_ID_DOWN_STEP_TIME_A     (500.0f)                /* Time to decrease id */
#define     CURRENT_CFG_IQ_DOWN_STEP_TIME_INV_A (1.0f /CURRENT_CFG_ID_UP_STEP_TIME_A)
                                                                        /* Inverse number of time to decrease iq */
#if (MTR_CONTROL_PARAMETER != 1)
#define     CURRENT_CFG_E_OBS_OMEGA_A           (1000.0f)               /* Natural frequency of BEMF observer */
#define     CURRENT_CFG_E_OBS_ZETA_A            (1.0f)                  /* Damping ratio of BEMF observer */
#define     CURRENT_CFG_PLL_EST_OMEGA_A         (20.0f)                 /* Natural frequency of PLL Speed estimate loop */
#define     CURRENT_CFG_PLL_EST_ZETA_A          (1.0f)                  /* Damping ratio of PLL Speed estimate loop */
#endif /* !MTR_CONTROL_PARAMETER */
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
#define     CURRENT_CFG_MIN_DIFFERENCE_DUTY_A   (600)                   /* Minimum difference of PWM duty */
#define     CURRENT_CFG_ADJUST_ADC_DELAY_A      (240)                   /* Adjustment delay for A/D conversion */

/* Current driver settings */
#define     CURRENT_CFG_FUNC_DUTY_SET_A         (R_Config_MTU3_MTU4_1ShuntUpdDuty)
                                                                        /* Duty set function */
#define     CURRENT_CFG_FUNC_ADC_TRIGGER_SET_A  (R_Config_MTU3_MTU4_AdcTriggerSet)
                                                                        /* AD double trigger timing set function */
#define     CURRENT_CFG_FUNC_PWM_MAX_COUNT_GET_A (R_Config_MTU3_MTU4_MaxCountGet)
                                                                        /* PWM max count get function */
#endif


/*
 * for Speed Module(speed_rx)
 */
/* Defines whether use flux-weakening in FOC */
#define     SPEED_CFG_FLUX_WEAKENING_A          (MTR_DISABLE)

/* Defines whether perform soft switching between open-loop and vector control */
#define     SPEED_CFG_LESS_SWITCH_A             (MTR_ENABLE)

/* Defines whether use the open-loop damping control */
#define     SPEED_CFG_OPENLOOP_DAMPING_A        (MTR_ENABLE)

#define     SPEED_CFG_CTRL_PERIOD_A             (0.0005f)       /* control period for speed loop */
#if (MTR_CONTROL_PARAMETER != 1)
#define     SPEED_CFG_OMEGA_A                   (3.0f)          /* natural frequency for speed loop */
#define     SPEED_CFG_ZETA_A                    (1.0f)          /* damping ratio for speed loop */
#define     SPEED_CFG_SPEED_LIMIT_RPM_A         (4500.0f)       /* over speed limit [rpm] (mechanical angle) */
#endif /* !MTR_CONTROL_PARAMETER */
#define     SPEED_CFG_LPF_OMEGA_A               (25.0f)         /* natural frequency for speed LPF */
#define     SPEED_CFG_RATE_LIMIT_RPM_A          (1000.0f)       /* Rate limit of speed change [rpm/s] */
#define     SPEED_OPL2LESS_SWITCH_TIME_A        (0.025f)        /* Time[s] to switch open-loop to sensor-less */
#define     SPEED_OPL_DAMP_ED_HPF_OMEGA_A       (2.5f)          /* HPF cutoff frequency for ed [Hz] */
#define     SPEED_OPL_DAMP_ZETA_A               (1.0f)          /* Damping ratio of open-loop damping control */
#define     SPEED_OPL_DAMP_FB_SPEED_LIMIT_RATE_A (0.2f)         /* Rate of reference speed for feedback speed limiter */


/*
 * for sensorless vector Manager(sensorless_vector_rx)
 */
#if (MTR_CONTROL_PARAMETER != 1)
#define     SENSORLESS_VECTOR_ID_DOWN_SPEED_RPM_A                       (600.0f)
                                                            /* Speed to start decreasing id [rpm] */
#define     SENSORLESS_VECTOR_ID_UP_SPEED_RPM_A                         (400.0f)
                                                            /* Speed to start increasing id [rpm] */
#endif /* !MTR_CONTROL_PARAMETER */
#define     SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_DEG_A           (10.0f)
                                                            /* Phase error[deg] to decide sensor-less switch timing */
#define     SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_RAD_A           \
                            ((SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_DEG_A * 3.14159265f) / 180.0f)
                                                            /* Phase error[rad] to decide sensor-less switch timing */
#define     SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_LPF_CUT_FREQ_A  (10.0f)
                                                            /* Cut off frequency[Hz] of phase error LPF */


/*
 * for Driver Module(driver_rx)
 */
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_START_A  (R_Config_MTU3_MTU4_StartTimerCtrl)
                                                        /* The StartTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_STOP_A   (R_Config_MTU3_MTU4_StopTimerCtrl)
                                                        /* The StopTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_ADC_DATA_GET_A      (R_Config_MTU3_MTU4_1ShuntAdcGetConvVal)
                                                        /* The AdcGetConvVal function of motor component */
#elif defined(MOTOR_SHUNT_TYPE_2_SHUNT)
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_START_A  (R_Config_MOTOR_A_StartTimerCtrl)
                                                        /* The StartTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_STOP_A   (R_Config_MOTOR_A_StopTimerCtrl)
                                                        /* The StopTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_ADC_DATA_GET_A      (R_Config_MOTOR_A_AdcGetConvVal)
                                                        /* The AdcGetConvVal function of motor component */
#define     DRIVER_CFG_FUNC_DUTY_SET_A          (R_Config_MOTOR_A_UpdDuty)
                                                        /* The UpdDuty function of motor component */
#endif

/*
 * other
 */
#define     MOTOR_COMMON_AD_SAMPLING_TIME_A     (MOTOR_MCU_CFG_AD_SAMPLING_CYCLE_A / MOTOR_MCU_CFG_AD_FREQ_A)
                                                        /* A/D sampling time [us] */
#define     MOTOR_COMMON_CARRIER_SET_BASE_A     \
                            ((uint16_t)(MOTOR_MCU_CFG_PWM_TIMER_FREQ_A * 1000 / MOTOR_MCU_CFG_CARRIER_FREQ_A / 2))
#define     MOTOR_COMMON_DEADTIME_SET_A         ((uint16_t)(INVERTER_CFG_DEADTIME_A * MOTOR_MCU_CFG_PWM_TIMER_FREQ_A))
                                                        /* Setting value of deadtime */
#define     MOTOR_COMMON_CTRL_PERIOD_A          \
                            ((MOTOR_MCU_CFG_INTR_DECIMATION_A + 1) / (MOTOR_MCU_CFG_CARRIER_FREQ_A * 1000))
                                                        /* Control period */
/****** Macro of current control*****/
#define     MOTOR_COMMON_ID_UP_STEP_RATE_A      (CURRENT_CFG_REF_ID_OPENLOOP_A / CURRENT_CFG_ID_UP_STEP_TIME_A)
                                                        /* addition value of id */
#define     MOTOR_COMMON_ID_DOWN_STEP_RATE_A    (CURRENT_CFG_REF_ID_OPENLOOP_A / CURRENT_CFG_ID_DOWN_STEP_TIME_A)
                                                        /* subtraction value of id */
#define     MOTOR_COMMON_PI_INTEGRAL_LIMIT_IQ_A (MOTOR_CFG_NOMINAL_CURRENT_RMS_A * MTR_SQRT_3)
                                                        /* speed PI integral term limit for iq */
#define     MOTOR_COMMON_LIMIT_IQ_A             (MOTOR_CFG_NOMINAL_CURRENT_RMS_A * MTR_SQRT_3)
                                                        /* speed PI limit for iq */
#define     MOTOR_COMMON_CURRENT_OBS_LIMIT_A    (MOTOR_CFG_NOMINAL_CURRENT_RMS_A * MTR_SQRT_3 * 3.0f)
                                                        /* Integration limit value of voltage disturbance estimate */
#define     MOTOR_COMMON_OVERCURRENT_LIMIT_A    \
                            (MOTOR_CFG_NOMINAL_CURRENT_RMS_A * MTR_SQRT_2 * MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT)
                                                        /* Over current limit [A] */
/* Motor B */
/*
 * for MCU
 */
#define     MOTOR_MCU_CFG_PWM_TIMER_FREQ_B      (CG_CONFIG_MOTOR_B_PWM_TIMER_FREQ)  /* PWM timer frequency [MHz] */
#define     MOTOR_MCU_CFG_CARRIER_FREQ_B        (CG_CONFIG_MOTOR_B_CARRIER_FREQ)    /* Carrier wave frequency [kHz] */
#define     MOTOR_MCU_CFG_INTR_DECIMATION_B     (CG_CONFIG_MOTOR_B_INTR_DECIMATION) /* Interrupt skipping number */
#define     MOTOR_MCU_CFG_AD_FREQ_B             (CG_MOTOR_MCU_CFG_AD_FREQ)          /* A/D frequency [MHz] */
#define     MOTOR_MCU_CFG_AD_SAMPLING_CYCLE_B   (6 + 39)
                                /* Scan start processing time(tD) + sample-and-hold processing time(tSPLSH) [cycle] */
/*#define     MOTOR_MCU_CFG_AD12BIT_DATA_B        (CG_MOTOR_CFG_MAX_AD_DATA)               *//* A/D 12Bit data */
/*#define     MOTOR_MCU_CFG_ADC_OFFSET_B          (0x7FF)                                  *//* A/D offset */

#if defined(__TFU)
#define     MOTOR_MCU_CFG_TFU_OPTIMIZE_B        (MTR_ENABLE)        /* TFU Optimization */
#else
#define     MOTOR_MCU_CFG_TFU_OPTIMIZE_B        (MTR_DISABLE)
#endif


/*
 * Motor control common configurations
 */
/*#define MOTOR_TYPE_BLDC     *//* The motor used is BLDC. */
/*#define MOTOR_TYPE_STM      *//* The motor used is STM. */

/* Select control loop mode
* - MOTOR_LOOP_SPEED(default)
*/
#define     MOTOR_COMMON_CFG_LOOP_MODE_B                (MOTOR_LOOP_SPEED)

/*#define     MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT_B  (1.5f)

/*#if defined(MOTOR_TYPE_BLDC)                                              */
/*#define     MOTOR_COMMON_CFG_IA_MAX_CALC_MULT_B         (MTR_SQRT_3)      */
/*#elif defined(MOTOR_TYPE_STM)                                             */
/*#define     MOTOR_COMMON_CFG_IA_MAX_CALC_MULT_B         (MTR_SQRT_2)      */
/*#endif                                                                    */


/*
 * for Current Module(current_rx)
 */
/* Defines whether use voltage error compensation in FOC */
#define     CURRENT_CFG_VOLT_ERR_COMP_B         (MTR_ENABLE)

/* Select modulation method
* - MOD_METHOD_SPWM
* - MOD_METHOD_SVPWM(default)
*/
#define     CURRENT_CFG_MODULATION_METHOD_B     (MOD_METHOD_SVPWM)

#define     CURRENT_CFG_OFFSET_CALC_TIME_B      (512.0f)                /* Current offset calculation time */
#define     CURRENT_CFG_PERIOD_MAG_VALUE_B      (1.0f)
                                                        /* Period magnification value for coordinate transformation */
#define     CURRENT_CFG_PI_INTEGRAL_LIMIT_VD_B  (INVERTER_CFG_INPUT_V * 0.5f)
                                                                        /* Current PI integral term limit for vd */
#define     CURRENT_CFG_PI_INTEGRAL_LIMIT_VQ_B  (INVERTER_CFG_INPUT_V * 0.5f)
                                                                        /* Current PI integral term limit for vq */
#if (MTR_CONTROL_PARAMETER != 1)
#define     CURRENT_CFG_OMEGA_B                 (300.0f)                /* natural frequency for current loop */
#define     CURRENT_CFG_ZETA_B                  (1.0f)                  /* damping ratio for current loop */
#define     CURRENT_CFG_REF_ID_OPENLOOP_B       (0.3f)                  /* id reference when low speed [A] */
#endif /* !MTR_CONTROL_PARAMETER */
#define     CURRENT_CFG_ID_UP_STEP_TIME_B       (2560.0f)               /* Time to increase id */
#define     CURRENT_CFG_ID_DOWN_STEP_TIME_B     (500.0f)                /* Time to decrease id */
#define     CURRENT_CFG_IQ_DOWN_STEP_TIME_INV_B (1.0f /CURRENT_CFG_ID_UP_STEP_TIME_B)
                                                                        /* Inverse number of time to decrease iq */
#if (MTR_CONTROL_PARAMETER != 1)
#define     CURRENT_CFG_E_OBS_OMEGA_B           (1000.0f)               /* Natural frequency of BEMF observer */
#define     CURRENT_CFG_E_OBS_ZETA_B            (1.0f)                  /* Damping ratio of BEMF observer */
#define     CURRENT_CFG_PLL_EST_OMEGA_B         (20.0f)                 /* Natural frequency of PLL Speed estimate loop */
#define     CURRENT_CFG_PLL_EST_ZETA_B          (1.0f)                  /* Damping ratio of PLL Speed estimate loop */
#endif /* !MTR_CONTROL_PARAMETER */
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
#define     CURRENT_CFG_MIN_DIFFERENCE_DUTY_B   (600)                   /* Minimum difference of PWM duty */
#define     CURRENT_CFG_ADJUST_ADC_DELAY_B      (240)                   /* Adjustment delay for A/D conversion */

/* Current driver settings */
#define     CURRENT_CFG_FUNC_DUTY_SET_B         (R_Config_MTU3_MTU4_1ShuntUpdDuty)
                                                                        /* Duty set function */
#define     CURRENT_CFG_FUNC_ADC_TRIGGER_SET_B  (R_Config_MTU3_MTU4_AdcTriggerSet)
                                                                        /* AD double trigger timing set function */
#define     CURRENT_CFG_FUNC_PWM_MAX_COUNT_GET_B (R_Config_MTU3_MTU4_MaxCountGet)
                                                                        /* PWM max count get function */
#endif


/*
 * for Speed Module(speed_rx)
 */
/* Defines whether use flux-weakening in FOC */
#define     SPEED_CFG_FLUX_WEAKENING_B          (MTR_DISABLE)

/* Defines whether perform soft switching between open-loop and vector control */
#define     SPEED_CFG_LESS_SWITCH_B             (MTR_ENABLE)

/* Defines whether use the open-loop damping control */
#define     SPEED_CFG_OPENLOOP_DAMPING_B        (MTR_ENABLE)

#define     SPEED_CFG_CTRL_PERIOD_B             (0.0005f)       /* control period for speed loop */
#if (MTR_CONTROL_PARAMETER != 1)
#define     SPEED_CFG_OMEGA_B                   (3.0f)          /* natural frequency for speed loop */
#define     SPEED_CFG_ZETA_B                    (1.0f)          /* damping ratio for speed loop */
#define     SPEED_CFG_SPEED_LIMIT_RPM_B         (4500.0f)       /* over speed limit [rpm] (mechanical angle) */
#endif /* !MTR_CONTROL_PARAMETER */
#define     SPEED_CFG_LPF_OMEGA_B               (25.0f)         /* natural frequency for speed LPF */
#define     SPEED_CFG_RATE_LIMIT_RPM_B          (1000.0f)       /* Rate limit of speed change [rpm/s] */
#define     SPEED_OPL2LESS_SWITCH_TIME_B        (0.025f)        /* Time[s] to switch open-loop to sensor-less */
#define     SPEED_OPL_DAMP_ED_HPF_OMEGA_B       (2.5f)          /* HPF cutoff frequency for ed [Hz] */
#define     SPEED_OPL_DAMP_ZETA_B               (1.0f)          /* Damping ratio of open-loop damping control */
#define     SPEED_OPL_DAMP_FB_SPEED_LIMIT_RATE_B (0.2f)         /* Rate of reference speed for feedback speed limiter */


/*
 * for sensorless vector Manager(sensorless_vector_rx)
 */
#if (MTR_CONTROL_PARAMETER != 1)
#define     SENSORLESS_VECTOR_ID_DOWN_SPEED_RPM_B                       (600.0f)
                                                            /* Speed to start decreasing id [rpm] */
#define     SENSORLESS_VECTOR_ID_UP_SPEED_RPM_B                         (400.0f)
                                                            /* Speed to start increasing id [rpm] */
#endif /* !MTR_CONTROL_PARAMETER */
#define     SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_DEG_B           (10.0f)
                                                            /* Phase error[deg] to decide sensor-less switch timing */
#define     SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_RAD_B           \
                            ((SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_DEG_B * 3.14159265f) / 180.0f)
                                                            /* Phase error[rad] to decide sensor-less switch timing */
#define     SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_LPF_CUT_FREQ_B  (10.0f)
                                                            /* Cut off frequency[Hz] of phase error LPF */


/*
 * for Driver Module(driver_rx)
 */
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_START_B  (R_Config_MTU3_MTU4_StartTimerCtrl)
                                                        /* The StartTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_STOP_B   (R_Config_MTU3_MTU4_StopTimerCtrl)
                                                        /* The StopTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_ADC_DATA_GET_B      (R_Config_MTU3_MTU4_1ShuntAdcGetConvVal)
                                                        /* The AdcGetConvVal function of motor component */
#elif defined(MOTOR_SHUNT_TYPE_2_SHUNT)
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_START_B  (R_Config_MOTOR_B_StartTimerCtrl)
                                                        /* The StartTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_STOP_B   (R_Config_MOTOR_B_StopTimerCtrl)
                                                        /* The StopTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_ADC_DATA_GET_B      (R_Config_MOTOR_B_AdcGetConvVal)
                                                        /* The AdcGetConvVal function of motor component */
#define     DRIVER_CFG_FUNC_DUTY_SET_B          (R_Config_MOTOR_B_UpdDuty)
                                                        /* The UpdDuty function of motor component */
#endif

/*
 * other
 */
#define     MOTOR_COMMON_AD_SAMPLING_TIME_B     (MOTOR_MCU_CFG_AD_SAMPLING_CYCLE_B / MOTOR_MCU_CFG_AD_FREQ_B)
                                                        /* A/D sampling time [us] */
#define     MOTOR_COMMON_CARRIER_SET_BASE_B     \
                            ((uint16_t)(MOTOR_MCU_CFG_PWM_TIMER_FREQ_B * 1000 / MOTOR_MCU_CFG_CARRIER_FREQ_B / 2))
#define     MOTOR_COMMON_DEADTIME_SET_B         ((uint16_t)(INVERTER_CFG_DEADTIME_B * MOTOR_MCU_CFG_PWM_TIMER_FREQ_B))
                                                        /* Setting value of deadtime */
#define     MOTOR_COMMON_CARRIER_ADJ_TIME_B     (100)   /* First interrupt timing adjustment time [us] */
#define     MTR_CARRIER_SET_ADJ_B     ((uint16_t)((MOTOR_COMMON_CARRIER_ADJ_TIME_B * MOTOR_MCU_CFG_CARRIER_FREQ_B / 2 )\
                                      + MOTOR_COMMON_DEADTIME_SET_B))

#define     MOTOR_COMMON_CTRL_PERIOD_B          \
                            ((MOTOR_MCU_CFG_INTR_DECIMATION_B + 1) / (MOTOR_MCU_CFG_CARRIER_FREQ_B * 1000))
                                                        /* Control period */
/****** Macro of current control*****/
#define     MOTOR_COMMON_ID_UP_STEP_RATE_B      (CURRENT_CFG_REF_ID_OPENLOOP_B / CURRENT_CFG_ID_UP_STEP_TIME_B)
                                                        /* addition value of id */
#define     MOTOR_COMMON_ID_DOWN_STEP_RATE_B    (CURRENT_CFG_REF_ID_OPENLOOP_B / CURRENT_CFG_ID_DOWN_STEP_TIME_B)
                                                        /* subtraction value of id */
#define     MOTOR_COMMON_PI_INTEGRAL_LIMIT_IQ_B (MOTOR_CFG_NOMINAL_CURRENT_RMS_B * MTR_SQRT_3)
                                                        /* speed PI integral term limit for iq */
#define     MOTOR_COMMON_LIMIT_IQ_B             (MOTOR_CFG_NOMINAL_CURRENT_RMS_B * MTR_SQRT_3)
                                                        /* speed PI limit for iq */
#define     MOTOR_COMMON_CURRENT_OBS_LIMIT_B    (MOTOR_CFG_NOMINAL_CURRENT_RMS_B * MTR_SQRT_3 * 3.0f)
                                                        /* Integration limit value of voltage disturbance estimate */
#define     MOTOR_COMMON_OVERCURRENT_LIMIT_B    \
                            (MOTOR_CFG_NOMINAL_CURRENT_RMS_B * MTR_SQRT_2 * MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT)
                                                        /* Over current limit [A] */
#endif /* R_MOTOR_MODULE_CFG_H */
