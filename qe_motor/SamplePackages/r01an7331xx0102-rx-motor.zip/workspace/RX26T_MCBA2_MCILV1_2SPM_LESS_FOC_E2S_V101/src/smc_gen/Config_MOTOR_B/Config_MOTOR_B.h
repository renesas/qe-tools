/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_MOTOR_B.h
* Component Version: 1.1.0
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_MOTOR_B.
***********************************************************************************************************************/

#ifndef CFG_Config_MOTOR_B_H
#define CFG_Config_MOTOR_B_H

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/* Interrupt Priority Level Select (IPR[3:0]) */
#define _00_MTR_PRIORITY_LEVEL0      (0x00U) /* Level 0 (interrupt disabled) */
#define _01_MTR_PRIORITY_LEVEL1      (0x01U) /* Level 1 */
#define _02_MTR_PRIORITY_LEVEL2      (0x02U) /* Level 2 */
#define _03_MTR_PRIORITY_LEVEL3      (0x03U) /* Level 3 */
#define _04_MTR_PRIORITY_LEVEL4      (0x04U) /* Level 4 */
#define _05_MTR_PRIORITY_LEVEL5      (0x05U) /* Level 5 */
#define _06_MTR_PRIORITY_LEVEL6      (0x06U) /* Level 6 */
#define _07_MTR_PRIORITY_LEVEL7      (0x07U) /* Level 7 */
#define _08_MTR_PRIORITY_LEVEL8      (0x08U) /* Level 8 */
#define _09_MTR_PRIORITY_LEVEL9      (0x09U) /* Level 9 */
#define _0A_MTR_PRIORITY_LEVEL10     (0x0AU) /* Level 10 */
#define _0B_MTR_PRIORITY_LEVEL11     (0x0BU) /* Level 11 */
#define _0C_MTR_PRIORITY_LEVEL12     (0x0CU) /* Level 12 */
#define _0D_MTR_PRIORITY_LEVEL13     (0x0DU) /* Level 13 */
#define _0E_MTR_PRIORITY_LEVEL14     (0x0EU) /* Level 14 */
#define _0F_MTR_PRIORITY_LEVEL15     (0x0FU) /* Level 15 (highest) */

//Timer Mode
#define _000D0000_MTR_GPT_COMPLEMENT_PWM_2        (0x000D0000UL)

//CNT_CLK
#define _00000000_MTR_GPT_PCLK             (0x00000000UL)
#define _00800000_MTR_GPT_PCLK_2           (0x00800000UL)
#define _01000000_MTR_GPT_PCLK_4           (0x01000000UL)
#define _01800000_MTR_GPT_PCLK_8           (0x01800000UL)
#define _02000000_MTR_GPT_PCLK_16          (0x02000000UL)
#define _02800000_MTR_GPT_PCLK_32          (0x02800000UL)
#define _03000000_MTR_GPT_PCLK_64          (0x03000000UL)
#define _03800000_MTR_GPT_PCLK_128         (0x03800000UL)
#define _04000000_MTR_GPT_PCLK_256         (0x04000000UL)
#define _04800000_MTR_GPT_PCLK_512         (0x04800000UL)
#define _05000000_MTR_GPT_PCLK_1024        (0x05000000UL)

//Initial Counter Value 
#define _00000000_GTCNT_INIT_COUNT                (0x00000000UL)

//Start_Stop Source
#define  _80000000_MTR_SOFTWARE_START_SOURCE_ENABLE            (0x80000000UL)
#define  _80000000_MTR_SOFTWARE_STOP_SOURCE_ENABLE             (0x80000000UL)

//Buffer Operation
#define  _00000000_MTR_GTPR_BUF_OP_ENABLE          (0x00000000UL)
#define  _00000004_MTR_GTADTR_BUF_OP_DISABLE       (0x00000004UL)

//AD Request Value
#define  _00000001_AD_REQUEST_VALUE                (0x00000001UL)

//GTCNT Counter Overflow Interrupt (GTCIVn) 
#define  _00000040_MTR_GTCIV_INTERRUPT_ENABLE      (0x00000040UL)
#define  _00000000_MTR_GTCIV_INTERRUPT_DISABLE     (0x00000000UL)
#define  _05000000_MTR_EXT1_NOT_SKIP_COUNT         (0x05000000UL)
#define  _00000000_MTR_NO_INT_SKIP_COUNT           (0x00000000UL)
#define  _00000001_MTR_EXT1_SKIP_CREST             (0x00000001UL)

//Skipping Count
#define  _00000000_MTR_GPT_INT_SKIP_DISABLE        (0x00000000UL)
#define  _00000010_MTR_GPT_INT_SKIP_COUNT_1        (0x00000010UL)
#define  _00000020_MTR_GPT_INT_SKIP_COUNT_2        (0x00000020UL)
#define  _00000030_MTR_GPT_INT_SKIP_COUNT_3        (0x00000030UL)
#define  _00000040_MTR_GPT_INT_SKIP_COUNT_4        (0x00000040UL)
#define  _00000050_MTR_GPT_INT_SKIP_COUNT_5        (0x00000050UL)
#define  _00000060_MTR_GPT_INT_SKIP_COUNT_6        (0x00000060UL)
#define  _00000070_MTR_GPT_INT_SKIP_COUNT_7        (0x00000070UL)
#define  _00000080_MTR_GPT_INT_SKIP_COUNT_8        (0x00000080UL)
#define  _00000090_MTR_GPT_INT_SKIP_COUNT_9        (0x00000090UL)
#define  _000000A0_MTR_GPT_INT_SKIP_COUNT_10       (0x000000A0UL)
#define  _000000B0_MTR_GPT_INT_SKIP_COUNT_11       (0x000000B0UL)
#define  _000000C0_MTR_GPT_INT_SKIP_COUNT_12       (0x000000C0UL)
#define  _000000D0_MTR_GPT_INT_SKIP_COUNT_13       (0x000000D0UL)
#define  _000000E0_MTR_GPT_INT_SKIP_COUNT_14       (0x000000E0UL)
#define  _000000F0_MTR_GPT_INT_SKIP_COUNT_15       (0x000000F0UL)

//AD Conversion Start Request Compare Match Skipping
#define  _00020000_MTR_ADTRA_DOWNCOUNTING_ENABLE   (0x00020000UL)
#define  _00000006_MTR_ADCMSAL_COUNT2_NOTSCNT      (0x00000006UL)
#define  _00000000_MTR_ADCM2_SKIP_DISABLE          (0x00000000UL)
#define  _00010000_MTR_ADCM2_SKIP_GTADTRA          (0x00010000UL)
#define  _00000000_MTR_ADCM2_SKIP_INIT_0           (0x00000000UL)

//Start_Stop GPT Counting
#define  _00000010_GPT4_COUNT                      (0x00000010UL)
#define  _00000001_GPT0_COUNT                      (0x00000001UL)

//S12AD
#define  _0000_MTR_AD_SINGLE_SCAN_MODE          (0x0000U)
#define  _1000_MTR_AD_SCAN_END_INTERRUPT_ENABLE (0x1000U)

#define  _0001_MTR_AD_AN000_USED                (0x0001U)
#define  _0002_MTR_AD_AN001_USED                (0x0002U)
#define  _0004_MTR_AD_AN002_USED                (0x0004U)
#define  _0008_MTR_AD_AN003_USED                (0x0008U)
#define  _0010_MTR_AD_AN004_USED                (0x0010U)
#define  _0020_MTR_AD_AN005_USED                (0x0020U)
#define  _0040_MTR_AD_AN006_USED                (0x0040U)
#define  _0080_MTR_AD_AN007_USED                (0x0080U)
#define  _0001_MTR_AD_AN016_USED                (0x0001U)
#define  _0002_MTR_AD_AN017_USED                (0x0002U)

#define  _0001_MTR_AD_AN100_USED                (0x0001U)
#define  _0002_MTR_AD_AN101_USED                (0x0002U)
#define  _0004_MTR_AD_AN102_USED                (0x0004U)
#define  _0008_MTR_AD_AN103_USED                (0x0008U)


#define  _0010_MTR_AD_AN104_USED                (0x0010U)
#define  _0020_MTR_AD_AN105_USED                (0x0020U)
#define  _0040_MTR_AD_AN106_USED                (0x0040U)
#define  _0080_MTR_AD_AN107_USED                (0x0080U)
#define  _0100_MTR_AD_AN108_USED                (0x0100U)
#define  _0200_MTR_AD_AN109_USED                (0x0200U)
#define  _0400_MTR_AD_AN110_USED                (0x0400U)
#define  _0800_MTR_AD_AN111_USED                (0x0800U)
#define  _1000_MTR_AD_AN112_USED                (0x1000U)
#define  _2000_MTR_AD_AN113_USED                (0x2000U)
#define  _4000_MTR_AD_AN114_USED                (0x4000U)
#define  _8000_MTR_AD_AN115_USED                (0x8000U)
#define  _0001_MTR_AD_AN116_USED                (0x0001U)
#define  _0002_MTR_AD_AN117_USED                (0x0002U)
#define  _0004_MTR_AD_AN118_USED                (0x0004U)
#define  _0008_MTR_AD_AN119_USED                (0x0008U)
#define  _0010_MTR_AD_AN120_USED                (0x0010U)

#define  _0001_MTR_AD_AN200_USED                (0x0001U)
#define  _0002_MTR_AD_AN201_USED                (0x0002U)
#define  _0004_MTR_AD_AN202_USED                (0x0004U)
#define  _0008_MTR_AD_AN203_USED                (0x0008U)
#define  _0010_MTR_AD_AN204_USED                (0x0010U)
#define  _0020_MTR_AD_AN205_USED                (0x0020U)
#define  _0040_MTR_AD_AN206_USED                (0x0040U)
#define  _0080_MTR_AD_AN207_USED                (0x0080U)
#define  _0100_MTR_AD_AN208_USED                (0x0100U)
#define  _0200_MTR_AD_AN209_USED                (0x0200U)
#define  _0400_MTR_AD_AN210_USED                (0x0400U)
#define  _0800_MTR_AD_AN211_USED                (0x0800U)
#define  _0001_MTR_AD_AN216_USED                (0x0001U)
#define  _0002_MTR_AD_AN217_USED                (0x0002U)

#define  _01_MTR_AD_DSH_AN000_SELECT            (0x01U)
#define  _02_MTR_AD_DSH_AN001_SELECT            (0x02U)
#define  _04_MTR_AD_DSH_AN002_SELECT            (0x04U)
#define  _01_MTR_AD_DSH_AN100_SELECT            (0x01U)
#define  _02_MTR_AD_DSH_AN101_SELECT            (0x02U)
#define  _04_MTR_AD_DSH_AN102_SELECT            (0x04U)
 
#define  _4000_MTR_AD_TRSA_GTADTRA0N            (0x4000U)
#define  _4C00_MTR_AD_TRSA_GTADTRA4N            (0x4C00U)

/*
    General PWM Timer I/O Control Register (GTIOR)
*/
/* GTIOCnA Pin Output Enable */
#define _00000100_MTR_GTIOCA_OUTPUT_ENABLE     (0x00000100UL) /* GPT output is enabled */
/* GTIOCnB Pin Output Enable */
#define _01000000_MTR_GTIOCB_OUTPUT_ENABLE     (0x01000000UL) /* GPT output is enabled */

/* Output Level Select GTIOCnA */
#define _00000256_MTR_GTIOCA_HL       (0x00000256UL) /* Initial output:H, Active level:L, Stop output:H, Negate:Hi-Z */
#define _00000209_MTR_GTIOCA_LH       (0x00000209UL) /* Initial output:L, Active level:H, Stop output:L, Negate:Hi-Z */
/* Output Level Select GTIOCnB */
#define _02590000_MTR_GTIOCB_HL       (0x02590000UL) /* Initial output:H, Active level:L, Stop output:H, Negate:Hi-Z */
#define _02060000_MTR_GTIOCB_LH       (0x02060000UL) /* Initial output:L, Active level:H, Stop output:L, Negate:Hi-Z */


#define _00000BB8_4GTPR_VALUE                  (0x00000BB8UL) /* GPT4.GTPR value */
#define _00000654_GPT4_COMP_MATCH_VALUE        (0x00000654UL) /* GPT4.GTCCRA value */
#define _00000654_GPT5_COMP_MATCH_VALUE        (0x00000654UL) /* GPT5.GTCCRA value */
#define _00000654_GPT6_COMP_MATCH_VALUE        (0x00000654UL) /* GPT6.GTCCRA value */
#define _000000F0_4GTDVU_VALUE                 (0x000000F0UL) /* GPT4.GTDVU value */

/*
    Macro definitions for Motor Middleware
*/
#define CG_CONFIG_MOTOR_B_PWM_TIMER_FREQ            (120.0f)         /* PWM timer frequency [MHz] */
#define CG_CONFIG_MOTOR_B_CARRIER_FREQ              (20.000f)        /* Carrier wave actual frequency [kHz] */
#define CG_CONFIG_MOTOR_B_DEADTIME                  (2.000f)        /* Deadtime actual value [us] */
#define CG_CONFIG_MOTOR_B_INTR_DECIMATION           (1.0)            /* Interrupt skipping number */
#define CG_CONFIG_MOTOR_B_AD_DECIMATION             (1.0)            /* AD skipping number */
#define CG_MOTOR_CFG_MAX_AD_DATA                      (4095.0f)        /* Max A/D data */
#define CG_MOTOR_MCU_CFG_AD_FREQ                      (60.0f)          /* A/D frequency [MHz] */

#ifndef MTR_ADC_TB
#define MTR_ADC_TB
typedef struct
{
    uint16_t   u2_iu_ad;
    uint16_t   u2_iv_ad;
    uint16_t   u2_iw_ad;
    uint16_t   u2_vdc_ad;
    uint16_t   u2_vphase_u_ad;
    uint16_t   u2_vphase_v_ad;
    uint16_t   u2_vphase_w_ad;
} r_mtr_adc_tb;
#endif

#ifndef MTR_ADC_TS
#define MTR_ADC_TS
typedef struct
{
    uint16_t   u2_ia_ad;
    uint16_t   u2_ib_ad;
    uint16_t   u2_vdc_ad;
    uint16_t   u2_vphase_a_ad;
    uint16_t   u2_vphase_b_ad;
} r_mtr_adc_ts;
#endif


/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void R_Config_MOTOR_B_Create(void);
void R_Config_MOTOR_B_Create_UserInit(void);
void R_Config_MOTOR_B_StartTimerCount(void);
void R_Config_MOTOR_B_StopTimerCount(void);
void R_Config_MOTOR_B_StartTimerCtrl(void);
void R_Config_MOTOR_B_StopTimerCtrl(void);
void R_Config_MOTOR_B_UpdDuty(uint32_t duty_u, uint32_t duty_v, uint32_t duty_w);
void R_Config_MOTOR_B_StartAD(void);
void R_Config_MOTOR_B_StopAD(void);
void R_Config_MOTOR_B_AdcGetConvVal(r_mtr_adc_tb *mtr_ad_data);
/* Start user code for function. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#endif
