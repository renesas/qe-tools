/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_MOTOR_B_user.c
* Component Version: 1.1.0
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_MOTOR_B.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_MOTOR_B.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_motor_sensorless_vector_api.h"
#include "r_app_rmw.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_B_Create_UserInit
* Description  : This function adds user code after initializing the GPT channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_B_Create_UserInit(void)
{
    /* Start user code for user init. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_MOTOR_B_ad_interrupt
* Description  : This function is S12ADI1 interrupt service routine
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

#if FAST_INTERRUPT_VECTOR == VECT_S12AD1_S12ADI1
#pragma interrupt r_Config_MOTOR_B_ad_interrupt(vect=VECT(S12AD1,S12ADI1),fint)
#else
#pragma interrupt r_Config_MOTOR_B_ad_interrupt(vect=VECT(S12AD1,S12ADI1))
#endif
static void r_Config_MOTOR_B_ad_interrupt(void)
{
    /* Start user code for r_Config_MOTOR_B_ad_interrupt-1. Do not edit comment generated here */
    R_MOTOR_SENSORLESS_VECTOR_CurrentInterrupt(&g_st_sensorless_vector_b);
    r_app_rmw_interrupt_handler();
    /* End user code. Do not edit comment generated here */
    
    /* Start user code for r_Config_MOTOR_B_ad_interrupt-2. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
