/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_MOTOR_B.c
* Component Version: 1.1.0
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_MOTOR_B.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_MOTOR_B.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_B_Create
* Description  : This function initializes the GPT for motor
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_B_Create(void)
{
    /* Cancel GPTW module stop state */
    MSTP(GPTW) = 0U;

    /* Disable control registers write protect */
    GPTW4.GTWP.LONG = 0x0000A500UL;
    GPTW5.GTWP.LONG = 0x0000A500UL;
    GPTW6.GTWP.LONG = 0x0000A500UL;

    /* Set operating mode */
    GPTW4.GTCR.LONG = _000D0000_MTR_GPT_COMPLEMENT_PWM_2;

    /* Select count clock */
    GPTW4.GTCR.LONG |= _00000000_MTR_GPT_PCLK;

    /* Period setting */
    GPTW4.GTPR = _00000BB8_4GTPR_VALUE;

    /* Set counter initial value */
    GPTW4.GTCNT = _00000000_GTCNT_INIT_COUNT;

    /* Set GPTW4 start sources */
    GPTW4.GTSSR.LONG = _80000000_MTR_SOFTWARE_START_SOURCE_ENABLE;

    /* Set GPTW4 stop sources */
    GPTW4.GTPSR.LONG = _80000000_MTR_SOFTWARE_STOP_SOURCE_ENABLE;

    /* Set pin function */
    GPTW4.GTIOR.LONG = _00000209_MTR_GTIOCA_LH | _02060000_MTR_GTIOCB_LH;
    GPTW5.GTIOR.LONG = _00000209_MTR_GTIOCA_LH | _02060000_MTR_GTIOCB_LH;
    GPTW6.GTIOR.LONG = _00000209_MTR_GTIOCA_LH | _02060000_MTR_GTIOCB_LH;

    /* Set buffer operation */
    GPTW4.GTBER.LONG = _00000000_MTR_GTPR_BUF_OP_ENABLE | _00000004_MTR_GTADTR_BUF_OP_DISABLE;

    /* Set compare match value */
    GPTW4.GTCCRA = _00000654_GPT4_COMP_MATCH_VALUE;
    GPTW5.GTCCRA = _00000654_GPT5_COMP_MATCH_VALUE;
    GPTW6.GTCCRA = _00000654_GPT6_COMP_MATCH_VALUE;
    GPTW4.GTADTRA = _00000001_AD_REQUEST_VALUE;

    /* Set buffer value */
    GPTW4.GTPBR = _00000BB8_4GTPR_VALUE;
    GPTW4.GTPDBR = _00000BB8_4GTPR_VALUE;
    GPTW4.GTCCRC = _00000654_GPT4_COMP_MATCH_VALUE;
    GPTW4.GTCCRD = _00000654_GPT4_COMP_MATCH_VALUE;
    GPTW5.GTCCRC = _00000654_GPT5_COMP_MATCH_VALUE;
    GPTW5.GTCCRD = _00000654_GPT5_COMP_MATCH_VALUE;
    GPTW6.GTCCRC = _00000654_GPT6_COMP_MATCH_VALUE;
    GPTW6.GTCCRD = _00000654_GPT6_COMP_MATCH_VALUE;
    GPTW4.GTOLBR.LONG = GPTW4.GTIOR.LONG & 0x001F001FUL;
    GPTW5.GTOLBR.LONG = GPTW5.GTIOR.LONG & 0x001F001FUL;
    GPTW6.GTOLBR.LONG = GPTW6.GTIOR.LONG & 0x001F001FUL;
    GPTW4.GTADTBRA = _00000001_AD_REQUEST_VALUE;

    /* Set dead time value */
    GPTW4.GTDVU = _000000F0_4GTDVU_VALUE;

    /* Set interrupt and A/D conversion request generation */
    GPTW4.GTINTAD.LONG = _00020000_MTR_ADTRA_DOWNCOUNTING_ENABLE;

    /* Set A/D conversion start request compare match skipping function */
    GPTW4.GTADCMSS.LONG = _00000006_MTR_ADCMSAL_COUNT2_NOTSCNT;
    GPTW4.GTADCMSC.LONG = _00000010_MTR_GPT_INT_SKIP_COUNT_1 << 16U | _00010000_MTR_ADCM2_SKIP_GTADTRA | _00000000_MTR_ADCM2_SKIP_INIT_0;

    /* Enable control registers write protect */
    GPTW4.GTWP.LONG = 0x0000A51FUL;
    GPTW5.GTWP.LONG = 0x0000A51FUL;
    GPTW6.GTWP.LONG = 0x0000A51FUL;

    //Init Up (GTIOC4A)
    PORT9.PODR.BIT.B5 = 0U; //Active High
    PORT9.PDR.BIT.B5 = 1U;
    PORT9.PMR.BIT.B5 = 0U;
    MPC.P95PFS.BIT.PSEL = 0x14U;
    //Init Un (GTIOC4B)
    PORT9.PODR.BIT.B2 = 0U; //Active High
    PORT9.PDR.BIT.B2 = 1U;
    PORT9.PMR.BIT.B2 = 0U;
    MPC.P92PFS.BIT.PSEL = 0x14U;
    //Init Vp (GTIOC5A)
    PORT9.PODR.BIT.B4 = 0U; //Active High
    PORT9.PDR.BIT.B4 = 1U;
    PORT9.PMR.BIT.B4 = 0U;
    MPC.P94PFS.BIT.PSEL = 0x14U;
    //Init Vn (GTIOC5B)
    PORT9.PODR.BIT.B1 = 0U; //Active High
    PORT9.PDR.BIT.B1 = 1U;
    PORT9.PMR.BIT.B1 = 0U;
    MPC.P91PFS.BIT.PSEL = 0x14U;
    //Init Wp (GTIOC6A)
    PORT9.PODR.BIT.B3 = 0U; //Active High
    PORT9.PDR.BIT.B3 = 1U;
    PORT9.PMR.BIT.B3 = 0U;
    MPC.P93PFS.BIT.PSEL = 0x14U;
    //Init Wn (GTIOC6B)
    PORT9.PODR.BIT.B0 = 0U; //Active High
    PORT9.PDR.BIT.B0 = 1U;
    PORT9.PMR.BIT.B0 = 0U;
    MPC.P90PFS.BIT.PSEL = 0x14U;

    /* Cancel S12AD1 module stop state */
    MSTP(S12AD1) = 0U;
    /* Disable and clear interrupt flags of S12AD1 module */
    S12AD1.ADCSR.BIT.ADIE = 0U;
    IEN(S12AD1, S12ADI1) = 0U;

    /* Configure S12AD1 as single scan mode AD converter */
    S12AD1.ADCSR.WORD = _0000_MTR_AD_SINGLE_SCAN_MODE;
    S12AD1.ADSTRGR.WORD = _4C00_MTR_AD_TRSA_GTADTRA4N;
    S12AD1.ADANSA0.WORD = _0001_MTR_AD_AN100_USED | _0004_MTR_AD_AN102_USED | _0008_MTR_AD_AN103_USED;
    S12AD1.ADSHCR.BIT.SHANS = _01_MTR_AD_DSH_AN100_SELECT | _04_MTR_AD_DSH_AN102_SELECT;
    S12AD1.ADPGACR.BIT.P100CR = 1U;
    S12AD1.ADPGACR.BIT.P102CR = 1U;
    S12AD1.ADCSR.WORD |= _1000_MTR_AD_SCAN_END_INTERRUPT_ENABLE;
    IPR(S12AD1, S12ADI1) = _0C_MTR_PRIORITY_LEVEL12;

    //Init AN100
    PORT4.PDR.BIT.B4 = 0U;
    MPC.P44PFS.BIT.ASEL = 1U;
    //Init AN102
    PORT4.PDR.BIT.B6 = 0U;
    MPC.P46PFS.BIT.ASEL = 1U;
    //Init AN103
    PORT4.PDR.BIT.B7 = 0U;
    MPC.P47PFS.BIT.ASEL = 1U;

    R_Config_MOTOR_B_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_B_StartTimerCount
* Description  : This function starts the GPT4 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_B_StartTimerCount(void)
{
    /* Disable start write protect */
    GPTW4.GTWP.LONG = 0x0000A51DUL;
    GPTW5.GTWP.LONG = 0x0000A51DUL;
    GPTW6.GTWP.LONG = 0x0000A51DUL;

    /* Start counting */
    GPTW4.GTSTR.BIT.CSTRT4 = 1U;

    /* Enable start write protect */
    GPTW4.GTWP.LONG = 0x0000A51FUL;
    GPTW5.GTWP.LONG = 0x0000A51FUL;
    GPTW6.GTWP.LONG = 0x0000A51FUL;
}

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_B_StopTimerCount
* Description  : This function stops the GPT4 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_B_StopTimerCount(void)
{
    /* Disable start write protect */
    GPTW4.GTWP.LONG = 0x0000A51BUL;
    GPTW5.GTWP.LONG = 0x0000A51BUL;
    GPTW6.GTWP.LONG = 0x0000A51BUL;

    /* Stop counting */
    GPTW4.GTSTP.BIT.CSTOP4 = 1U;

    /* Enable start write protect */
    GPTW4.GTWP.LONG = 0x0000A51FUL;
    GPTW5.GTWP.LONG = 0x0000A51FUL;
    GPTW6.GTWP.LONG = 0x0000A51FUL;
}

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_B_StartTimerOutput
* Description  : This function starts the GPT output
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_B_StartTimerCtrl(void)
{
    /* Disable start write protect */
    GPTW4.GTWP.LONG = 0x0000A51EUL;
    GPTW5.GTWP.LONG = 0x0000A51EUL;
    GPTW6.GTWP.LONG = 0x0000A51EUL;

    //Init Up (GTIOC4A)
    PORT9.PODR.BIT.B5 = 0U; //Active High
    PORT9.PMR.BIT.B5 = 1U;
    //Init Un (GTIOC4B)
    PORT9.PODR.BIT.B2 = 0U; //Active High
    PORT9.PMR.BIT.B2 = 1U;
    //Init Vp (GTIOC5A)
    PORT9.PODR.BIT.B4 = 0U; //Active High
    PORT9.PMR.BIT.B4 = 1U;
    //Init Vn (GTIOC5B)
    PORT9.PODR.BIT.B1 = 0U; //Active High
    PORT9.PMR.BIT.B1 = 1U;
    //Init Wp (GTIOC6A)
    PORT9.PODR.BIT.B3 = 0U; //Active High
    PORT9.PMR.BIT.B3 = 1U;
    //Init Wn (GTIOC6B)
    PORT9.PODR.BIT.B0 = 0U; //Active High
    PORT9.PMR.BIT.B0 = 1U;

    /* Enable GPT PWM output */
    GPTW4.GTIOR.LONG |= (_00000100_MTR_GTIOCA_OUTPUT_ENABLE | _01000000_MTR_GTIOCB_OUTPUT_ENABLE);
    GPTW5.GTIOR.LONG |= (_00000100_MTR_GTIOCA_OUTPUT_ENABLE | _01000000_MTR_GTIOCB_OUTPUT_ENABLE);
    GPTW6.GTIOR.LONG |= (_00000100_MTR_GTIOCA_OUTPUT_ENABLE | _01000000_MTR_GTIOCB_OUTPUT_ENABLE);

    /* Enable start write protect */
    GPTW4.GTWP.LONG = 0x0000A51FUL;
    GPTW5.GTWP.LONG = 0x0000A51FUL;
    GPTW6.GTWP.LONG = 0x0000A51FUL;
}

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_B_StopTimerOutput
* Description  : This function stops the GPT output
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_B_StopTimerCtrl(void)
{
    /* Disable start write protect */
    GPTW4.GTWP.LONG = 0x0000A51EUL;
    GPTW5.GTWP.LONG = 0x0000A51EUL;
    GPTW6.GTWP.LONG = 0x0000A51EUL;

    /* Disable GPT PWM output */
    GPTW4.GTIOR.LONG &= ~(_00000100_MTR_GTIOCA_OUTPUT_ENABLE | _01000000_MTR_GTIOCB_OUTPUT_ENABLE);
    GPTW5.GTIOR.LONG &= ~(_00000100_MTR_GTIOCA_OUTPUT_ENABLE | _01000000_MTR_GTIOCB_OUTPUT_ENABLE);
    GPTW6.GTIOR.LONG &= ~(_00000100_MTR_GTIOCA_OUTPUT_ENABLE | _01000000_MTR_GTIOCB_OUTPUT_ENABLE);

    //Init Up (GTIOC4A)
    PORT9.PODR.BIT.B5 = 0U; //Active High
    PORT9.PMR.BIT.B5 = 0U;
    //Init Un (GTIOC4B)
    PORT9.PODR.BIT.B2 = 0U; //Active High
    PORT9.PMR.BIT.B2 = 0U;
    //Init Vp (GTIOC5A)
    PORT9.PODR.BIT.B4 = 0U; //Active High
    PORT9.PMR.BIT.B4 = 0U;
    //Init Vn (GTIOC5B)
    PORT9.PODR.BIT.B1 = 0U; //Active High
    PORT9.PMR.BIT.B1 = 0U;
    //Init Wp (GTIOC6A)
    PORT9.PODR.BIT.B3 = 0U; //Active High
    PORT9.PMR.BIT.B3 = 0U;
    //Init Wn (GTIOC6B)
    PORT9.PODR.BIT.B0 = 0U; //Active High
    PORT9.PMR.BIT.B0 = 0U;

    /* Enable start write protect */
    GPTW4.GTWP.LONG = 0x0000A51FUL;
    GPTW5.GTWP.LONG = 0x0000A51FUL;
    GPTW6.GTWP.LONG = 0x0000A51FUL;
}

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_B_UpdDuty
* Description  : This function updates duty cycle
* Arguments    : duty_u -
*                    U phase duty register value
*                duty_v -
*                    V phase duty register value
*                duty_w -
*                    W phase duty register value
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_B_UpdDuty(uint32_t duty_u, uint32_t duty_v, uint32_t duty_w)
{
    /* Disable start write protect */
    GPTW4.GTWP.LONG = 0x0000A51EUL;
    GPTW5.GTWP.LONG = 0x0000A51EUL;
    GPTW6.GTWP.LONG = 0x0000A51EUL;

    GPTW4.GTCCRD = duty_u;
    GPTW5.GTCCRD = duty_v;
    GPTW6.GTCCRD = duty_w;

    /* Enable start write protect */
    GPTW4.GTWP.LONG = 0x0000A51FUL;
    GPTW5.GTWP.LONG = 0x0000A51FUL;
    GPTW6.GTWP.LONG = 0x0000A51FUL;
}

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_B_StartAD
* Description  : This function starts the AD conversiont
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_B_StartAD(void)
{
    IR(S12AD1, S12ADI1) = 0U;
    IEN(S12AD1, S12ADI1) = 1U;
    S12AD1.ADCSR.BIT.TRGE = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_B_StopAD
* Description  : This function stops the AD conversion
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_B_StopAD(void)
{
    S12AD1.ADCSR.BIT.TRGE = 0U;
    S12AD1.ADCSR.BIT.ADST = 0U;
    IEN(S12AD1, S12ADI1) = 0U;
    IR(S12AD1, S12ADI1) = 0U;
}

/***********************************************************************************************************************
* Function Name: R_Config_MOTOR_B_AdcGetConvVal
* Description  : This function gets conversion result
* Arguments    : mtr_ad_data -
*                    buffer pointer
* Return Value : None
***********************************************************************************************************************/

void R_Config_MOTOR_B_AdcGetConvVal( r_mtr_adc_tb *mtr_ad_data )
{
    mtr_ad_data->u2_iu_ad  = (uint16_t)(S12AD1.ADDR0);
    mtr_ad_data->u2_iv_ad  =  0xFFFFU;
    mtr_ad_data->u2_iw_ad  = (uint16_t)(S12AD1.ADDR2);
    mtr_ad_data->u2_vdc_ad  = (uint16_t)(S12AD1.ADDR3);
    mtr_ad_data->u2_vphase_u_ad  =  0xFFFFU;
    mtr_ad_data->u2_vphase_v_ad  =  0xFFFFU;
    mtr_ad_data->u2_vphase_w_ad  =  0xFFFFU;
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
