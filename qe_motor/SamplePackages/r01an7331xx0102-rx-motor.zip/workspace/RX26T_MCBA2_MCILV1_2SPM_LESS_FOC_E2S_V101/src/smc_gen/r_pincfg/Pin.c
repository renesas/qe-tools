/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Pin.c
* Version          : 1.0.2
* Device(s)        : R5F526TFCxFP
* Description      : This file implements SMC pin code generation.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Pins_Create
* Description  : This function initializes Smart Configurator pins
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Pins_Create(void)
{
    R_BSP_RegisterProtectDisable(BSP_REG_PROTECT_MPC);

    /* Set AN000 pin */
    PORT4.PMR.BYTE &= 0xFEU;
    PORT4.PDR.BYTE &= 0xFEU;
    MPC.P40PFS.BYTE = 0x80U;

    /* Set AN002 pin */
    PORT4.PMR.BYTE &= 0xFBU;
    PORT4.PDR.BYTE &= 0xFBU;
    MPC.P42PFS.BYTE = 0x80U;

    /* Set AN003 pin */
    PORT4.PMR.BYTE &= 0xF7U;
    PORT4.PDR.BYTE &= 0xF7U;
    MPC.P43PFS.BYTE = 0x80U;

    /* Set AN100 pin */
    PORT4.PMR.BYTE &= 0xEFU;
    PORT4.PDR.BYTE &= 0xEFU;
    MPC.P44PFS.BYTE = 0x80U;

    /* Set AN102 pin */
    PORT4.PMR.BYTE &= 0xBFU;
    PORT4.PDR.BYTE &= 0xBFU;
    MPC.P46PFS.BYTE = 0x80U;

    /* Set AN103 pin */
    PORT4.PMR.BYTE &= 0x7FU;
    PORT4.PDR.BYTE &= 0x7FU;
    MPC.P47PFS.BYTE = 0x80U;

    /* Set AN203 pin */
    PORT5.PMR.BYTE &= 0xDFU;
    PORT5.PDR.BYTE &= 0xDFU;
    MPC.P55PFS.BYTE = 0x80U;

    /* Set AN204 pin */
    PORT5.PMR.BYTE &= 0xFEU;
    PORT5.PDR.BYTE &= 0xFEU;
    MPC.P50PFS.BYTE = 0x80U;

    /* Set GTETRGA pin */
    MPC.P01PFS.BYTE = 0x14U;
    PORT0.PMR.BYTE |= 0x02U;

    /* Set GTIOC4A pin */
    MPC.P95PFS.BYTE = 0x14U;
    PORT9.PMR.BYTE |= 0x20U;

    /* Set GTIOC4B pin */
    MPC.P92PFS.BYTE = 0x14U;
    PORT9.PMR.BYTE |= 0x04U;

    /* Set GTIOC5A pin */
    MPC.P94PFS.BYTE = 0x14U;
    PORT9.PMR.BYTE |= 0x10U;

    /* Set GTIOC5B pin */
    MPC.P91PFS.BYTE = 0x14U;
    PORT9.PMR.BYTE |= 0x02U;

    /* Set GTIOC6A pin */
    MPC.P93PFS.BYTE = 0x14U;
    PORT9.PMR.BYTE |= 0x08U;

    /* Set GTIOC6B pin */
    MPC.P90PFS.BYTE = 0x14U;
    PORT9.PMR.BYTE |= 0x01U;

    /* Set MTIOC3B pin */
    MPC.P71PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x02U;

    /* Set MTIOC3D pin */
    MPC.P74PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x10U;

    /* Set MTIOC4A pin */
    MPC.P72PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x04U;

    /* Set MTIOC4B pin */
    MPC.P73PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x08U;

    /* Set MTIOC4C pin */
    MPC.P75PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x20U;

    /* Set MTIOC4D pin */
    MPC.P76PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x40U;

    /* Set POE0# pin */
    MPC.P70PFS.BYTE = 0x07U;
    PORT7.PMR.BYTE |= 0x01U;

    R_BSP_RegisterProtectEnable(BSP_REG_PROTECT_MPC);
}

