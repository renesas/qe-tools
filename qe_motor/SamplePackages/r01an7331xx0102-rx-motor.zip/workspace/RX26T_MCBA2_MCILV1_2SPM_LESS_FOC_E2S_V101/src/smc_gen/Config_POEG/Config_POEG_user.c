/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_POEG_user.c
* Component Version: 1.11.0
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_POEG.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_POEG.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_motor_sensorless_vector_api.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_POEG_Create_UserInit
* Description  : This function adds user code after initializing the POEG module
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_POEG_Create_UserInit(void)
{
    /* Start user code for code init. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_POEG_poeggai_interrupt
* Description  : This function is POEGGAI interrupt service routine
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void r_Config_POEG_poeggai_interrupt(void)
{
    /* Start user code for r_Config_POEG_poeggai_interrupt. Do not edit comment generated here */
    R_MOTOR_SENSORLESS_VECTOR_OverCurrentInterrupt(&g_st_sensorless_vector_b);
    R_Config_POEG_Stop();
    POEG.POEGGA.BIT.PIDF = 0u;				/* PIDF Clear */
    POEG.POEGGA.BIT.IOCF = 0u;				/* IOCF Clear */
    R_Config_POEG_Start();
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
