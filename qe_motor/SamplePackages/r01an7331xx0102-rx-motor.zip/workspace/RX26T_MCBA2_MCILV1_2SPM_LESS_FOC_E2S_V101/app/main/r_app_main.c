/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_app_main.c
* Description : The main function and the processes of application layer
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 05.08.2022 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_smc_entry.h"
#include "r_app_control_cfg.h"
#include "r_app_main.h"
#include "r_app_rmw.h"
#include "r_app_board_ui.h"
#include "r_motor_sensorless_vector_api.h"
#include "r_motor_sensorless_vector_manager.h"
#include "r_motor_current.h"
#include "r_motor_speed.h"
#include "r_motor_driver.h"

/***********************************************************************************************************************
* Global variables
***********************************************************************************************************************/
/*** DTC table for ICS ***/
#pragma section DTCTBL
uint32_t g_dtc_table[256];
#pragma section
/*************************/

/***********************************************************************************************************************
* Private functions
***********************************************************************************************************************/
static void     r_app_main_ui_mainloop (void);           /* User interface control routine */

/* Connect modules used for sensorless structures */
static void     r_app_main_init_motor_ctrl (st_sensorless_vector_control_t * p_st_sensorless);

/* Initialize motor control instance */
static void     r_app_main_start_motor_ctrl (void);      /* Start motor control */

static void     r_app_sensorless_vector_init_link (st_sensorless_vector_control_t  * p_sv,
                                                    st_sensorless_vector_control_t * p_sv_init,
                                                    st_sv_cfg_t                    * p_cfg_init);

static void     r_app_current_init_link (st_current_control_t * p_cc, st_current_control_t * p_cc_init,
                                        st_cc_cfg_t * p_cfg_init);
static void     r_app_speed_init_link (st_speed_control_t * p_sc, st_speed_control_t * p_sc_init,
                                        st_spd_cfg_t * p_cfg_init);
static void     r_app_driver_init_link (st_motor_driver_t *p_drv, st_motor_driver_t *p_drv_init,
                                        st_drv_cfg_t * p_cfg_init);
static void     r_app_sv_set (st_sensorless_vector_control_t * p_sv,
                            st_current_control_t             * p_cc,
                            st_speed_control_t               * p_sc,
                            st_motor_driver_t                * p_drv);

static void     r_app_sensorless_vector_a_default_init (void * p_st_sv_init);
static void     r_app_sensorless_vector_b_default_init (void * p_st_sv_init);

static void     r_app_current_a_init_ctrl (void * p_st_cc_init);
static void     r_app_current_b_init_ctrl (void * p_st_cc_init);

static void     r_app_speed_a_init_ctrl (void * p_st_sc_init);
static void     r_app_speed_b_init_ctrl (void * p_st_sc_init);

static void     r_app_driver_a_init_ctrl (void * p_st_driver_init);
static void     r_app_driver_b_init_ctrl (void * p_st_driver_init);

/***********************************************************************************************************************
* Function Name : main
* Description   : Initialization and main routine
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void main(void)
{
clrpsw_i();                                       /* Disable interrupt */

    /* LED off */
    r_app_board_ui_led_control(MTR_ID_A, STATEMACHINE_STATE_STOP);
    r_app_board_ui_led_control(MTR_ID_B, STATEMACHINE_STATE_STOP);

    /* Initialize ICS */
    ics2_init((void*)g_dtc_table, APP_CFG_SCI_CH_SELECT, ICS_INT_LEVEL, ICS_BRR, ICS_INT_MODE);

    /* Link initialization variables */
    r_app_sensorless_vector_init_link(&g_st_sensorless_vector_a, &g_st_sensorless_vector_a_init,
                                        &g_st_sensorless_vector_a_cfg);
    r_app_sensorless_vector_init_link(&g_st_sensorless_vector_b, &g_st_sensorless_vector_b_init,
                                        &g_st_sensorless_vector_b_cfg);
    r_app_current_init_link(&g_st_cc_a, &g_st_cc_a_init, &g_st_cc_a_cfg);
    r_app_current_init_link(&g_st_cc_b, &g_st_cc_b_init, &g_st_cc_b_cfg);
    r_app_speed_init_link(&g_st_sc_a, &g_st_sc_a_init, &g_st_sc_a_cfg);
    r_app_speed_init_link(&g_st_sc_b, &g_st_sc_b_init, &g_st_sc_a_cfg);
    r_app_driver_init_link(&g_st_driver_a, &g_st_driver_a_init, &g_st_driver_a_cfg);
    r_app_driver_init_link(&g_st_driver_b, &g_st_driver_b_init, &g_st_driver_b_cfg);

    r_app_sv_set(&g_st_sensorless_vector_a, &g_st_cc_a, &g_st_sc_a, &g_st_driver_a);
    r_app_sv_set(&g_st_sensorless_vector_b, &g_st_cc_b, &g_st_sc_b, &g_st_driver_b);

    /* Initialize open motor control instance */
    r_app_current_a_init_ctrl((void *)&g_st_cc_a_init);
    r_app_current_b_init_ctrl((void *)&g_st_cc_b_init);

    r_app_speed_a_init_ctrl((void *)&g_st_sc_a_init);
    r_app_speed_b_init_ctrl((void *)&g_st_sc_b_init);
    
    r_app_driver_a_init_ctrl((void *)&g_st_driver_a_init);
    r_app_driver_b_init_ctrl((void *)&g_st_driver_b_init);

    r_app_sensorless_vector_a_default_init(&g_st_sensorless_vector_a_init);
    r_app_sensorless_vector_b_default_init(&g_st_sensorless_vector_b_init);

    r_app_main_init_motor_ctrl(&g_st_sensorless_vector_a);
    r_app_main_init_motor_ctrl(&g_st_sensorless_vector_b);

    /* Initialize RMW communication support for motor control
     * MUST be called after motor instance being configured */
    r_app_rmw_ui_init(MTR_ID_A);
    r_app_rmw_ui_init(MTR_ID_B);

setpsw_i();                                       /* Enable interrupt */

    /* Start peripheral functions */
    r_app_main_start_motor_ctrl();

    /*** Main routine ***/
    while (1)
    {
        /* User interface */
        r_app_main_ui_mainloop();

        /* Clear watch dog timer */
        R_Config_IWDT_Restart();
    }
} /* End of function main */

/***********************************************************************************************************************
* Function Name : r_app_main_ui_mainloop
* Description   : User interface control routine
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_main_ui_mainloop(void)
{
    uint8_t u1_temp;
    uint8_t u1_motor_status;

    /*============================*/
    /*        Get ICS value       */
    /*============================*/
    r_app_rmw_copy_com_to_buffer();

    /*============================*/
    /*   User interface switch    */
    /*============================*/
    u1_temp = com_u1_sw_userif_a;

    if (g_u1_sw_userif_a != u1_temp)
    {
        if (u1_temp >= MAIN_UI_SIZE)
        {
            com_u1_sw_userif_a = g_u1_sw_userif_a;
        }
        else
        {
            g_u1_sw_userif_a = u1_temp;

            if (MAIN_UI_RMW == g_u1_sw_userif_a)
            {
                /* Get status of motor control system */
                u1_motor_status    = R_MOTOR_SENSORLESS_VECTOR_StatusGet(&g_st_sensorless_vector_a);
                g_u1_system_mode_a = u1_motor_status;
            }
            else
            {
                nop();  /* Do Nothing */
            }
        }
    }

    /*============================*/
    /*        Execute event       */
    /*============================*/
    if (MAIN_UI_RMW == g_u1_sw_userif_a)
    {
        /* Main process for ICS UI */
        r_app_rmw_ui_mainloop();
    }
    else if (MAIN_UI_BOARD == g_u1_sw_userif_a)
    {
        /* Main process for board UI */
        r_app_board_ui_mainloop();
    }
    else
    {
        nop();      /* Do Nothing */
    }

    /*============================*/
    /*         LED control        */
    /*============================*/
    /* Get status of motor control system */
    u1_motor_status = R_MOTOR_SENSORLESS_VECTOR_StatusGet(&g_st_sensorless_vector_a);
    r_app_board_ui_led_control(MTR_ID_A, u1_motor_status);

    /*============================*/
    /*   User interface switch    */
    /*============================*/
    u1_temp = com_u1_sw_userif_b;

    if (g_u1_sw_userif_b != u1_temp)
    {
        if (u1_temp >= MAIN_UI_SIZE)
        {
            com_u1_sw_userif_b = g_u1_sw_userif_b;
        }
        else
        {
            g_u1_sw_userif_b = u1_temp;

            if (MAIN_UI_RMW == g_u1_sw_userif_b)
            {
                /* Get status of motor control system */
                u1_motor_status    = R_MOTOR_SENSORLESS_VECTOR_StatusGet(&g_st_sensorless_vector_b);
                g_u1_system_mode_b = u1_motor_status;
            }
            else
            {
                nop();      /* Do Nothing */
            }
        }
    }

    /*============================*/
    /*        Execute event       */
    /*============================*/
    if (MAIN_UI_RMW == g_u1_sw_userif_b)
    {
        /* Main process for ICS UI */
        r_app_rmw_ui_mainloop();
    }
    else if (MAIN_UI_BOARD == g_u1_sw_userif_b)
    {
        /* Main process for board UI */
        r_app_board_ui_mainloop();
    }
    else
    {
        nop();      /* Do Nothing */
    }

    /*============================*/
    /*         LED control        */
    /*============================*/
    /* Get status of motor control system */
    u1_motor_status = R_MOTOR_SENSORLESS_VECTOR_StatusGet(&g_st_sensorless_vector_b);
    r_app_board_ui_led_control(MTR_ID_B, u1_motor_status);
} /* End of function r_app_main_ui_mainloop */

/***********************************************************************************************************************
* Function Name : r_app_sensorless_vector_init_link
* Description   : Link the sensorless vector initialization variable pointer to the sensorless vector instance variable.
* Arguments     : p_sv       - The pointer to the motor control management data structure
*               : p_sv_init  - The pointer to the motor control management init data structure
*               : p_cfg_init - The pointer to the motor control management init data structure
* Return Value  : None
***********************************************************************************************************************/
static void r_app_sensorless_vector_init_link(st_sensorless_vector_control_t   *p_sv,
                                                st_sensorless_vector_control_t *p_sv_init,
                                                st_sv_cfg_t                    *p_cfg_init)
{
    if ((NULL != p_sv) && (NULL != p_sv_init) && (NULL != p_cfg_init))
    {
        p_sv_init->p_st_cfg_init = p_cfg_init;
        p_sv->p_st_sv_init       = (void *) p_sv_init;
        p_sv->p_st_cfg_init      = (st_sv_cfg_t *) NULL;
    }
} /* End of function r_app_sensorless_vector_init_link */

/***********************************************************************************************************************
* Function Name : r_app_current_init_link
* Description   : Link the current initialization variable pointer to the current instance variable.
* Arguments     : p_cc       - The pointer to the current control management data structure
*               : p_cc_init  - The pointer to the currnet control management init data structure
*               : p_cfg_init - The pointer to the currnet config  init data structure
* Return Value  : None
***********************************************************************************************************************/
static void r_app_current_init_link(st_current_control_t *p_cc, st_current_control_t *p_cc_init, 
                                    st_cc_cfg_t *p_cfg_init)
{
    if ((NULL != p_cc) && (NULL != p_cc_init) && (NULL != p_cfg_init))
    {
        p_cc_init->p_st_cfg_init = p_cfg_init;
        p_cc->p_st_cc_init       = (void *) p_cc_init;
        p_cc->p_st_cfg_init      = (st_cc_cfg_t *) NULL;
    }
} /* End of function r_app_current_init_link */

/***********************************************************************************************************************
* Function Name : r_app_speed_init_link
* Description   : Link the speed initialization variable pointer to the speed instance variable.
* Arguments     : p_sc       - The pointer to the motor control management data structure
*               : p_sc_init  - The pointer to the motor control management init data structure
*               : p_cfg_init - The pointer to the currnet config  init data structure
* Return Value  : None
***********************************************************************************************************************/
static void r_app_speed_init_link(st_speed_control_t *p_sc, st_speed_control_t *p_sc_init, st_spd_cfg_t *p_cfg_init)
{
    if ((NULL != p_sc) && (NULL != p_sc_init) && (NULL != p_cfg_init))
    {
        p_sc_init->p_st_cfg_init = p_cfg_init;
        p_sc->p_st_sc_init       = (void *) p_sc_init;
        p_sc->p_st_cfg_init      = (st_spd_cfg_t *) NULL;
    }
} /* End of function r_app_speed_init_link */

/***********************************************************************************************************************
* Function Name : r_app_driver_init_link
* Description   : Link the driver initialization variable pointer to the speed instance variable.
* Arguments     : p_sc       - The pointer to the motor control management data structure
*               : p_sc_init  - The pointer to the motor control management init data structure
*               : p_cfg_init - The pointer to the currnet config  init data structure
* Return Value  : None
***********************************************************************************************************************/
static void r_app_driver_init_link(st_motor_driver_t *p_drv, st_motor_driver_t *p_drv_init, st_drv_cfg_t *p_cfg_init)
{
    if ((NULL != p_drv) && (NULL != p_drv_init) && (NULL != p_cfg_init))
    {
        p_drv_init->p_st_cfg_init = p_cfg_init;
        p_drv->p_st_driver_init   = (void *) p_drv_init;
        p_drv->p_st_cfg_init      = (st_drv_cfg_t *) NULL;
    }
} /* End of function r_app_speed_init_link */

/***********************************************************************************************************************
* Function Name : r_app_sv_set
* Description   : Set a pointer inside the sensorless_vector_ctrl.
* Arguments     : p_sv       - The pointer to the motor control management data structure
*               : p_cc       - The pointer to the motor control management data structure
*               : p_sc       - The pointer to the motor control management data structure
*               : p_drv      - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
static void r_app_sv_set(st_sensorless_vector_control_t *p_sv,
                        st_current_control_t            *p_cc,
                        st_speed_control_t              *p_sc,
                        st_motor_driver_t               *p_drv)
{
    st_sensorless_vector_control_t * p_sv_init;

    if (NULL != p_sv)
    {
        p_sv->p_st_cc     = p_cc;
        p_sv->p_st_sc     = p_sc;
        p_sv->p_st_driver = p_drv;

        p_sv_init = (st_sensorless_vector_control_t *)p_sv->p_st_sv_init;

        p_sv_init->p_st_cc     = p_cc->p_st_cc_init;
        p_sv_init->p_st_sc     = p_sc->p_st_sc_init;
        p_sv_init->p_st_driver = p_drv->p_st_driver_init;
    }
} /* End of function r_app_sv_set */

/***********************************************************************************************************************
* Function Name : r_app_sensorless_vector_a_default_init
* Description   : Initializes motor a drive modules with default configuration
* Arguments     : p_st_sv_init - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
static void r_app_sensorless_vector_a_default_init(void *p_st_sv_init)
{
    st_current_cfg_t        * p_cur_cfg;
    st_bemf_observer_cfg_t  * p_bemf_obs_cfg;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    st_current_driver_cfg_t st_cur_driver_cfg;
#endif
    st_speed_cfg_t          * p_spd_cfg;
    st_motor_driver_cfg_t   * p_driver_cfg;

    st_sensorless_vector_cfg_t *p_sv_cfg;

    st_sensorless_vector_control_t * p_st_sv = (st_sensorless_vector_control_t *)p_st_sv_init;

    p_cur_cfg      = &p_st_sv->p_st_cc->p_st_cfg_init->st_cc_init_cfg;
    p_bemf_obs_cfg = &p_st_sv->p_st_cc->p_st_cfg_init->st_bemf_init_cfg;
    p_spd_cfg      = &p_st_sv->p_st_sc->p_st_cfg_init->st_sc_init_cfg;
    p_driver_cfg   = &p_st_sv->p_st_driver->p_st_cfg_init->st_drv_init_cfg;
    p_sv_cfg       = &p_st_sv->p_st_cfg_init->st_sv_init_cfg;

    /* Initialize member of motor parameter structure */
    p_st_sv->st_motor.u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS_A;
    p_st_sv->st_motor.f4_mtr_r               = MOTOR_CFG_RESISTANCE_A;
    p_st_sv->st_motor.f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE_A;
    p_st_sv->st_motor.f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE_A;
    p_st_sv->st_motor.f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX_A;
    p_st_sv->st_motor.f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA_A;
    p_st_sv->st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS_A;

    p_st_sv->u1_flag_less_switch_use      = SPEED_CFG_LESS_SWITCH_A;
    p_st_sv->u1_flag_openloop_damping_use = SPEED_CFG_OPENLOOP_DAMPING_A;
    p_st_sv->u1_direction                 = MTR_CW;
    p_st_sv->u1_ctrl_loop_mode            = MOTOR_COMMON_CFG_LOOP_MODE_A;
    p_st_sv->f4_overcurrent_limit         = MOTOR_COMMON_OVERCURRENT_LIMIT_A;
    p_st_sv->f4_overvoltage_limit         = INVERTER_CFG_OVERVOLTAGE_LIMIT_A;
    p_st_sv->f4_undervoltage_limit        = INVERTER_CFG_UNDERVOLTAGE_LIMIT_A;
    p_st_sv->f4_overspeed_limit_rad       = (SPEED_CFG_SPEED_LIMIT_RPM_A * MTR_RPM2RAD);
    p_st_sv->f4_switch_phase_err_rad      = SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_RAD_A;
    p_st_sv->f4_id_down_speed_rad         = (SENSORLESS_VECTOR_ID_DOWN_SPEED_RPM_A * MTR_RPM2RAD);
    p_st_sv->f4_id_up_speed_rad           = (SENSORLESS_VECTOR_ID_UP_SPEED_RPM_A * MTR_RPM2RAD);

    /* Initialize phase error LPF */
    /* variable set */

    /* Current configuration set */
    p_cur_cfg->u1_flag_volt_err_comp_use = CURRENT_CFG_VOLT_ERR_COMP_A;
    p_cur_cfg->u2_offset_calc_time       = CURRENT_CFG_OFFSET_CALC_TIME_A;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    p_cur_cfg->s2_difference_minimum     = CURRENT_CFG_MIN_DIFFERENCE_DUTY_A;
    p_cur_cfg->s2_adjust_adc_delay       = CURRENT_CFG_ADJUST_ADC_DELAY_A;
#endif
    p_cur_cfg->f4_ctrl_period            = MOTOR_COMMON_CTRL_PERIOD_A;
    p_cur_cfg->f4_current_omega_hz       = CURRENT_CFG_OMEGA_A;
    p_cur_cfg->f4_current_zeta           = CURRENT_CFG_ZETA_A;
    p_cur_cfg->f4_id_up_step             = MOTOR_COMMON_ID_UP_STEP_RATE_A;
    p_cur_cfg->f4_id_down_step           = MOTOR_COMMON_ID_DOWN_STEP_RATE_A;
    p_cur_cfg->f4_iq_down_step_time_inv  = CURRENT_CFG_IQ_DOWN_STEP_TIME_INV_A;
    p_cur_cfg->f4_ol_ref_id              = CURRENT_CFG_REF_ID_OPENLOOP_A;
    p_cur_cfg->st_motor                  = p_st_sv->st_motor;

    /* BEMF observer */
    p_bemf_obs_cfg->f4_e_obs_omega_hz   = CURRENT_CFG_E_OBS_OMEGA_A;
    p_bemf_obs_cfg->f4_e_obs_zeta       = CURRENT_CFG_E_OBS_ZETA_A;
    p_bemf_obs_cfg->f4_pll_est_omega_hz = CURRENT_CFG_PLL_EST_OMEGA_A;
    p_bemf_obs_cfg->f4_pll_est_zeta     = CURRENT_CFG_PLL_EST_ZETA_A;


#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    st_cur_driver_cfg.BLDC1ShuntDutySet = CURRENT_CFG_FUNC_DUTY_SET_A;
    st_cur_driver_cfg.ADCTriggerSet     = CURRENT_CFG_FUNC_ADC_TRIGGER_SET_A;
    st_cur_driver_cfg.PWMMaxCountGet    = CURRENT_CFG_FUNC_PWM_MAX_COUNT_GET_A;
    R_MOTOR_CURRENT_DriverParameterUpdate(p_st_sv->p_st_cc, &st_cur_driver_cfg);
#endif

    /* Voltage error compensation*/
    static const float  volterr_array[VERR_COMP_ARY_SIZE] =
    {
        INVERTER_CFG_COMP_V0_A,  /* f4_comp_v[0] */
        INVERTER_CFG_COMP_V1_A,  /* f4_comp_v[1] */
        INVERTER_CFG_COMP_V2_A,  /* f4_comp_v[2] */
        INVERTER_CFG_COMP_V3_A,  /* f4_comp_v[3] */
        INVERTER_CFG_COMP_V4_A,  /* f4_comp_v[4] */
    };
    static const float  crnt_array[VERR_COMP_ARY_SIZE] =
    {
        INVERTER_CFG_COMP_I0_A,  /* f4_comp_i[0] */
        INVERTER_CFG_COMP_I1_A,  /* f4_comp_i[1] */
        INVERTER_CFG_COMP_I2_A,  /* f4_comp_i[2] */
        INVERTER_CFG_COMP_I3_A,  /* f4_comp_i[3] */
        INVERTER_CFG_COMP_I4_A   /* f4_comp_i[4] */
    };

    p_cur_cfg->p_volterr_array = (float *)&volterr_array[0];
    p_cur_cfg->p_crnt_array    = (float *)&crnt_array[0];

    /* Speed configuration set */
    p_spd_cfg->u1_flag_fluxwkn_use         = SPEED_CFG_FLUX_WEAKENING_A;
    p_spd_cfg->f4_speed_ctrl_period        = SPEED_CFG_CTRL_PERIOD_A;
    p_spd_cfg->f4_max_speed_rpm            = MOTOR_CFG_MAX_SPEED_RPM_A;
    p_spd_cfg->f4_speed_rate_limit_rpm     = SPEED_CFG_RATE_LIMIT_RPM_A;
    p_spd_cfg->f4_speed_omega_hz           = SPEED_CFG_OMEGA_A;
    p_spd_cfg->f4_speed_zeta               = SPEED_CFG_ZETA_A;
    p_spd_cfg->f4_speed_lpf_hz             = SPEED_CFG_LPF_OMEGA_A;
    p_spd_cfg->f4_opl2less_sw_time         = SPEED_OPL2LESS_SWITCH_TIME_A;
    p_spd_cfg->f4_ed_hpf_omega             = SPEED_OPL_DAMP_ED_HPF_OMEGA_A;
    p_spd_cfg->f4_ol_damping_zeta          = SPEED_OPL_DAMP_ZETA_A;
    p_spd_cfg->f4_ol_damping_fb_limit_rate = SPEED_OPL_DAMP_FB_SPEED_LIMIT_RATE_A;
    p_spd_cfg->f4_ol_ref_id                = CURRENT_CFG_REF_ID_OPENLOOP_A;
    p_spd_cfg->f4_id_down_speed_rpm        = SENSORLESS_VECTOR_ID_DOWN_SPEED_RPM_A;
    p_spd_cfg->st_motor                    = p_st_sv->st_motor;

    /* Setup current limits by nominal current of motor */
    /* variable set */

    /* driver */
    p_driver_cfg->ADCDataGet           = DRIVER_CFG_FUNC_ADC_DATA_GET_A;
#if defined(MOTOR_SHUNT_TYPE_2_SHUNT)
    p_driver_cfg->BLDCDutySet          = (void (*)(uint32_t, uint32_t, uint32_t))DRIVER_CFG_FUNC_DUTY_SET_A;
#endif
    p_driver_cfg->PWMOutputStart       = DRIVER_CFG_FUNC_PWM_OUTPUT_START_A;
    p_driver_cfg->PWMOutputStop        = DRIVER_CFG_FUNC_PWM_OUTPUT_STOP_A;
    p_driver_cfg->f4_shunt_ohm         = INVERTER_CFG_SHUNT_RESIST;
    p_driver_cfg->f4_volt_gain         = INVERTER_CFG_VOLTAGE_GAIN;
    p_driver_cfg->f4_crnt_amp_gain     = INVERTER_CFG_CURRENT_AMP_GAIN;
    p_driver_cfg->f4_pwm_period_cnt    = MOTOR_COMMON_CARRIER_SET_BASE_A;
    p_driver_cfg->f4_pwm_dead_time_cnt = MOTOR_COMMON_DEADTIME_SET_A;

    /* sensorless vector cfg */
    p_sv_cfg->u1_flag_less_switch_use      = SPEED_CFG_LESS_SWITCH_A;
    p_sv_cfg->u1_flag_openloop_damping_use = SPEED_CFG_OPENLOOP_DAMPING_A;
    p_sv_cfg->f4_overspeed_limit_rpm       = SPEED_CFG_SPEED_LIMIT_RPM_A;
    p_sv_cfg->f4_switch_phase_err_deg      = SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_DEG_A;
    p_sv_cfg->f4_phase_err_lpf_cut_freq    = SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_LPF_CUT_FREQ_A;
    p_sv_cfg->f4_id_down_speed_rpm         = SENSORLESS_VECTOR_ID_DOWN_SPEED_RPM_A;
    p_sv_cfg->f4_id_up_speed_rpm           = SENSORLESS_VECTOR_ID_UP_SPEED_RPM_A;
    p_sv_cfg->f4_ctrl_period               = MOTOR_COMMON_CTRL_PERIOD_A;
    p_sv_cfg->st_motor                     = p_st_sv->st_motor;

} /* End of function r_app_sensorless_vector_a_default_init */

/***********************************************************************************************************************
* Function Name : r_app_sensorless_vector_b_default_init
* Description   : Initializes motor b drive modules with default configuration
* Arguments     : p_st_sv_init - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
static void r_app_sensorless_vector_b_default_init(void *p_st_sv_init)
{
    st_current_cfg_t        * p_cur_cfg;
    st_bemf_observer_cfg_t  * p_bemf_obs_cfg;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    st_current_driver_cfg_t st_cur_driver_cfg;
#endif
    st_speed_cfg_t          * p_spd_cfg;
    st_motor_driver_cfg_t   * p_driver_cfg;

    st_sensorless_vector_cfg_t * p_sv_cfg;

    st_sensorless_vector_control_t * p_st_sv = (st_sensorless_vector_control_t *)p_st_sv_init;

    p_cur_cfg      = &p_st_sv->p_st_cc->p_st_cfg_init->st_cc_init_cfg;
    p_bemf_obs_cfg = &p_st_sv->p_st_cc->p_st_cfg_init->st_bemf_init_cfg;
    p_spd_cfg      = &p_st_sv->p_st_sc->p_st_cfg_init->st_sc_init_cfg;
    p_driver_cfg   = &p_st_sv->p_st_driver->p_st_cfg_init->st_drv_init_cfg;
    p_sv_cfg       = &p_st_sv->p_st_cfg_init->st_sv_init_cfg;

    /* Initialize member of motor parameter structure */
    p_st_sv->st_motor.u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS_B;
    p_st_sv->st_motor.f4_mtr_r               = MOTOR_CFG_RESISTANCE_B;
    p_st_sv->st_motor.f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE_B;
    p_st_sv->st_motor.f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE_B;
    p_st_sv->st_motor.f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX_B;
    p_st_sv->st_motor.f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA_B;
    p_st_sv->st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS_B;

    p_st_sv->u1_flag_less_switch_use      = SPEED_CFG_LESS_SWITCH_B;
    p_st_sv->u1_flag_openloop_damping_use = SPEED_CFG_OPENLOOP_DAMPING_B;
    p_st_sv->u1_direction                 = MTR_CW;
    p_st_sv->u1_ctrl_loop_mode            = MOTOR_COMMON_CFG_LOOP_MODE_B;
    p_st_sv->f4_overcurrent_limit         = MOTOR_COMMON_OVERCURRENT_LIMIT_B;
    p_st_sv->f4_overvoltage_limit         = INVERTER_CFG_OVERVOLTAGE_LIMIT_B;
    p_st_sv->f4_undervoltage_limit        = INVERTER_CFG_UNDERVOLTAGE_LIMIT_B;
    p_st_sv->f4_overspeed_limit_rad       = (SPEED_CFG_SPEED_LIMIT_RPM_B * MTR_RPM2RAD);
    p_st_sv->f4_switch_phase_err_rad      = SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_RAD_B;
    p_st_sv->f4_id_down_speed_rad         = (SENSORLESS_VECTOR_ID_DOWN_SPEED_RPM_B * MTR_RPM2RAD);
    p_st_sv->f4_id_up_speed_rad           = (SENSORLESS_VECTOR_ID_UP_SPEED_RPM_B * MTR_RPM2RAD);

    /* Initialize phase error LPF */
    /* variable set */

    /* Current configuration set */
    p_cur_cfg->u1_flag_volt_err_comp_use = CURRENT_CFG_VOLT_ERR_COMP_B;
    p_cur_cfg->u2_offset_calc_time       = CURRENT_CFG_OFFSET_CALC_TIME_B;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    p_cur_cfg->s2_difference_minimum     = CURRENT_CFG_MIN_DIFFERENCE_DUTY_B;
    p_cur_cfg->s2_adjust_adc_delay       = CURRENT_CFG_ADJUST_ADC_DELAY_B;
#endif
    p_cur_cfg->f4_ctrl_period            = MOTOR_COMMON_CTRL_PERIOD_B;
    p_cur_cfg->f4_current_omega_hz       = CURRENT_CFG_OMEGA_B;
    p_cur_cfg->f4_current_zeta           = CURRENT_CFG_ZETA_B;
    p_cur_cfg->f4_id_up_step             = MOTOR_COMMON_ID_UP_STEP_RATE_B;
    p_cur_cfg->f4_id_down_step           = MOTOR_COMMON_ID_DOWN_STEP_RATE_B;
    p_cur_cfg->f4_iq_down_step_time_inv  = CURRENT_CFG_IQ_DOWN_STEP_TIME_INV_B;
    p_cur_cfg->f4_ol_ref_id              = CURRENT_CFG_REF_ID_OPENLOOP_B;
    p_cur_cfg->st_motor                  = p_st_sv->st_motor;

    /* BEMF observer */
    p_bemf_obs_cfg->f4_e_obs_omega_hz   = CURRENT_CFG_E_OBS_OMEGA_B;
    p_bemf_obs_cfg->f4_e_obs_zeta       = CURRENT_CFG_E_OBS_ZETA_B;
    p_bemf_obs_cfg->f4_pll_est_omega_hz = CURRENT_CFG_PLL_EST_OMEGA_B;
    p_bemf_obs_cfg->f4_pll_est_zeta     = CURRENT_CFG_PLL_EST_ZETA_B;

#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    st_cur_driver_cfg.BLDC1ShuntDutySet = CURRENT_CFG_FUNC_DUTY_SET_B;
    st_cur_driver_cfg.ADCTriggerSet     = CURRENT_CFG_FUNC_ADC_TRIGGER_SET_B;
    st_cur_driver_cfg.PWMMaxCountGet    = CURRENT_CFG_FUNC_PWM_MAX_COUNT_GET_B;
    R_MOTOR_CURRENT_DriverParameterUpdate(p_st_sv->p_st_cc, &st_cur_driver_cfg);
#endif

    /* Voltage error compensation*/
    static const float  volterr_array[VERR_COMP_ARY_SIZE] =
    {
        INVERTER_CFG_COMP_V0_B,  /* f4_comp_v[0] */
        INVERTER_CFG_COMP_V1_B,  /* f4_comp_v[1] */
        INVERTER_CFG_COMP_V2_B,  /* f4_comp_v[2] */
        INVERTER_CFG_COMP_V3_B,  /* f4_comp_v[3] */
        INVERTER_CFG_COMP_V4_B,  /* f4_comp_v[4] */
    };
    static const float  crnt_array[VERR_COMP_ARY_SIZE] =
    {
        INVERTER_CFG_COMP_I0_B,  /* f4_comp_i[0] */
        INVERTER_CFG_COMP_I1_B,  /* f4_comp_i[1] */
        INVERTER_CFG_COMP_I2_B,  /* f4_comp_i[2] */
        INVERTER_CFG_COMP_I3_B,  /* f4_comp_i[3] */
        INVERTER_CFG_COMP_I4_B   /* f4_comp_i[4] */
    };

    p_cur_cfg->p_volterr_array = (float *)&volterr_array[0];
    p_cur_cfg->p_crnt_array    = (float *)&crnt_array[0];

    /* Speed configuration set */
    p_spd_cfg->u1_flag_fluxwkn_use         = SPEED_CFG_FLUX_WEAKENING_B;
    p_spd_cfg->f4_speed_ctrl_period        = SPEED_CFG_CTRL_PERIOD_B;
    p_spd_cfg->f4_max_speed_rpm            = MOTOR_CFG_MAX_SPEED_RPM_B;
    p_spd_cfg->f4_speed_rate_limit_rpm     = SPEED_CFG_RATE_LIMIT_RPM_B;
    p_spd_cfg->f4_speed_omega_hz           = SPEED_CFG_OMEGA_B;
    p_spd_cfg->f4_speed_zeta               = SPEED_CFG_ZETA_B;
    p_spd_cfg->f4_speed_lpf_hz             = SPEED_CFG_LPF_OMEGA_B;
    p_spd_cfg->f4_opl2less_sw_time         = SPEED_OPL2LESS_SWITCH_TIME_B;
    p_spd_cfg->f4_ed_hpf_omega             = SPEED_OPL_DAMP_ED_HPF_OMEGA_B;
    p_spd_cfg->f4_ol_damping_zeta          = SPEED_OPL_DAMP_ZETA_B;
    p_spd_cfg->f4_ol_damping_fb_limit_rate = SPEED_OPL_DAMP_FB_SPEED_LIMIT_RATE_B;
    p_spd_cfg->f4_ol_ref_id                = CURRENT_CFG_REF_ID_OPENLOOP_B;
    p_spd_cfg->f4_id_down_speed_rpm        = SENSORLESS_VECTOR_ID_DOWN_SPEED_RPM_B;
    p_spd_cfg->st_motor                    = p_st_sv->st_motor;

    /* Setup current limits by nominal current of motor */
    motor_sensorless_vector_nominal_current_set(p_st_sv, MOTOR_CFG_NOMINAL_CURRENT_RMS_B);

    /* driver */
    p_driver_cfg->ADCDataGet           = DRIVER_CFG_FUNC_ADC_DATA_GET_B;
#if defined(MOTOR_SHUNT_TYPE_2_SHUNT)
    p_driver_cfg->BLDCDutySet          = DRIVER_CFG_FUNC_DUTY_SET_B;
#endif
    p_driver_cfg->PWMOutputStart       = DRIVER_CFG_FUNC_PWM_OUTPUT_START_B;
    p_driver_cfg->PWMOutputStop        = DRIVER_CFG_FUNC_PWM_OUTPUT_STOP_B;
    p_driver_cfg->f4_shunt_ohm         = INVERTER_CFG_SHUNT_RESIST;
    p_driver_cfg->f4_volt_gain         = INVERTER_CFG_VOLTAGE_GAIN;
    p_driver_cfg->f4_crnt_amp_gain     = INVERTER_CFG_CURRENT_AMP_GAIN;
    p_driver_cfg->f4_pwm_period_cnt    = MOTOR_COMMON_CARRIER_SET_BASE_B;
    p_driver_cfg->f4_pwm_dead_time_cnt = MOTOR_COMMON_DEADTIME_SET_B;

    /* sensorless vector cfg */
    p_sv_cfg->u1_flag_less_switch_use      = SPEED_CFG_LESS_SWITCH_B;
    p_sv_cfg->u1_flag_openloop_damping_use = SPEED_CFG_OPENLOOP_DAMPING_B;
    p_sv_cfg->f4_overspeed_limit_rpm       = SPEED_CFG_SPEED_LIMIT_RPM_B;
    p_sv_cfg->f4_switch_phase_err_deg      = SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_DEG_B;
    p_sv_cfg->f4_phase_err_lpf_cut_freq    = SENSORLESS_VECTOR_OPL2LESS_SWITCH_PHASE_ERR_LPF_CUT_FREQ_B;
    p_sv_cfg->f4_id_down_speed_rpm         = SENSORLESS_VECTOR_ID_DOWN_SPEED_RPM_B;
    p_sv_cfg->f4_id_up_speed_rpm           = SENSORLESS_VECTOR_ID_UP_SPEED_RPM_B;
    p_sv_cfg->f4_ctrl_period               = MOTOR_COMMON_CTRL_PERIOD_B;
    p_sv_cfg->st_motor                     = p_st_sv->st_motor;

} /* End of function r_app_sensorless_vector_b_default_init */

/***********************************************************************************************************************
* Function Name : r_app_current_a_init_ctrl
* Description   : motor a initialize current contorl control structure
* Arguments     : p_st_cc_init  - The pointer to the current control structure
* Return Value  : None
***********************************************************************************************************************/
static void r_app_current_a_init_ctrl(void *p_st_cc_init)
{
    st_current_control_t    * p_st_cc = (st_current_control_t *)p_st_cc_init;

    st_cc_cfg_t             * p_st_cc_cfg         = p_st_cc->p_st_cfg_init;
    st_bemf_observer_cfg_t  * p_bemf_obs_cfg_init = &p_st_cc_cfg->st_bemf_init_cfg;

    p_st_cc->u1_flag_volt_err_comp_use       = CURRENT_CFG_VOLT_ERR_COMP_A;
    p_st_cc->u1_state_id_ref                 = CURRENT_STATE_ID_ZERO_CONST;
    p_st_cc->u1_state_iq_ref                 = CURRENT_STATE_IQ_ZERO_CONST;
    p_st_cc->u1_flag_offset_calc             = MTR_FLG_CLR;
    p_st_cc->u2_offset_calc_time             = CURRENT_CFG_OFFSET_CALC_TIME_A;
    p_st_cc->u2_crnt_offset_cnt              = 0;
    p_st_cc->f4_ctrl_period                  = MOTOR_COMMON_CTRL_PERIOD_A;
    p_st_cc->f4_lim_iq                       = MOTOR_COMMON_LIMIT_IQ_A;
    p_st_cc->f4_offset_iu                    = 0.0f;
    p_st_cc->f4_offset_iw                    = 0.0f;
    p_st_cc->f4_sum_iu_ad                    = 0.0f;
    p_st_cc->f4_sum_iw_ad                    = 0.0f;
    p_st_cc->f4_id_up_step                   = MOTOR_COMMON_ID_UP_STEP_RATE_A;
    p_st_cc->f4_id_down_step                 = MOTOR_COMMON_ID_DOWN_STEP_RATE_A;
    p_st_cc->f4_iq_down_step                 = 0.0f;
    p_st_cc->f4_iq_down_step_time_inv        = CURRENT_CFG_IQ_DOWN_STEP_TIME_INV_A;
    p_st_cc->f4_ol_ref_id                    = CURRENT_CFG_REF_ID_OPENLOOP_A;
    p_st_cc->f4_va_max                       = 0.0f;
    p_st_cc->st_pi_id.f4_ilimit              = CURRENT_CFG_PI_INTEGRAL_LIMIT_VD_A;
    p_st_cc->st_pi_iq.f4_ilimit              = CURRENT_CFG_PI_INTEGRAL_LIMIT_VQ_A;
    p_st_cc->st_motor.u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS_A;
    p_st_cc->st_motor.f4_mtr_r               = MOTOR_CFG_RESISTANCE_A;
    p_st_cc->st_motor.f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE_A;
    p_st_cc->st_motor.f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE_A;
    p_st_cc->st_motor.f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX_A;
    p_st_cc->st_motor.f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA_A;
    p_st_cc->st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS_A;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    p_st_cc->s2_difference_minimum           = CURRENT_CFG_MIN_DIFFERENCE_DUTY_A;
    p_st_cc->s2_adjust_adc_delay             = CURRENT_CFG_ADJUST_ADC_DELAY_A;
    p_st_cc->f4_pwm_period_cnt               = MOTOR_COMMON_CARRIER_SET_BASE_A;
    p_st_cc->f4_pwm_dead_time_cnt            = MOTOR_COMMON_DEADTIME_SET_A;
#endif

    /* Current pi control gain */

    /* Modulation */

    /* Voltage error compensation */

    /* BEMF observer and PLL */
    (p_st_cc->st_bemf_observer).st_d_axis.f4_d_est_limit = MOTOR_COMMON_CURRENT_OBS_LIMIT_A;
    (p_st_cc->st_bemf_observer).st_q_axis.f4_d_est_limit = MOTOR_COMMON_CURRENT_OBS_LIMIT_A;
    p_bemf_obs_cfg_init->f4_e_obs_omega_hz = CURRENT_CFG_E_OBS_OMEGA_A;
    p_bemf_obs_cfg_init->f4_e_obs_zeta     = CURRENT_CFG_E_OBS_ZETA_A;
    /* p_st_cc->f4_ctrl_period = MOTOR_COMMON_CTRL_PERIOD_A */
    p_bemf_obs_cfg_init->f4_pll_est_omega_hz = CURRENT_CFG_PLL_EST_OMEGA_A;
    p_bemf_obs_cfg_init->f4_pll_est_zeta     = CURRENT_CFG_PLL_EST_ZETA_A;
    /* p_st_cc->f4_ctrl_period = MOTOR_COMMON_CTRL_PERIOD_A */

    /* Rotor angle parameter set */
    p_st_cc_cfg->f4_cfg_carrier_freq        = MOTOR_MCU_CFG_CARRIER_FREQ_A;
    p_st_cc_cfg->f4_cfg_deadtime            = INVERTER_CFG_DEADTIME_A;
    p_st_cc_cfg->f4_ad_sampling_time        = MOTOR_COMMON_AD_SAMPLING_TIME_A;
    p_st_cc_cfg->f4_current_verr_comp_limit = CURRENT_VERR_COMP_LIMIT_A;

    p_st_cc->p_st_cc_init = (void *)NULL;
} /* End of function r_app_current_a_init_ctrl */

/***********************************************************************************************************************
* Function Name : r_app_current_b_init_ctrl
* Description   : motor b initialize current contorl control structure
* Arguments     : p_st_cc_init  - The pointer to the current control structure
* Return Value  : None
***********************************************************************************************************************/
static void r_app_current_b_init_ctrl(void *p_st_cc_init)
{
    st_current_control_t * p_st_cc = (st_current_control_t *)p_st_cc_init;

    st_cc_cfg_t             * p_st_cc_cfg         = p_st_cc->p_st_cfg_init;
    st_bemf_observer_cfg_t  * p_bemf_obs_cfg_init = &p_st_cc_cfg->st_bemf_init_cfg;

    p_st_cc->u1_flag_volt_err_comp_use       = CURRENT_CFG_VOLT_ERR_COMP_B;
    p_st_cc->u1_state_id_ref                 = CURRENT_STATE_ID_ZERO_CONST;
    p_st_cc->u1_state_iq_ref                 = CURRENT_STATE_IQ_ZERO_CONST;
    p_st_cc->u1_flag_offset_calc             = MTR_FLG_CLR;
    p_st_cc->u2_offset_calc_time             = CURRENT_CFG_OFFSET_CALC_TIME_B;
    p_st_cc->u2_crnt_offset_cnt              = 0;
    p_st_cc->f4_ctrl_period                  = MOTOR_COMMON_CTRL_PERIOD_B;
    p_st_cc->f4_lim_iq                       = MOTOR_COMMON_LIMIT_IQ_B;
    p_st_cc->f4_offset_iu                    = 0.0f;
    p_st_cc->f4_offset_iw                    = 0.0f;
    p_st_cc->f4_sum_iu_ad                    = 0.0f;
    p_st_cc->f4_sum_iw_ad                    = 0.0f;
    p_st_cc->f4_id_up_step                   = MOTOR_COMMON_ID_UP_STEP_RATE_B;
    p_st_cc->f4_id_down_step                 = MOTOR_COMMON_ID_DOWN_STEP_RATE_B;
    p_st_cc->f4_iq_down_step                 = 0.0f;
    p_st_cc->f4_iq_down_step_time_inv        = CURRENT_CFG_IQ_DOWN_STEP_TIME_INV_B;
    p_st_cc->f4_ol_ref_id                    = CURRENT_CFG_REF_ID_OPENLOOP_B;
    p_st_cc->f4_va_max                       = 0.0f;
    p_st_cc->st_pi_id.f4_ilimit              = CURRENT_CFG_PI_INTEGRAL_LIMIT_VD_B;
    p_st_cc->st_pi_iq.f4_ilimit              = CURRENT_CFG_PI_INTEGRAL_LIMIT_VQ_B;
    p_st_cc->st_motor.u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS_B;
    p_st_cc->st_motor.f4_mtr_r               = MOTOR_CFG_RESISTANCE_B;
    p_st_cc->st_motor.f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE_B;
    p_st_cc->st_motor.f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE_B;
    p_st_cc->st_motor.f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX_B;
    p_st_cc->st_motor.f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA_B;
    p_st_cc->st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS_B;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    p_st_cc->s2_difference_minimum           = CURRENT_CFG_MIN_DIFFERENCE_DUTY_B;
    p_st_cc->s2_adjust_adc_delay             = CURRENT_CFG_BDJUST_BDC_DELAY_B;
    p_st_cc->f4_pwm_period_cnt               = MOTOR_COMMON_CARRIER_SET_BASE_B;
    p_st_cc->f4_pwm_dead_time_cnt            = MOTOR_COMMON_DEADTIME_SET_B;
#endif

    /* Current pi control gain */

    /* Modulation */

    /* Voltage error compensation */

    /* BEMF observer and PLL */
    (p_st_cc->st_bemf_observer).st_d_axis.f4_d_est_limit = MOTOR_COMMON_CURRENT_OBS_LIMIT_B;
    (p_st_cc->st_bemf_observer).st_q_axis.f4_d_est_limit = MOTOR_COMMON_CURRENT_OBS_LIMIT_B;
    p_bemf_obs_cfg_init->f4_e_obs_omega_hz = CURRENT_CFG_E_OBS_OMEGA_B;
    p_bemf_obs_cfg_init->f4_e_obs_zeta     = CURRENT_CFG_E_OBS_ZETA_B;
    /* p_st_cc->f4_ctrl_period = MOTOR_COMMON_CTRL_PERIOD_B */
    p_bemf_obs_cfg_init->f4_pll_est_omega_hz = CURRENT_CFG_PLL_EST_OMEGA_B;
    p_bemf_obs_cfg_init->f4_pll_est_zeta     = CURRENT_CFG_PLL_EST_ZETA_B;
    /* p_st_cc->f4_ctrl_period = MOTOR_COMMON_CTRL_PERIOD_A */

    /* Rotor angle parameter set */
    p_st_cc_cfg->f4_cfg_carrier_freq        = MOTOR_MCU_CFG_CARRIER_FREQ_B;
    p_st_cc_cfg->f4_cfg_deadtime            = INVERTER_CFG_DEADTIME_B;
    p_st_cc_cfg->f4_ad_sampling_time        = MOTOR_COMMON_AD_SAMPLING_TIME_B;
    p_st_cc_cfg->f4_current_verr_comp_limit = CURRENT_VERR_COMP_LIMIT_B;

    p_st_cc->p_st_cc_init = (void *)NULL;
}  /* End of function r_app_current_b_init_ctrl */

/***********************************************************************************************************************
* Function Name : r_app_speed_a_init_ctrl
* Description   : Initialize speed control structure(motor A)
* Arguments     : p_st_sc_init  - The pointer to the speed control structure for initialization
* Return Value  : None
***********************************************************************************************************************/
static void r_app_speed_a_init_ctrl(void *p_st_sc_init)
{
    st_speed_control_t * p_st_sc;
    st_spd_cfg_t       * p_sc_cfg;

    p_st_sc  = (st_speed_control_t *)p_st_sc_init;
    p_sc_cfg = p_st_sc->p_st_cfg_init;

    p_st_sc->u1_flag_fluxwkn_use             = SPEED_CFG_FLUX_WEAKENING_A;
    p_st_sc->f4_speed_ctrl_period            = SPEED_CFG_CTRL_PERIOD_A;
    p_st_sc->f4_ref_speed_rad                = 0.0f;
    p_st_sc->f4_ref_speed_rad_manual         = 0.0f;
    p_st_sc->f4_max_speed_rad                = (MOTOR_CFG_MAX_SPEED_RPM_A * MTR_RPM2RAD);
    p_st_sc->f4_speed_rate_limit_rad         = (SPEED_CFG_CTRL_PERIOD_A * SPEED_CFG_RATE_LIMIT_RPM_A * MTR_RPM2RAD);
    p_st_sc->f4_opl2less_sw_time             = SPEED_OPL2LESS_SWITCH_TIME_A;
    p_st_sc->st_motor.u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS_A;
    p_st_sc->st_motor.f4_mtr_r               = MOTOR_CFG_RESISTANCE_A;
    p_st_sc->st_motor.f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE_A;
    p_st_sc->st_motor.f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE_A;
    p_st_sc->st_motor.f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX_A;
    p_st_sc->st_motor.f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA_A;
    p_st_sc->st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS_A;

    /* Initialize member of PI control structure */
    p_sc_cfg->f4_pi_integral_limit_iq = MOTOR_COMMON_PI_INTEGRAL_LIMIT_IQ_A;
    p_sc_cfg->f4_lim_iq               = MOTOR_COMMON_LIMIT_IQ_A;
    
    /* Initialize Flux-weakening module */
    
    /* Initialize open-loop damping control module */

    /* Initialize speed LPF */

    p_st_sc->p_st_sc_init = (void *)NULL;

} /* End of function r_app_speed_a_init_ctrl */

/***********************************************************************************************************************
* Function Name : r_app_speed_b_init_ctrl
* Description   : Initialize speed control structure(motor B)
* Arguments     : p_st_sc_init  - The pointer to the speed control structure for initialization
* Return Value  : None
***********************************************************************************************************************/
static void r_app_speed_b_init_ctrl(void *p_st_sc_init)
{
    st_speed_control_t * p_st_sc;
    st_spd_cfg_t       * p_sc_cfg;

    p_st_sc  = (st_speed_control_t *)p_st_sc_init;
    p_sc_cfg = p_st_sc->p_st_cfg_init;

    p_st_sc->u1_flag_fluxwkn_use             = SPEED_CFG_FLUX_WEAKENING_B;
    p_st_sc->f4_speed_ctrl_period            = SPEED_CFG_CTRL_PERIOD_B;
    p_st_sc->f4_ref_speed_rad                = 0.0f;
    p_st_sc->f4_ref_speed_rad_manual         = 0.0f;
    p_st_sc->f4_max_speed_rad                = (MOTOR_CFG_MAX_SPEED_RPM_B * MTR_RPM2RAD);
    p_st_sc->f4_speed_rate_limit_rad         = (SPEED_CFG_CTRL_PERIOD_B * SPEED_CFG_RATE_LIMIT_RPM_B * MTR_RPM2RAD);
    p_st_sc->f4_opl2less_sw_time             = SPEED_OPL2LESS_SWITCH_TIME_B;
    p_st_sc->st_motor.u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS_B;
    p_st_sc->st_motor.f4_mtr_r               = MOTOR_CFG_RESISTANCE_B;
    p_st_sc->st_motor.f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE_B;
    p_st_sc->st_motor.f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE_B;
    p_st_sc->st_motor.f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX_B;
    p_st_sc->st_motor.f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA_B;
    p_st_sc->st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS_B;

    /* Initialize member of PI control structure */
    p_sc_cfg->f4_pi_integral_limit_iq = MOTOR_COMMON_PI_INTEGRAL_LIMIT_IQ_B;
    p_sc_cfg->f4_lim_iq = MOTOR_COMMON_LIMIT_IQ_B;

    /* Initialize Flux-weakening module */

    /* Initialize open-loop damping control module */

    /* Initialize speed LPF */

    p_st_sc->p_st_sc_init = (void *)NULL;

} /* End of function r_app_speed_b_init_ctrl */

/***********************************************************************************************************************
* Function Name : r_app_driver_a_init_ctrl
* Description   : Initialize driver control structure(motor A)
* Arguments     : p_st_driver_init  - The pointer to the driver control structure for initialization
* Return Value  : None
***********************************************************************************************************************/
static void r_app_driver_a_init_ctrl(void *p_st_driver_init)
{
    st_motor_driver_t * p_st_driver = (st_motor_driver_t *) p_st_driver_init;

    p_st_driver->f4_ad_crnt_per_digit = 0.0f;
    p_st_driver->f4_ad_vdc_per_digit  = 0.0f;
    p_st_driver->f4_pwm_period_cnt    = 0.0f;
    p_st_driver->f4_pwm_dead_time_cnt = 0.0f;
    
    p_st_driver->p_st_driver_init = (void *)NULL;
} /* End of function r_app_driver_a_init_ctrl */

/***********************************************************************************************************************
* Function Name : r_app_driver_b_init_ctrl
* Description   : Initialize driver control structure(motor B)
* Arguments     : p_st_driver_init  - The pointer to the driver control structure for initialization
* Return Value  : None
***********************************************************************************************************************/
static void r_app_driver_b_init_ctrl(void *p_st_driver_init)
{
    st_motor_driver_t * p_st_driver = (st_motor_driver_t *) p_st_driver_init;

    p_st_driver->f4_ad_crnt_per_digit = 0.0f;
    p_st_driver->f4_ad_vdc_per_digit  = 0.0f;
    p_st_driver->f4_pwm_period_cnt    = 0.0f;
    p_st_driver->f4_pwm_dead_time_cnt = 0.0f;

    p_st_driver->p_st_driver_init = (void *)NULL;
} /* End of function r_app_driver_b_init_ctrl */

/***********************************************************************************************************************
* Function Name : r_app_main_init_motor_ctrl
* Description   : Open motor control module
* Arguments     : 
* Return Value  : None
***********************************************************************************************************************/
static void r_app_main_init_motor_ctrl(st_sensorless_vector_control_t *p_st_sensorless)
{
    /* Create a Motor Instance */
    R_MOTOR_SENSORLESS_VECTOR_Open(p_st_sensorless);
} /* End of function r_app_main_init_motor_ctrl */

/***********************************************************************************************************************
* Function Name : r_app_main_start_motor_ctrl
* Description   : Start motor control
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_main_start_motor_ctrl(void)
{
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    /* initialize timer setting */
    R_Config_MTU3_MTU4_StopTimerCtrl();
    R_Config_MTU3_MTU4_StartTimerCount();

    /* Start of A/D converter */
    R_Config_MTU3_MTU4_StartAD();
    R_Config_S12AD2_Start();
#elif defined(MOTOR_SHUNT_TYPE_2_SHUNT)
    /* initialize timer setting */
    R_Config_MOTOR_A_StopTimerCtrl();
    R_Config_MOTOR_B_StopTimerCtrl();
    R_Config_MOTOR_A_StartTimerCount();
    R_Config_MOTOR_B_StartTimerCount();

    /* Start of A/D converter */
    R_Config_MOTOR_A_StartAD();
    R_Config_MOTOR_B_StartAD();

    R_Config_S12AD2_Start();
#endif
    /* Start of CMT0 */
    R_Config_CMT0_Start();

    /* Clear POE with Create function before starting POE to avoid miss detection */
    R_Config_POE_Create();
    R_Config_POE_Start();

    /* Clear POEG with Create function before starting POEG to avoid miss detection */
    R_Config_POEG_Create();
    R_Config_POEG_Start();
} /* End of function r_app_main_start_motor_ctrl */
