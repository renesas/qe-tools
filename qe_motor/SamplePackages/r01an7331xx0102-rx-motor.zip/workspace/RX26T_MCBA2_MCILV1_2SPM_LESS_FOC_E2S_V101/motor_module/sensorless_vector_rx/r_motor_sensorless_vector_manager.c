/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_sensorless_vector_manager.c
* Description : The processes of motor control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 30.10.2021 1.00
*         : 12.05.2022 1.10
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <math.h>
#include <machine.h>
#include <stdint.h>
/* Main associated header file */
#include "r_motor_sensorless_vector_manager.h"

/* Project headers */
#include "r_motor_common.h"
#include "r_motor_pi_control.h"
#include "r_motor_sensorless_vector_statemachine.h"
#include "r_motor_sensorless_vector_protection.h"
#include "r_motor_current_api.h"
#include "r_motor_speed_api.h"
#include "r_motor_driver.h"
#include "r_smc_entry.h"

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name : motor_sensorless_vector_default_init
* Description   : Initializes motor drive modules with default configuration
* Arguments     : p_st_sensorless_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_sensorless_vector_default_init(st_sensorless_vector_control_t *p_st_sensorless_vector)
{
    st_current_cfg_t           * p_cur_cfg;
    st_bemf_observer_cfg_t     * p_bemf_obs_cfg;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    st_current_driver_cfg_t      st_cur_driver_cfg;
#endif
    st_speed_cfg_t             * p_spd_cfg;
    st_motor_driver_cfg_t      * p_driver_cfg;
    st_sensorless_vector_cfg_t * p_sv_cfg;

    st_sensorless_vector_control_t * p_st_sv_init =
            (st_sensorless_vector_control_t *)p_st_sensorless_vector->p_st_sv_init;

    st_current_cfg_t        st_cur_cfg;
    st_bemf_observer_cfg_t  st_bemf_obs_cfg;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    st_current_driver_cfg_t st_cur_driver_cfg;
#endif
    st_speed_cfg_t          st_spd_cfg;
    st_motor_driver_cfg_t   st_driver_cfg;

    p_cur_cfg      = &p_st_sv_init->p_st_cc->p_st_cfg_init->st_cc_init_cfg;
    p_bemf_obs_cfg = &p_st_sv_init->p_st_cc->p_st_cfg_init->st_bemf_init_cfg;
    p_spd_cfg      = &p_st_sv_init->p_st_sc->p_st_cfg_init->st_sc_init_cfg;
    p_driver_cfg   = &p_st_sv_init->p_st_driver->p_st_cfg_init->st_drv_init_cfg;
    p_sv_cfg       = &p_st_sv_init->p_st_cfg_init->st_sv_init_cfg;


    /* Initialize member of motor parameter structure */
    p_st_sensorless_vector->st_motor.u2_mtr_pp              = p_st_sv_init->st_motor.u2_mtr_pp;
    p_st_sensorless_vector->st_motor.f4_mtr_r               = p_st_sv_init->st_motor.f4_mtr_r;
    p_st_sensorless_vector->st_motor.f4_mtr_ld              = p_st_sv_init->st_motor.f4_mtr_ld;
    p_st_sensorless_vector->st_motor.f4_mtr_lq              = p_st_sv_init->st_motor.f4_mtr_lq;
    p_st_sensorless_vector->st_motor.f4_mtr_m               = p_st_sv_init->st_motor.f4_mtr_m;
    p_st_sensorless_vector->st_motor.f4_mtr_j               = p_st_sv_init->st_motor.f4_mtr_j;
    p_st_sensorless_vector->st_motor.f4_nominal_current_rms = p_st_sv_init->st_motor.f4_nominal_current_rms;

    p_st_sensorless_vector->u1_flag_less_switch_use      = p_st_sv_init->u1_flag_less_switch_use;
    p_st_sensorless_vector->u1_flag_openloop_damping_use = p_st_sv_init->u1_flag_openloop_damping_use;
    p_st_sensorless_vector->u1_direction                 = p_st_sv_init->u1_direction;
    p_st_sensorless_vector->u1_ctrl_loop_mode            = p_st_sv_init->u1_ctrl_loop_mode;
    p_st_sensorless_vector->f4_overcurrent_limit         = p_st_sv_init->f4_overcurrent_limit;
    p_st_sensorless_vector->f4_overvoltage_limit         = p_st_sv_init->f4_overvoltage_limit;
    p_st_sensorless_vector->f4_undervoltage_limit        = p_st_sv_init->f4_undervoltage_limit;
    p_st_sensorless_vector->f4_overspeed_limit_rad       = p_st_sv_init->f4_overspeed_limit_rad;
    p_st_sensorless_vector->f4_switch_phase_err_rad      = p_st_sv_init->f4_switch_phase_err_rad;
    p_st_sensorless_vector->f4_id_down_speed_rad         = p_st_sv_init->f4_id_down_speed_rad;
    p_st_sensorless_vector->f4_id_up_speed_rad           = p_st_sv_init->f4_id_up_speed_rad;

    /* Initialize phase error LPF */
    motor_filter_first_order_lpff_init(&p_st_sensorless_vector->st_phase_err_lpf);
    motor_sensorless_phase_err_lpf_setup(p_st_sensorless_vector,
                                        p_sv_cfg->f4_phase_err_lpf_cut_freq,
                                        p_spd_cfg->f4_speed_ctrl_period);

    /* Current configuration set */
    st_cur_cfg.u1_flag_volt_err_comp_use = p_cur_cfg->u1_flag_volt_err_comp_use;
    st_cur_cfg.u2_offset_calc_time       = p_cur_cfg->u2_offset_calc_time;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    st_cur_cfg.s2_difference_minimum     = CURRENT_CFG_MIN_DIFFERENCE_DUTY;
    st_cur_cfg.s2_adjust_adc_delay       = CURRENT_CFG_ADJUST_ADC_DELAY;
#endif
    st_cur_cfg.f4_ctrl_period            = p_cur_cfg->f4_ctrl_period;
    st_cur_cfg.f4_current_omega_hz       = p_cur_cfg->f4_current_omega_hz;
    st_cur_cfg.f4_current_zeta           = p_cur_cfg->f4_current_zeta;
    st_cur_cfg.f4_id_up_step             = p_cur_cfg->f4_id_up_step;
    st_cur_cfg.f4_id_down_step           = p_cur_cfg->f4_id_down_step;
    st_cur_cfg.f4_iq_down_step_time_inv  = p_cur_cfg->f4_iq_down_step_time_inv;
    st_cur_cfg.f4_ol_ref_id              = p_cur_cfg->f4_ol_ref_id;
    st_cur_cfg.st_motor                  = p_st_sensorless_vector->st_motor;
    R_MOTOR_CURRENT_ParameterUpdate(p_st_sensorless_vector->p_st_cc, &st_cur_cfg);

    /* BEMF observer */
    st_bemf_obs_cfg.f4_e_obs_omega_hz   = p_bemf_obs_cfg->f4_e_obs_omega_hz;
    st_bemf_obs_cfg.f4_e_obs_zeta       = p_bemf_obs_cfg->f4_e_obs_zeta;
    st_bemf_obs_cfg.f4_pll_est_omega_hz = p_bemf_obs_cfg->f4_pll_est_omega_hz;
    st_bemf_obs_cfg.f4_pll_est_zeta     = p_bemf_obs_cfg->f4_pll_est_zeta;
    R_MOTOR_CURRENT_BEMFObserverParameterUpdate(p_st_sensorless_vector->p_st_cc, &st_bemf_obs_cfg);

#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
    st_cur_driver_cfg.BLDC1ShuntDutySet         = p_st_sensorless_vector->p_st_cc_init->BLDC1ShuntDutySet;
    st_cur_driver_cfg.ADCTriggerSet             = p_st_sensorless_vector->p_st_cc_init->ADCTriggerSet;
    st_cur_driver_cfg.PWMMaxCountGet            = p_st_sensorless_vector->p_st_cc_init->PWMMaxCountGet;
    R_MOTOR_CURRENT_DriverParameterUpdate(p_st_sensorless_vector->p_st_cc, &st_cur_driver_cfg);
#endif

    /* Voltage error compensation*/
    float ref_voltage;
    ref_voltage = INVERTER_CFG_INPUT_V;
    R_MOTOR_CURRENT_VoltErrCompParamSet(p_st_sensorless_vector->p_st_cc,
                                        p_cur_cfg->p_crnt_array,
                                        p_cur_cfg->p_volterr_array,
                                        ref_voltage);

    /* Speed configuration set */
    st_spd_cfg.u1_flag_fluxwkn_use         = p_spd_cfg->u1_flag_fluxwkn_use;
    st_spd_cfg.f4_speed_ctrl_period        = p_spd_cfg->f4_speed_ctrl_period;
    st_spd_cfg.f4_max_speed_rpm            = p_spd_cfg->f4_max_speed_rpm;
    st_spd_cfg.f4_speed_rate_limit_rpm     = p_spd_cfg->f4_speed_rate_limit_rpm;
    st_spd_cfg.f4_speed_omega_hz           = p_spd_cfg->f4_speed_omega_hz;
    st_spd_cfg.f4_speed_zeta               = p_spd_cfg->f4_speed_zeta;
    st_spd_cfg.f4_speed_lpf_hz             = p_spd_cfg->f4_speed_lpf_hz;
    st_spd_cfg.f4_opl2less_sw_time         = p_spd_cfg->f4_opl2less_sw_time;
    st_spd_cfg.f4_ed_hpf_omega             = p_spd_cfg->f4_ed_hpf_omega;
    st_spd_cfg.f4_ol_damping_zeta          = p_spd_cfg->f4_ol_damping_zeta;
    st_spd_cfg.f4_ol_damping_fb_limit_rate = p_spd_cfg->f4_ol_damping_fb_limit_rate;
    st_spd_cfg.f4_ol_ref_id                = p_spd_cfg->f4_ol_ref_id;
    st_spd_cfg.f4_id_down_speed_rpm        = p_spd_cfg->f4_id_down_speed_rpm;
    st_spd_cfg.st_motor                    = p_st_sensorless_vector->st_motor;
    R_MOTOR_SPEED_ParameterUpdate(p_st_sensorless_vector->p_st_sc, &st_spd_cfg);

    /* Setup current limits by nominal current of motor */
    motor_sensorless_vector_nominal_current_set(p_st_sensorless_vector, p_st_sv_init->st_motor.f4_nominal_current_rms);

    /* driver */
    st_driver_cfg.ADCDataGet           = p_driver_cfg->ADCDataGet;
#if defined(MOTOR_SHUNT_TYPE_2_SHUNT)
    st_driver_cfg.BLDCDutySet          = p_driver_cfg->BLDCDutySet;
#endif
    st_driver_cfg.PWMOutputStart       = p_driver_cfg->PWMOutputStart;
    st_driver_cfg.PWMOutputStop        = p_driver_cfg->PWMOutputStop;
    st_driver_cfg.f4_shunt_ohm         = p_driver_cfg->f4_shunt_ohm;
    st_driver_cfg.f4_volt_gain         = p_driver_cfg->f4_volt_gain;
    st_driver_cfg.f4_crnt_amp_gain     = p_driver_cfg->f4_crnt_amp_gain;
    st_driver_cfg.f4_pwm_period_cnt    = p_driver_cfg->f4_pwm_period_cnt;
    st_driver_cfg.f4_pwm_dead_time_cnt = p_driver_cfg->f4_pwm_dead_time_cnt;
    R_MOTOR_DRIVER_ParameterUpdate(p_st_sensorless_vector->p_st_driver, &st_driver_cfg);

    /* Reset motor */
    motor_sensorless_vector_reset(p_st_sensorless_vector);
} /* End of function motor_sensorless_vector_default_init */

/**********************************************************************************************************************
* Function Name : motor_sensorless_vector_reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : p_st_sensorless_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_sensorless_vector_reset(st_sensorless_vector_control_t *p_st_sensorless_vector)
{
    /* Reset status structure members */
    p_st_sensorless_vector->u1_flag_down_to_ol   = MTR_FLG_CLR;
    p_st_sensorless_vector->u1_state_id_ref      = CURRENT_STATE_ID_ZERO_CONST;
    p_st_sensorless_vector->u1_state_iq_ref      = CURRENT_STATE_IQ_ZERO_CONST;
    p_st_sensorless_vector->u1_state_speed_ref   = SPEED_STATE_ZERO_CONST;
    p_st_sensorless_vector->u2_error_status      = MOTOR_SENSORLESS_VECTOR_ERROR_NONE;
    p_st_sensorless_vector->u2_run_mode          = MOTOR_MODE_INIT;
    p_st_sensorless_vector->f4_vdc_ad            = 0.0f;
    p_st_sensorless_vector->f4_iu_ad             = 0.0f;
    p_st_sensorless_vector->f4_iv_ad             = 0.0f;
    p_st_sensorless_vector->f4_iw_ad             = 0.0f;
    p_st_sensorless_vector->f4_phase_err_rad_lpf = 0.0f;
    p_st_sensorless_vector->f4_damp_comp_speed   = 0.0f;
    p_st_sensorless_vector->f4_ol_speed_rad      = 0.0f;

    /* Reset phase error LPF */
    motor_filter_first_order_lpff_reset(&p_st_sensorless_vector->st_phase_err_lpf);

    /* Current output reset */
    p_st_sensorless_vector->st_current_output.u1_flag_offset_calc = MTR_FLG_CLR;
#if defined(MOTOR_SHUNT_TYPE_1_SHUNT)
#else
    p_st_sensorless_vector->st_current_output.f4_modu             = 0.0f;
    p_st_sensorless_vector->st_current_output.f4_modv             = 0.0f;
    p_st_sensorless_vector->st_current_output.f4_modw             = 0.0f;
#endif
    p_st_sensorless_vector->st_current_output.f4_neutral_duty     = 0.0f;
    p_st_sensorless_vector->st_current_output.f4_va_max           = 0.0f;
    p_st_sensorless_vector->st_current_output.f4_ref_id_ctrl      = 0.0f;
    p_st_sensorless_vector->st_current_output.f4_speed_rad        = 0.0f;
    p_st_sensorless_vector->st_current_output.f4_ed               = 0.0f;
    p_st_sensorless_vector->st_current_output.f4_eq               = 0.0f;
    p_st_sensorless_vector->st_current_output.f4_phase_err_rad    = 0.0f;

    /* Speed output reset */
    p_st_sensorless_vector->st_speed_output.f4_id_ref             = 0.0f;
    p_st_sensorless_vector->st_speed_output.f4_iq_ref             = 0.0f;
    p_st_sensorless_vector->st_speed_output.f4_ref_speed_rad_ctrl = 0.0f;
    p_st_sensorless_vector->st_speed_output.f4_speed_rad_lpf      = 0.0f;

    /* Reset current control module */
    R_MOTOR_CURRENT_Reset(p_st_sensorless_vector->p_st_cc);

    /* Reset speed control module */
    R_MOTOR_SPEED_Reset(p_st_sensorless_vector->p_st_sc);
} /* End of function motor_sensorless_vector_reset */

/***********************************************************************************************************************
* Function Name : motor_sensorless_vector_decide_direction
* Description   : Decide direction
* Arguments     : p_st_sensorless_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_sensorless_vector_decide_direction(st_sensorless_vector_control_t *p_st_sensorless_vector)
{
    if (0.0f <= p_st_sensorless_vector->st_speed_output.f4_speed_rad_lpf)
    {
        p_st_sensorless_vector->u1_direction = MTR_CW;
    }
    else if (0.0f > p_st_sensorless_vector->st_speed_output.f4_speed_rad_lpf)
    {
        p_st_sensorless_vector->u1_direction = MTR_CCW;
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_sensorless_vector_decide_direction */

/***********************************************************************************************************************
* Function Name : motor_sensorless_vector_error_process
* Description   : Sets error flags and trigger error event when u2_error_flag is not zero
* Arguments     : p_st_sensorless_vector - The pointer to the motor control management data structure
*                 u2_error_flag - The error flags of the errors to report
* Return Value  : None
***********************************************************************************************************************/
void motor_sensorless_vector_error_process(st_sensorless_vector_control_t *p_st_sensorless_vector,
                                            uint16_t u2_error_flag)
{
    if (MOTOR_SENSORLESS_VECTOR_ERROR_NONE != u2_error_flag)
    {
        p_st_sensorless_vector->u2_error_status |= u2_error_flag;
        motor_sensorless_vector_statemachine_event(&p_st_sensorless_vector->st_stm,
                                                   p_st_sensorless_vector,
                                                   STATEMACHINE_EVENT_ERROR);
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_sensorless_vector_error_process */

/***********************************************************************************************************************
* Function Name : motor_sensorless_vector_speed_status_select
* Description   : Performs state transition related to speed reference
* Arguments     : p_st_sensorless_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_sensorless_vector_speed_status_select(st_sensorless_vector_control_t *p_st_sensorless_vector)
{
    if ((SPEED_STATE_ZERO_CONST == p_st_sensorless_vector->u1_state_speed_ref) &&
        (MOTOR_MODE_DRIVE       == p_st_sensorless_vector->u2_run_mode))
    {
        p_st_sensorless_vector->u1_state_speed_ref = SPEED_STATE_MANUAL;
    }
} /* End of function motor_sensorless_vector_speed_status_select */

/***********************************************************************************************************************
* Function Name : motor_sensorless_vector_iq_status_select
* Description   : Performs state transition related to q-axis current reference
* Arguments     : p_st_sensorless_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_sensorless_vector_iq_status_select(st_sensorless_vector_control_t *p_st_sensorless_vector)
{
    uint8_t u1_temp0;
    float   f4_temp0;

    if (MTR_FLG_SET == p_st_sensorless_vector->u1_flag_down_to_ol)
    {
        p_st_sensorless_vector->u1_state_iq_ref = CURRENT_STATE_IQ_DOWN;
    }

    switch (p_st_sensorless_vector->u1_state_iq_ref)
    {
        case CURRENT_STATE_IQ_ZERO_CONST:
            f4_temp0 = fabsf(p_st_sensorless_vector->st_speed_output.f4_ref_speed_rad_ctrl);

            if (MTR_FLG_SET == p_st_sensorless_vector->u1_flag_openloop_damping_use)
            {
                /* Open loop damping control*/
                p_st_sensorless_vector->f4_damp_comp_speed = R_MOTOR_SPEED_OplDampCtrl(
                                                                    p_st_sensorless_vector->p_st_sc,
                                                                    p_st_sensorless_vector->st_current_output.f4_ed);
            }

            if (f4_temp0 >= p_st_sensorless_vector->f4_id_down_speed_rad)
            {
                if (MTR_FLG_SET == p_st_sensorless_vector->u1_flag_less_switch_use)
                {
                    p_st_sensorless_vector->u1_state_iq_ref = CURRENT_STATE_IQ_AUTO_ADJ;
                    R_MOTOR_SPEED_Opl2lessPreprocess(p_st_sensorless_vector->p_st_sc,
                                                     p_st_sensorless_vector->st_current_output.f4_ref_id_ctrl,
                                                     p_st_sensorless_vector->f4_phase_err_rad_lpf);
                }
                else
                {
                    p_st_sensorless_vector->u1_state_iq_ref = CURRENT_STATE_IQ_SPEED_PI_OUTPUT;
                    R_MOTOR_CURRENT_HuntingSuppress(p_st_sensorless_vector->p_st_cc,
                                                    p_st_sensorless_vector->st_speed_output.f4_ref_speed_rad_ctrl);
                }
                if (MTR_FLG_SET == p_st_sensorless_vector->u1_flag_openloop_damping_use)
                {
                    R_MOTOR_SPEED_OplDampReset(p_st_sensorless_vector->p_st_sc);
                    p_st_sensorless_vector->f4_damp_comp_speed = 0.0f;
                }
            }
            break;

        case CURRENT_STATE_IQ_AUTO_ADJ:
            p_st_sensorless_vector->st_speed_output.f4_iq_ref = R_MOTOR_SPEED_Opl2lessReferenceIqCalc(
                                                        p_st_sensorless_vector->p_st_sc,
                                                        p_st_sensorless_vector->st_current_output.f4_ed,
                                                        p_st_sensorless_vector->st_current_output.f4_eq,
                                                        p_st_sensorless_vector->st_current_output.f4_ref_id_ctrl,
                                                        p_st_sensorless_vector->st_current_output.f4_phase_err_rad);

            if (MTR_CW == p_st_sensorless_vector->u1_direction)
            {
                u1_temp0 = (p_st_sensorless_vector->st_current_output.f4_phase_err_rad <=
                                p_st_sensorless_vector->f4_switch_phase_err_rad);
            }
            else if (MTR_CCW == p_st_sensorless_vector->u1_direction)
            {
                u1_temp0 = ((p_st_sensorless_vector->st_current_output.f4_phase_err_rad) >= 
                            (-p_st_sensorless_vector->f4_switch_phase_err_rad));
            }
            else
            {
                /* Do Nothing */
            }

            if (1 == u1_temp0)
            {
                p_st_sensorless_vector->u1_state_iq_ref = CURRENT_STATE_IQ_SPEED_PI_OUTPUT;

                /* Preset for suppress speed hunting */
                R_MOTOR_SPEED_SwitchingFlagSet(p_st_sensorless_vector->p_st_sc);
                R_MOTOR_CURRENT_HuntingSuppress(p_st_sensorless_vector->p_st_cc,
                                                p_st_sensorless_vector->st_speed_output.f4_ref_speed_rad_ctrl);
                R_MOTOR_SPEED_HuntingSuppress(p_st_sensorless_vector->p_st_sc,
                                              p_st_sensorless_vector->st_speed_output.f4_iq_ref);
            }
            break;

        case CURRENT_STATE_IQ_DOWN:
            if (p_st_sensorless_vector->p_st_cc->f4_ref_iq_ctrl <= 0.0f)
            {
                p_st_sensorless_vector->u1_state_iq_ref = CURRENT_STATE_IQ_ZERO_CONST;
            }
            break;

        default:
            /* Do Nothing */
            break;
    }
} /* End of function motor_sensorless_vector_iq_status_select */

/***********************************************************************************************************************
* Function Name : motor_sensorless_vector_id_status_select
* Description   : Performs state transition related to d-axis current reference
* Arguments     : p_st_sensorless_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_sensorless_vector_id_status_select(st_sensorless_vector_control_t *p_st_sensorless_vector)
{
    float f4_temp0;

    if (MTR_FLG_SET == p_st_sensorless_vector->u1_flag_down_to_ol)
    {
        p_st_sensorless_vector->u1_state_id_ref = CURRENT_STATE_ID_UP;
    }

    switch (p_st_sensorless_vector->u1_state_id_ref)
    {
        case CURRENT_STATE_ID_ZERO_CONST:
            if (MOTOR_MODE_BOOT == p_st_sensorless_vector->u2_run_mode)
            {
                p_st_sensorless_vector->u1_state_id_ref = CURRENT_STATE_ID_UP;
            }
            break;

        case CURRENT_STATE_ID_UP:
            if (p_st_sensorless_vector->p_st_cc->f4_ref_id_ctrl >= p_st_sensorless_vector->p_st_cc->f4_ol_ref_id)
            {
                p_st_sensorless_vector->u1_state_id_ref = CURRENT_STATE_ID_MANUAL;
            }
            break;

        case CURRENT_STATE_ID_MANUAL:
            f4_temp0 = fabsf(p_st_sensorless_vector->st_speed_output.f4_ref_speed_rad_ctrl);
            if (f4_temp0 >= p_st_sensorless_vector->f4_id_down_speed_rad)
            {
                p_st_sensorless_vector->u1_state_id_ref = CURRENT_STATE_ID_DOWN;
            }
            break;

        case CURRENT_STATE_ID_DOWN:
            if (0.0f >= p_st_sensorless_vector->p_st_cc->f4_ref_id_ctrl)
            {
                p_st_sensorless_vector->u1_state_id_ref = CURRENT_STATE_ID_INPUT;
            }
            break;

        default:
            /* Do Nothing */
            break;
    }
} /* End of function motor_sensorless_vector_id_status_select */

/***********************************************************************************************************************
* Function Name : motor_sensorless_vector_nominal_current_set
* Description   : Setup current related limit values by the nominal current of motor
* Arguments     : p_st_sensorless_vector - The pointer to the motor control management data structure
*                 f4_nominal_current_rms - The nominal current[Arms] of motor
* Return Value  : None
***********************************************************************************************************************/
void motor_sensorless_vector_nominal_current_set(st_sensorless_vector_control_t *p_st_sensorless_vector,
                                                    float f4_nominal_current_rms)
{
    p_st_sensorless_vector->f4_overcurrent_limit = (f4_nominal_current_rms * MTR_SQRT_2)
                                                    * MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT;

    if (p_st_sensorless_vector->f4_overcurrent_limit > INVERTER_CFG_CURRENT_LIMIT)
    {
        p_st_sensorless_vector->f4_overcurrent_limit = INVERTER_CFG_CURRENT_LIMIT;
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_sensorless_vector_nominal_current_set */

/***********************************************************************************************************************
* Function Name : motor_sensorless_vector_module_activate
* Description   : Activate modules
* Arguments     : p_st_sensorless_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_sensorless_vector_module_activate(st_sensorless_vector_control_t *p_st_sensorless_vector)
{
    switch (p_st_sensorless_vector->u1_ctrl_loop_mode)
    {
        case MOTOR_LOOP_SPEED:
            R_MOTOR_CURRENT_Run(p_st_sensorless_vector->p_st_cc);
            R_MOTOR_SPEED_Run(p_st_sensorless_vector->p_st_sc);
            break;

        default:
            /* Do Nothing */
            break;
    }
} /* End of function motor_sensorless_vector_module_activate */

/***********************************************************************************************************************
* Function Name : motor_sensorless_phase_err_lpf_setup
* Description   : Setups LPF for estimated phase error by given cutoff frequency[Hz]
* Arguments     : p_st_sensorless_vector - The pointer to the motor control management data structure
*                 f4_phase_err_lpf_cut_freq - Cut off frequency[Hz] of phase error LPF
*                 f4_ctrl_period - Control period [s]
* Return Value  : None
***********************************************************************************************************************/
void motor_sensorless_phase_err_lpf_setup(st_sensorless_vector_control_t *p_st_sensorless_vector,
                                          float f4_phase_err_lpf_cut_freq,
                                          float f4_ctrl_period)
{
    motor_filter_first_order_lpff_gain_calc(&p_st_sensorless_vector->st_phase_err_lpf,
                                            f4_phase_err_lpf_cut_freq,
                                            f4_ctrl_period);
} /* End of function motor_sensorless_phase_err_lpf_setup */
