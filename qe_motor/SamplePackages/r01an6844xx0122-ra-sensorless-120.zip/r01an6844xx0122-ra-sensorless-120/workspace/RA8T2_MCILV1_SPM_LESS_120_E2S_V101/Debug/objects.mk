################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA8T2_MCILV1_SPM_LESS_120_E2S_V101/src/application/rmw/ICS2_RA8T2.o

LIBS :=

