/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_mtr_rmw.c
* Description : Processes of a user interface (tool)
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 19.01.2024 1.00
*         : 14.05.2025 1.01     Instance pointers are reffered.
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "mtr_main.h"
#include "r_mtr_rmw.h"
#include "hal_data.h"
#include "r_mtr_motor_parameter.h"
#include "r_mtr_control_parameter.h"
static uint8_t u1_cnt_ics;                  /* Counter for period of calling "scope_watchpoint" */

float    g_f4_iu_offset_monitor;            /* U-phase current A/D offset */
float    g_f4_iw_offset_monitor;            /* W-phase current A/D offset */
float    g_f4_iu_ad_monitor;                /* U-phase current [A] */
float    g_f4_iw_ad_monitor;                /* W-phase current [A] */
float    g_f4_vdc_ad_monitor;               /* Main line voltage [V] */
float    g_f4_vu_monitor;                   /* U-phase voltage [V] */
float    g_f4_vv_monitor;                   /* V-phase voltage [V] */
float    g_f4_vw_monitor;                   /* W-phase voltage [V] */
float    g_f4_speed_rad_monitor;            /* Rotational speed [rad/sec] */
float    g_f4_speed_rpm_monitor;            /* Rotational speed [rpm] */
float    g_f4_speed_ref_monitor;            /* Speed reference [rad/sec] */
float    g_f4_speed_kp_monitor;             /* Propotional parameter of speed PI loop */
float    g_f4_speed_ki_monitor;             /* Integral parameter of speed PI loop */
float    g_f4_v_ref_monitor;                /* Voltage reference [V] */
uint8_t  g_u1_direction_monitor;            /* Rotational direction */

float    com_f4_ref_speed_rpm = 0.0F;       /* Motor speed reference [rpm] (mechanical) */

float    com_f4_overcurrent_limit;          /* Over current limit */
float    com_f4_overvoltage_limit;          /* Over voltage limit */
float    com_f4_overspeed_limit_rpm;        /* Over speed limit */
float    com_f4_lowvoltage_limit;           /* Low voltage limit */

uint32_t com_u4_timeout_cnt;                /* undetected time of zero cross pattern */
float    com_f4_max_drive_v;                /* max output voltage [V] */
float    com_f4_min_drive_v;                /* min output voltage [V] */
int32_t  com_s4_angle_shift_adjust;         /* adjusting angle */
float    com_f4_speed_lpf_k;                /* speed LPF parameter */
float    com_f4_limit_speed_change;         /* speed ref change limit */
float    com_f4_boot_ref_v;                 /* voltage reference when zero speed [V] */
uint32_t com_u4_v_up_time;                  /* voltage lamping time */
uint32_t com_u4_v_const_time;               /* voltage constant adjust time value [ms] */
int32_t  com_s4_ol_start_rpm;               /* start speed of open loop [rpm] */
int32_t  com_s4_ol_mode1_change_rpm;        /* to mode2 change speed [rpm] */
int32_t  com_s4_ol_mode2_change_rpm;        /* to mode3 change speed [rpm] */
float    com_f4_ol_start_refv;              /* start reference voltage [V] */
float    com_f4_ol_mode1_rate_rpm;          /* increase rate of reference speed [rpm/control period] */
float    com_f4_ol_mode2_rate_refv;         /* increase rate of reference voltage [v/control period] */
float    com_f4_ol_mode2_rate_rpm;          /* increase rate of reference speed [rpm/control period] */
float    com_f4_ol_mode3_rate_refv;         /* increase rate of reference voltage [v/control period] */
float    com_f4_ol_mode3_max_refv;          /* openloop max voltage [v] */
float    com_f4_pi_ctrl_kp;                 /* pi control error */
float    com_f4_pi_ctrl_ki;                 /* pi control buffer of integral term */
float    com_f4_pi_ctrl_ilimit;             /* pi control limit of integral term */
uint32_t com_u4_mtr_pp;                     /* Pole pairs */
float    com_f4_mtr_r;                      /* Resistance [ohm] */
float    com_f4_mtr_ld;                     /* D-axis inductance [H] */
float    com_f4_mtr_lq;                     /* Q-axis inductance [H] */
float    com_f4_mtr_m;                      /* Permanent magnetic flux [Wb] */
float    com_f4_mtr_j;                      /* Rotor inertia [kgm^2] */

uint8_t  com_u1_enable_write = 0U;          /* ICS write enable flag */
uint8_t  g_u1_enable_write = 0U;            /* ICS write enable flag */

extern   const motor_instance_t  *p_motor_instance;
extern   motor_120_degree_extended_cfg_t g_user_motor_120_degree_extended_cfg;
extern   motor_120_control_cfg_t g_user_motor_120_control_cfg;
extern   motor_120_control_sensorless_extended_cfg_t g_user_motor_120_control_extended_cfg;
extern   motor_120_driver_cfg_t g_user_motor_120_driver_cfg;
extern   motor_120_driver_extended_cfg_t g_user_motor_120_driver_extended_cfg;
extern float g_f4_max_speed_rpm;
extern uint8_t g_u1_mode_system;

static   motor_120_control_instance_t const   *p_120_ctrl_instance;
static   motor_120_driver_instance_t const    *p_120_driver_instance;
static   uint8_t  g_u1_trig_enable_write = MTR_FLG_CLR;

/***********************************************************************************************************************
* Function Name : mtr_set_com_variables
* Description   : Set com variables
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_set_com_variables(void)
{
    motor_120_control_sensorless_instance_ctrl_t *p_120_less_ctrl
        = (motor_120_control_sensorless_instance_ctrl_t *)p_120_ctrl_instance->p_ctrl;

    if (com_u1_enable_write == g_u1_enable_write)
    {
        if (com_f4_ref_speed_rpm > g_f4_max_speed_rpm)
        {
            com_f4_ref_speed_rpm = g_f4_max_speed_rpm;
        }
        else if (com_f4_ref_speed_rpm < -g_f4_max_speed_rpm)
        {
            com_f4_ref_speed_rpm = -g_f4_max_speed_rpm;
        }

        if ((g_u1_direction_monitor == MTR_CW && com_f4_ref_speed_rpm < 0.0F) ||
            (g_u1_direction_monitor == MTR_CCW && com_f4_ref_speed_rpm > 0.0F))
        {
            p_motor_instance->p_api->stop(p_motor_instance->p_ctrl);
            g_u1_mode_system = MOTOR_120_DEGREE_CTRL_EVENT_STOP;
            p_120_less_ctrl->flag_wait_stop = MOTOR_120_CONTROL_WAIT_STOP_FLAG_SET;
        }

        p_motor_instance->p_api->speedSet(p_motor_instance->p_ctrl, com_f4_ref_speed_rpm);

        g_user_motor_120_degree_extended_cfg.f_overcurrent_limit = com_f4_overcurrent_limit *
                                                                 MTR_SQRT_2 *
                                                                 MTR_OVERCURRENT_MARGIN_MULT;
        g_user_motor_120_degree_extended_cfg.f_overvoltage_limit = com_f4_overvoltage_limit;
        g_user_motor_120_degree_extended_cfg.f_overspeed_limit   = com_f4_overspeed_limit_rpm;
        g_user_motor_120_degree_extended_cfg.f_lowvoltage_limit  = com_f4_lowvoltage_limit;

        g_user_motor_120_control_cfg.u4_timeout_cnt                    = com_u4_timeout_cnt;
        g_user_motor_120_control_cfg.f4_max_drive_v                    = com_f4_max_drive_v;
        g_user_motor_120_control_cfg.f4_min_drive_v                    = com_f4_min_drive_v;
        g_user_motor_120_control_cfg.f4_pi_ctrl_ilimit                 = com_f4_pi_ctrl_ilimit;
        g_user_motor_120_control_cfg.motor_param.u4_motor_pp           = com_u4_mtr_pp;
        g_user_motor_120_control_cfg.motor_param.f4_motor_r            = com_f4_mtr_r;
        g_user_motor_120_control_cfg.motor_param.f4_motor_ld           = com_f4_mtr_ld;
        g_user_motor_120_control_cfg.motor_param.f4_motor_lq           = com_f4_mtr_lq;
        g_user_motor_120_control_cfg.motor_param.f4_motor_m            = com_f4_mtr_m;
        g_user_motor_120_control_cfg.motor_param.f4_motor_j            = com_f4_mtr_j;
        g_user_motor_120_control_cfg.f4_speed_lpf_k                    = com_f4_speed_lpf_k;
        g_user_motor_120_control_cfg.f4_limit_speed_change             = com_f4_limit_speed_change;
        g_user_motor_120_control_cfg.f4_pi_ctrl_kp                     = com_f4_pi_ctrl_kp;
        g_user_motor_120_control_cfg.f4_pi_ctrl_ki                     = com_f4_pi_ctrl_ki;
        g_user_motor_120_control_extended_cfg.s4_angle_shift_adjust    = com_s4_angle_shift_adjust;
        g_user_motor_120_control_extended_cfg.s4_ol_start_rpm          = com_s4_ol_start_rpm;
        g_user_motor_120_control_extended_cfg.s4_ol_mode1_change_rpm   = com_s4_ol_mode1_change_rpm;
        g_user_motor_120_control_extended_cfg.s4_ol_mode2_change_rpm   = com_s4_ol_mode2_change_rpm;
        g_user_motor_120_control_extended_cfg.f4_ol_start_refv         = com_f4_ol_start_refv;
        g_user_motor_120_control_extended_cfg.f4_ol_mode1_rate_rpm     = com_f4_ol_mode1_rate_rpm;
        g_user_motor_120_control_extended_cfg.f4_ol_mode2_rate_refv    = com_f4_ol_mode2_rate_refv;
        g_user_motor_120_control_extended_cfg.f4_ol_mode2_rate_rpm     = com_f4_ol_mode2_rate_rpm;
        g_user_motor_120_control_extended_cfg.f4_ol_mode3_rate_refv    = com_f4_ol_mode3_rate_refv;
        g_user_motor_120_control_extended_cfg.f4_ol_mode3_max_refv     = com_f4_ol_mode3_max_refv;
        g_user_motor_120_control_extended_cfg.u4_v_up_time             = com_u4_v_up_time;
        g_user_motor_120_control_extended_cfg.u4_v_const_time          = com_u4_v_const_time;
        g_user_motor_120_control_extended_cfg.f4_boot_ref_v            = com_f4_boot_ref_v;

        g_u1_trig_enable_write = MTR_FLG_SET;
        g_u1_enable_write ^= 1;                         /* Change every time 0 and 1 */
    }
}

/***********************************************************************************************************************
* Function Name : mtr_ics_variables_init
* Description   : Initialize valiables for Analyzer interface
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_ics_variables_init(void)
{
    p_120_ctrl_instance   = g_user_motor_120_degree_extended_cfg.p_motor_120_control_instance;
    p_120_driver_instance = g_user_motor_120_control_extended_cfg.p_motor_120_driver_instance;

    g_u1_enable_write = 0U;
    com_u1_enable_write = 0U;

#if MTR_MOTOR_PARAMETER
    com_u4_mtr_pp            = MP_POLE_PAIRS;
    com_f4_mtr_r             = MP_RESISTANCE;
    com_f4_mtr_ld            = MP_D_INDUCTANCE;
    com_f4_mtr_lq            = MP_Q_INDUCTANCE;
    com_f4_mtr_m             = MP_MAGNETIC_FLUX;
    com_f4_mtr_j             = MP_ROTOR_INERTIA;
    com_f4_overcurrent_limit = MP_NOMINAL_CURRENT_RMS;
#else
    com_u4_mtr_pp            = g_user_motor_120_control_cfg.motor_param.u4_motor_pp;
    com_f4_mtr_r             = g_user_motor_120_control_cfg.motor_param.f4_motor_r;
    com_f4_mtr_ld            = g_user_motor_120_control_cfg.motor_param.f4_motor_ld;
    com_f4_mtr_lq            = g_user_motor_120_control_cfg.motor_param.f4_motor_lq;
    com_f4_mtr_m             = g_user_motor_120_control_cfg.motor_param.f4_motor_m;
    com_f4_mtr_j             = g_user_motor_120_control_cfg.motor_param.f4_motor_j;
    com_f4_overcurrent_limit = g_user_motor_120_degree_extended_cfg.f_overcurrent_limit
                                / (MTR_SQRT_2 * MTR_OVERCURRENT_MARGIN_MULT);
#endif

    com_f4_ref_speed_rpm = 0.0F;
    com_f4_overvoltage_limit    = g_user_motor_120_degree_extended_cfg.f_overvoltage_limit;
    com_f4_overspeed_limit_rpm  = g_user_motor_120_degree_extended_cfg.f_overspeed_limit;
    com_f4_lowvoltage_limit     = g_user_motor_120_degree_extended_cfg.f_lowvoltage_limit;

    com_u4_timeout_cnt          = g_user_motor_120_control_cfg.u4_timeout_cnt;
    com_f4_max_drive_v          = g_user_motor_120_control_cfg.f4_max_drive_v;
    com_f4_min_drive_v          = g_user_motor_120_control_cfg.f4_min_drive_v;
    com_f4_pi_ctrl_ilimit       = g_user_motor_120_control_cfg.f4_pi_ctrl_ilimit;
    com_f4_speed_lpf_k          = g_user_motor_120_control_cfg.f4_speed_lpf_k;
    com_f4_limit_speed_change   = g_user_motor_120_control_cfg.f4_limit_speed_change;
    com_f4_pi_ctrl_kp           = g_user_motor_120_control_cfg.f4_pi_ctrl_kp;
    com_f4_pi_ctrl_ki           = g_user_motor_120_control_cfg.f4_pi_ctrl_ki;
    com_s4_angle_shift_adjust   = g_user_motor_120_control_extended_cfg.s4_angle_shift_adjust;
    com_s4_ol_start_rpm         = g_user_motor_120_control_extended_cfg.s4_ol_start_rpm;
    com_s4_ol_mode1_change_rpm  = g_user_motor_120_control_extended_cfg.s4_ol_mode1_change_rpm;
    com_s4_ol_mode2_change_rpm  = g_user_motor_120_control_extended_cfg.s4_ol_mode2_change_rpm;
    com_f4_ol_start_refv        = g_user_motor_120_control_extended_cfg.f4_ol_start_refv;
    com_f4_ol_mode1_rate_rpm    = g_user_motor_120_control_extended_cfg.f4_ol_mode1_rate_rpm;
    com_f4_ol_mode2_rate_refv   = g_user_motor_120_control_extended_cfg.f4_ol_mode2_rate_refv;
    com_f4_ol_mode2_rate_rpm    = g_user_motor_120_control_extended_cfg.f4_ol_mode2_rate_rpm;
    com_f4_ol_mode3_rate_refv   = g_user_motor_120_control_extended_cfg.f4_ol_mode3_rate_refv;
    com_f4_ol_mode3_max_refv    = g_user_motor_120_control_extended_cfg.f4_ol_mode3_max_refv;
    com_u4_v_up_time            = g_user_motor_120_control_extended_cfg.u4_v_up_time;
    com_u4_v_const_time         = g_user_motor_120_control_extended_cfg.u4_v_const_time;
    com_f4_boot_ref_v           = g_user_motor_120_control_extended_cfg.f4_boot_ref_v;
}

/***********************************************************************************************************************
* Function Name : mtr_ics_interrupt_process
* Description   : Interrupt process to reflect data into RMW (called at current backward event)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void mtr_ics_interrupt_process(void)
{
    motor_120_control_sensorless_instance_ctrl_t *p_120_less_ctrl
        = (motor_120_control_sensorless_instance_ctrl_t *)p_120_ctrl_instance->p_ctrl;
    motor_120_driver_instance_ctrl_t *p_120_driver_ctrl
        = (motor_120_driver_instance_ctrl_t *)p_120_driver_instance->p_ctrl;

    // Reflect user settig parameters (com_xxx)
    mtr_set_com_variables();

    /* Decimation of ICS call */
    u1_cnt_ics++;
    if (MTR_ICS_DECIMATION <= u1_cnt_ics)
    {
        g_f4_iu_offset_monitor        = p_120_driver_ctrl->f_offset_iu;
        g_f4_iw_offset_monitor        = p_120_driver_ctrl->f_offset_iw;
        g_f4_iu_ad_monitor            = p_120_driver_ctrl->f_iu_ad - g_f4_iu_offset_monitor;
        g_f4_iw_ad_monitor            = p_120_driver_ctrl->f_iw_ad - g_f4_iw_offset_monitor;
        g_f4_vdc_ad_monitor           = p_120_driver_ctrl->f_vdc_ad;
        g_f4_vu_monitor               = p_120_driver_ctrl->f_vu_ad;
        g_f4_vv_monitor               = p_120_driver_ctrl->f_vv_ad;
        g_f4_vw_monitor               = p_120_driver_ctrl->f_vw_ad;
        g_f4_speed_kp_monitor         = p_120_ctrl_instance->p_cfg->f4_pi_ctrl_kp;
        g_f4_speed_ki_monitor         = p_120_ctrl_instance->p_cfg->f4_pi_ctrl_ki;
        g_u1_direction_monitor        = p_120_less_ctrl->direction;
        g_f4_speed_ref_monitor        = p_120_less_ctrl->f4_ref_speed_rad_ctrl;
        g_f4_v_ref_monitor            = p_120_less_ctrl->f4_v_ref;

        if (MTR_CW == g_u1_direction_monitor)
        {
            g_f4_speed_rad_monitor = p_120_less_ctrl->f4_speed_rad;
        }
        else
        {
            g_f4_speed_rad_monitor = -p_120_less_ctrl->f4_speed_rad;
        }
        g_f4_speed_rpm_monitor = g_f4_speed_rad_monitor * MTR_RAD_RPM
                                    / (float)g_user_motor_120_control_cfg.motor_param.u4_motor_pp;

        u1_cnt_ics = 0U;

        /* Call ICS */
        ics2_watchpoint();
    }

    if (MTR_FLG_SET == g_u1_trig_enable_write)
    {
        p_120_ctrl_instance->p_api->parameterUpdate(p_120_ctrl_instance->p_ctrl, &g_user_motor_120_control_cfg);
        p_120_driver_instance->p_api->parameterUpdate(p_120_driver_instance->p_ctrl, &g_user_motor_120_driver_cfg);
        g_u1_trig_enable_write = MTR_FLG_CLR;
    }
} /* End of function mtr_ics_interrupt_process */
