################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Workspace/RA6T2_MCILV1_2SPM_LESS_FOC_E2S_V122/src/application/rmw/ICS2_RA6T2.o

LIBS := -lrm_motor_current -lrm_motor_estimate -lrm_motor_speed

