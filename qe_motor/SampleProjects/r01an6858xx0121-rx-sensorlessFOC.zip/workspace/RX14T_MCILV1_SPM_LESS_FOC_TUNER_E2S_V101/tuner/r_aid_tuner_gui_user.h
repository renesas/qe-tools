/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name    : r_aid_tuner_gui_user.h
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 **********************************************************************************************************************/
#include "r_smc_entry.h"
#include "r_motor_sensorless_vector_api.h"
#include "r_motor_driver.h"
#include "r_motor_module_cfg.h"

/***********************************************************************************************************************
 Macro definitions
 **********************************************************************************************************************/
#define AIDU_CURRENT_OMEGA               (CURRENT_CFG_OMEGA)           /* Natural frequency of current loop */
#define AIDU_CURRENT_ZETA                (CURRENT_CFG_ZETA)            /* Damping ratio of current loop */
#define AIDU_SPEED_OMEGA                 (SPEED_CFG_OMEGA)             /* Natural frequency of speed loop */
#define AIDU_SPEED_ZETA                  (SPEED_CFG_ZETA)              /* Damping ratio of speed loop */
#define AIDU_E_OBS_OMEGA                 (CURRENT_CFG_E_OBS_OMEGA)     /* Natural frequency of BEMF observer */
#define AIDU_E_OBS_ZETA                  (CURRENT_CFG_E_OBS_ZETA)      /* Damping ratio of BEMF observer */
#define AIDU_PLL_EST_OMEGA               (CURRENT_CFG_PLL_EST_OMEGA)   /* Natural frequency of PLL Speed estimate loop */
#define AIDU_PLL_EST_ZETA                (CURRENT_CFG_PLL_EST_ZETA)    /* Damping ratio of PLL Speed estimate loop */
#define AIDU_INPUT_V                     (INVERTER_CFG_INPUT_V)        /* Damping ratio of PLL Speed estimate loop */
#define AIDU_SPEED_CTRL_PERIOD           (SPEED_CFG_CTRL_PERIOD)       /* The speed control period[s] */
#define AIDU_INT_DECIMATION              (1)
#define AIDU_INV_INFO_OVERVOLTAGE_TH     (INVERTER_CFG_OVERVOLTAGE_LIMIT)
#define AIDU_INV_INFO_UNDERVOLTAGE_TH    (INVERTER_CFG_UNDERVOLTAGE_LIMIT)
#define AIDU_INV_INFO_PWM_CYCLE_S        (MOTOR_COMMON_CTRL_PERIOD)
#define AIDU_INV_INFO_PWM_DEADTIME_S     (INVERTER_CFG_DEADTIME/1000000.0f)
#define AIDU_CARRIER_SET_BASE            (MOTOR_COMMON_CARRIER_SET_BASE)
#define AIDU_DEADTIME_SET                (MOTOR_COMMON_DEADTIME_SET)

#define AIDU_INV_INFO_OVERCURRENT_TH     (5.0f * MTR_SQRT_2 * MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT)
#define AIDU_INV_INFO_CURRENT_RANGE      (INVERTER_CFG_ADC_REF_VOLTAGE / (INVERTER_CFG_CURRENT_AMP_GAIN * INVERTER_CFG_SHUNT_RESIST))

#define AIDU_PWM_TIMER_W_REG             ((uint16_t *)&(MTU3.TGRD))
#define AIDU_PWM_TIMER_V_REG             ((uint16_t *)&(MTU4.TGRC))
#define AIDU_PWM_TIMER_U_REG             ((uint16_t *)&(MTU4.TGRD))

#define AIDU_TUNE_VOLTERR_ENABLE         (true)

/***********************************************************************************************************************
 Exported global functions (to be accessed by other files)
 **********************************************************************************************************************/
void aid_mtr_inv_set_uvw(float f4_duty_u, float f4_duty_v, float f4_duty_w, uint8_t u1_id);
void aid_mtr_get_current_iuiw(float *f4_iu_ad, float *f4_iw_ad, uint8_t u1_id);
float aid_mtr_get_vdc(uint8_t u1_id);
void aid_mtr_clear_oc_flag(void);
void aid_mtr_ctrl_start(uint8_t u1_id);
void aid_mtr_ctrl_stop(uint8_t u1_id);
void mtr_ics_1_parameter(void);
void aid_mtr_ics_interrupt(void);
