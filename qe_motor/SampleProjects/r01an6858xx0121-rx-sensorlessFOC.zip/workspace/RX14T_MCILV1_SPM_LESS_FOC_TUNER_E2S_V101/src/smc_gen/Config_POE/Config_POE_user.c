/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_POE_user.c
* Component Version: 1.11.0
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_POE.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_POE.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_motor_sensorless_vector_api.h"
#include "r_app_rmw.h"
#if USE_RMW_TUNER
#include "r_aid_tuner_gui.h"
#include "r_aid_auto_identify.h"
#endif
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_POE_Create_UserInit
* Description  : This function adds user code after initializing the POE3 module
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_POE_Create_UserInit(void)
{
    /* Start user code for code init. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_POE_oei4_interrupt
* Description  : This function is OEI4 interrupt service routine
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

#if FAST_INTERRUPT_VECTOR == VECT_POE_OEI4
#pragma interrupt r_Config_POE_oei4_interrupt(vect=VECT(POE,OEI4),fint)
#else
#pragma interrupt r_Config_POE_oei4_interrupt(vect=VECT(POE,OEI4))
#endif
static void r_Config_POE_oei4_interrupt(void)
{
    /* Start user code for r_Config_POE_oei4_interrupt. Do not edit comment generated here */
#if USE_RMW_TUNER
    if (R_TUNER_IsRunning())
    {
        R_AID_UserError(1);
    }
    else
    {
        R_MOTOR_SENSORLESS_VECTOR_OverCurrentInterrupt(&g_st_sensorless_vector);
        R_Config_POE_Stop();
        R_Config_POE_Start();
    }
#else
    R_MOTOR_SENSORLESS_VECTOR_OverCurrentInterrupt(&g_st_sensorless_vector);
    R_Config_POE_Stop();
    R_Config_POE_Start();
#endif
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
