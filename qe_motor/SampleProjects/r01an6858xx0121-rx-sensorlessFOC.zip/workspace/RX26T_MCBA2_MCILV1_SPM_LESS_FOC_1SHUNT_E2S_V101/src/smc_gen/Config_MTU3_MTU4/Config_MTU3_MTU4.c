/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_MTU3_MTU4.c
* Component Version: 1.11.0
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_MTU3_MTU4.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_MTU3_MTU4.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_smc_entry.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_Create
* Description  : This function initializes the MTU3 channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_Create(void)
{
    /* Release MTU channel 3 from stop state */
    MSTP(MTU3) = 0U;

    /* Enable read/write to MTU3, MTU4 registers */
    MTU.TRWERA.BIT.RWE = 1U;

    /* Stop MTU channel 3 counter */
    MTU.TSTRA.BIT.CST3 = 0U;
    MTU.TSTRA.BIT.CST4 = 0U;

    /* Set A/D conversion signal output for ADSM0, ADSM1 pins */
    MTU.TADSTRGR0.BYTE = _00_MTU_TADSMEN_DISABLE;
    MTU.TADSTRGR1.BYTE = _00_MTU_TADSMEN_DISABLE;

    /* Set TGIA3 interrupt priority level */
    IPR(MTU3, TGIA3) = _0C_MTU_PRIORITY_LEVEL12;

    /* MTU channel 3 is used as complementary PWM mode 3 */
    MTU3.TIER.BYTE = 0x00U;
    MTU4.TIER.BYTE = 0x00U;
    MTU.TITCR1A.BIT.T3AEN = 0U;
    MTU.TITCR1A.BIT.T4VEN = 0U;
    MTU3.TCR.BYTE = _00_MTU_PCLK_1 | _00_MTU_CKCL_DIS;
    MTU4.TCR.BYTE = _00_MTU_PCLK_1;
    MTU3.TCR2.BYTE = _00_MTU_PCLK_1;
    MTU4.TCR2.BYTE = _00_MTU_PCLK_1;
    MTU.TGCRA.BYTE = _80_MTU_BDC_OUT;
    MTU3.TCNT = _00F0_3TCNT_VALUE;
    MTU4.TCNT = 0x0000U;
    MTU.TSYRA.BIT.SYNC3 = 0U;
    MTU.TSYRA.BIT.SYNC4 = 0U;
    MTU3.TGRB = _0654_3TGRB_VALUE;
    MTU3.TGRD = _0654_3TGRB_VALUE;
    MTU4.TGRA = _0654_4TGRA_VALUE;
    MTU4.TGRC = _0654_4TGRA_VALUE;
    MTU4.TGRB = _0654_4TGRB_VALUE;
    MTU4.TGRD = _0654_4TGRB_VALUE;
    MTU3.TGRE = _0654_3TGRE_VALUE;
    MTU4.TGRE = _0654_4TGRE_VALUE;
    MTU4.TGRF = _0654_4TGRF_VALUE;
    MTU.TDERA.BIT.TDER = 1U;
    MTU.TDDRA = _00F0_TDDRA_VALUE;
    MTU.TCDRA = _0BB8_TCDRA_VALUE;
    MTU.TCBRA = _0BB8_TCDRA_VALUE;
    MTU3.TGRA = _0CA8_SUM_VALUE;
    MTU3.TGRC = _0CA8_SUM_VALUE;
    MTU.TOCR1A.BYTE = _00_MTU_PSYE_DISABLE | _08_MTU_TOCL_DISABLE | _04_MTU_TOCS_TOCR2;
    MTU.TOCR2A.BYTE = _80_MTU_TOLBR_T | _20_MTU_OLS3N_LH | _10_MTU_OLS3P_LH | _08_MTU_OLS2N_LH | _04_MTU_OLS2P_LH | 
                      _02_MTU_OLS1N_LH | _01_MTU_OLS1P_LH;
    MTU.TOLBRA.BYTE = MTU.TOCR2A.BYTE & 0x3FU;
    MTU3.TIER.BYTE = _01_MTU_TGIEA_ENABLE | _00_MTU_TGIEB_DISABLE | _80_MTU_TTGE_ENABLE;
    MTU4.TIER.BYTE = _00_MTU_TGIEA_DISABLE | _00_MTU_TGIEB_DISABLE | _00_MTU_TCIEV_DISABLE | _00_MTU_TTGE2_DISABLE;
    MTU4.TADCORA = _0320_TADCORA_VALUE;
    MTU4.TADCOBRA = _0320_TADCOBRA_VALUE;
    MTU4.TADCORB = _0960_TADCORB_VALUE;
    MTU4.TADCOBRB = _0960_TADCOBRB_VALUE;
    MTU4.TADCR.WORD = _0080_MTU_UTAE_ENABLE | _0000_MTU_DTAE_DISABLE | _0020_MTU_UTBE_ENABLE | 
                      _0000_MTU_DTBE_DISABLE | _0000_MTU_BF_DISABLE;
    MTU.TITMRA.BIT.TITM = 1U;
    MTU.TITCR2A.BYTE = _00_MTU_TRGCOR_4_7_SKIP_COUNT_0;
    MTU3.TMDR1.BYTE = _0F_MTU_CMT3 | _10_MTU_BFA_BUFFER | _20_MTU_BFB_BUFFER;
    MTU.TMDR2A.BIT.DRS = 1U;
    MTU.TOERA.BYTE = _E0_MTU_OE4D_ENABLE | _D0_MTU_OE4C_ENABLE | _C8_MTU_OE3D_ENABLE | _C4_MTU_OE4B_ENABLE | 
                     _C2_MTU_OE4A_ENABLE | _C1_MTU_OE3B_ENABLE;

    /* Disable read/write to MTU3, MTU4 registers */
    MTU.TRWERA.BIT.RWE = 0U;

    /* Set MTIOC3B pin */
    MPC.P71PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x02U;

    /* Set MTIOC3D pin */
    MPC.P74PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x10U;

    /* Set MTIOC4A pin */
    MPC.P72PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x04U;

    /* Set MTIOC4B pin */
    MPC.P73PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x08U;

    /* Set MTIOC4C pin */
    MPC.P75PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x20U;

    /* Set MTIOC4D pin */
    MPC.P76PFS.BYTE = 0x01U;
    PORT7.PMR.BYTE |= 0x40U;

    R_Config_MTU3_MTU4_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_Start
* Description  : This function starts the MTU3 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_Start(void)
{
    /* Enable TGIA3 interrupt in ICU */
    IEN(MTU3, TGIA3) = 1U;

    /* Start MTU3, MTU4 channel counter */
    MTU.TSTRA.BYTE |= (_40_MTU_CST3_ON | _80_MTU_CST4_ON);
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_Stop
* Description  : This function stops the MTU3 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_Stop(void)
{
    /* Disable TGIA3 interrupt in ICU */
    IEN(MTU3, TGIA3) = 0U;

    /* Stop MTU3, MTU4 channel counter */
    MTU.TSTRA.BIT.CST3 = 0U;
    MTU.TSTRA.BIT.CST4 = 0U;
}

/* Start user code for adding. Do not edit comment generated here */
void R_Config_MTU3_MTU4_StartTimerCount(void)
{
    /* Enable TGIA3 interrupt in ICU */
    IEN(MTU3, TGIA3) = 1U;

    /* Start MTU3, MTU4 counter */
    MTU.TCSYSTR.BYTE = (0x10U | 0x08U);
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_StopTimerCount
* Description  : This function stops the MTU3 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_StopTimerCount(void)
{
    /* Disable TGIA3 interrupt in ICU */
    IEN(MTU3, TGIA3) = 0U;

    /* Stop MTU3, MTU4 channel counter */
    MTU.TSTRA.BYTE = MTU.TSTRA.BYTE & 0x3FU;
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_StartTimerOutput
* Description  : This function starts the MTU output
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_StartTimerCtrl(void)
{
    /* Enable read/write to MTU3, MTU4 registers */
    MTU.TRWERA.BIT.RWE = 1U;

    //Control Up (MTIOC3B)
    PORT7.PODR.BIT.B1 = 0U; //Active High
    PORT7.PMR.BIT.B1 = 1U;
    //Control Un (MTIOC3D)
    PORT7.PODR.BIT.B4 = 0U; //Active High
    PORT7.PMR.BIT.B4 = 1U;
    //Control Vp (MTIOC4A)
    PORT7.PODR.BIT.B2 = 0U; //Active High
    PORT7.PMR.BIT.B2 = 1U;
    //Control Wp (MTIOC4B)
    PORT7.PODR.BIT.B3 = 0U; //Active High
    PORT7.PMR.BIT.B3 = 1U;
    //Control Vn (MTIOC4C)
    PORT7.PODR.BIT.B5 = 0U; //Active High
    PORT7.PMR.BIT.B5 = 1U;
    //Control Wn (MTIOC4D)
    PORT7.PODR.BIT.B6 = 0U; //Active High
    PORT7.PMR.BIT.B6 = 1U;
    //Enable MTU3,MTU4 PWM output
    MTU.TOERA.BYTE = 0xC1U | 0xC8U | 0xC2U |
                     0xD0U | 0xC4U | 0xE0U;

    /* Disable read/write to MTU3, MTU4 registers */
    MTU.TRWERA.BIT.RWE = 0U;
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_StopTimerOutput
* Description  : This function stops the MTU output
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_StopTimerCtrl(void)
{
    /* Enable read/write to MTU3, MTU4 registers */
    MTU.TRWERA.BIT.RWE = 1U;

    //Disable MTU3,MTU4 PWM output
    MTU.TOERA.BYTE = 0xC0U;
    //Control Up (MTIOC3B)
    PORT7.PODR.BIT.B1 = 0U; //Active High
    PORT7.PMR.BIT.B1 = 0U;
    //Control Un (MTIOC3D)
    PORT7.PODR.BIT.B4 = 0U; //Active High
    PORT7.PMR.BIT.B4 = 0U;
    //Control Vp (MTIOC4A)
    PORT7.PODR.BIT.B2 = 0U; //Active High
    PORT7.PMR.BIT.B2 = 0U;
    //Control Wp (MTIOC4B)
    PORT7.PODR.BIT.B3 = 0U; //Active High
    PORT7.PMR.BIT.B3 = 0U;
    //Control Vn (MTIOC4C)
    PORT7.PODR.BIT.B5 = 0U; //Active High
    PORT7.PMR.BIT.B5 = 0U;
    //Control Wn (MTIOC4D)
    PORT7.PODR.BIT.B6 = 0U; //Active High
    PORT7.PMR.BIT.B6 = 0U;

    /* Disable read/write to MTU3, MTU4 registers */
    MTU.TRWERA.BIT.RWE = 0U;
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_1ShuntUpdDuty
* Description  : This function updates duty cycle
* Arguments    : duty_u -
*                    U phase duty register value
*                duty_v -
*                    V phase duty register value
*                duty_w -
*                    W phase duty register value
*                duty_u_buff -
*                    U phase duty buffer register value
*                duty_v_buff -
*                    V phase duty buffer register value
*                duty_w_buff -
*                    W phase duty buffer register value
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_1ShuntUpdDuty(uint16_t duty_u,
                                      uint16_t duty_v,
                                      uint16_t duty_w,
                                      uint16_t duty_u_buff,
                                      uint16_t duty_v_buff,
                                      uint16_t duty_w_buff)
{
    /* set duty for double buffer */
	MTU4.TGRF = duty_u;
    MTU4.TGRE = duty_v;
    MTU3.TGRE = duty_w;
    MTU4.TGRC = duty_v_buff;
    MTU3.TGRD = duty_w_buff;
    /* transfer trigger */
    MTU4.TGRD = duty_u_buff;
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_StartAD
* Description  : This function starts the AD conversiont
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_StartAD(void)
{
    S12AD.ADCSR.BIT.TRGE = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_StopAD
* Description  : This function stops the AD conversion
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_StopAD(void)
{
    S12AD.ADCSR.BIT.TRGE = 0U;
    S12AD.ADCSR.BIT.ADST = 0U;
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_1ShuntAdcGetConvVal
* Description  : This function gets conversion result for 1shunt
* Arguments    : mtr_ad_data -
*                    buffer pointer
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_1ShuntAdcGetConvVal( r_mtr_adc_tb *mtr_ad_data )
{
    while (1 == S12AD.ADCSR.BIT.ADST)
    {
        /* wait until AD conversion finish */
    }

    /* Get Vdc */
    mtr_ad_data->u2_vdc_ad   = (uint16_t)(S12AD.ADDR3);

    /* Get double buffer data */
    mtr_ad_data->u2_Iac_raw0 = (uint16_t)(0x0FFF & S12AD.ADDR0);
    mtr_ad_data->u2_Iac_raw1 = (uint16_t)(0x0FFF & S12AD.ADDBLDR);
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_AdcTriggerSet
* Description  : This function sets double trigger AD conversion counts for 1shunt
* Arguments    : compare_match_value_a -
*                    A/D trigger timing A
*                compare_match_value_b -
*                    A/D trigger timing B
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_AdcTriggerSet(uint16_t compare_match_value_a, uint16_t compare_match_value_b)
{
    MTU4.TADCORA = compare_match_value_a;
    MTU4.TADCORB = compare_match_value_b;
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_MaxCountGet
* Description  : This function gets timer counts for 1shunt
* Arguments    : None
* Return Value : Period in raw timer counts
***********************************************************************************************************************/

uint16_t R_Config_MTU3_MTU4_MaxCountGet(void)
{
    uint16_t u2_period_counts;

    /* Enable read/write to MTU3, MTU4 registers */
    MTU.TRWERA.BIT.RWE = 1U;

    u2_period_counts = MTU3.TGRA;

    /* Disable read/write to MTU3, MTU4 registers */
    MTU.TRWERA.BIT.RWE = 0U;

    return (u2_period_counts);
}
/* End user code. Do not edit comment generated here */
