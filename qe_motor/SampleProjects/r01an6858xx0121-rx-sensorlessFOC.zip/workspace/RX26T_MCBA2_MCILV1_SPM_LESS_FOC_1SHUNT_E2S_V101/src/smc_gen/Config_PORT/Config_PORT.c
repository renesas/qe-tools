/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_PORT.c
* Component Version: 2.4.1
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_PORT.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_PORT.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_motor_common.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_PORT_Create
* Description  : This function initializes the PORT
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_PORT_Create(void)
{
    /* Set PORT0 registers */
    PORT0.PODR.BYTE = _00_Pm0_OUTPUT_0;
    PORT0.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm1_CMOS_OUTPUT;
    PORT0.DSCR.BYTE = _00_Pm0_HIDRV_OFF | _00_Pm1_HIDRV_OFF;
    PORT0.PMR.BYTE &= (_FE_Pm0_PIN_GPIO);
    PORT0.PDR.BYTE = _01_Pm0_MODE_OUTPUT;

    /* Set PORT2 registers */
    PORT2.PODR.BYTE = _01_Pm0_OUTPUT_1 | _02_Pm1_OUTPUT_1;
    PORT2.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm1_CMOS_OUTPUT;
    PORT2.ODR1.BYTE = _00_Pm4_CMOS_OUTPUT | _00_Pm7_CMOS_OUTPUT;
    PORT2.PCR.BYTE = _00_Pm2_PULLUP_OFF | _00_Pm3_PULLUP_OFF;
    PORT2.DSCR.BYTE = _00_Pm0_HIDRV_OFF | _00_Pm1_HIDRV_OFF | _00_Pm4_HIDRV_OFF | _00_Pm7_HIDRV_OFF;
    PORT2.PMR.BYTE &= (_FE_Pm0_PIN_GPIO & _FD_Pm1_PIN_GPIO & _FB_Pm2_PIN_GPIO & _F7_Pm3_PIN_GPIO);
    PORT2.PDR.BYTE = _01_Pm0_MODE_OUTPUT | _02_Pm1_MODE_OUTPUT | _00_Pm2_MODE_INPUT | _00_Pm3_MODE_INPUT;

    /* Set PORT4 registers */
    PORT4.PODR.BYTE = _00_Pm4_OUTPUT_0 | _00_Pm5_OUTPUT_0 | _00_Pm6_OUTPUT_0 | _00_Pm7_OUTPUT_0;
    PORT4.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm1_CMOS_OUTPUT | _00_Pm2_CMOS_OUTPUT | _00_Pm3_CMOS_OUTPUT;
    PORT4.ODR1.BYTE = _00_Pm4_CMOS_OUTPUT | _00_Pm5_CMOS_OUTPUT | _00_Pm6_CMOS_OUTPUT | _00_Pm7_CMOS_OUTPUT;
    PORT4.PMR.BYTE &= (_EF_Pm4_PIN_GPIO & _DF_Pm5_PIN_GPIO & _BF_Pm6_PIN_GPIO & _7F_Pm7_PIN_GPIO);
    PORT4.PDR.BYTE = _10_Pm4_MODE_OUTPUT | _20_Pm5_MODE_OUTPUT | _40_Pm6_MODE_OUTPUT | _80_Pm7_MODE_OUTPUT;

    /* Set PORT5 registers */
    PORT5.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm1_CMOS_OUTPUT | _00_Pm2_CMOS_OUTPUT | _00_Pm3_CMOS_OUTPUT;
    PORT5.PCR.BYTE = _10_Pm4_PULLUP_ON | _20_Pm5_PULLUP_ON;
    PORT5.PMR.BYTE &= (_EF_Pm4_PIN_GPIO & _DF_Pm5_PIN_GPIO);
    PORT5.PDR.BYTE = _00_Pm4_MODE_INPUT | _00_Pm5_MODE_INPUT;

    /* Set PORT6 registers */
    PORT6.PODR.BYTE = _00_Pm0_OUTPUT_0 | _00_Pm1_OUTPUT_0 | _00_Pm2_OUTPUT_0 | _00_Pm3_OUTPUT_0;
    PORT6.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm1_CMOS_OUTPUT | _00_Pm2_CMOS_OUTPUT | _00_Pm3_CMOS_OUTPUT;
    PORT6.ODR1.BYTE = _00_Pm4_CMOS_OUTPUT | _00_Pm5_CMOS_OUTPUT;
    PORT6.PMR.BYTE &= (_FE_Pm0_PIN_GPIO & _FD_Pm1_PIN_GPIO & _FB_Pm2_PIN_GPIO & _F7_Pm3_PIN_GPIO);
    PORT6.PDR.BYTE = _01_Pm0_MODE_OUTPUT | _02_Pm1_MODE_OUTPUT | _04_Pm2_MODE_OUTPUT | _08_Pm3_MODE_OUTPUT;

    /* Set PORT8 registers */
    PORT8.PODR.BYTE = _00_Pm2_OUTPUT_0;
    PORT8.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm1_CMOS_OUTPUT | _00_Pm2_CMOS_OUTPUT;
    PORT8.DSCR.BYTE = _00_Pm0_HIDRV_OFF | _00_Pm1_HIDRV_OFF | _00_Pm2_HIDRV_OFF;
    PORT8.DSCR2.BYTE = _00_Pm0_LARGECUR_OFF | _00_Pm1_LARGECUR_OFF | _00_Pm2_LARGECUR_OFF;
    PORT8.PMR.BYTE &= (_FB_Pm2_PIN_GPIO);
    PORT8.PDR.BYTE = _04_Pm2_MODE_OUTPUT;

    /* Set PORT9 registers */
    PORT9.PODR.BYTE = _00_Pm0_OUTPUT_0 | _00_Pm1_OUTPUT_0 | _00_Pm2_OUTPUT_0 | _00_Pm3_OUTPUT_0 | _00_Pm4_OUTPUT_0 | 
                      _00_Pm5_OUTPUT_0 | _00_Pm6_OUTPUT_0;
    PORT9.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm1_CMOS_OUTPUT | _00_Pm2_CMOS_OUTPUT | _00_Pm3_CMOS_OUTPUT;
    PORT9.ODR1.BYTE = _00_Pm4_CMOS_OUTPUT | _00_Pm5_CMOS_OUTPUT | _00_Pm6_CMOS_OUTPUT;
    PORT9.DSCR.BYTE = _00_Pm0_HIDRV_OFF | _00_Pm1_HIDRV_OFF | _00_Pm2_HIDRV_OFF | _00_Pm3_HIDRV_OFF | 
                      _00_Pm4_HIDRV_OFF | _00_Pm5_HIDRV_OFF | _00_Pm6_HIDRV_OFF;
    PORT9.DSCR2.BYTE = _00_Pm0_LARGECUR_OFF | _00_Pm1_LARGECUR_OFF | _00_Pm2_LARGECUR_OFF | _00_Pm3_LARGECUR_OFF | 
                       _00_Pm4_LARGECUR_OFF | _00_Pm5_LARGECUR_OFF | _00_Pm6_LARGECUR_OFF;
    PORT9.PMR.BYTE &= (_FE_Pm0_PIN_GPIO & _FD_Pm1_PIN_GPIO & _FB_Pm2_PIN_GPIO & _F7_Pm3_PIN_GPIO & _EF_Pm4_PIN_GPIO & 
                      _DF_Pm5_PIN_GPIO & _BF_Pm6_PIN_GPIO);
    PORT9.PDR.BYTE = _01_Pm0_MODE_OUTPUT | _02_Pm1_MODE_OUTPUT | _04_Pm2_MODE_OUTPUT | _08_Pm3_MODE_OUTPUT | 
                     _10_Pm4_MODE_OUTPUT | _20_Pm5_MODE_OUTPUT | _40_Pm6_MODE_OUTPUT;

    /* Set PORTA registers */
    PORTA.PODR.BYTE = _00_Pm0_OUTPUT_0 | _00_Pm2_OUTPUT_0 | _00_Pm3_OUTPUT_0 | _00_Pm4_OUTPUT_0;
    PORTA.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm2_CMOS_OUTPUT | _00_Pm3_CMOS_OUTPUT;
    PORTA.ODR1.BYTE = _00_Pm4_CMOS_OUTPUT;
    PORTA.PCR.BYTE = _02_Pm1_PULLUP_ON | _20_Pm5_PULLUP_ON;
    PORTA.DSCR.BYTE = _00_Pm0_HIDRV_OFF | _00_Pm2_HIDRV_OFF | _00_Pm3_HIDRV_OFF | _00_Pm4_HIDRV_OFF;
    PORTA.PMR.BYTE &= (_FE_Pm0_PIN_GPIO & _FD_Pm1_PIN_GPIO & _FB_Pm2_PIN_GPIO & _F7_Pm3_PIN_GPIO & _EF_Pm4_PIN_GPIO & 
                      _DF_Pm5_PIN_GPIO);
    PORTA.PDR.BYTE = _01_Pm0_MODE_OUTPUT | _00_Pm1_MODE_INPUT | _04_Pm2_MODE_OUTPUT | _08_Pm3_MODE_OUTPUT | 
                     _10_Pm4_MODE_OUTPUT | _00_Pm5_MODE_INPUT;

    /* Set PORTB registers */
    PORTB.PODR.BYTE = _00_Pm0_OUTPUT_0 | _00_Pm5_OUTPUT_0;
    PORTB.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm1_CMOS_OUTPUT | _00_Pm2_CMOS_OUTPUT | _00_Pm3_CMOS_OUTPUT;
    PORTB.ODR1.BYTE = _00_Pm4_CMOS_OUTPUT | _00_Pm5_CMOS_OUTPUT | _00_Pm6_CMOS_OUTPUT | _00_Pm7_CMOS_OUTPUT;
    PORTB.DSCR.BYTE = _00_Pm0_HIDRV_OFF | _00_Pm3_HIDRV_OFF | _00_Pm4_HIDRV_OFF | _00_Pm5_HIDRV_OFF | 
                      _00_Pm6_HIDRV_OFF | _00_Pm7_HIDRV_OFF;
    PORTB.DSCR2.BYTE = _00_Pm0_LARGECUR_OFF | _00_Pm3_LARGECUR_OFF | _00_Pm4_LARGECUR_OFF | _00_Pm5_LARGECUR_OFF | 
                       _00_Pm6_LARGECUR_OFF | _00_Pm7_LARGECUR_OFF;
    PORTB.PMR.BYTE &= (_FE_Pm0_PIN_GPIO & _DF_Pm5_PIN_GPIO);
    PORTB.PDR.BYTE = _01_Pm0_MODE_OUTPUT | _20_Pm5_MODE_OUTPUT;

    /* Set PORTD registers */
    PORTD.PODR.BYTE = _00_Pm0_OUTPUT_0 | _00_Pm1_OUTPUT_0 | _00_Pm2_OUTPUT_0 | _00_Pm3_OUTPUT_0 | _00_Pm4_OUTPUT_0 | 
                      _00_Pm5_OUTPUT_0 | _00_Pm6_OUTPUT_0 | _00_Pm7_OUTPUT_0;
    PORTD.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm1_CMOS_OUTPUT | _00_Pm2_CMOS_OUTPUT | _00_Pm3_CMOS_OUTPUT;
    PORTD.ODR1.BYTE = _00_Pm4_CMOS_OUTPUT | _00_Pm5_CMOS_OUTPUT | _00_Pm6_CMOS_OUTPUT | _00_Pm7_CMOS_OUTPUT;
    PORTD.DSCR.BYTE = _00_Pm0_HIDRV_OFF | _00_Pm1_HIDRV_OFF | _00_Pm2_HIDRV_OFF | _00_Pm3_HIDRV_OFF | 
                      _00_Pm4_HIDRV_OFF | _00_Pm5_HIDRV_OFF | _00_Pm6_HIDRV_OFF | _00_Pm7_HIDRV_OFF;
    PORTD.DSCR2.BYTE = _00_Pm0_LARGECUR_OFF | _00_Pm1_LARGECUR_OFF | _00_Pm2_LARGECUR_OFF | _00_Pm3_LARGECUR_OFF | 
                       _00_Pm4_LARGECUR_OFF | _00_Pm5_LARGECUR_OFF | _00_Pm6_LARGECUR_OFF | _00_Pm7_LARGECUR_OFF;
    PORTD.PMR.BYTE &= (_FE_Pm0_PIN_GPIO & _FD_Pm1_PIN_GPIO & _FB_Pm2_PIN_GPIO & _F7_Pm3_PIN_GPIO & _EF_Pm4_PIN_GPIO & 
                      _DF_Pm5_PIN_GPIO & _BF_Pm6_PIN_GPIO & _7F_Pm7_PIN_GPIO);
    PORTD.PDR.BYTE = _01_Pm0_MODE_OUTPUT | _02_Pm1_MODE_OUTPUT | _04_Pm2_MODE_OUTPUT | _08_Pm3_MODE_OUTPUT | 
                     _10_Pm4_MODE_OUTPUT | _20_Pm5_MODE_OUTPUT | _40_Pm6_MODE_OUTPUT | _80_Pm7_MODE_OUTPUT;

    /* Set PORTE registers */
    PORTE.PODR.BYTE = _00_Pm0_OUTPUT_0;
    PORTE.ODR0.BYTE = _00_Pm0_CMOS_OUTPUT | _00_Pm3_CMOS_OUTPUT;
    PORTE.ODR1.BYTE = _00_Pm4_CMOS_OUTPUT | _00_Pm5_CMOS_OUTPUT;
    PORTE.PCR.BYTE = _02_Pm1_PULLUP_ON;
    PORTE.DSCR.BYTE = _00_Pm0_HIDRV_OFF | _00_Pm3_HIDRV_OFF | _00_Pm4_HIDRV_OFF | _00_Pm5_HIDRV_OFF;
    PORTE.PMR.BYTE &= (_FE_Pm0_PIN_GPIO & _FD_Pm1_PIN_GPIO);
    PORTE.PDR.BYTE = _01_Pm0_MODE_OUTPUT | _00_Pm1_MODE_INPUT;

    R_Config_PORT_Create_UserInit();
}

/* Start user code for adding. Do not edit comment generated here */
/******************************************************************************
* Function Name : R_Config_PORT_GetSW1
* Description   : Get state of SW1
* Arguments     : none
* Return Value  : state of SW1
******************************************************************************/
uint8_t R_Config_PORT_GetSW1(void)
{
    return(PORT2.PIDR.BIT.B3);
} /* End of function R_Config_PORT_GetSW1 */

/******************************************************************************
* Function Name : R_Config_PORT_GetSW2
* Description   : Get state of SW2
* Arguments     : none
* Return Value  : state of SW2
******************************************************************************/
uint8_t R_Config_PORT_GetSW2(void)
{
    return (PORT2.PIDR.BIT.B2);
} /* End of function R_Config_PORT_GetSW2 */

/******************************************************************************
* Function Name : R_Config_PORT_Led1_on
* Description   : Turn on LED1
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_Config_PORT_Led1_on(void)
{
    PORT2.PODR.BIT.B1 = MTR_LED_ON;
} /* End of function R_Config_PORT_Led1_on */

/******************************************************************************
* Function Name : R_Config_PORT_Led2_on
* Description   : Turn on LED2
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_Config_PORT_Led2_on(void)
{
    PORT2.PODR.BIT.B0 = MTR_LED_ON;
} /* End of function R_Config_PORT_Led2_on */

/******************************************************************************
* Function Name : R_Config_PORT_Led1_off
* Description   : Turn off LED1
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_Config_PORT_Led1_off(void)
{
    PORT2.PODR.BIT.B1 = MTR_LED_OFF;
} /* End of function R_Config_PORT_Led1_off */

/******************************************************************************
* Function Name : R_Config_PORT_Led2_off
* Description   : Turn off LED2
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_Config_PORT_Led2_off(void)
{
    PORT2.PODR.BIT.B0 = MTR_LED_OFF;
} /* End of function R_Config_PORT_Led2_off */
/* End user code. Do not edit comment generated here */
