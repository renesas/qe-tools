/*
* Copyright (c) 2016 - 2026 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_MTU3_MTU4.h
* Component Version: 1.11.0
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_MTU3_MTU4.
***********************************************************************************************************************/

#ifndef CFG_Config_MTU3_MTU4_H
#define CFG_Config_MTU3_MTU4_H

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_mtu3.h"

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define MTU3_PCLK_COUNTER_DIVISION      (1)
#define _0030_3TCNT_VALUE               (0x0030U) /* MTU3.TCNT value */
#define _0030_TDDRA_VALUE               (0x0030U) /* MTU.TDDRA value */
#define _0960_TCDRA_VALUE               (0x0960U) /* MTU.TCDRA value */
#define _0064_3TGRB_VALUE               (0x0064U) /* MTU3.TGRB value */
#define _0064_4TGRA_VALUE               (0x0064U) /* MTU4.TGRA value */
#define _0064_4TGRB_VALUE               (0x0064U) /* MTU4.TGRB value */
#define _0064_3TGRE_VALUE               (0x0064U) /* MTU3.TGRE value */
#define _0064_4TGRE_VALUE               (0x0064U) /* MTU4.TGRE value */
#define _0064_4TGRF_VALUE               (0x0064U) /* MTU4.TGRF value */
/* Timer A/D Converter Start Request Cycle Set Registers A value */
#define _0064_TADCORA_VALUE             (0x0064U)
/* Timer A/D Converter Start Request Cycle Set Buffer Registers A value */
#define _0190_TADCOBRA_VALUE            (0x0190U)
/* Timer A/D Converter Start Request Cycle Set Registers B value */
#define _0320_TADCORB_VALUE             (0x0320U)
/* Timer A/D Converter Start Request Cycle Set Buffer Registers B value */
#define _0320_TADCOBRB_VALUE            (0x0320U)
#define _0990_SUM_VALUE                 (0x0990U) /* Timer General Register (TGR) value */

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void R_Config_MTU3_MTU4_Create(void);
void R_Config_MTU3_MTU4_Create_UserInit(void);
void R_Config_MTU3_MTU4_Start(void);
void R_Config_MTU3_MTU4_Stop(void);
/* Start user code for function. Do not edit comment generated here */
#ifndef MTR_ADC_TB
#define MTR_ADC_TB
typedef struct
{
    uint16_t   u2_vdc_ad;
    uint16_t   u2_Iac_raw0;
    uint16_t   u2_Iac_raw1;
} r_mtr_adc_tb;
#endif

#ifndef MTR_ADC_TS
#define MTR_ADC_TS
typedef struct
{
    uint16_t   u2_ia_ad;
    uint16_t   u2_ib_ad;
    uint16_t   u2_vdc_ad;
    uint16_t   u2_vphase_a_ad;
    uint16_t   u2_vphase_b_ad;
} r_mtr_adc_ts;
#endif

void R_Config_MTU3_MTU4_StartTimerCount(void);
void R_Config_MTU3_MTU4_StopTimerCount(void);
void R_Config_MTU3_MTU4_StartTimerCtrl(void);
void R_Config_MTU3_MTU4_StopTimerCtrl(void);
void R_Config_MTU3_MTU4_1ShuntUpdDuty(uint16_t duty_u,
                                      uint16_t duty_v,
                                      uint16_t duty_w,
                                      uint16_t duty_u_buff,
                                      uint16_t duty_v_buff,
                                      uint16_t duty_w_buff);
void R_Config_MTU3_MTU4_StartAD(void);
void R_Config_MTU3_MTU4_StopAD(void);
void R_Config_MTU3_MTU4_1ShuntAdcGetConvVal( r_mtr_adc_tb *mtr_ad_data );
void R_Config_MTU3_MTU4_AdcTriggerSet(uint16_t compare_match_value_a, uint16_t compare_match_value_b);
uint16_t R_Config_MTU3_MTU4_MaxCountGet(void);

typedef r_mtr_adc_tb r_mtr_adc_t;
/* End user code. Do not edit comment generated here */
#endif
