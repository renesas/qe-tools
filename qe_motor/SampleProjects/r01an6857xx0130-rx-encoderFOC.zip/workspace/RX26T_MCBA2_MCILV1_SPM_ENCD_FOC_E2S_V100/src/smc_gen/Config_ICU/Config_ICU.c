/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_ICU.c
* Component Version: 2.3.0
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_ICU.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_ICU.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_ICU_Create
* Description  : This function initializes the ICU module
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_Create(void)
{
    /* Disable IRQ interrupts */
    ICU.IER[0x08].BYTE = 0x00U;
    ICU.IER[0x09].BYTE = 0x00U;

    /* Disable software interrupt */
    IEN(ICU,SWINT) = 0U;
    IEN(ICU,SWINT2) = 0U;

    /* Disable IRQ digital filter */
    ICU.IRQFLTE0.BYTE &= ~(_10_ICU_IRQ4_FILTER_ENABLE | _80_ICU_IRQ7_FILTER_ENABLE);
    ICU.IRQFLTE1.BYTE &= ~(_80_ICU_IRQ15_FILTER_ENABLE);

    /* Set IRQ digital filter sampling clock */
    ICU.IRQFLTC0.BIT.FCLKSEL4 = _0000_ICU_IRQ_FILTER_PCLK;
    ICU.IRQFLTC0.BIT.FCLKSEL7 = _0000_ICU_IRQ_FILTER_PCLK;
    ICU.IRQFLTC1.BIT.FCLKSEL15 = _0000_ICU_IRQ_FILTER_PCLK;

    /* Set IRQ4 pin */
    MPC.P24PFS.BYTE = 0x40U;
    PORT2.PDR.BYTE &= 0xEFU;
    PORT2.PMR.BYTE &= 0xEFU;

    /* Set IRQ7 pin */
    MPC.P30PFS.BYTE = 0x40U;
    PORT3.PDR.BYTE &= 0xFEU;
    PORT3.PMR.BYTE &= 0xFEU;

    /* Set IRQ15 pin */
    MPC.P27PFS.BYTE = 0x40U;
    PORT2.PDR.BYTE &= 0x7FU;
    PORT2.PMR.BYTE &= 0x7FU;

    /* Set IRQ detection type */
    ICU.IRQCR[4].BYTE = _0C_ICU_IRQ_EDGE_BOTH;
    IR(ICU,IRQ4) = 0U;
    ICU.IRQCR[7].BYTE = _0C_ICU_IRQ_EDGE_BOTH;
    IR(ICU,IRQ7) = 0U;
    ICU.IRQCR[15].BYTE = _0C_ICU_IRQ_EDGE_BOTH;
    IR(ICU,IRQ15) = 0U;

    /* Enable IRQ digital filter */
    ICU.IRQFLTE0.BYTE |= (_10_ICU_IRQ4_FILTER_ENABLE | _80_ICU_IRQ7_FILTER_ENABLE);
    ICU.IRQFLTE1.BYTE |= (_80_ICU_IRQ15_FILTER_ENABLE);

    /* Set IRQ priority level */
    IPR(ICU,IRQ4) = _0E_ICU_PRIORITY_LEVEL14;
    IPR(ICU,IRQ7) = _0E_ICU_PRIORITY_LEVEL14;
    IPR(ICU,IRQ15) = _0E_ICU_PRIORITY_LEVEL14;

    R_Config_ICU_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ4_Start
* Description  : This function enables IRQ4 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ4_Start(void)
{
    /* Enable IRQ4 interrupt */
    IEN(ICU,IRQ4) = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ4_Stop
* Description  : This function disables IRQ4 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ4_Stop(void)
{
    /* Disable IRQ4 interrupt */
    IEN(ICU,IRQ4) = 0U;
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ7_Start
* Description  : This function enables IRQ7 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ7_Start(void)
{
    /* Enable IRQ7 interrupt */
    IEN(ICU,IRQ7) = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ7_Stop
* Description  : This function disables IRQ7 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ7_Stop(void)
{
    /* Disable IRQ7 interrupt */
    IEN(ICU,IRQ7) = 0U;
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ15_Start
* Description  : This function enables IRQ15 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ15_Start(void)
{
    /* Enable IRQ15 interrupt */
    IEN(ICU,IRQ15) = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_ICU_IRQ15_Stop
* Description  : This function disables IRQ15 interrupt
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_ICU_IRQ15_Stop(void)
{
    /* Disable IRQ15 interrupt */
    IEN(ICU,IRQ15) = 0U;
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
