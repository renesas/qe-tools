/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_MTU0_user.c
* Component Version: 1.12.0
* Device(s)        : R5F526TFCxFP
* Description      : This file implements device driver for Config_MTU0.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_MTU0.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_motor_encoder_vector_api.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_MTU0_Create_UserInit
* Description  : This function adds user code after initializing the MTU0 channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU0_Create_UserInit(void)
{
    /* Start user code for user init. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_MTU0_tgib0_interrupt
* Description  : This function is TGIB0 interrupt service routine
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

#if FAST_INTERRUPT_VECTOR == VECT_MTU0_TGIB0
#pragma interrupt r_Config_MTU0_tgib0_interrupt(vect=VECT(MTU0,TGIB0),fint)
#else
#pragma interrupt r_Config_MTU0_tgib0_interrupt(vect=VECT(MTU0,TGIB0))
#endif
static void r_Config_MTU0_tgib0_interrupt(void)
{
    
    /* Start user code for r_Config_MTU0_tgib0_interrupt. Do not edit comment generated here */
    R_MOTOR_ENCODER_VECTOR_EncoderInterrupt(&g_st_encoder_vector);
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
