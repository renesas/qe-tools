/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_encoder_vector_manager.c
* Description : The processes of motor control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <math.h>
#include <machine.h>
#include <stdint.h>
/* Main associated header file */
#include "r_motor_encoder_vector_manager.h"

/* Project headers */
#include "r_motor_common.h"
#include "r_motor_pi_control.h"
#include "r_motor_encoder_vector_statemachine.h"
#include "r_motor_encoder_vector_protection.h"
#include "r_motor_current_api.h"
#include "r_motor_speed_api.h"
#include "r_motor_position_api.h"
#include "r_motor_sensor_api.h"
#include "r_motor_driver.h"
#include "r_motor_ipd_api.h"
#include "r_motor_current.h"
#include "r_smc_entry.h"

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_default_init
* Description   : Initializes motor drive modules with default configuration
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_default_init(st_encoder_vector_control_t *p_st_encoder_vector)
{
    st_current_cfg_t        st_cur_cfg;
    st_speed_cfg_t          st_spd_cfg;
    st_position_cfg_t       st_pos_cfg;
    st_sensor_encoder_cfg_t st_encd_cfg;
    st_motor_driver_cfg_t   st_driver_cfg;
    st_ext_observer_cfg_t   st_ext_obs_cfg;
    st_encoder_driver_cfg_t st_encoder_driver_cfg;

    /* Initialize member of motor parameter structure */
    p_st_encoder_vector->st_motor.u2_mtr_pp = MOTOR_CFG_POLE_PAIRS;
    p_st_encoder_vector->st_motor.f4_mtr_r  = MOTOR_CFG_RESISTANCE;
    p_st_encoder_vector->st_motor.f4_mtr_ld = MOTOR_CFG_D_INDUCTANCE;
    p_st_encoder_vector->st_motor.f4_mtr_lq = MOTOR_CFG_Q_INDUCTANCE;
    p_st_encoder_vector->st_motor.f4_mtr_m  = MOTOR_CFG_MAGNETIC_FLUX;
    p_st_encoder_vector->st_motor.f4_mtr_j  = MOTOR_CFG_ROTOR_INERTIA;
    p_st_encoder_vector->st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS;

    p_st_encoder_vector->u1_direction             = MTR_CW;
    p_st_encoder_vector->f4_overspeed_limit_rad   = (SPEED_CFG_SPEED_LIMIT_RPM * MTR_RPM2RAD);
    p_st_encoder_vector->f4_overvoltage_limit     = INVERTER_CFG_OVERVOLTAGE_LIMIT;
    p_st_encoder_vector->f4_undervoltage_limit    = INVERTER_CFG_UNDERVOLTAGE_LIMIT;
    p_st_encoder_vector->u1_encd_angle_adj_mode   = ENCODER_VECTOR_CFG_ANGLE_ADJUST_MODE;
    p_st_encoder_vector->u1_ctrl_loop_mode        = MOTOR_COMMON_CFG_LOOP_MODE;
    p_st_encoder_vector->u1_flag_ipd_use          = MOTOR_COMMON_CFG_IPD_CTRL;
    p_st_encoder_vector->f4_max_speed_rc_fil_rpm  = MOTOR_COMMON_RC_FIL_MAX_SPEED_RPM;
    p_st_encoder_vector->f4_overcurrent_limit     = MOTOR_COMMON_OVERCURRENT_LIMIT;
    p_st_encoder_vector->u1_encd_angle_adj_status = MOTOR_ENCODER_ANGLE_ADJ_90DEG;
    p_st_encoder_vector->u2_encd_angle_adj_time   = SENSOR_ENCD_ANGLE_ADJ_TIME;
    p_st_encoder_vector->u2_encd_angle_adj_cnt    = 0;
    p_st_encoder_vector->u1_state_id_ref          = CURRENT_STATE_ID_ZERO_CONST;
    p_st_encoder_vector->u1_state_iq_ref          = CURRENT_STATE_IQ_ZERO_CONST;
    p_st_encoder_vector->u1_state_speed_ref       = SPEED_STATE_ZERO_CONST;

    /* Current configuration set */
    st_cur_cfg.st_motor                  = p_st_encoder_vector->st_motor;
    st_cur_cfg.u1_flag_volt_err_comp_use = CURRENT_CFG_VOLT_ERR_COMP;
    st_cur_cfg.u2_offset_calc_time       = CURRENT_CFG_OFFSET_CALC_TIME;
    st_cur_cfg.f4_ctrl_period            = MOTOR_COMMON_CTRL_PERIOD;
    st_cur_cfg.f4_id_up_step             = MOTOR_COMMON_ID_UP_STEP_RATE;
    st_cur_cfg.f4_ol_ref_id              = CURRENT_CFG_REF_ID_OPENLOOP;
    st_cur_cfg.f4_current_omega_hz       = CURRENT_CFG_OMEGA;
    st_cur_cfg.f4_current_zeta           = CURRENT_CFG_ZETA;
    R_MOTOR_CURRENT_ParameterUpdate(p_st_encoder_vector->p_st_cc, &st_cur_cfg);

    /* Voltage error compensation*/
    static const float  volterr_array[VERR_COMP_ARY_SIZE] =
    {
        INVERTER_CFG_COMP_V0,    /* f4_comp_v[0] */
        INVERTER_CFG_COMP_V1,    /* f4_comp_v[1] */
        INVERTER_CFG_COMP_V2,    /* f4_comp_v[2] */
        INVERTER_CFG_COMP_V3,    /* f4_comp_v[3] */
        INVERTER_CFG_COMP_V4,    /* f4_comp_v[4] */
    };
    static const float  crnt_array[VERR_COMP_ARY_SIZE] =
    {
        INVERTER_CFG_COMP_I0,    /* f4_comp_i[0] */
        INVERTER_CFG_COMP_I1,    /* f4_comp_i[1] */
        INVERTER_CFG_COMP_I2,    /* f4_comp_i[2] */
        INVERTER_CFG_COMP_I3,    /* f4_comp_i[3] */
        INVERTER_CFG_COMP_I4     /* f4_comp_i[4] */
    };
    float ref_voltage;
    ref_voltage = INVERTER_CFG_INPUT_V;
    R_MOTOR_CURRENT_VoltErrCompParamSet(p_st_encoder_vector->p_st_cc,
                                        crnt_array,
                                        volterr_array,
                                        ref_voltage);

    /* Speed configuration set */
    st_spd_cfg.st_motor                = p_st_encoder_vector->st_motor;
    st_spd_cfg.u1_flag_extobserver_use = SPEED_CFG_OBSERVER;
    st_spd_cfg.u1_flag_fluxwkn_use     = SPEED_CFG_FLUX_WEAKENING;
    st_spd_cfg.f4_speed_ctrl_period    = SPEED_CFG_CTRL_PERIOD;
    st_spd_cfg.f4_max_speed_rpm        = MOTOR_CFG_MAX_SPEED_RPM;
    st_spd_cfg.f4_speed_rate_limit_rpm = SPEED_CFG_RATE_LIMIT_RPM;
    st_spd_cfg.f4_speed_omega_hz       = SPEED_CFG_OMEGA;
    st_spd_cfg.f4_speed_zeta           = SPEED_CFG_ZETA;
    st_spd_cfg.f4_speed_lpf_hz         = SPEED_CFG_LPF_OMEGA;
    R_MOTOR_SPEED_ParameterUpdate(p_st_encoder_vector->p_st_sc, &st_spd_cfg);

    /* speed observer */
    st_ext_obs_cfg.f4_extobs_omega  = SPEED_CFG_SOB_OMEGA;
    R_MOTOR_SPEED_ExtObserverParameterUpdate(&g_st_sc, &st_ext_obs_cfg);

    /* Position configuration set */
    st_pos_cfg.st_motor                     = p_st_encoder_vector->st_motor;
    st_pos_cfg.u2_dead_band                 = POSITION_CFG_DEAD_BAND;
    st_pos_cfg.u2_band_limit                = POSITION_CFG_BAND_LIMIT;
    st_pos_cfg.u2_pos_interval_time         = POSITION_CFG_INTERVAL_TIME;
    st_pos_cfg.f4_feedforward_ratio         = POSITION_CFG_SPEED_FF_RATIO;
    st_pos_cfg.f4_position_omega_hz         = POSITION_CFG_OMEGA;
    st_pos_cfg.f4_ctrl_period               = POSITION_CFG_CTRL_PERIOD;
    st_pos_cfg.f4_mech_angle_per_sensor_cnt = (MTR_TWOPI / MOTOR_COMMON_SENSOR_ENCD_CPR);
    st_pos_cfg.f4_max_speed_rad             = (MOTOR_CFG_MAX_SPEED_RPM * MTR_RPM2RAD);
    st_pos_cfg.f4_accel_time                = POSITION_PROFILE_ACCEL_TIME;
    st_pos_cfg.f4_posprof_max_speed_rad     = (MOTOR_CFG_MAX_SPEED_RPM * MTR_RPM2RAD);
    R_MOTOR_POSITION_ParameterUpdate(p_st_encoder_vector->p_st_pc, &st_pos_cfg);
    R_MOTOR_POSITION_CommandModeSet(p_st_encoder_vector->p_st_pc, POSITION_COMMAND_MODE_TRAPEZOID);

    /* IPD configuration set */
    R_MOTOR_IPD_ParameterUpdate(p_st_encoder_vector->p_st_ipd,
                                IPD_POS_KP_RATIO,
                                IPD_POS_FF_RATIO,
                                IPD_SPEED_RATIO,
                                IPD_POS_ERR_INPUT_LIMIT,
                                IPD_POS_ERR_INTEGRATOR_LIMIT_RATIO);
    R_MOTOR_IPD_CtrlGainCalc(p_st_encoder_vector->p_st_ipd,
                             &p_st_encoder_vector->st_motor,
                             IPD_CFG_OMEGA,
                             POSITION_CFG_CTRL_PERIOD);

    /* Setup current limits by nominal current of motor */
    motor_encoder_vector_nominal_current_set(p_st_encoder_vector, MOTOR_CFG_NOMINAL_CURRENT_RMS);

    /* encoder control parameter reset */
    st_encd_cfg.st_motor                = p_st_encoder_vector->st_motor;
    st_encd_cfg.u1_ctrl_loop_mode       = p_st_encoder_vector->u1_ctrl_loop_mode;
    st_encd_cfg.u2_encd_cpr             = SENSOR_CFG_ENCD_PPR;
    st_encd_cfg.f4_ctrl_period          = MOTOR_COMMON_CTRL_PERIOD;
    st_encd_cfg.f4_hs_change_speed_rpm  = SENSOR_ENCD_HS_CHANGE_RPM;
    st_encd_cfg.f4_hs_change_margin_rpm = SENSOR_ENCD_HS_CHANGE_MARGIN_RPM;
    R_MOTOR_SENSOR_ENCODER_ParameterUpdate(p_st_encoder_vector->p_st_sensor, &st_encd_cfg);
    /* Sensor connect to driver */
    st_encoder_driver_cfg.EncdCntDataGet       = SENSOR_CFG_ENCD_FUNC_CNT_GET;
    st_encoder_driver_cfg.EncdCntDataSet       = SENSOR_CFG_ENCD_FUNC_CNT_SET;
    st_encoder_driver_cfg.EncdInterruptEnable  = SENSOR_CFG_ENCD_FUNC_INT_ENABLE;
    st_encoder_driver_cfg.EncdInterruptDisable = SENSOR_CFG_ENCD_FUNC_INT_DISABLE;
    st_encoder_driver_cfg.EncdTimerStart       = SENSOR_CFG_ENCD_FUNC_SPD_TIMER_START;
    st_encoder_driver_cfg.EncdTimerGet         = SENSOR_CFG_ENCD_FUNC_SPD_TIMER_CNT_GET;
    st_encoder_driver_cfg.HallSignalGet        = SENSOR_CFG_HALL_FUNC_SIGNAL_GET;
    st_encoder_driver_cfg.HallUEnable          = SENSOR_CFG_HALL_FUNC_INT_U_START;
    st_encoder_driver_cfg.HallVEnable          = SENSOR_CFG_HALL_FUNC_INT_V_START;
    st_encoder_driver_cfg.HallWEnable          = SENSOR_CFG_HALL_FUNC_INT_W_START;
    st_encoder_driver_cfg.HallUDisable         = SENSOR_CFG_HALL_FUNC_INT_U_STOP;
    st_encoder_driver_cfg.HallVDisable         = SENSOR_CFG_HALL_FUNC_INT_V_STOP;
    st_encoder_driver_cfg.HallWDisable         = SENSOR_CFG_HALL_FUNC_INT_W_STOP;
    R_MOTOR_SENSOR_ENCODER_DriverParameterUpdate(p_st_encoder_vector->p_st_sensor, &st_encoder_driver_cfg);

    /* driver */
    st_driver_cfg.ADCDataGet           = DRIVER_CFG_FUNC_ADC_DATA_GET;
    st_driver_cfg.BLDCDutySet          = DRIVER_CFG_FUNC_DUTY_SET;
    st_driver_cfg.PWMOutputStart       = DRIVER_CFG_FUNC_PWM_OUTPUT_START;
    st_driver_cfg.PWMOutputStop        = DRIVER_CFG_FUNC_PWM_OUTPUT_STOP;
    st_driver_cfg.f4_shunt_ohm         = INVERTER_CFG_SHUNT_RESIST;
    st_driver_cfg.f4_volt_gain         = INVERTER_CFG_VOLTAGE_GAIN;
    st_driver_cfg.f4_crnt_amp_gain     = INVERTER_CFG_CURRENT_AMP_GAIN;
    st_driver_cfg.f4_pwm_period_cnt    = MOTOR_COMMON_CARRIER_SET_BASE;
    st_driver_cfg.f4_pwm_dead_time_cnt = MOTOR_COMMON_DEADTIME_SET;
    R_MOTOR_DRIVER_ParameterUpdate(p_st_encoder_vector->p_st_driver, &st_driver_cfg);

    /* Reset motor */
    motor_encoder_vector_reset(p_st_encoder_vector);
} /* End of function motor_encoder_vector_default_init */

/**********************************************************************************************************************
* Function Name : motor_encoder_vector_reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_reset(st_encoder_vector_control_t *p_st_encoder_vector)
{
    /* Reset status structure members */
    p_st_encoder_vector->u2_run_mode              = MOTOR_MODE_INIT;
    p_st_encoder_vector->u2_error_status          = MOTOR_ENCODER_VECTOR_ERROR_NONE;
    p_st_encoder_vector->u1_state_id_ref          = CURRENT_STATE_ID_ZERO_CONST;
    p_st_encoder_vector->u1_state_iq_ref          = CURRENT_STATE_IQ_ZERO_CONST;
    p_st_encoder_vector->u1_state_speed_ref       = SPEED_STATE_ZERO_CONST;
    p_st_encoder_vector->u1_encd_angle_adj_status = MOTOR_ENCODER_ANGLE_ADJ_90DEG;
    p_st_encoder_vector->u2_encd_angle_adj_time   = SENSOR_ENCD_ANGLE_ADJ_TIME;
    p_st_encoder_vector->u2_encd_angle_adj_cnt    = 0;
    p_st_encoder_vector->f4_vdc_ad                = 0.0f;
    p_st_encoder_vector->f4_iu_ad                 = 0.0f;
    p_st_encoder_vector->f4_iv_ad                 = 0.0f;
    p_st_encoder_vector->f4_iw_ad                 = 0.0f;

    /* Current output reset */
    p_st_encoder_vector->st_current_output.f4_modu             = 0.0f;
    p_st_encoder_vector->st_current_output.f4_modv             = 0.0f;
    p_st_encoder_vector->st_current_output.f4_modw             = 0.0f;
    p_st_encoder_vector->st_current_output.f4_neutral_duty     = 0.0f;
    p_st_encoder_vector->st_current_output.f4_va_max           = 0.0f;
    p_st_encoder_vector->st_current_output.u1_flag_offset_calc = MTR_FLG_CLR;
    /* Speed output reset */
    p_st_encoder_vector->st_speed_output.f4_id_ref             = 0.0f;
    p_st_encoder_vector->st_speed_output.f4_iq_ref             = 0.0f;
    p_st_encoder_vector->st_speed_output.f4_ref_speed_rad_ctrl = 0.0f;
    p_st_encoder_vector->st_speed_output.f4_speed_rad_lpf      = 0.0f;
    /* Position output reset*/
    p_st_encoder_vector->st_position_output.f4_position_err    = 0.0f;
    p_st_encoder_vector->st_position_output.f4_speed_ref       = 0.0f;
    p_st_encoder_vector->st_position_output.u1_in_position     = MTR_FLG_CLR;
    /* Sensor output reset */
    p_st_encoder_vector->st_sensor_encoder_output.f4_pos_rad     = 0.0f;
    p_st_encoder_vector->st_sensor_encoder_output.f4_speed_rad   = 0.0f;
    p_st_encoder_vector->st_sensor_hall_output.f4_hall_angle_rad = 0.0f;

    /* Reset current control module */
    R_MOTOR_CURRENT_Reset(p_st_encoder_vector->p_st_cc);
    /* Reset speed control module */
    R_MOTOR_SPEED_Reset(p_st_encoder_vector->p_st_sc);
    /* Reset position control module */
    R_MOTOR_POSITION_Reset(p_st_encoder_vector->p_st_pc);
    /* Encoder control parameter reset */
    R_MOTOR_SENSOR_ENCODER_Reset(p_st_encoder_vector->p_st_sensor);
    /* ipd control */
    R_MOTOR_IPD_Reset(p_st_encoder_vector->p_st_ipd);
} /* End of function motor_encoder_vector_reset */

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_decide_direction
* Description   : Decide direction
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_decide_direction(st_encoder_vector_control_t *p_st_encoder_vector)
{
    if (0.0f <= p_st_encoder_vector->st_speed_output.f4_speed_rad_lpf)
    {
        p_st_encoder_vector->u1_direction = MTR_CW;
    }
    else if (0.0f > p_st_encoder_vector->st_speed_output.f4_speed_rad_lpf)
    {
        p_st_encoder_vector->u1_direction = MTR_CCW;
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_encoder_vector_decide_direction */

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_error_process
* Description   : Sets error flags and trigger error event when u2_error_flag is not zero
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
*                 u2_error_flag - The error flags of the errors to report
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_error_process(st_encoder_vector_control_t *p_st_encoder_vector, uint16_t u2_error_flag)
{
    if (MOTOR_ENCODER_VECTOR_ERROR_NONE != u2_error_flag)
    {
        p_st_encoder_vector->u2_error_status |= u2_error_flag;
        motor_encoder_vector_statemachine_event(&p_st_encoder_vector->st_stm,
                                                p_st_encoder_vector,
                                                STATEMACHINE_EVENT_ERROR);
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_encoder_vector_error_process */

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_angle_speed_select
* Description   : Angle and speed detection
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_angle_speed_select(st_encoder_vector_control_t *p_st_encoder_vector)
{

    float f4_angle_rad = 0.0f;

    if (MOTOR_MODE_INIT == p_st_encoder_vector->u2_run_mode)
    {
        f4_angle_rad = p_st_encoder_vector->st_sensor_hall_output.f4_hall_angle_rad;
    }
    else if (MOTOR_MODE_BOOT == p_st_encoder_vector->u2_run_mode)
    {
        /* speed must be zero while adjusting angle */
        p_st_encoder_vector->st_sensor_encoder_output.f4_speed_rad = 0.0f;

        if (MOTOR_ENCODER_ANGLE_ADJ_90DEG == p_st_encoder_vector->u1_encd_angle_adj_status)
        {
            /* set alignment angle to Pi/2[rad] */
            f4_angle_rad = MTR_TWOPI * 0.25f;
        }
        else if (MOTOR_ENCODER_ANGLE_ADJ_0DEG == p_st_encoder_vector->u1_encd_angle_adj_status)
        {
            /* set alignment angle to 0[rad] */
            f4_angle_rad = 0.0f;
        }
        else
        {
                /* Do Nothing */
        }
    }
    else if (MOTOR_MODE_DRIVE == p_st_encoder_vector->u2_run_mode)
    {
        R_MOTOR_SENSOR_ENCODER_ParameterGet(p_st_encoder_vector->p_st_sensor,
                                            &p_st_encoder_vector->st_sensor_encoder_output);

        /* convert mechanical angle to electrical angle */
        if (MOTOR_ANGLE_ADJ_HALL == p_st_encoder_vector->u1_encd_angle_adj_mode)
        {
            f4_angle_rad = p_st_encoder_vector->st_sensor_hall_output.f4_hall_angle_rad
                    + fmod((p_st_encoder_vector->st_sensor_encoder_output.f4_pos_rad
                            * p_st_encoder_vector->st_motor.u2_mtr_pp), MTR_TWOPI);
        }
        else if (MOTOR_ANGLE_ADJ_EXCIT == p_st_encoder_vector->u1_encd_angle_adj_mode)
        {
            f4_angle_rad = fmod((p_st_encoder_vector->st_sensor_encoder_output.f4_pos_rad
                    * p_st_encoder_vector->st_motor.u2_mtr_pp), MTR_TWOPI);
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        /* Do Nothing */
    }

    if (f4_angle_rad >= MTR_TWOPI)
    {
        f4_angle_rad = f4_angle_rad - MTR_TWOPI;
    }
    else if (f4_angle_rad < 0.0f)
    {
        f4_angle_rad = f4_angle_rad + MTR_TWOPI;
    }
    else
    {
        /* Do nothing */
    }

    p_st_encoder_vector->f4_rotor_angle_rad = f4_angle_rad;
} /* End of function motor_encoder_vector_angle_speed_select */

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_pos_offset_adjust
* Description   : Angle adjust with forced excitation
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : command value of id
***********************************************************************************************************************/
void motor_encoder_vector_pos_offset_adjust(st_encoder_vector_control_t *p_st_encoder_vector)
{
    /* angle adjusted to 90 degree */
    if (MOTOR_ENCODER_ANGLE_ADJ_90DEG == p_st_encoder_vector->u1_encd_angle_adj_status)
    {
        /* reset angle adjust counter */
        p_st_encoder_vector->u2_encd_angle_adj_cnt = 0;
        p_st_encoder_vector->u1_encd_angle_adj_status = MOTOR_ENCODER_ANGLE_ADJ_0DEG;
    }
    /* angle adjusted to 0 degree */
    else if (MOTOR_ENCODER_ANGLE_ADJ_0DEG == p_st_encoder_vector->u1_encd_angle_adj_status)
    {
clrpsw_i();
        /* reset timer counter */
        p_st_encoder_vector->p_st_sensor->EncdCntDataSet(0);
setpsw_i();
        p_st_encoder_vector->p_st_sensor->EncdTimerStart();
        /* prevent angle adjust count overflow (not necessary,TBD)*/
        p_st_encoder_vector->u2_encd_angle_adj_cnt    = p_st_encoder_vector->u2_encd_angle_adj_time;
        p_st_encoder_vector->u1_encd_angle_adj_status = MOTOR_ENCODER_ANGLE_ADJ_FIN;
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_encoder_vector_pos_offset_adjust */

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_speed_status_select
* Description   : Performs state transition related to speed reference
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_speed_status_select(st_encoder_vector_control_t *p_st_encoder_vector)
{
    if ((SPEED_STATE_ZERO_CONST == p_st_encoder_vector->u1_state_speed_ref)
                                   && (MOTOR_ENCODER_ANGLE_ADJ_FIN == p_st_encoder_vector->u1_encd_angle_adj_status))
    {
        /* check control loop mode */
        if (MOTOR_LOOP_SPEED == p_st_encoder_vector->u1_ctrl_loop_mode)
        {
            p_st_encoder_vector->u1_state_speed_ref = SPEED_STATE_MANUAL;
            R_MOTOR_SPEED_IPDEnableSet(p_st_encoder_vector->p_st_sc, MTR_FALSE);
        }
        else if (MOTOR_LOOP_POSITION == p_st_encoder_vector->u1_ctrl_loop_mode)
        {
            p_st_encoder_vector->u1_state_speed_ref = SPEED_STATE_POS_CONTROL_OUTPUT;
            R_MOTOR_SPEED_IPDEnableSet(p_st_encoder_vector->p_st_sc, p_st_encoder_vector->u1_flag_ipd_use);
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_encoder_vector_speed_status_select */

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_iq_status_select
* Description   : Performs state transition related to q-axis current reference
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_iq_status_select(st_encoder_vector_control_t *p_st_encoder_vector)
{
    if ((CURRENT_STATE_IQ_ZERO_CONST == p_st_encoder_vector->u1_state_iq_ref)
                                        && (MOTOR_MODE_DRIVE == p_st_encoder_vector->u2_run_mode))
    {
        p_st_encoder_vector->u1_state_iq_ref = CURRENT_STATE_IQ_SPEED_PI_OUTPUT;
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_encoder_vector_iq_status_select */

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_id_status_select
* Description   : Performs state transition related to d-axis current reference
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_id_status_select(st_encoder_vector_control_t *p_st_encoder_vector)
{
    switch (p_st_encoder_vector->u1_state_id_ref)
    {
        case CURRENT_STATE_ID_ZERO_CONST:
            if (p_st_encoder_vector->u2_run_mode == MOTOR_MODE_BOOT)
            {
                p_st_encoder_vector->u1_state_id_ref = CURRENT_STATE_ID_UP;
            }
            else if (p_st_encoder_vector->u2_run_mode == MOTOR_MODE_DRIVE)
            {
                p_st_encoder_vector->u1_state_id_ref = CURRENT_STATE_ID_INPUT;
            }
        break;

        case CURRENT_STATE_ID_UP:
            /* d axis current ramping */
            if (p_st_encoder_vector->p_st_cc->f4_ref_id_ctrl >= p_st_encoder_vector->p_st_cc->f4_ol_ref_id)
            {
                p_st_encoder_vector->u1_state_id_ref = CURRENT_STATE_ID_MANUAL;
            }
        break;

        case CURRENT_STATE_ID_MANUAL:
            p_st_encoder_vector->u2_encd_angle_adj_cnt++;
            if (p_st_encoder_vector->u2_encd_angle_adj_cnt >= p_st_encoder_vector->u2_encd_angle_adj_time)
            {
                /* angle adjusted to 90 degree */
                if (MOTOR_ENCODER_ANGLE_ADJ_90DEG == p_st_encoder_vector->u1_encd_angle_adj_status)
                {
                    /* repeat soft start */
                    p_st_encoder_vector->u1_state_id_ref = CURRENT_STATE_ID_UP;
                }
                /* angle adjusted to 0 degree */
                else if (MOTOR_ENCODER_ANGLE_ADJ_0DEG == p_st_encoder_vector->u1_encd_angle_adj_status)
                {
                    /* id mode transition to input mode */
                    p_st_encoder_vector->u1_state_id_ref = CURRENT_STATE_ID_INPUT;
                }
                else
                {
                    /* Do Nothing */
                }
                motor_encoder_vector_pos_offset_adjust(p_st_encoder_vector);
            }
        break;

        default:
            /* Do Nothing */
        break;
    }
} /* End of function motor_encoder_vector_id_status_select */

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_position_status_select
* Description   : Performs state transition related to position reference
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_position_status_select(st_encoder_vector_control_t *p_st_encoder_vector)
{
    if (MOTOR_MODE_DRIVE == p_st_encoder_vector->u2_run_mode)
    {
        if (MOTOR_LOOP_POSITION == p_st_encoder_vector->u1_ctrl_loop_mode)
        {
            R_MOTOR_POSITION_IPDEnableSet(p_st_encoder_vector->p_st_pc, p_st_encoder_vector->u1_flag_ipd_use);
        }
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_encoder_vector_position_status_select */

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_nominal_current_set
* Description   : Setup current related limit values by the nominal current of motor
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
*                 f4_nominal_current_rms - The nominal current[Arms] of motor
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_nominal_current_set(st_encoder_vector_control_t *p_st_encoder_vector,
        float f4_nominal_current_rms)
{
    p_st_encoder_vector->f4_overcurrent_limit = (f4_nominal_current_rms * MTR_SQRT_2)
                                                * MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT;

    if (p_st_encoder_vector->f4_overcurrent_limit > INVERTER_CFG_CURRENT_LIMIT)
    {
        p_st_encoder_vector->f4_overcurrent_limit = INVERTER_CFG_CURRENT_LIMIT;
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function motor_encoder_vector_nominal_current_set */

/***********************************************************************************************************************
* Function Name : motor_encoder_vector_module_activate
* Description   : Activate modules
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_encoder_vector_module_activate(st_encoder_vector_control_t *p_st_encoder_vector)
{
    switch (p_st_encoder_vector->u1_ctrl_loop_mode)
    {
        case MOTOR_LOOP_SPEED:
            R_MOTOR_CURRENT_Run(p_st_encoder_vector->p_st_cc);
            R_MOTOR_SPEED_Run(p_st_encoder_vector->p_st_sc);
            break;

        case MOTOR_LOOP_POSITION:
            R_MOTOR_CURRENT_Run(p_st_encoder_vector->p_st_cc);
            R_MOTOR_SPEED_Run(p_st_encoder_vector->p_st_sc);
            R_MOTOR_POSITION_Run(p_st_encoder_vector->p_st_pc);
            break;

        default:
            /* Do Nothing */
            break;
    }
} /* End of function motor_encoder_vector_module_activate */
