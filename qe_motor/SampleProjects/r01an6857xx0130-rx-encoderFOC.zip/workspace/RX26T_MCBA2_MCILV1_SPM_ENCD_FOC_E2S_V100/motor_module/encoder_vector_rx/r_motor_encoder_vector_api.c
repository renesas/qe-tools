/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_encoder_vector_api.c
* Description : The processes of accessing driver
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <math.h>
#include "r_smc_entry.h"

/* Main associated header file */
#include "r_motor_encoder_vector_api.h"
#include "r_motor_encoder_vector_manager.h"

/* Module headers */
/* Submodule headers */
#include "r_motor_encoder_vector_protection.h"

/* General library headers */
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/
st_encoder_vector_control_t g_st_encoder_vector;

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_Open
* Description   : Open Encoder FOC Control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_Open(void)
{
    R_MOTOR_CURRENT_Open();
    R_MOTOR_SPEED_Open();
    R_MOTOR_POSITION_Open();
    R_MOTOR_IPD_Open();
    R_MOTOR_SENSOR_ENCODER_Open();
    R_MOTOR_DRIVER_Open();

    /* Store the address of the module instance in a structure and connect the module to be used */
    g_st_encoder_vector.p_st_cc             = &g_st_cc;
    g_st_encoder_vector.p_st_sc             = &g_st_sc;
    g_st_encoder_vector.p_st_pc             = &g_st_pc;
    g_st_encoder_vector.p_st_ipd            = &g_st_ipd;
    g_st_encoder_vector.p_st_sensor         = &g_st_sensor;
    g_st_encoder_vector.p_st_driver         = &g_st_driver;

    R_MOTOR_POSITION_IPDInstanceAddressSet(g_st_encoder_vector.p_st_pc, g_st_encoder_vector.p_st_ipd);
    R_MOTOR_SPEED_IPDInstanceAddressSet(g_st_encoder_vector.p_st_sc, g_st_encoder_vector.p_st_ipd);

    motor_encoder_vector_statemachine_init(&g_st_encoder_vector.st_stm);
    motor_encoder_vector_default_init(&g_st_encoder_vector);
} /* End of function R_MOTOR_ENCODER_VECTOR_Open */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_Close
* Description   : Close Encoder FOC Control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_Close(void)
{
    R_MOTOR_CURRENT_Close();
    R_MOTOR_SPEED_Close();
    R_MOTOR_POSITION_Close();
    R_MOTOR_IPD_Close();
    R_MOTOR_SENSOR_ENCODER_Close();
    R_MOTOR_DRIVER_Close();
    motor_encoder_vector_reset(&g_st_encoder_vector);
} /* End of function R_MOTOR_ENCODER_VECTOR_Close */

/**********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_Reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_Reset(st_encoder_vector_control_t *p_st_encoder_vector)
{
    motor_encoder_vector_reset(p_st_encoder_vector);
} /* End of function R_MOTOR_ENCODER_VECTOR_Reset */

/**********************************************************************************************************************
 * Function Name: R_MOTOR_ENCODER_VECTOR_ParameterUpdate
 * Description  : Update parameter for Encoder Vector Control
 * Arguments    : p_st_encoder_vector    - The pointer to the motor control management data structure
 *              : p_cfg                  - The pointer to the motor control management config structure
 * Return Value : None
 *********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_ParameterUpdate(st_encoder_vector_control_t * p_st_encoder_vector,
                                            st_encoder_vector_cfg_t * p_cfg)
{
    if (motor_encoder_vector_statemachine_status_get(&p_st_encoder_vector->st_stm) == STATEMACHINE_STATE_RUN)
    {
        return;
    }
    p_st_encoder_vector->st_motor = p_cfg->st_motor;
    motor_encoder_vector_nominal_current_set(&g_st_encoder_vector,
                                             p_st_encoder_vector->st_motor.f4_nominal_current_rms);
    p_st_encoder_vector->u1_encd_angle_adj_mode  = p_cfg->u1_encd_angle_adj_mode;
    p_st_encoder_vector->f4_max_speed_rc_fil_rpm =
            60.0f / (MOTOR_COMMON_RC_FIL_TIME_CONS * ENCODER_VECTOR_CFG_RC_FIL_TIME_CONS_MAG
            * p_cfg->u2_encd_cpr * SENSOR_CFG_ENCD_RESOLUTION_MULTIPL);
    p_st_encoder_vector->f4_overspeed_limit_rad  = p_cfg->f4_overspeed_limit_rpm * MTR_RPM2RAD;
} /* End of function R_MOTOR_ENCODER_VECTOR_ParameterUpdate */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_MotorStart
* Description   : Start to drive motor
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_MotorStart(st_encoder_vector_control_t *p_st_encoder_vector)
{
    motor_encoder_vector_statemachine_event(&p_st_encoder_vector->st_stm,
                                            p_st_encoder_vector,
                                            STATEMACHINE_EVENT_RUN);
} /* End of function R_MOTOR_ENCODER_VECTOR_MotorStart */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_MotorStop
* Description   : Stop driving motor
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_MotorStop(st_encoder_vector_control_t *p_st_encoder_vector)
{
    motor_encoder_vector_statemachine_event(&p_st_encoder_vector->st_stm,
                                            p_st_encoder_vector,
                                            STATEMACHINE_EVENT_STOP);
} /* End of function R_MOTOR_ENCODER_VECTOR_MotorStop */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_MotorReset
* Description   : Cancel error
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_MotorReset(st_encoder_vector_control_t *p_st_encoder_vector)
{
    motor_encoder_vector_statemachine_event(&p_st_encoder_vector->st_stm,
                                            p_st_encoder_vector,
                                            STATEMACHINE_EVENT_RESET);
} /* End of function R_MOTOR_ENCODER_VECTOR_MotorReset */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_ErrorSet
* Description   : Set error
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_ErrorSet(st_encoder_vector_control_t *p_st_encoder_vector)
{
    p_st_encoder_vector->u2_error_status |= MOTOR_ENCODER_VECTOR_ERROR_UNKNOWN;
    motor_encoder_vector_statemachine_event(&p_st_encoder_vector->st_stm,
                                            p_st_encoder_vector,
                                            STATEMACHINE_EVENT_ERROR);
} /* End of function R_MOTOR_ENCODER_VECTOR_ErrorSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_PositionSet
* Description   : Set position reference
* Arguments     : p_st_encoder_vector        - The pointer to the motor control management data structure
*                 f4_ref_position - position reference [degree]
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_PositionSet(st_encoder_vector_control_t *p_st_encoder_vector, float f4_ref_position)
{
    R_MOTOR_POSITION_PosRefSet(p_st_encoder_vector->p_st_pc, f4_ref_position);
} /* End of function R_MOTOR_ENCODER_VECTOR_PositionSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_PositionGet
* Description   : Get position [degree]
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : position [degree]
***********************************************************************************************************************/
float R_MOTOR_ENCODER_VECTOR_PositionGet(st_encoder_vector_control_t *p_st_encoder_vector)
{
    float f4_position_deg;

    f4_position_deg = (p_st_encoder_vector->st_sensor_encoder_output.f4_pos_rad * 360.0f) / MTR_TWOPI;

    return (f4_position_deg);
} /* End of function R_MOTOR_ENCODER_VECTOR_PositionGet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_SpeedSet
* Description   : Set speed reference
* Arguments     : p_st_encoder_vector     - The pointer to the motor control management data structure
*                 f4_ref_speed - speed reference [rpm]
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_SpeedSet(st_encoder_vector_control_t *p_st_encoder_vector, float f4_ref_speed)
{
    R_MOTOR_SPEED_SpdRefSet(p_st_encoder_vector->p_st_sc, f4_ref_speed);
} /* End of function R_MOTOR_ENCODER_VECTOR_SpeedSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_SpeedGet
* Description   : Get speed value
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : speed
***********************************************************************************************************************/
float R_MOTOR_ENCODER_VECTOR_SpeedGet(st_encoder_vector_control_t *p_st_encoder_vector)
{
    float f4_speed_rpm;

    f4_speed_rpm = (p_st_encoder_vector->st_speed_output.f4_speed_rad_lpf * MTR_RAD2RPM);

    return (f4_speed_rpm);
} /* End of function R_MOTOR_ENCODER_VECTOR_SpeedGet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_StatusGet
* Description   : Get status of motor control system
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : motor status
***********************************************************************************************************************/
uint8_t R_MOTOR_ENCODER_VECTOR_StatusGet(st_encoder_vector_control_t *p_st_encoder_vector)
{
    uint8_t u1_status;

    u1_status = motor_encoder_vector_statemachine_status_get(&p_st_encoder_vector->st_stm);

    return (u1_status);
} /* End of function R_MOTOR_ENCODER_VECTOR_StatusGet */

/**********************************************************************************************************************
 * Function Name: R_MOTOR_ENCODER_VECTOR_ErrorStatusGet
 * Description  : Get current error status
 * Arguments    : p_st_encoder_vector    - The pointer to the motor control management data structure
 * Return Value : Error status
 *********************************************************************************************************************/
uint16_t R_MOTOR_ENCODER_VECTOR_ErrorStatusGet(st_encoder_vector_control_t * p_st_encoder_vector)
{
    uint16_t u2_error_status;

    u2_error_status = p_st_encoder_vector->u2_error_status;

    return (u2_error_status);
} /* End of function R_MOTOR_ENCODER_VECTOR_ErrorStatusGet */

/**********************************************************************************************************************
 * Function Name: R_MOTOR_ENCODER_VECTOR_CtrlTypeSet
 * Description  : Set control type
 * Arguments    : p_st_encoder_vector    - The pointer to the motor control management data structure
 *                ctrl_type -
 *                   The control type that defined in e_mtr_ctrl_type_t
 * Return Value : None
 *********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_CtrlTypeSet(st_encoder_vector_control_t * p_st_encoder_vector, uint8_t ctrl_type)
{
    if (motor_encoder_vector_statemachine_status_get(&p_st_encoder_vector->st_stm) == STATEMACHINE_STATE_RUN)
    {
        return;
    }

    switch (ctrl_type)
    {
        case MOTOR_CTRL_TYPE_POS:
        {
            p_st_encoder_vector->u1_ctrl_loop_mode = MOTOR_LOOP_POSITION;
            break;
        }
        case MOTOR_CTRL_TYPE_SPEED:
        {
            p_st_encoder_vector->u1_ctrl_loop_mode = MOTOR_LOOP_SPEED;
            break;
        }
        default:
        {
            /* Do nothing */
        }
    }
} /* End of function R_MOTOR_ENCODER_VECTOR_CtrlTypeSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_LoopModeStatusGet
* Description   : Get loop mode status
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : control loop mode status
***********************************************************************************************************************/
uint8_t R_MOTOR_ENCODER_VECTOR_LoopModeStatusGet(st_encoder_vector_control_t *p_st_encoder_vector)
{
    return (p_st_encoder_vector->u1_ctrl_loop_mode);
} /* End of function R_MOTOR_ENCODER_VECTOR_LoopModeStatusGet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_PositionCommandModeSet
* Description   : Set position status
* Arguments     : p_st_encoder_vector      - The pointer to the motor control management data structure
*                 u1_position_command_mode - Position command mode to set
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_PositionCommandModeSet(st_encoder_vector_control_t *p_st_encoder_vector,
                                                   uint8_t u1_position_command_mode)
{
    R_MOTOR_POSITION_CommandModeSet(p_st_encoder_vector->p_st_pc, u1_position_command_mode);
} /* End of function R_MOTOR_ENCODER_VECTOR_PositionCommandModeSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_InPositionFlagGet
* Description   : Get Positioning Flag
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : positioning flag
***********************************************************************************************************************/
uint8_t R_MOTOR_ENCODER_VECTOR_InPositionFlagGet(st_encoder_vector_control_t *p_st_encoder_vector)
{
    return (p_st_encoder_vector->st_position_output.u1_in_position);
} /* End of function R_MOTOR_ENCODER_VECTOR_InPositionFlagGet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_PosSpeedInterrupt
* Description   : 500us interrupt handler of FOC control
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_PosSpeedInterrupt(st_encoder_vector_control_t *p_st_encoder_vector)
{
    st_speed_input_t    st_speed_input;
    st_position_input_t st_position_input;

    if (STATEMACHINE_STATE_RUN == motor_encoder_vector_statemachine_status_get(&p_st_encoder_vector->st_stm))
    {
        /* Decide direction */
        motor_encoder_vector_decide_direction(p_st_encoder_vector);

        /* Id, Iq, speed, position references setting */
        switch (p_st_encoder_vector->u2_run_mode)
        {
            case MOTOR_MODE_INIT:
                if (MTR_FLG_SET == p_st_encoder_vector->st_current_output.u1_flag_offset_calc)
                {
                    if (MOTOR_ANGLE_ADJ_HALL == p_st_encoder_vector->u1_encd_angle_adj_mode)
                    {
                        /* Position offset adjustment */
                        p_st_encoder_vector->st_sensor_hall_output.f4_hall_angle_rad =
                                R_MOTOR_SENSOR_HALL_AngleAdjustInit(p_st_encoder_vector->p_st_sensor);
                        motor_encoder_vector_hall_error_check(p_st_encoder_vector);
clrpsw_i();
                        /* reset encoder counter and timer */
                        p_st_encoder_vector->p_st_sensor->EncdCntDataSet(0);
setpsw_i();
                        p_st_encoder_vector->p_st_sensor->EncdTimerStart();
                        R_MOTOR_SENSOR_HALL_InterruptEnable(p_st_encoder_vector->p_st_sensor);
                        p_st_encoder_vector->u1_encd_angle_adj_status = MOTOR_ENCODER_ANGLE_ADJ_FIN;
                        p_st_encoder_vector->u2_run_mode              = MOTOR_MODE_DRIVE;
                    }
                    else
                    {
                        p_st_encoder_vector->u2_run_mode = MOTOR_MODE_BOOT;
                    }
                }
            break;

            case MOTOR_MODE_BOOT:
                if (MOTOR_ENCODER_ANGLE_ADJ_FIN == p_st_encoder_vector->u1_encd_angle_adj_status)
                {
                    p_st_encoder_vector->u2_run_mode = MOTOR_MODE_DRIVE;
                }
            break;

            case MOTOR_MODE_DRIVE:
                /* Setting of position command value */
                /* Set position input */
                st_position_input.f4_position_rad = p_st_encoder_vector->st_sensor_encoder_output.f4_pos_rad;
                R_MOTOR_POSITION_ParameterSet(p_st_encoder_vector->p_st_pc, &st_position_input);
                R_MOTOR_POSITION_PositionCyclic(p_st_encoder_vector->p_st_pc);
                R_MOTOR_POSITION_ParameterGet(p_st_encoder_vector->p_st_pc, &p_st_encoder_vector->st_position_output);

                /* Connect position output to speed module and set speed input */
                st_speed_input.u1_state_speed_ref = p_st_encoder_vector->u1_state_speed_ref;
                st_speed_input.f4_ref_speed_rad   = p_st_encoder_vector->st_position_output.f4_speed_ref;
                st_speed_input.f4_speed_rad       = p_st_encoder_vector->st_sensor_encoder_output.f4_speed_rad;
                st_speed_input.f4_va_max          = p_st_encoder_vector->st_current_output.f4_va_max;
                R_MOTOR_SPEED_ParameterSet(p_st_encoder_vector->p_st_sc, &st_speed_input);
                R_MOTOR_SPEED_SpeedCyclic(p_st_encoder_vector->p_st_sc);
                R_MOTOR_SPEED_ParameterGet(p_st_encoder_vector->p_st_sc, &p_st_encoder_vector->st_speed_output);
            break;

            default:
                /* Do Nothing */
            break;
        }

        /* Set references */
        motor_encoder_vector_position_status_select(p_st_encoder_vector);
        motor_encoder_vector_speed_status_select(p_st_encoder_vector);
        motor_encoder_vector_iq_status_select(p_st_encoder_vector);
        motor_encoder_vector_id_status_select(p_st_encoder_vector);
    }
} /* End of function R_MOTOR_ENCODER_VECTOR_PosSpeedInterrupt */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_CurrentInterrupt
* Description   : The carrier interrupt handler of FOC control
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_CurrentInterrupt(st_encoder_vector_control_t *p_st_encoder_vector)
{
    st_current_input_t st_current_input;
    float f4_neutral_duty;

    /* integrate encoder counter difference */
    R_MOTOR_SENSOR_ENCODER_HsCountDiffCalc(p_st_encoder_vector->p_st_sensor);

    /* Current, Voltage detection */
    R_MOTOR_DRIVER_BldcAnalogGet(p_st_encoder_vector->p_st_driver,
                                 &p_st_encoder_vector->f4_iu_ad,
                                 &p_st_encoder_vector->f4_iw_ad,
                                 &p_st_encoder_vector->f4_vdc_ad);

    /* current offset adjustment */
    R_MOTOR_CURRENT_CurrentOffsetRemove(p_st_encoder_vector->p_st_cc,
                                        &p_st_encoder_vector->f4_iu_ad,
                                        &p_st_encoder_vector->f4_iw_ad);

    /* V-phase current calculation */
    p_st_encoder_vector->f4_iv_ad = -(p_st_encoder_vector->f4_iu_ad + p_st_encoder_vector->f4_iw_ad);

setpsw_i();                                             /* Interrupt enable */
    /* error check */
    motor_encoder_vector_error_check(p_st_encoder_vector);

    /* position & speed calculation */
    R_MOTOR_SENSOR_ENCODER_PosSpdCalc(p_st_encoder_vector->p_st_sensor);

    R_MOTOR_SENSOR_ENCODER_ParameterGet(p_st_encoder_vector->p_st_sensor,
                                        &p_st_encoder_vector->st_sensor_encoder_output);
    R_MOTOR_SENSOR_HALL_ParameterGet(&p_st_encoder_vector->p_st_sensor->st_hc,
                                     &p_st_encoder_vector->st_sensor_hall_output);

    /* speed & angle detection */
    motor_encoder_vector_angle_speed_select(p_st_encoder_vector);

    /* set current input */
    st_current_input.u1_state_id_ref    = p_st_encoder_vector->u1_state_id_ref;
    st_current_input.u1_state_iq_ref    = p_st_encoder_vector->u1_state_iq_ref;
    st_current_input.f4_iu_ad           = p_st_encoder_vector->f4_iu_ad;
    st_current_input.f4_iv_ad           = p_st_encoder_vector->f4_iv_ad;
    st_current_input.f4_iw_ad           = p_st_encoder_vector->f4_iw_ad;
    st_current_input.f4_vdc_ad          = p_st_encoder_vector->f4_vdc_ad;
    st_current_input.f4_iq_ref          = p_st_encoder_vector->st_speed_output.f4_iq_ref;
    st_current_input.f4_id_ref          = p_st_encoder_vector->st_speed_output.f4_id_ref;
    st_current_input.f4_speed_rad       = p_st_encoder_vector->st_sensor_encoder_output.f4_speed_rad
                                                            * p_st_encoder_vector->st_motor.u2_mtr_pp;
    st_current_input.f4_rotor_angle_rad = p_st_encoder_vector->f4_rotor_angle_rad;
    R_MOTOR_CURRENT_ParameterSet(p_st_encoder_vector->p_st_cc, &st_current_input);

    if (STATEMACHINE_STATE_RUN == motor_encoder_vector_statemachine_status_get(&p_st_encoder_vector->st_stm))
    {
        /* Calculate offset current values */
        if (MTR_FLG_CLR == p_st_encoder_vector->st_current_output.u1_flag_offset_calc)
        {
            /* Current offset calibration */
            f4_neutral_duty = p_st_encoder_vector->st_current_output.f4_neutral_duty;
            /* set half carrier */
            R_MOTOR_DRIVER_BldcDutySet(p_st_encoder_vector->p_st_driver,
                                       f4_neutral_duty,
                                       f4_neutral_duty,
                                       f4_neutral_duty);
            R_MOTOR_CURRENT_OffsetCalibration(p_st_encoder_vector->p_st_cc);
            R_MOTOR_CURRENT_ParameterGet(p_st_encoder_vector->p_st_cc, &p_st_encoder_vector->st_current_output);
        }
        else
        {

            R_MOTOR_CURRENT_CurrentCyclic(p_st_encoder_vector->p_st_cc);
            R_MOTOR_CURRENT_ParameterGet(p_st_encoder_vector->p_st_cc, &p_st_encoder_vector->st_current_output);

            /* PWM reference setting */
            R_MOTOR_DRIVER_BldcDutySet(p_st_encoder_vector->p_st_driver,
                                       p_st_encoder_vector->st_current_output.f4_modu,
                                       p_st_encoder_vector->st_current_output.f4_modv,
                                       p_st_encoder_vector->st_current_output.f4_modw);
        }
    }
}/* End of function R_MOTOR_ENCODER_VECTOR_CurrentInterrupt */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_OverCurrentInterrupt
* Description   : POE interrupt
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_OverCurrentInterrupt(st_encoder_vector_control_t *p_st_encoder_vector)
{
    motor_encoder_vector_error_process(p_st_encoder_vector, MOTOR_ENCODER_VECTOR_ERROR_OVER_CURRENT_HW);
} /* End of function R_MOTOR_ENCODER_VECTOR_OverCurrentInterrupt */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_HallInterrupt
* Description   : Hall interrupt handler
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_HallInterrupt(st_encoder_vector_control_t *p_st_encoder_vector)
{
    if (MOTOR_MODE_DRIVE == g_st_encoder_vector.u2_run_mode)
    {
        R_MOTOR_SENSOR_HALL_AdjustInterrupt(p_st_encoder_vector->p_st_sensor,
                                            p_st_encoder_vector->u1_direction);
        motor_encoder_vector_hall_error_check(p_st_encoder_vector);
        R_MOTOR_SENSOR_HALL_InterruptDisable(p_st_encoder_vector->p_st_sensor);         /* hall interrupt disable */
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function R_MOTOR_ENCODER_VECTOR_HallInterrupt */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_EncoderInterrupt
* Description   : Hall interrupt handler of FOC control
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_EncoderInterrupt(st_encoder_vector_control_t *p_st_encoder_vector)
{
    if (MOTOR_ENCODER_ANGLE_ADJ_FIN == g_st_encoder_vector.u1_encd_angle_adj_status)
    {
        R_MOTOR_SENSOR_ENCODER_PosSpdCalcInterrupt(&g_st_sensor);
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function R_MOTOR_ENCODER_VECTOR_EncoderInterrupt */

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_IPDEnableSet
* Description   : Set IPD enable state
* Arguments     : p_st_encoder_vector  - The pointer to the motor control management data structure
*               : u1_enable - Whether enable IPD as position control method (0: Disable IPD, 1: Enable IPD)
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_IPDEnableSet(st_encoder_vector_control_t *p_st_encoder_vector, uint8_t u1_enable)
{
    p_st_encoder_vector->u1_flag_ipd_use = u1_enable;
} /* End of function R_MOTOR_ENCODER_VECTOR_IPDEnableSet */
