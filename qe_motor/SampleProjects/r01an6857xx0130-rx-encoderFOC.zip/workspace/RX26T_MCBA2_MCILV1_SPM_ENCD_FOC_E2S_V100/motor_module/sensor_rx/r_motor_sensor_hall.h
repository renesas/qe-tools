/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_sensor_hall.h
* Description : Definitions of a Hall control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_SENSOR_HALL_H
#define R_MOTOR_SENSOR_HALL_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_motor_common.h"
#include "r_motor_sensor_api.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Low Level = N pole , High Level = S pole */
#define     SENSOR_HALL_NL_SH               (1)    /* Enable */
/* How Level = N pole , Low Level = S pole */
#define     SENSOR_HALL_NH_SL               (0)    /* Disable */

#if SENSOR_HALL_NL_SH
#define     SENSOR_HALL_W              (1)
#define     SENSOR_HALL_UW             (5)
#define     SENSOR_HALL_U              (4)
#define     SENSOR_HALL_UV             (6)
#define     SENSOR_HALL_V              (2)
#define     SENSOR_HALL_VW             (3)
#elif SENSOR_HALL_NH_SL
#define     SENSOR_HALL_W              (6)
#define     SENSOR_HALL_UW             (2)
#define     SENSOR_HALL_U              (3)
#define     SENSOR_HALL_UV             (1)
#define     SENSOR_HALL_V              (5)
#define     SENSOR_HALL_VW             (4)
#endif

#define     SENSOR_HALL_EDGE_ANGLE_30  (30.0f*MTR_DEG2RAD)
#define     SENSOR_HALL_EDGE_ANGLE_90  (90.0f*MTR_DEG2RAD)
#define     SENSOR_HALL_EDGE_ANGLE_150 (150.0f*MTR_DEG2RAD)
#define     SENSOR_HALL_EDGE_ANGLE_210 (210.0f*MTR_DEG2RAD)
#define     SENSOR_HALL_EDGE_ANGLE_270 (270.0f*MTR_DEG2RAD)
#define     SENSOR_HALL_EDGE_ANGLE_330 (330.0f*MTR_DEG2RAD)

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : motor_sensor_hall_angle_edge_set
* Description   : Process for hall edge angle set
* Arguments     : u1_hall_signal - hall signal
                  u1_pre_hall_signal - previous value of hall signal
* Return Value  : Rotor angle of signal detected for hall sensor
***********************************************************************************************************************/
float motor_sensor_hall_angle_edge_set(uint8_t u1_hall_signal, uint8_t u1_pre_hall_signal);

/***********************************************************************************************************************
* Function Name : motor_sensor_hall_angle_set
* Description   : Process for hall sensor interrupt
* Arguments     : u1_hall_signal - hall signal
* Return Value  : Rotor angle of signal detected for hall sensor
***********************************************************************************************************************/
float motor_sensor_hall_angle_set(uint8_t u1_hall_signal);

#endif /* R_MOTOR_SENSOR_HALL_H */
