/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_sensor_api.c
* Description : Sensor API
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_smc_entry.h"
#include "r_motor_sensor_api.h"
#include "r_motor_sensor_encoder.h"
#include "r_motor_sensor_hall.h"
#include "r_motor_common.h"
#include "r_motor_driver.h"

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
st_sensor_t         g_st_sensor;

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_Open
* Description   : Open sensor module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_Open(void)
{
    st_sensor_t *p_st_sensor;
    p_st_sensor = &g_st_sensor;

    /* initialize of encoder variables */
    p_st_sensor->st_ec.u2_encd_cpr_mech                = MOTOR_COMMON_SENSOR_ENCD_CPR;
    p_st_sensor->st_ec.f4_encd_angle_diff              = SENSOR_ENCD_ANGLE_DIFF;
    p_st_sensor->st_ec.f4_encd_cpr_mech_inv            = (1.0f / (float)MOTOR_COMMON_SENSOR_ENCD_CPR);
    p_st_sensor->st_ehc.f4_encd_hs_sw_speed_rad        = SENSOR_ENCD_HS_CHANGE_RAD;
    p_st_sensor->st_ehc.f4_encd_hs_sw_speed_margin_rad = SENSOR_ENCD_HS_CHANGE_MARGIN_RAD;

    R_MOTOR_SENSOR_ENCODER_Reset(p_st_sensor);
} /* End of function R_MOTOR_SENSOR_ENCODER_Open */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_Close
* Description   : Close sensor module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_Close(void)
{
    st_sensor_t *p_st_sensor;
    p_st_sensor = &g_st_sensor;

    R_MOTOR_SENSOR_ENCODER_Reset(p_st_sensor);
} /* End of function R_MOTOR_SENSOR_ENCODER_Close */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_Reset
* Description   : Reset variables when encoder control
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_Reset(st_sensor_t *p_st_sensor)
{
    p_st_sensor->st_ec.u2_encd_pre_phase_cnt        = 0;
    p_st_sensor->st_ec.u4_encd_timer_cap_tcnt       = 0;
    p_st_sensor->st_ec.u4_encd_timer_cap_pre_tcnt   = 0;
    p_st_sensor->st_ec.u2_encd_timer_cnt_num        = 0;
    p_st_sensor->st_ec.u4_encd_timer_cnt_buff[0]    = 0;
    p_st_sensor->st_ec.u4_encd_timer_cnt_buff[1]    = 0;
    p_st_sensor->st_ec.u4_encd_timer_cnt_buff[2]    = 0;
    p_st_sensor->st_ec.u4_encd_timer_cnt_buff[3]    = 0;
    p_st_sensor->st_ec.u4_encd_pulse_width          = 0;
    p_st_sensor->st_ec.u4_encd_pulse_width_buff     = 0;
    p_st_sensor->st_ec.u4_encd_pulse_width_sum      = 0;
    p_st_sensor->st_ec.s4_encd_angle_cnt            = 0;
    p_st_sensor->st_ec.f4_encd_pos_rad              = 0.0f;
    p_st_sensor->st_ec.f4_encd_speed_pre_rad        = 0.0f;
    p_st_sensor->st_ec.f4_encd_speed_rad            = 0.0f;

    p_st_sensor->st_ehc.u1_encd_pos_speed_calc_mode = SENSOR_ENCD_PS_CALC_ENCD_INTERRUPT;
    p_st_sensor->st_ehc.u1_encd_interrupt_on_flag   = MTR_FLG_CLR;
    p_st_sensor->st_ehc.u1_encd_pos_speed_calc_cnt  = 0;
    p_st_sensor->st_ehc.s4_encd_hs_angle_cnt        = 0;
    p_st_sensor->st_ehc.u2_encd_hs_pre_phase_cnt    = 0;
    p_st_sensor->st_ehc.f4_encd_hs_pos_rad          = 0.0f;
    p_st_sensor->st_ehc.f4_encd_hs_pos_pre_rad      = 0.0f;
    p_st_sensor->st_ehc.f4_encd_hs_speed_rad        = 0.0f;
    p_st_sensor->st_ehc.f4_encd_hs_speed_pre_rad    = 0.0f;

    p_st_sensor->st_hc.u1_hall_signal               = 0;
    p_st_sensor->st_hc.u1_hall_pre_signal           = 0;
    p_st_sensor->st_hc.u1_hall_interrupt_flg        = MTR_FLG_CLR;
    p_st_sensor->st_hc.f4_hall_angle_rad            = 0.0f;

    if (NULL != p_st_sensor->EncdCntDataSet)
    {
        p_st_sensor->EncdCntDataSet(0);
    }
    if (NULL != p_st_sensor->EncdInterruptEnable)
    {
        p_st_sensor->EncdInterruptEnable();
    }
} /* End of function R_MOTOR_SENSOR_ENCODER_Reset */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_ParameterGet
* Description   : Get variables when motor encoder control
* Arguments     : p_st_sensor         - The pointer to sensor structure
*                 p_st_encoder_output - The pointer to sensor output parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_ParameterGet(st_sensor_t *p_st_sensor, st_sensor_encoder_output_t *p_st_encoder_output)
{
    if (SENSOR_ENCD_PS_CALC_CTRL_INTERRUPT == p_st_sensor->st_ehc.u1_encd_pos_speed_calc_mode)
    {
        p_st_encoder_output->f4_pos_rad   = p_st_sensor->st_ehc.f4_encd_hs_pos_rad;
        p_st_encoder_output->f4_speed_rad = p_st_sensor->st_ehc.f4_encd_hs_speed_rad;    /* mechanical */
        motor_sensor_encoder_hs_encd_interrupt_switch(p_st_sensor, p_st_encoder_output->f4_speed_rad);
    }
    else if (SENSOR_ENCD_PS_CALC_ENCD_INTERRUPT == p_st_sensor->st_ehc.u1_encd_pos_speed_calc_mode)
    {
        p_st_encoder_output->f4_pos_rad   = p_st_sensor->st_ec.f4_encd_pos_rad;
        p_st_encoder_output->f4_speed_rad = p_st_sensor->st_ec.f4_encd_speed_rad;    /* mechanical */
        motor_sensor_encoder_hs_ctrl_interrupt_switch(p_st_sensor, p_st_encoder_output->f4_speed_rad);
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function R_MOTOR_SENSOR_ENCODER_ParameterGet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_ParameterUpdate
* Description   : Update the sensor parameter
* Arguments     : p_st_sensor      - The pointer to sensor structure
*                 p_st_encoder_cfg - The pointer to sensor configuration parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_ParameterUpdate(st_sensor_t *p_st_sensor, const st_sensor_encoder_cfg_t *p_st_encoder_cfg)
{
    uint16_t u2_temp;

    p_st_sensor->f4_ctrl_period    = p_st_encoder_cfg->f4_ctrl_period;
    p_st_sensor->u1_ctrl_loop_mode = p_st_encoder_cfg->u1_ctrl_loop_mode;
    p_st_sensor->st_motor          = p_st_encoder_cfg->st_motor;

    /* Setup encoder counts per revolution (mechanical) */
    /* Setup inverse number of encoder counts per revolution (mechanical) */
    /* Setup angle of encoder 1 pulse width */
    u2_temp = p_st_encoder_cfg->u2_encd_cpr * SENSOR_CFG_ENCD_RESOLUTION_MULTIPL;
    motor_sensor_encoder_mech_param_set(p_st_sensor, u2_temp);
    /* Setup toggle speed for high speed mode */
    motor_sensor_encoder_sw_hs_speed_rad_set(p_st_sensor,
                                             p_st_encoder_cfg->f4_hs_change_speed_rpm);
    motor_sensor_encoder_sw_hs_speed_margin_rad_set(p_st_sensor,
                                                    p_st_encoder_cfg->f4_hs_change_margin_rpm);
} /* End of function R_MOTOR_SENSOR_ENCODER_ParameterUpdate */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_DriverParameterUpdate
* Description   : Update the sensor parameter
* Arguments     : p_st_sensor      - The pointer to sensor structure
*                 p_st_encoder_driver_cfg - The pointer to encoder driver configuration parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_DriverParameterUpdate(st_sensor_t *p_st_sensor,
                                                  const st_encoder_driver_cfg_t *p_st_encoder_driver_cfg)
{
    p_st_sensor->EncdCntDataGet       = p_st_encoder_driver_cfg->EncdCntDataGet;
    p_st_sensor->EncdCntDataSet       = p_st_encoder_driver_cfg->EncdCntDataSet;
    p_st_sensor->EncdInterruptEnable  = p_st_encoder_driver_cfg->EncdInterruptEnable;
    p_st_sensor->EncdInterruptDisable = p_st_encoder_driver_cfg->EncdInterruptDisable;
    p_st_sensor->EncdTimerStart       = p_st_encoder_driver_cfg->EncdTimerStart;
    p_st_sensor->EncdTimerGet         = p_st_encoder_driver_cfg->EncdTimerGet;
    p_st_sensor->HallSignalGet        = p_st_encoder_driver_cfg->HallSignalGet;
    p_st_sensor->HallUEnable          = p_st_encoder_driver_cfg->HallUEnable;
    p_st_sensor->HallVEnable          = p_st_encoder_driver_cfg->HallVEnable;
    p_st_sensor->HallWEnable          = p_st_encoder_driver_cfg->HallWEnable;
    p_st_sensor->HallUDisable         = p_st_encoder_driver_cfg->HallUDisable;
    p_st_sensor->HallVDisable         = p_st_encoder_driver_cfg->HallVDisable;
    p_st_sensor->HallWDisable         = p_st_encoder_driver_cfg->HallWDisable;
} /* End of function R_MOTOR_SENSOR_ENCODER_DriverParameterUpdate */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_PosSpdCalcInterrupt
* Description   : Rotor angle adjust process for carrier interrupt
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_PosSpdCalcInterrupt(st_sensor_t *p_st_sensor)
{

    uint16_t u2_temp;
    int16_t  s2_encd_delta_tcnt;
    uint32_t u4_temp;
    float    f4_temp_speed_rad_avg;
    float    f4_temp0;

    /* integrate encoder counter difference */
    u2_temp = p_st_sensor->EncdCntDataGet();
    if (MTR_FLG_SET == p_st_sensor->st_ehc.u1_encd_interrupt_on_flag)
    {
        p_st_sensor->st_ec.s4_encd_angle_cnt          = p_st_sensor->st_ehc.s4_encd_hs_angle_cnt;
        p_st_sensor->st_ec.u2_encd_pre_phase_cnt      = p_st_sensor->st_ehc.u2_encd_hs_pre_phase_cnt;
        p_st_sensor->st_ehc.u1_encd_interrupt_on_flag = MTR_FLG_CLR;
    }
    else
    {
        /* Do Nothing */
    }
    s2_encd_delta_tcnt                       = p_st_sensor->st_ec.u2_encd_pre_phase_cnt - u2_temp;
    p_st_sensor->st_ec.s4_encd_angle_cnt     += (int32_t)s2_encd_delta_tcnt;
    p_st_sensor->st_ec.u2_encd_pre_phase_cnt = u2_temp;

    /*=========================*/
    /*    angle calculation    */
    /*=========================*/
    if (SENSOR_ENCD_LOOP_SPEED == p_st_sensor->u1_ctrl_loop_mode)
    {
        /* limit count value to counts of one rotation */
        if (p_st_sensor->st_ec.s4_encd_angle_cnt >= (int32_t)p_st_sensor->st_ec.u2_encd_cpr_mech)
        {
            p_st_sensor->st_ec.s4_encd_angle_cnt -= (int32_t)p_st_sensor->st_ec.u2_encd_cpr_mech;
        }
        else if (p_st_sensor->st_ec.s4_encd_angle_cnt < 0.0f)
        {
            p_st_sensor->st_ec.s4_encd_angle_cnt += (int32_t)p_st_sensor->st_ec.u2_encd_cpr_mech;
        }
        else
        {
            /* Do Nothing */
        }
    }

    /* calculate angle (mechanical) */
    p_st_sensor->st_ec.f4_encd_pos_rad = (MTR_TWOPI * p_st_sensor->st_ec.s4_encd_angle_cnt)
                                          * p_st_sensor->st_ec.f4_encd_cpr_mech_inv;

    /*===============================*/
    /*    pulse width calculation    */
    /*===============================*/
    /* calculate integrated pulse width */

    p_st_sensor->st_ec.u4_encd_timer_cap_tcnt     =  p_st_sensor->EncdTimerGet();
    u4_temp = (p_st_sensor->st_ec.u4_encd_timer_cap_tcnt - p_st_sensor->st_ec.u4_encd_timer_cap_pre_tcnt);
    /* Since the data calculation process is 32 bits, a mask is used when a 16-bit timer is assigned. */
    if (16 == SENSOR_CFG_ENCD_TIMER_BIT)
    {
        u4_temp &= 0x0000FFFF;
    }
    p_st_sensor->st_ec.u4_encd_pulse_width_buff   += u4_temp;
    p_st_sensor->st_ec.u4_encd_timer_cap_pre_tcnt = p_st_sensor->st_ec.u4_encd_timer_cap_tcnt;
    /* limit pulse width, prevent u4_encd_pulse_width_buff from overflow */
    if (p_st_sensor->st_ec.u4_encd_pulse_width_buff > SENSOR_ENCD_ZEROSPEED_PW)
    {
        p_st_sensor->st_ec.u4_encd_pulse_width_buff = SENSOR_ENCD_ZEROSPEED_PW;
    }
    /* push last pulse width to buffer */
    p_st_sensor->st_ec.u4_encd_pulse_width      = p_st_sensor->st_ec.u4_encd_pulse_width_buff;
    p_st_sensor->st_ec.u4_encd_pulse_width_buff = 0;
    p_st_sensor->st_ec.u4_encd_pulse_width_sum += p_st_sensor->st_ec.u4_encd_pulse_width
            - p_st_sensor->st_ec.u4_encd_timer_cnt_buff[p_st_sensor->st_ec.u2_encd_timer_cnt_num];
    p_st_sensor->st_ec.u4_encd_timer_cnt_buff[p_st_sensor->st_ec.u2_encd_timer_cnt_num] =
            p_st_sensor->st_ec.u4_encd_pulse_width;
    p_st_sensor->st_ec.u2_encd_timer_cnt_num++;
    p_st_sensor->st_ec.u2_encd_timer_cnt_num %= SENSOR_ENCD_CNTAVG;

    /*=======================*/
    /*    speed averaging    */
    /*=======================*/
    if (0 != p_st_sensor->st_ec.u4_encd_pulse_width_sum)
    {
        /* calculate angle[rad] difference (SENSOR_ENCD_CNTAVG count of encoder) */
        /* angle[rad] = 2Pi * (Count Difference) / (Count Per Rotation) */
        /* divide angle[rad] by time[s] to calculate speed[rad/s] */
        /* time[s] = pulse_width[count] / (MTU0 Frequency[Hz]) = pulse_width[count]/(PWM Frequency[Hz]) */
        f4_temp0              = p_st_sensor->st_ec.f4_encd_angle_diff * SENSOR_ENCD_CALC_AVG;
        f4_temp_speed_rad_avg = f4_temp0 / (float)p_st_sensor->st_ec.u4_encd_pulse_width_sum;
        /* get speed direction from encoder position change */
        if (0 > s2_encd_delta_tcnt)
        {
            f4_temp_speed_rad_avg = - f4_temp_speed_rad_avg;
        }
        else if (0 == s2_encd_delta_tcnt)
        {
            if (0.0f > p_st_sensor->st_ec.f4_encd_speed_pre_rad)
            {
                f4_temp_speed_rad_avg = - f4_temp_speed_rad_avg;
            }
        }
        else
        {
            /* Do Nothing*/
        }
        p_st_sensor->st_ec.f4_encd_speed_pre_rad = p_st_sensor->st_ec.f4_encd_speed_rad;
        p_st_sensor->st_ec.f4_encd_speed_rad     = f4_temp_speed_rad_avg;
    }
} /* End of function R_MOTOR_SENSOR_ENCODER_PosSpdCalcInterrupt */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_PosSpdCalc
* Description   : calculate rotor position and speed
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_PosSpdCalc(st_sensor_t *p_st_sensor)
{
    float f4_temp;
    float f4_temp_pos_err;

    /*=================================*/
    /*    angle & speed calculation    */
    /*=================================*/
    f4_temp_pos_err = 0;
    if (SENSOR_ENCD_LOOP_SPEED == p_st_sensor->u1_ctrl_loop_mode)
    {
        /* limit count value to counts of one rotation */
        if (p_st_sensor->st_ehc.s4_encd_hs_angle_cnt >= (int32_t)p_st_sensor->st_ec.u2_encd_cpr_mech)
        {
            p_st_sensor->st_ehc.s4_encd_hs_angle_cnt -= (int32_t)p_st_sensor->st_ec.u2_encd_cpr_mech;
            f4_temp_pos_err += MTR_TWOPI;
        }
        else if (p_st_sensor->st_ehc.s4_encd_hs_angle_cnt < 0.0f)
        {
            p_st_sensor->st_ehc.s4_encd_hs_angle_cnt += (int32_t)p_st_sensor->st_ec.u2_encd_cpr_mech;
            f4_temp_pos_err -= MTR_TWOPI;
        }
        else
        {
            /* Do Nothing */
        }
    }
    /* calculate angle (mechanical) */
    f4_temp = MTR_TWOPI * p_st_sensor->st_ehc.s4_encd_hs_angle_cnt;
    p_st_sensor->st_ehc.f4_encd_hs_pos_rad = f4_temp * p_st_sensor->st_ec.f4_encd_cpr_mech_inv;
    /* speed calculation */
    f4_temp_pos_err += (p_st_sensor->st_ehc.f4_encd_hs_pos_rad - p_st_sensor->st_ehc.f4_encd_hs_pos_pre_rad);
    motor_sensor_encoder_hs_speed_calc(p_st_sensor, f4_temp_pos_err, p_st_sensor->f4_ctrl_period);
} /* End of function R_MOTOR_SENSOR_ENCODER_PosSpdCalc */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_HsCountDiffCalc
* Description   : Enncoder count difference calculation
* Arguments     : p_st_ehc - The pointer to encoder highspeed structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_HsCountDiffCalc(st_sensor_t *p_st_sensor)
{
    uint16_t u2_temp;
    int16_t  s2_encd_delta_tcnt;

    u2_temp = p_st_sensor->EncdCntDataGet();
    s2_encd_delta_tcnt = p_st_sensor->st_ehc.u2_encd_hs_pre_phase_cnt - u2_temp;
    p_st_sensor->st_ehc.s4_encd_hs_angle_cnt += (int32_t)s2_encd_delta_tcnt;
    p_st_sensor->st_ehc.u2_encd_hs_pre_phase_cnt = u2_temp;
} /* End of function R_MOTOR_SENSOR_ENCODER_HsCountDiffCalc */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_HALL_ParameterGet
* Description   : Get variables when motor encoder control
* Arguments     : p_st_hc          - The pointer to hall control structure
*                 p_st_hall_output - The pointer to hall output parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_ParameterGet(st_hall_t *p_st_hc, st_sensor_hall_output_t *p_st_hall_output)
{
    p_st_hall_output->f4_hall_angle_rad = p_st_hc->f4_hall_angle_rad;
} /* End of function R_MOTOR_SENSOR_HALL_ParameterGet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_HALL_AngleAdjustInit
* Description   : Initialize hall angle for angle adjust mode
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : rotor angle of signal detected for hall sensor
***********************************************************************************************************************/
float R_MOTOR_SENSOR_HALL_AngleAdjustInit(st_sensor_t *p_st_sensor)
{
    p_st_sensor->st_hc.u1_hall_signal     = p_st_sensor->HallSignalGet();      /* Get hall signal */
    p_st_sensor->st_hc.u1_hall_pre_signal = p_st_sensor->st_hc.u1_hall_signal;
    p_st_sensor->st_hc.f4_hall_angle_rad  = motor_sensor_hall_angle_set(p_st_sensor->st_hc.u1_hall_pre_signal);
                                                                /* between the hall edge angle set */
    return (p_st_sensor->st_hc.f4_hall_angle_rad);
} /* End of function R_MOTOR_SENSOR_HALL_AngleAdjustInit */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_HALL_AdjustInterrupt
* Description   : calculate rotor position
* Arguments     : p_st_sensor  - The pointer to sensor structure
*                 u1_direction - rotational direction
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_AdjustInterrupt(st_sensor_t *p_st_sensor, uint8_t u1_direction)
{
    float    f4_temp;
    float    f4_hall_angle_rad;

    /* integrate encoder counter difference */
    R_MOTOR_SENSOR_ENCODER_HsCountDiffCalc(p_st_sensor);
    /* calculate angle (mechanical) */
    f4_temp = MTR_TWOPI * p_st_sensor->st_ehc.s4_encd_hs_angle_cnt;
    f4_temp = f4_temp * p_st_sensor->st_ec.f4_encd_cpr_mech_inv;
    p_st_sensor->st_hc.u1_hall_signal = p_st_sensor->HallSignalGet();     /* get hall signal */
    if (MTR_CW == u1_direction)
    {
        f4_hall_angle_rad = motor_sensor_hall_angle_edge_set(p_st_sensor->st_hc.u1_hall_signal,
                                                             p_st_sensor->st_hc.u1_hall_pre_signal);
        p_st_sensor->st_hc.f4_hall_angle_rad = f4_hall_angle_rad - (f4_temp * p_st_sensor->st_motor.u2_mtr_pp);
    }
    else
    {
        f4_hall_angle_rad = motor_sensor_hall_angle_edge_set(p_st_sensor->st_hc.u1_hall_signal,
                                                             p_st_sensor->st_hc.u1_hall_pre_signal);
        p_st_sensor->st_hc.f4_hall_angle_rad = f4_hall_angle_rad + (360.0f * MTR_DEG2RAD - f4_temp)
                                               * p_st_sensor->st_motor.u2_mtr_pp;
    }
    p_st_sensor->st_hc.u1_hall_interrupt_flg = MTR_FLG_SET;
} /* End of function R_MOTOR_SENSOR_HALL_AdjustInterrupt */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_HALL_InterruptEnable
* Description   : Enables external(Hall) interrupt
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_InterruptEnable(st_sensor_t *p_st_sensor)
{
    /* Hall interrupt enable */
    p_st_sensor->HallUEnable();
    p_st_sensor->HallVEnable();
    p_st_sensor->HallWEnable();
} /* End of function R_MOTOR_SENSOR_HALL_InterruptEnable */

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_HALL_InterruptDisable
* Description   : Disables external(Hall) interrupt
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_InterruptDisable(st_sensor_t *p_st_sensor)
{
    /* Hall interrupt disable */
    p_st_sensor->HallUDisable();
    p_st_sensor->HallVDisable();
    p_st_sensor->HallWDisable();
} /* End of function R_MOTOR_SENSOR_HALL_InterruptDisable */
