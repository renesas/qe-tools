/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_position_api.h
* Description : Definitions of position control API
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MOTOR_POSITION_API_H
#define R_MOTOR_POSITION_API_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_motor_common.h"
#include "r_motor_filter.h"
#include "r_motor_position_profiling.h"
#include "r_motor_ipd_api.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Position reference mode */
#define     POSITION_COMMAND_MODE_ZERO         (0)
#define     POSITION_COMMAND_MODE_STEP         (1)
#define     POSITION_COMMAND_MODE_TRAPEZOID    (2)

/* Ctrl mode */
#define     POSITION_CONTROL_PID               (0)
#define     POSITION_CONTROL_IPD               (1)

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
/* Motor position control parameter structure */
typedef struct
{
    uint8_t     u1_is_in_position;            /* In-position status */
    uint8_t     u1_active;                    /* Flag to set active/inactive state of the position control */
    uint8_t     u1_pos_command_mode;          /* Position command value mode buffer */
    uint8_t     u1_ctrl_method_mode;          /* Position control mode */
    uint16_t    u2_pos_dead_band;             /* Position dead-band */
    uint16_t    u2_pos_band_limit;            /* Positioning band limit */
    float       f4_pos_kp;                    /* Proportional gain for position */
    float       f4_pos_err_rad;               /* Position error [rad] (mechanical) */
    float       f4_pos_rad;                   /* Position value [rad] (mechanical) */
    float       f4_ref_pos_rad;               /* Reference position [rad] (mechanical) */
    float       f4_ref_pos_pre_rad;           /* Previous value of reference position [rad] (mechanical) */
    float       f4_ref_pos_rad_ctrl;          /* Reference position for control [rad] (mechanical) */
    float       f4_speed_ff_rad;              /* Feed-forward speed [rad/s] (mechanical) */
    float       f4_speed_ff_ratio;            /* Speed feed-forward gain ratio */
    float       f4_ref_speed_rad_output;      /* Reference speed value [rad/s] */
    float       f4_max_speed_rad;             /* Maximum speed command value [rad/s] */
    float       f4_ctrl_period;               /* The control period */
    float       f4_mech_angle_per_sensor_cnt; /* The angle of encoder counts per revolution (mechanical) */
    st_position_profiling_t  st_ppf;          /* Position profiling structure */
    st_motor_parameter_t     st_motor;        /* Motor parameters */
    st_ipd_ctrl_t          * p_st_ipd;        /* The pointer to IPD module */
} st_position_control_t;

typedef struct
{
    st_motor_parameter_t st_motor;                      /* Motor parameters */
    uint16_t             u2_dead_band;                  /* Position dead-band */
    uint16_t             u2_band_limit;                 /* Positioning in-position range */
    uint16_t             u2_pos_interval_time;          /* Interval time [s] for position profile */
    float                f4_feedforward_ratio;          /* Speed feed-forward gain ratio */
    float                f4_position_omega_hz;          /* Natural frequency for position control */
    float                f4_ctrl_period;                /* Control period[s] */
    float                f4_mech_angle_per_sensor_cnt;  /* Angle per sensor count */
    float                f4_max_speed_rad;              /* Maximum speed [rad/s] */
    float                f4_accel_time;                 /* Acceleration time [s] */
    float                f4_posprof_max_speed_rad;      /* Maximum speed for position profiling [rad/s] (mechanical) */
} st_position_cfg_t;

typedef struct
{
    float   f4_position_rad;    /* Input position value [rad] (mechanical) */
} st_position_input_t;

typedef struct
{
    float   f4_speed_ref;       /* Speed reference (mechanical) [rad/s] */
    float   f4_position_err;    /* Position error */
    uint8_t u1_in_position;     /* In-position flag */
} st_position_output_t;

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
extern st_position_control_t     g_st_pc;           /* Position & speed control structure */

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_Open
* Description   : Open position control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_Open(void);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_Close
* Description   : Close position control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_Close(void);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_Reset
* Description   : Reset variables when motor position control
* Arguments     : p_st_pc         - The pointer to position control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_Reset(st_position_control_t * p_st_pc);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_Run
* Description   : Run the motor position control
* Arguments     : p_st_pc            - The pointer to position control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_Run(st_position_control_t * p_st_pc);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_ParameterSet
* Description   : Set the position control parameter
* Arguments     : p_st_pc             - The pointer to position control structure
*                 p_st_position_input - The pointer to position control input parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_ParameterSet(st_position_control_t * p_st_pc, const st_position_input_t * p_st_position_input);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_ParameterGet
* Description   : Get the position control parameter
* Arguments     : p_st_pc              - The pointer to position control structure
*                 p_st_position_output - The pointer to position control output parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_ParameterGet(st_position_control_t * p_st_pc, st_position_output_t * p_st_position_output);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_ParameterUpdate
* Description   : Update the position control parameter
* Arguments     : p_st_pc           - The pointer to position control structure
*                 p_st_position_cfg - The pointer to position control configuration parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_ParameterUpdate(st_position_control_t * p_st_pc, const st_position_cfg_t * p_st_position_cfg);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_PositionCyclic
* Description   : The cyclic processing of position control
* Arguments     : p_st_pc         - The pointer to position control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_PositionCyclic(st_position_control_t * p_st_pc);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_CommandModeSet
* Description   : Set position command mode
* Arguments     : p_st_pc                  - The pointer to position control structure
*                 u1_position_command mode - Position command mode to set
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_CommandModeSet(st_position_control_t * p_st_pc, uint8_t u1_position_command_mode);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_PosRefSet
* Description   : Set parameter for position reference
* Arguments     : p_st_pc                - The pointer to position control structure
*                 f4_ref_position_deg    - The position reference [degree]
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_PosRefSet(st_position_control_t * p_st_pc, float f4_ref_position_deg);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_IPDInstanceAddressSet
* Description   : Link the I-PD structure
* Arguments     : p_st_pc         - The pointer to position control structure
*                 p_st_ipd        - The pointer to the IPD control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_IPDInstanceAddressSet(st_position_control_t * p_st_pc, st_ipd_ctrl_t * p_st_ipd);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_IPDEnableSet
* Description   : Sets enable state of IPD control
* Arguments     : p_st_pc         - The pointer to position control structure
*                 u1_enable       - Enable(1)/disable(0) state to set
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_IPDEnableSet(st_position_control_t * p_st_pc, uint8_t u1_enable);

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_Sync
* Description   : Synchronizes internal position data with given position command
* Arguments     : p_st_pc        - The pointer to speed control structure
*                 f4_pos_ref_rad - The position reference to set
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_Sync(st_position_control_t * p_st_pc, float f4_pos_ref_rad);
#endif /* R_MOTOR_POSITION_API_H */
