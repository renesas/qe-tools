/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_motor_module_cfg.h
* Description  : Compile-time configurations
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
*         : 05.08.2022 1.10
*         : 31.01.2023 1.20
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MOTOR_MODULE_CFG_H
#define R_MOTOR_MODULE_CFG_H

#include "r_motor_common.h"
#include "r_motor_targetmotor_cfg.h"
#include "r_motor_inverter_cfg.h"
#include "r_smc_entry.h"

/* RMW output files */
#include "r_mtr_control_parameter.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/**
 * Middle ware Layer Configurations
 */
/*
 * Software system configurations
 */
/*
 * for MCU
 */
#define     MOTOR_MCU_CFG_PWM_TIMER_FREQ        (CG_CONFIG_MOTOR_PWM_TIMER_FREQ)           /* PWM timer frequency [MHz] */
#define     MOTOR_MCU_CFG_CARRIER_FREQ          (CG_CONFIG_MOTOR_CARRIER_FREQ)             /* Carrier wave frequency [kHz] */
#define     MOTOR_MCU_CFG_INTR_DECIMATION       (CG_CONFIG_MOTOR_INTR_DECIMATION)          /* Interrupt skipping number */
#define     MOTOR_MCU_CFG_AD_FREQ               (CG_MOTOR_MCU_CFG_AD_FREQ)                 /* A/D frequency [MHz] */
#define     MOTOR_MCU_CFG_AD_SAMPLING_CYCLE     (6 + 39)                                   /* Scan start processing time(tD) + sample-and-hold processing time(tSPLSH) [cycle] */
#define     MOTOR_MCU_CFG_AD12BIT_DATA          (CG_MOTOR_CFG_MAX_AD_DATA)                 /* A/D 12Bit data */
#define     MOTOR_MCU_CFG_ADC_OFFSET            (0x7FF)                                    /* A/D offset */

#if defined(__TFU)
#define     MOTOR_MCU_CFG_TFU_OPTIMIZE          (MTR_ENABLE)        /* TFU Optimization */
#else
#define     MOTOR_MCU_CFG_TFU_OPTIMIZE          (MTR_DISABLE)
#endif


/*
 * Motor control common configurations
 */
#define MOTOR_TYPE_BLDC     /* The motor used is BLDC. */
//#define MOTOR_TYPE_STM      /* The motor used is STM. */

/* Select control loop mode
* - MOTOR_LOOP_SPEED(default)
* - MOTOR_LOOP_POSITION
*/
#define     MOTOR_COMMON_CFG_LOOP_MODE                  (MOTOR_LOOP_SPEED)

/* Defines whether use IPD ctrl */
#define     MOTOR_COMMON_CFG_IPD_CTRL                   (MTR_DISABLE)

#define     MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT    (1.5f)

#if defined(MOTOR_TYPE_BLDC)
#define     MOTOR_COMMON_CFG_IA_MAX_CALC_MULT           (MTR_SQRT_3)
#elif defined(MOTOR_TYPE_STM)
#define     MOTOR_COMMON_CFG_IA_MAX_CALC_MULT           (MTR_SQRT_2)
#endif


/*
 * for Current Module(current_rx)
 */
/* Defines whether use voltage error compensation in FOC */
#define     CURRENT_CFG_VOLT_ERR_COMP           (MTR_ENABLE)

/* Select modulation method
* - MOD_METHOD_SPWM
* - MOD_METHOD_SVPWM(default)
*/
#define     CURRENT_CFG_MODULATION_METHOD       (MOD_METHOD_SVPWM)

#define     CURRENT_CFG_OFFSET_CALC_TIME        (512.0f)                        /* Current offset calculation time */
#define     CURRENT_CFG_PERIOD_MAG_VALUE        (1.0f)                          /* Period magnification value for coordinate transformation */
#define     CURRENT_CFG_PI_INTEGRAL_LIMIT_VD    (INVERTER_CFG_INPUT_V * 0.5f)   /* Current PI integral term limit for vd */
#define     CURRENT_CFG_PI_INTEGRAL_LIMIT_VQ    (INVERTER_CFG_INPUT_V * 0.5f)   /* Current PI integral term limit for vq */
#if (MTR_CONTROL_PARAMETER != 1)
#define     CURRENT_CFG_OMEGA                   (300.0f)                        /* natural frequency for current loop */
#define     CURRENT_CFG_ZETA                    (1.0f)                          /* damping ratio for current loop */
#define     CURRENT_CFG_REF_ID_OPENLOOP         (1.5f)                          /* id reference when low speed [A] */
#endif /* !MTR_CONTROL_PARAMETER */
#define     CURRENT_CFG_ID_UP_STEP_TIME         (2560.0f)                       /* Time to increase id */


/*
 * for Speed Module(speed_rx)
 */
/* Defines whether use flux-weakening in FOC */
#define     SPEED_CFG_FLUX_WEAKENING            (MTR_DISABLE)

/* Defines whether use Speed observer in FOC */
#define     SPEED_CFG_OBSERVER                  (MTR_DISABLE)

#define     SPEED_CFG_CTRL_PERIOD               (0.0005f)       /* control period for speed loop */
#if (MTR_CONTROL_PARAMETER != 1)
#define     SPEED_CFG_OMEGA                     (12.0f)         /* natural frequency for speed loop */
#define     SPEED_CFG_ZETA                      (1.0f)          /* damping ratio for speed loop */
#define     SPEED_CFG_SPEED_LIMIT_RPM           (4500.0f)       /* over speed limit [rpm] (mechanical angle) */
#define     SPEED_CFG_SOB_OMEGA                 (100.0f)        /* natural frequency for speed observer */
#endif /* !MTR_CONTROL_PARAMETER */
#define     SPEED_CFG_LPF_OMEGA                 (250.0f)        /* natural frequency for speed LPF */
#define     SPEED_CFG_RATE_LIMIT_RPM            (1000.0f)       /* Rate limit of speed change [rpm/s] */

/*
 * for Position Module(position_rx)
 */
#define     POSITION_CFG_CTRL_PERIOD            (SPEED_CFG_CTRL_PERIOD)
                                                                /* control period for position loop */
#define     POSITION_CFG_SPEED_FF_RATIO         (0.8f)          /* speed feed-forward ratio */
#define     POSITION_CFG_DEAD_BAND              (1.0f)          /* position dead-band */
#define     POSITION_CFG_INTERVAL_TIME          (800)           /* Interval time for reference position change */
#if (MTR_CONTROL_PARAMETER != 1)
#define     POSITION_CFG_OMEGA                  (4.0f)          /* natural frequency for position loop */
#endif /* !MTR_CONTROL_PARAMETER */
#define     POSITION_CFG_BAND_LIMIT             (3.0f)          /* positioning band limit */

/*
 * for IPD Module(ipd_rx)
 */
#define     IPD_CFG_OMEGA                       (5.0f)          /* Nature frequency for IPD control */

/*
 * for encoder vector Manager(encoder_vector_rx)
 */
/* Select angle adjust mode
* - MOTOR_ANGLE_ADJ_EXCIT(default)
* - MOTOR_ANGLE_ADJ_HALL
*/
#define     ENCODER_VECTOR_CFG_ANGLE_ADJUST_MODE        (MOTOR_ANGLE_ADJ_EXCIT)

#define     ENCODER_VECTOR_CFG_RC_FIL_R                 (1000.0f)           /* sensor RC filter resistance [ohm] */
#define     ENCODER_VECTOR_CFG_RC_FIL_C                 (0.0000000001f)     /* sensor RC filter capacitance[F]  */
#define     ENCODER_VECTOR_CFG_RC_FIL_TIME_CONS_MAG     (2)                 /* magnification of time constant */


/*
 * for Sensor Module(sensor_rx)
 */
#define     SENSOR_CFG_ENCD_TIMER_FREQ              (120.0f)    /* Encoder phase counter capture clock frequency */
#define     SENSOR_CFG_ENCD_TIMER_BIT               (32)        /* Number of bits for speed measurement timer (32 or 16) */

/* Encoder parameter */
#define     SENSOR_CFG_ENCD_PPR                     (1000)      /* Pulse par revolution [ppr] */
#define     SENSOR_CFG_ENCD_RESOLUTION_MULTIPL      (4)         /* The multiplication factor */

/* Encoder driver settings */
#define     SENSOR_CFG_ENCD_FUNC_CNT_GET            (R_Config_MTU1_TcntGet)
/* Encoder count value get function */
#define     SENSOR_CFG_ENCD_FUNC_CNT_SET            (R_Config_MTU1_TcntSet)
/* Encoder count value set function */
#define     SENSOR_CFG_ENCD_FUNC_INT_ENABLE         (R_Config_MTU0_InterruptEnable)
/* Encoder interrupt enable function */
#define     SENSOR_CFG_ENCD_FUNC_INT_DISABLE        (R_Config_MTU0_InterruptDisable)
/* Encoder interrupt disable function */
#define     SENSOR_CFG_ENCD_FUNC_SPD_TIMER_START    (R_Config_GPT3_SpeedCalcTimerStart)
/* Encoder speed timer start function */
#define     SENSOR_CFG_ENCD_FUNC_SPD_TIMER_CNT_GET  (R_Config_GPT3_TcntGet)
/* Encoder speed timer count value get function */
#define     SENSOR_CFG_HALL_FUNC_SIGNAL_GET         (R_Config_PORT_HallSignalGet)
/* Hall signal get function */
#define     SENSOR_CFG_HALL_FUNC_INT_U_START        (R_Config_ICU_IRQ7_Start)
/* U-phase of Hall interrupt start function */
#define     SENSOR_CFG_HALL_FUNC_INT_V_START        (R_Config_ICU_IRQ15_Start)
/* V-phase of Hall interrupt start function */
#define     SENSOR_CFG_HALL_FUNC_INT_W_START        (R_Config_ICU_IRQ4_Start)
/* W-phase of Hall interrupt start function */
#define     SENSOR_CFG_HALL_FUNC_INT_U_STOP         (R_Config_ICU_IRQ7_Stop)
/* U-phase of Hall interrupt stop function */
#define     SENSOR_CFG_HALL_FUNC_INT_V_STOP         (R_Config_ICU_IRQ15_Stop)
/* V-phase of Hall interrupt stop function */
#define     SENSOR_CFG_HALL_FUNC_INT_W_STOP         (R_Config_ICU_IRQ4_Stop)
/* W-phase of Hall interrupt stop function */

/*
 * for Driver Module(driver_rx)
 */
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_START    (R_Config_MOTOR_StartTimerCtrl)
                                                        /* The StartTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_STOP     (R_Config_MOTOR_StopTimerCtrl)
                                                        /* The StopTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_ADC_DATA_GET        (R_Config_MOTOR_AdcGetConvVal)
                                                        /* The AdcGetConvVal function of motor component */
#define     DRIVER_CFG_FUNC_DUTY_SET            (R_Config_MOTOR_UpdDuty)
                                                        /* The UpdDuty function of motor component */

/*
 * other
 */
#define     MOTOR_COMMON_AD_SAMPLING_TIME       (MOTOR_MCU_CFG_AD_SAMPLING_CYCLE / MOTOR_MCU_CFG_AD_FREQ)
                                                        /* A/D sampling time [us] */
#define     MOTOR_COMMON_CARRIER_SET_BASE       ((uint16_t)(MOTOR_MCU_CFG_PWM_TIMER_FREQ * 1000 / MOTOR_MCU_CFG_CARRIER_FREQ / 2))
#define     MOTOR_COMMON_DEADTIME_SET           ((uint16_t)(INVERTER_CFG_DEADTIME * MOTOR_MCU_CFG_PWM_TIMER_FREQ))
                                                        /* Setting value of deadtime */
#define     MOTOR_COMMON_CTRL_PERIOD            ((MOTOR_MCU_CFG_INTR_DECIMATION + 1) / (MOTOR_MCU_CFG_CARRIER_FREQ * 1000))
                                                        /* Control period */
/****** Macro of current control*****/
#define     MOTOR_COMMON_ID_UP_STEP_RATE        (CURRENT_CFG_REF_ID_OPENLOOP / CURRENT_CFG_ID_UP_STEP_TIME)
                                                        /* addition value of id */
#define     MOTOR_COMMON_PI_INTEGRAL_LIMIT_IQ   (MOTOR_CFG_NOMINAL_CURRENT_RMS * MTR_SQRT_3)
                                                        /* speed PI integral term limit for iq */
#define     MOTOR_COMMON_LIMIT_IQ               (MOTOR_CFG_NOMINAL_CURRENT_RMS * MTR_SQRT_3)
                                                        /* speed PI limit for iq */
#define     MOTOR_COMMON_OVERCURRENT_LIMIT      (MOTOR_CFG_NOMINAL_CURRENT_RMS * MTR_SQRT_2 * MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT)
                                                        /* Over current limit [A] */
/****** Macro of encoder control*****/
#define     MOTOR_COMMON_SENSOR_ENCD_CPR        (SENSOR_CFG_ENCD_PPR * SENSOR_CFG_ENCD_RESOLUTION_MULTIPL)
                                                        /* encoder counts per revolution (mechanical) */
/* sensor RC filter parameter and speed limit calculation */
#define     MOTOR_COMMON_RC_FIL_TIME_CONS       (ENCODER_VECTOR_CFG_RC_FIL_R * ENCODER_VECTOR_CFG_RC_FIL_C)
                                                        /* time constant for RC filter */
#define     MOTOR_COMMON_RC_FIL_MAX_SPEED_RPM   (60.0f / (MOTOR_COMMON_RC_FIL_TIME_CONS * ENCODER_VECTOR_CFG_RC_FIL_TIME_CONS_MAG * MOTOR_COMMON_SENSOR_ENCD_CPR))

#endif /* R_MOTOR_MODULE_CFG_H */
