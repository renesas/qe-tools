/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_app_rmw.c
* Description : Processes of a user interface (tool)
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 05.08.2022 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <machine.h>

/* Main associated header file */
#include "r_app_rmw.h"
#include "r_app_main.h"
#include "r_app_board_ui_ctrl.h"
#include "r_motor_module_cfg.h"
#include "r_motor_encoder_vector_api.h"
#if USE_RMW_TUNER
#include "r_aid_tuner_gui.h"
#endif

/***********************************************************************************************************************
* Global variables
***********************************************************************************************************************/
uint16_t    g_u2_conf_hw   = 0x0008;        /* 0000000000001000b */
#if USE_RMW_TUNER
uint16_t    g_u2_conf_sw   = 0x40C1;        /* 0100000000000000b */
uint16_t    g_u2_conf_tool = 0x0600;        /* 0000011000000000b */
#else
uint16_t    g_u2_conf_sw   = 0x00C1;        /* 0000000011000001b */
uint16_t    g_u2_conf_tool = 0x0200;        /* 0000001000000000b */
#endif
uint8_t     gui_u1_active_gui;
uint16_t    g_u2_conf_sw_ver;

/***********************************************************************************************************************
* Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
st_rmw_param_buffer_t   g_st_rmw_input_buffer;      /* Structure for ICS input */
uint8_t     g_u1_update_param_flag = 0;             /* Update commands and configurations flag */

/* Operation variables */
uint8_t     com_u1_system_mode;             /* System mode */
uint8_t     g_u1_system_mode;               /* System mode */
uint8_t     com_u1_enable_write;            /* ICS write enable flag */
uint8_t     g_u1_enable_write;              /* ICS write enable flag */
uint8_t     com_u1_sw_userif;               /* User interface switch */
uint8_t     g_u1_sw_userif;                 /* User interface switch */

/* Offset parameters */
uint16_t    com_u2_offset_calc_time;        /* current offset calculation time */

/* Motor parameters */
uint16_t    com_u2_mtr_pp;                  /* pole pairs */
float       com_f4_mtr_r;                   /* resistance [ohm] */
float       com_f4_mtr_ld;                  /* d-axis inductance [H] */
float       com_f4_mtr_lq;                  /* q-axis inductance [H] */
float       com_f4_mtr_m;                   /* permanent magnetic flux [Wb] */
float       com_f4_mtr_j;                   /* rotor inertia [kgm^2] */
float       com_f4_nominal_current_rms;     /* The nominal current[Arms] */
float       com_f4_max_speed_rpm;           /* maximum speed [rpm] (mechanical) */

/* Encoder parameter */
uint8_t     com_u1_ctrl_loop_mode;          /* loop mode select */
uint8_t     com_u1_encd_angle_adj_mode;     /* encoder angle adjustment mode */
uint16_t    com_u2_encd_cpr;                /* encoder counts per revolution */
float       com_f4_hs_change_speed_rpm;     /* toggle speed for high speed mode [rpm] (mechanical) */
float       com_f4_hs_change_margin_rpm;    /* margin of toggle speed for high speed mode [rpm] (mechanical) */
float       com_f4_ol_ref_id;               /* id reference when open loop [A] */
float       com_f4_id_up_time;              /* time to increase id */

/* Control parameters */
/* Current control */
float       com_f4_current_omega_hz;        /* natural frequency for current loop [Hz] */
float       com_f4_current_zeta;            /* damping ratio for current loop */

/* Speed control */
float       com_f4_speed_omega_hz;          /* natural frequency for speed loop [Hz] */
float       com_f4_speed_zeta;              /* damping ratio for speed loop */
float       com_f4_speed_lpf_hz;            /* Natural frequency for speed LPF [Hz] */
float       com_f4_ref_speed_rpm;           /* motor speed reference [rpm] (mechanical) */
float       com_f4_speed_rate_limit_rpm;    /* limit of speed change [rpm/s] */
float       com_f4_overspeed_limit_rpm;     /* over speed limit [rpm] (mechanical) */

/* Position control */
uint8_t     com_u1_pos_cmd_mode;            /* position command value management */
uint16_t    com_u2_pos_interval_time;       /* interval time for reference position update */
uint16_t    com_u2_pos_dead_band;           /* position dead-band */
uint16_t    com_u2_pos_band_limit;          /* positioning band limit */
float       com_f4_pos_omega_hz;            /* natural frequency for position [Hz] */
float       com_f4_pos_ff_ratio;            /* The feed-forward gain from position control to speed command */
float       com_f4_ref_position_deg;        /* motor position reference [degree] (mechanical) */

/* Optional functions */
/* Extended observe */
uint8_t     com_u1_flag_extobserver_use;    /* Flags whether use ext observer*/
float       com_f4_extobs_omega;            /* natural frequency for ext observer [Hz] */

/* Position profile */
float       com_f4_accel_time;              /* reference acceleration time */
float       com_f4_posprof_max_speed_rpm;   /* Maximum speed for position profiling [rpm] (mechanical) */

/* IPD control */
uint8_t     com_u1_flag_ipd_use;            /* position loop method select */
float       com_f4_ipd_speed_k_ratio;       /* speed gain ratio for I-PD */
float       com_f4_ipd_pos_kp_ratio;        /* position control gain ratio for I-PD */
float       com_f4_ipd_omega_hz;            /* control frequency[Hz] of IPD controller */
float       com_f4_ipd_pos_ff_ratio;        /* Position feed-forward gain for I-PD */

/* Voltage error compensation */
uint8_t     com_u1_flag_volt_err_comp_use;  /* Flags whether use voltage error compensation */

/* Flux-weakening control */
uint8_t     com_u1_flag_fluxwkn_use;        /* Flags whether use flux-weakening */

/***********************************************************************************************************************
 Private global variables and functions
 **********************************************************************************************************************/
static uint8_t  s_u1_cnt_ics = 0;           /* Counter for period of calling "scope_watchpoint" */
static void r_app_rmw_system_mode(void);
static void r_app_rmw_check_com_input(void);
static void r_app_rmw_update_params(void);
static void r_app_rmw_update_command(void);

/***********************************************************************************************************************
* Function Name : r_app_rmw_ui_init
* Description   : Initialize variables for Analyzer interface
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_ui_init(void)
{
    /* Operation variables */
    com_u1_system_mode  = STATEMACHINE_EVENT_STOP;
    g_u1_system_mode    = STATEMACHINE_EVENT_STOP;
    com_u1_enable_write = 0;
    g_u1_enable_write   = 0;
    com_u1_sw_userif    = APP_CFG_USE_UI;
    g_u1_sw_userif      = APP_CFG_USE_UI;

    /* Offset parameters */
    com_u2_offset_calc_time = CURRENT_CFG_OFFSET_CALC_TIME;

    /* Motor parameters */
    com_u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS;
    com_f4_mtr_r               = MOTOR_CFG_RESISTANCE;
    com_f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE;
    com_f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE;
    com_f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX;
    com_f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA;
    com_f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS;
    com_f4_max_speed_rpm       = MOTOR_CFG_MAX_SPEED_RPM;

    /* Encoder parameter */
    com_u1_ctrl_loop_mode       = MOTOR_COMMON_CFG_LOOP_MODE;
    com_u1_encd_angle_adj_mode  = ENCODER_VECTOR_CFG_ANGLE_ADJUST_MODE;
    com_u2_encd_cpr             = SENSOR_CFG_ENCD_PPR;
    com_f4_hs_change_speed_rpm  = SENSOR_ENCD_HS_CHANGE_RPM;
    com_f4_hs_change_margin_rpm = SENSOR_ENCD_HS_CHANGE_MARGIN_RPM;
    com_f4_ol_ref_id            = CURRENT_CFG_REF_ID_OPENLOOP;
    com_f4_id_up_time           = CURRENT_CFG_ID_UP_STEP_TIME;

    /* Control parameters */
    /* Current control */
    com_f4_current_omega_hz = CURRENT_CFG_OMEGA;
    com_f4_current_zeta     = CURRENT_CFG_ZETA;

    /* Speed control */
    com_f4_speed_omega_hz       = SPEED_CFG_OMEGA;
    com_f4_speed_zeta           = SPEED_CFG_ZETA;
    com_f4_speed_lpf_hz         = SPEED_CFG_LPF_OMEGA;
    com_f4_ref_speed_rpm        = 0.0f;
    com_f4_speed_rate_limit_rpm = SPEED_CFG_RATE_LIMIT_RPM;
    com_f4_overspeed_limit_rpm  = SPEED_CFG_SPEED_LIMIT_RPM;

    /* Position control */
    com_u1_pos_cmd_mode      = POSITION_COMMAND_MODE_TRAPEZOID;
    com_u2_pos_interval_time = POSITION_CFG_INTERVAL_TIME;
    com_u2_pos_dead_band     = POSITION_CFG_DEAD_BAND;
    com_u2_pos_band_limit    = POSITION_CFG_BAND_LIMIT;
    com_f4_pos_omega_hz      = POSITION_CFG_OMEGA;
    com_f4_pos_ff_ratio      = POSITION_CFG_SPEED_FF_RATIO;
    com_f4_ref_position_deg  = 0.0f;

    /* Optional functions */
    /* Extended observe */
    com_u1_flag_extobserver_use = SPEED_CFG_OBSERVER;
    com_f4_extobs_omega         = SPEED_CFG_SOB_OMEGA;

    /* Position profile */
    com_f4_accel_time            = POSITION_PROFILE_ACCEL_TIME;
    com_f4_posprof_max_speed_rpm = MOTOR_CFG_MAX_SPEED_RPM;

    /* IPD control */
    com_u1_flag_ipd_use      = MOTOR_COMMON_CFG_IPD_CTRL;
    com_f4_ipd_speed_k_ratio = IPD_SPEED_RATIO;
    com_f4_ipd_pos_kp_ratio  = IPD_POS_KP_RATIO;
    com_f4_ipd_omega_hz      = IPD_CFG_OMEGA;
    com_f4_ipd_pos_ff_ratio  = IPD_POS_FF_RATIO;

    /* Voltage error compensation */
    com_u1_flag_volt_err_comp_use = CURRENT_CFG_VOLT_ERR_COMP;

    /* Flux-weakening control */
    com_u1_flag_fluxwkn_use = SPEED_CFG_FLUX_WEAKENING;
} /* End of function r_app_rmw_ui_init */

/***********************************************************************************************************************
* Function Name : r_app_rmw_ui_mainloop
* Description   : RMW communication main-loop process
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_ui_mainloop(void)
{
    uint8_t u1_temp;
    uint8_t u1_motor_status;

    r_app_rmw_system_mode();

    u1_motor_status = R_MOTOR_ENCODER_VECTOR_StatusGet(&g_st_encoder_vector);  /* Get status of motor control system */

    if (STATEMACHINE_STATE_RUN == u1_motor_status)
    {
        /***** Positioning flag *****/
        u1_temp = R_MOTOR_ENCODER_VECTOR_InPositionFlagGet(&g_st_encoder_vector);
        if (MTR_FLG_SET == u1_temp)
        {
            /* Do nothing */
        }
        else if (MTR_FLG_CLR == u1_temp)
        {
            /* Do nothing */
        }
        else
        {
            /* Do nothing */
        }
    }
} /* End of function r_app_rmw_ui_mainloop */

/***********************************************************************************************************************
* Function Name : r_app_rmw_copy_com_to_buffer
* Description   : Set com variables to "tool" input buffer
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_copy_com_to_buffer(void)
{
    r_app_rmw_check_com_input();

    /***** When com_s2_enable_sw and g_u1_enable_write are same value, rewrite enable. *****/
    if (com_u1_enable_write == g_u1_enable_write)
    {
        /* Offset parameters */
        g_st_rmw_input_buffer.u2_offset_calc_time = com_u2_offset_calc_time;

        /* Motor parameters */
        g_st_rmw_input_buffer.st_motor.u2_mtr_pp              = com_u2_mtr_pp;
        g_st_rmw_input_buffer.st_motor.f4_mtr_r               = com_f4_mtr_r;
        g_st_rmw_input_buffer.st_motor.f4_mtr_ld              = com_f4_mtr_ld;
        g_st_rmw_input_buffer.st_motor.f4_mtr_lq              = com_f4_mtr_lq;
        g_st_rmw_input_buffer.st_motor.f4_mtr_m               = com_f4_mtr_m;
        g_st_rmw_input_buffer.st_motor.f4_mtr_j               = com_f4_mtr_j;
        g_st_rmw_input_buffer.st_motor.f4_nominal_current_rms = com_f4_nominal_current_rms;
        g_st_rmw_input_buffer.f4_max_speed_rpm                = com_f4_max_speed_rpm;

        /* Encoder parameter */
        g_st_rmw_input_buffer.u1_ctrl_loop_mode       = com_u1_ctrl_loop_mode;
        g_st_rmw_input_buffer.u1_encd_angle_adj_mode  = com_u1_encd_angle_adj_mode;
        g_st_rmw_input_buffer.u2_encd_cpr             = com_u2_encd_cpr;
        g_st_rmw_input_buffer.f4_hs_change_speed_rpm  = com_f4_hs_change_speed_rpm;
        g_st_rmw_input_buffer.f4_hs_change_margin_rpm = com_f4_hs_change_margin_rpm;
        g_st_rmw_input_buffer.f4_ol_ref_id            = com_f4_ol_ref_id;
        g_st_rmw_input_buffer.f4_id_up_time           = com_f4_id_up_time;

        /* Control parameters */
        /* Current control */
        g_st_rmw_input_buffer.f4_current_omega_hz = com_f4_current_omega_hz;
        g_st_rmw_input_buffer.f4_current_zeta     = com_f4_current_zeta;

        /* Speed control */
        g_st_rmw_input_buffer.f4_speed_omega_hz       = com_f4_speed_omega_hz;
        g_st_rmw_input_buffer.f4_speed_zeta           = com_f4_speed_zeta;
        g_st_rmw_input_buffer.f4_speed_lpf_hz         = com_f4_speed_lpf_hz;
        g_st_rmw_input_buffer.f4_ref_speed_rpm        = com_f4_ref_speed_rpm;
        g_st_rmw_input_buffer.f4_speed_rate_limit_rpm = com_f4_speed_rate_limit_rpm;
        g_st_rmw_input_buffer.f4_overspeed_limit_rpm  = com_f4_overspeed_limit_rpm;

        /* Position control */
        g_st_rmw_input_buffer.u1_pos_cmd_mode      = com_u1_pos_cmd_mode;
        g_st_rmw_input_buffer.u2_pos_interval_time = com_u2_pos_interval_time;
        g_st_rmw_input_buffer.u2_pos_dead_band     = com_u2_pos_dead_band;
        g_st_rmw_input_buffer.u2_pos_band_limit    = com_u2_pos_band_limit;
        g_st_rmw_input_buffer.f4_pos_omega_hz      = com_f4_pos_omega_hz;
        g_st_rmw_input_buffer.f4_pos_ff_ratio      = com_f4_pos_ff_ratio;
        g_st_rmw_input_buffer.f4_ref_position_deg  = com_f4_ref_position_deg;

        /* Optional functions */
        /* Extended observe */
        g_st_rmw_input_buffer.u1_flag_extobserver_use = com_u1_flag_extobserver_use;
        g_st_rmw_input_buffer.f4_extobs_omega         = com_f4_extobs_omega;

        /* Position profile */
        g_st_rmw_input_buffer.f4_accel_time            = com_f4_accel_time;
        g_st_rmw_input_buffer.f4_posprof_max_speed_rpm = com_f4_posprof_max_speed_rpm;

        /* IPD control */
        g_st_rmw_input_buffer.u1_flag_ipd_use      = com_u1_flag_ipd_use;
        g_st_rmw_input_buffer.f4_ipd_speed_k_ratio = com_f4_ipd_speed_k_ratio;
        g_st_rmw_input_buffer.f4_ipd_pos_kp_ratio  = com_f4_ipd_pos_kp_ratio;
        g_st_rmw_input_buffer.f4_ipd_omega_hz      = com_f4_ipd_omega_hz;
        g_st_rmw_input_buffer.f4_ipd_pos_ff_ratio  = com_f4_ipd_pos_ff_ratio;

        /* Voltage error compensation */
        g_st_rmw_input_buffer.u1_flag_volt_err_comp_use = com_u1_flag_volt_err_comp_use;

        /* Flux-weakening control */
        g_st_rmw_input_buffer.u1_flag_fluxwkn_use = com_u1_flag_fluxwkn_use;

        /* copy variables com to ICS input */
        g_u1_update_param_flag = 1;
        g_u1_enable_write     ^= 1;                     /* change every time 0 and 1 */
    }
} /* End of function r_app_rmw_copy_com_to_buffer */

/***********************************************************************************************************************
* Function Name : r_app_rmw_interrupt_handler
* Description   : Process for ICS(Analyzer)
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void r_app_rmw_interrupt_handler(void)
{
    s_u1_cnt_ics++;

    /* Decimation of ICS call */
    if (ICS_DECIMATION < s_u1_cnt_ics)
    {
        s_u1_cnt_ics = 0;

        /* Call ICS */
        ics2_watchpoint();
    }

    /* Update commands and configurations when trigger flag is set */
    if (1 == g_u1_update_param_flag)
    {
        r_app_rmw_update_params();
#if USE_RMW_TUNER
        R_TUNER_SetTuneResult();
#endif
        g_u1_update_param_flag = 0;
    }
    else
    {
        if (MAIN_UI_RMW == g_u1_sw_userif)
        {
            r_app_rmw_update_command();
        }
    }
} /* End of function r_app_rmw_interrupt_handler */

/***********************************************************************************************************************
* Function Name : r_app_rmw_system_mode
* Description   : Process system mode command
* Arguments     : None
* Return Value  : None
************************************************************************************************************************/
static void r_app_rmw_system_mode(void)
{
    uint8_t u1_temp;
    uint8_t u1_motor_status;

    /*============================*/
    /*        Execute event       */
    /*============================*/
    u1_temp = com_u1_system_mode;

    if (g_u1_system_mode != u1_temp)
    {
        if (u1_temp >= STATEMACHINE_EVENT_SIZE)
        {
            com_u1_system_mode = g_u1_system_mode;
        }
        else
        {
            g_u1_system_mode = u1_temp;
            switch (g_u1_system_mode)
            {
                case STATEMACHINE_EVENT_STOP:
                    R_MOTOR_ENCODER_VECTOR_MotorStop(&g_st_encoder_vector);
                break;

                case STATEMACHINE_EVENT_RUN:
                    R_MOTOR_ENCODER_VECTOR_MotorStart(&g_st_encoder_vector);
                break;

                case STATEMACHINE_EVENT_RESET:
                    R_MOTOR_ENCODER_VECTOR_MotorReset(&g_st_encoder_vector);
                break;

                default:
                    /* Do nothing */
                break;
            }
        }
    }

    u1_motor_status = R_MOTOR_ENCODER_VECTOR_StatusGet(&g_st_encoder_vector);  /* Get status of motor control system */

    if (STATEMACHINE_EVENT_RESET == g_u1_system_mode)
    {
        if (STATEMACHINE_STATE_STOP == u1_motor_status)
        {
            r_app_rmw_ui_init();                            /* Initialize private global variables for reset event */
        }
        else if (STATEMACHINE_STATE_ERROR == u1_motor_status)
        {
            g_u1_system_mode   = STATEMACHINE_EVENT_ERROR;
            com_u1_system_mode = STATEMACHINE_EVENT_ERROR;
        }
        else
        {
            /* Do nothing */
        }
    }
} /* End of function r_app_rmw_system_mode */

/***********************************************************************************************************************
* Function Name : r_app_rmw_check_com_input
* Description   : Check com variables
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_rmw_check_com_input(void)
{
    float f4_temp0;

    /**************************/
    /*    limit variables     */
    /**************************/
    com_f4_ref_speed_rpm = motor_filter_limitf_abs(com_f4_ref_speed_rpm, com_f4_max_speed_rpm);

    /* current natural frequency limit 1Hz ~ 1000Hz */
    com_f4_current_omega_hz = motor_filter_limitf(com_f4_current_omega_hz,
                                                  APP_CFG_MAX_CURRENT_OMEGA,
                                                  APP_CFG_MIN_OMEGA);

    /* natural frequency & damping ratio for speed control loop */
    f4_temp0 = com_f4_current_omega_hz / APP_CFG_FREQ_BAND_LIMIT;
    if (f4_temp0 < com_f4_speed_omega_hz)
    {
        com_f4_speed_omega_hz = f4_temp0;

        /* speed natural frequency minimum limit 1Hz */
        com_f4_speed_omega_hz = motor_filter_lower_limitf(com_f4_speed_omega_hz, APP_CFG_MIN_OMEGA);
    }

    /* natural frequency for position control loop */
    if (MTR_FLG_CLR == com_u1_flag_ipd_use)
    {
        f4_temp0 = com_f4_speed_omega_hz / APP_CFG_FREQ_BAND_LIMIT;
        if (f4_temp0 < com_f4_pos_omega_hz)
        {
            com_f4_pos_omega_hz = f4_temp0;

            /* position natural frequency minimum limit 1Hz */
            com_f4_pos_omega_hz = motor_filter_lower_limitf(com_f4_pos_omega_hz, APP_CFG_MIN_OMEGA);
        }
    }
    else if (MTR_FLG_SET == com_u1_flag_ipd_use)
    {
        f4_temp0 = com_f4_current_omega_hz / APP_CFG_FREQ_BAND_LIMIT;
        if (f4_temp0 < (com_f4_ipd_speed_k_ratio * com_f4_ipd_omega_hz))
        {
            com_f4_ipd_speed_k_ratio = APP_CFG_FREQ_BAND_LIMIT;
            com_f4_ipd_omega_hz = f4_temp0 / com_f4_ipd_speed_k_ratio;

            /* position natural frequency minimum limit 1Hz */
            com_f4_ipd_omega_hz = motor_filter_lower_limitf(com_f4_ipd_omega_hz, APP_CFG_MIN_OMEGA);
        }
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function r_app_rmw_check_com_input */

/**********************************************************************************************************************
 * Function Name: r_app_rmw_update_params
 * Description  : Apply parameters in buffer through API
 * Arguments    : None
 * Return Value : None
 *********************************************************************************************************************/
static void r_app_rmw_update_params(void)
{
    st_rmw_param_buffer_t *p_st_rmw_input = &g_st_rmw_input_buffer;

    st_current_cfg_t        st_cur_cfg;
    st_speed_cfg_t          st_spd_cfg;
    st_ext_observer_cfg_t   st_ext_obs_cfg;
    st_position_cfg_t       st_pos_cfg;
    st_sensor_encoder_cfg_t st_encd_cfg;
    st_encoder_vector_cfg_t st_encoder_vector_cfg;

    /* FOC configuration set */
    st_encoder_vector_cfg.st_motor               = p_st_rmw_input->st_motor;
    st_encoder_vector_cfg.u1_encd_angle_adj_mode = p_st_rmw_input->u1_encd_angle_adj_mode;
    st_encoder_vector_cfg.u2_encd_cpr            = p_st_rmw_input->u2_encd_cpr;
    st_encoder_vector_cfg.f4_overspeed_limit_rpm = p_st_rmw_input->f4_overspeed_limit_rpm;
    R_MOTOR_ENCODER_VECTOR_ParameterUpdate(&g_st_encoder_vector, &st_encoder_vector_cfg);

    /* Commands */
    R_MOTOR_ENCODER_VECTOR_CtrlTypeSet(&g_st_encoder_vector, p_st_rmw_input->u1_ctrl_loop_mode);
    R_MOTOR_ENCODER_VECTOR_SpeedSet(&g_st_encoder_vector, p_st_rmw_input->f4_ref_speed_rpm);
    R_MOTOR_ENCODER_VECTOR_PositionSet(&g_st_encoder_vector, p_st_rmw_input->f4_ref_position_deg);

    /* Current configuration set */
    st_cur_cfg.u1_flag_volt_err_comp_use = p_st_rmw_input->u1_flag_volt_err_comp_use;
    st_cur_cfg.u2_offset_calc_time       = p_st_rmw_input->u2_offset_calc_time;
    st_cur_cfg.f4_ctrl_period            = MOTOR_COMMON_CTRL_PERIOD;
    st_cur_cfg.f4_current_omega_hz       = p_st_rmw_input->f4_current_omega_hz;
    st_cur_cfg.f4_current_zeta           = p_st_rmw_input->f4_current_zeta;
    st_cur_cfg.f4_ol_ref_id              = p_st_rmw_input->f4_ol_ref_id;
    st_cur_cfg.f4_id_up_step             = p_st_rmw_input->f4_ol_ref_id / p_st_rmw_input->f4_id_up_time;
    st_cur_cfg.st_motor                  = p_st_rmw_input->st_motor;
    R_MOTOR_CURRENT_ParameterUpdate(&g_st_cc, &st_cur_cfg);

    /* Speed configuration set */
    st_spd_cfg.st_motor                = p_st_rmw_input->st_motor;
    st_spd_cfg.u1_flag_extobserver_use = p_st_rmw_input->u1_flag_extobserver_use;
    st_spd_cfg.u1_flag_fluxwkn_use     = p_st_rmw_input->u1_flag_fluxwkn_use;
    if (p_st_rmw_input->f4_max_speed_rpm > g_st_encoder_vector.f4_max_speed_rc_fil_rpm)
    {
        p_st_rmw_input->f4_max_speed_rpm = g_st_encoder_vector.f4_max_speed_rc_fil_rpm;
    }
    st_spd_cfg.f4_speed_ctrl_period    = SPEED_CFG_CTRL_PERIOD;
    st_spd_cfg.f4_max_speed_rpm        = p_st_rmw_input->f4_max_speed_rpm;
    st_spd_cfg.f4_speed_rate_limit_rpm = p_st_rmw_input->f4_speed_rate_limit_rpm;
    st_spd_cfg.f4_speed_omega_hz       = p_st_rmw_input->f4_speed_omega_hz;
    st_spd_cfg.f4_speed_zeta           = p_st_rmw_input->f4_speed_zeta;
    st_spd_cfg.f4_speed_lpf_hz         = p_st_rmw_input->f4_speed_lpf_hz;
    R_MOTOR_SPEED_ParameterUpdate(&g_st_sc, &st_spd_cfg);

    /* extended observer */
    st_ext_obs_cfg.f4_extobs_omega = p_st_rmw_input->f4_extobs_omega;
    R_MOTOR_SPEED_ExtObserverParameterUpdate(&g_st_sc, &st_ext_obs_cfg);

    /* Position configuration set */
    st_pos_cfg.st_motor                     = p_st_rmw_input->st_motor;
    st_pos_cfg.u2_dead_band                 = p_st_rmw_input->u2_pos_dead_band;
    st_pos_cfg.u2_band_limit                = p_st_rmw_input->u2_pos_band_limit;
    st_pos_cfg.u2_pos_interval_time         = p_st_rmw_input->u2_pos_interval_time;
    st_pos_cfg.f4_feedforward_ratio         = p_st_rmw_input->f4_pos_ff_ratio;
    st_pos_cfg.f4_position_omega_hz         = p_st_rmw_input->f4_pos_omega_hz;
    st_pos_cfg.f4_ctrl_period               = POSITION_CFG_CTRL_PERIOD;
    st_pos_cfg.f4_mech_angle_per_sensor_cnt = MTR_TWOPI / MOTOR_COMMON_SENSOR_ENCD_CPR;
    st_pos_cfg.f4_max_speed_rad             = p_st_rmw_input->f4_max_speed_rpm * MTR_RPM2RAD;
    st_pos_cfg.f4_accel_time                = p_st_rmw_input->f4_accel_time;
    st_pos_cfg.f4_posprof_max_speed_rad     = p_st_rmw_input->f4_posprof_max_speed_rpm * MTR_RPM2RAD;
    R_MOTOR_POSITION_ParameterUpdate(&g_st_pc, &st_pos_cfg);
    R_MOTOR_ENCODER_VECTOR_PositionCommandModeSet(&g_st_encoder_vector, p_st_rmw_input->u1_pos_cmd_mode);

    /* IPD configuration set */
    R_MOTOR_IPD_ParameterUpdate(&g_st_ipd,
                                p_st_rmw_input->f4_ipd_pos_kp_ratio,
                                p_st_rmw_input->f4_ipd_pos_ff_ratio,
                                p_st_rmw_input->f4_ipd_speed_k_ratio,
                                IPD_POS_ERR_INPUT_LIMIT,
                                IPD_POS_ERR_INTEGRATOR_LIMIT_RATIO);
    R_MOTOR_IPD_CtrlGainCalc(&g_st_ipd,
                             &p_st_rmw_input->st_motor,
                             p_st_rmw_input->f4_ipd_omega_hz,
                             POSITION_CFG_CTRL_PERIOD);
    R_MOTOR_ENCODER_VECTOR_IPDEnableSet(&g_st_encoder_vector, p_st_rmw_input->u1_flag_ipd_use);

    /* Sensor configuration set */
    st_encd_cfg.f4_ctrl_period          = MOTOR_COMMON_CTRL_PERIOD;
    st_encd_cfg.f4_hs_change_speed_rpm  = p_st_rmw_input->f4_hs_change_speed_rpm;
    st_encd_cfg.f4_hs_change_margin_rpm = p_st_rmw_input->f4_hs_change_margin_rpm;
    st_encd_cfg.u1_ctrl_loop_mode       = p_st_rmw_input->u1_ctrl_loop_mode;
    st_encd_cfg.u2_encd_cpr             = p_st_rmw_input->u2_encd_cpr;
    st_encd_cfg.st_motor                = p_st_rmw_input->st_motor;
    R_MOTOR_SENSOR_ENCODER_ParameterUpdate(&g_st_sensor, &st_encd_cfg);
} /* End of function r_app_rmw_update_params */

/***********************************************************************************************************************
* Function Name : r_app_rmw_update_command
* Description   : Update commands without copying to buffer or update trigger
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
static void r_app_rmw_update_command(void)
{
    if (MOTOR_LOOP_SPEED == g_st_encoder_vector.u1_ctrl_loop_mode)
    {
        R_MOTOR_ENCODER_VECTOR_SpeedSet(&g_st_encoder_vector, com_f4_ref_speed_rpm);
    }
    else if (MOTOR_LOOP_POSITION == g_st_encoder_vector.u1_ctrl_loop_mode)
    {
        R_MOTOR_ENCODER_VECTOR_PositionSet(&g_st_encoder_vector, com_f4_ref_position_deg);
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function r_app_rmw_update_command */
