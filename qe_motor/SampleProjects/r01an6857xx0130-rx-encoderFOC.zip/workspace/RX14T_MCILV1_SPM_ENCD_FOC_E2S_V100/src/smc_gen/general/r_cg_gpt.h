/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : r_cg_gpt.h
* Version          : 1.0.1
* Device(s)        : R5F514T5AxFM
* Description      : General header file for GPT peripheral.
***********************************************************************************************************************/

#ifndef GPT_H
#define GPT_H

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/
/*
    General PWM Timer Start Source Select Register(GTSSR)
    General PWM Timer Stop Source Select Register(GTPSR)
    General PWM Timer Clear Source Select Register(GTCSR)
    General PWM Timer Input Capture Source Select Register A(GTICASR)
    General PWM Timer Input Capture Source Select Register B(GTICBSR)
*/
/* GTETRGA Rising Source Count Start Enable(SSGTRGAR) */
/* GTETRGA Rising Source Count Stop Enable(PSGTRGAR) */
/* GTETRGA Rising Source Counter Clear Enable(CSGTRGAR) */
/* GTETRGA Rising Source GTCCRA Input Capture Enable(ASGTRGAR) */
/* GTETRGA Rising Source GTCCRB Input Capture Enable(BSGTRGAR) */
/* GTETRGA Falling Source Count Start Enable (SSGTRGAF) */
/* GTETRGA Falling Source Count Stop Enable(PSGTRGAF) */
/* GTETRGA Falling Source Counter Clear Enable(CSGTRGAF) */
/* GTETRGA Falling Source GTCCRA Input Capture Enable(ASGTRGAF) */
/* GTETRGA Falling Source GTCCRB Input Capture Enable(BSGTRGAF) */
#define _00000000_GPTn_GTETRGA_DISABLE                 (0x00000000UL) /* Disable use the GTETRGA input */
#define _00000001_GPTn_GTETRGA_RISE_EDGE               (0x00000001UL) /* Enable at rising of the GTETRGA input */
#define _00000002_GPTn_GTETRGA_FALL_EDGE               (0x00000002UL) /* Enable at falling of the GTETRGA input */
#define _00000003_GPTn_GTETRGA_BOTH_EDGES              (0x00000003UL) /* Enable at both edges of the GTETRGA input */
/* A Pin at Rising and B Pin 0 Source count start disable(SSCARBL) */
/* A Pin at Rising and B Pin 0 Source Count Stop Enable(PSCARBL) */
/* A Pin at Rising and B Pin 0 Source counter clear(CSCARBL) */
/* A Pin at Rising and B Pin 0 Source GTCCRA Input Capture Enable(ASCARBL) */
/* A Pin at Rising and B Pin 0 Source GTCCRB Input Capture Enable(BSCARBL) */
/* A Pin at Rising and B Pin 1 Source count start disable(SSCARBH) */
/* A Pin at Rising and B Pin 1 Source Count Stop Enable(PSCARBH) */
/* A Pin at Rising and B Pin 1 Source Counter Clear Enable(CSCARBH) */
/* A Pin at Rising and B Pin 1 Source GTCCRB Input Capture Enable(ASCARBH) */
/* A Pin at Rising and B Pin 1 Source GTCCRB Input Capture Enable(BSCARBH) */
#define _00000000_GPTn_GTIOCnA_RISE_DISABLE            (0x00000000UL) /* Disable at rising of the GTIOCnA pin input */
#define _00000100_GPTn_GTIOCnA_RISE_GTIOCnB_0_ENABLE   (0x00000100UL) /* Enable at rising of the GTIOCnA pin input
                                                                         while the GTIOCnB pin input is 1 */
#define _00000200_GPTn_GTIOCnA_RISE_GTIOCnB_1_ENABLE   (0x00000200UL) /* Enable at rising of the GTIOCnA pin input
                                                                         while the GTIOCnB pin input is 1 */
#define _00000300_GPTn_GTIOCnA_RISE_ENABLE             (0x00000300UL) /* Enable at rising of the GTIOCnA pin input */
/* A Pin at Falling and B Pin 0 Source Count Start Enable(SSCAFBL) */
/* A Pin at Falling and B Pin 0 Source Count Stop Enable(PSCAFBL) */
/* A Pin at Falling and B Pin 0 Source Counter Clear Enable(CSCAFBL) */
/* A Pin at Falling and B Pin 0 Source GTCCRA Input Capture Enable(ASCAFBL) */
/* A Pin at Falling and B Pin 0 Source GTCCRB Input Capture Enable(BSCAFBL) */
/* A Pin at Falling and B Pin 1 Source Count Start Enable(SSCAFBH) */
/* A Pin at Falling and B Pin 1 Source Count Stop Enable(PSCAFBH) */
/* A Pin at Falling and B Pin 1 Source Counter Clear Enable(CSCAFBH) */
/* A Pin at Falling and B Pin 1 Source GTCCRA Input Capture Enable(ASCAFBH) */
/* A Pin at Falling and B Pin 1 Source GTCCRB Input Capture Enable(BSCAFBH) */
#define _00000000_GPTn_GTIOCnA_FALL_DISABLE            (0x00000000UL) /* Disable at falling of the GTIOCnA pin input */
#define _00000400_GPTn_GTIOCnA_FALL_GTIOCnB_0_ENABLE   (0x00000400UL) /* Enable at falling of the GTIOCnA pin input
                                                                         while the GTIOCnB pin input is 1 */
#define _00000800_GPTn_GTIOCnA_FALL_GTIOCnB_1_ENABLE   (0x00000800UL) /* Enable at falling of the GTIOCnA pin input
                                                                         while the GTIOCnB pin input is 1 */
#define _00000C00_GPTn_GTIOCnA_FALL_ENABLE             (0x00000C00UL) /* Enable at falling of the GTIOCnA pin input */
/* B Pin at Rising and A Pin 0 Source Count Start Enable(SSCBRAL) */
/* B Pin at Rising and A Pin 0 Source Count Stop Enable(PSCBRAL) */
/* B Pin at Rising and A Pin 0 Source Counter Clear Enable(CSCBRAL) */
/* B Pin at Rising and A Pin 0 Source GTCCRA Input Capture Enable(ASCBRAL) */
/* B Pin at Rising and A Pin 0 Source GTCCRB Input Capture Enable(BSCBRAL) */
/* B Pin at Rising and A Pin 1 Source Count Start Enable(SSCBRAH) */
/* B Pin at Rising and A Pin 1 Source Count Stop Enable(PSCBRAH) */
/* B Pin at Rising and A Pin 1 Source Counter Clear Enable(CSCBRAH) */
/* B Pin at Rising and A Pin 1 Source GTCCRA Input Capture Enable(ASCBRAH) */
/* B Pin at Rising and A Pin 1 Source GTCCRB Input Capture Enable(BSCBRAH) */
#define _00000000_GPTn_GTIOCnB_RISE_DISABLE            (0x00000000UL) /* Disable at rising of the GTIOCnB pin input */
#define _00001000_GPTn_GTIOCnB_RISE_GTIOCnA_0_ENABLE   (0x00001000UL) /* Enable at rising of the GTIOCnB pin input
                                                                         while the GTIOCnA pin input is 1 */
#define _00002000_GPTn_GTIOCnB_RISE_GTIOCnA_1_ENABLE   (0x00002000UL) /* Enable at rising of the GTIOCnB pin input
                                                                         while the GTIOCnA pin input is 1 */
#define _00003000_GPTn_GTIOCnB_RISE_ENABLE             (0x00003000UL) /* Enable at rising of the GTIOCnB pin input */
/* B Pin at Falling and A Pin 0 Source Count Start Enable(SSCBFAL) */
/* B Pin at Falling and A Pin 0 Source Count Stop Enable(PSCBFAL) */
/* B Pin at Falling and A Pin 0 Source Counter Clear Enable(CSCBFAL) */
/* B Pin at Falling and A Pin 0 Source GTCCRA Input Capture Enable(ASCBFAL) */
/* B Pin at Falling and A Pin 0 Source GTCCRB Input Capture Enable(BSCBFAL) */
/* B Pin at Falling and A Pin 1 Source Count Start Enable (SSCBFAH) */
/* B Pin at Falling and A Pin 1 Source Count Stop Enable(PSCBFAH) */
/* B Pin at Falling and A Pin 1 Source Counter Clear Enable(CSCBFAH) */
/* B Pin at Falling and A Pin 1 Source GTCCRA Input Capture Enable(ASCBFAH) */
/* B Pin at Falling and A Pin 1 Source GTCCRB Input Capture Enable(BSCBFAH) */
#define _00000000_GPTn_GTIOCnB_FALL_DISABLE            (0x00000000UL) /* Disable at falling of the GTIOCnB pin input */
#define _00004000_GPTn_GTIOCnB_FALL_GTIOCnA_0_ENABLE   (0x00004000UL) /* Enable at falling of the GTIOCnB pin input
                                                                         while the GTIOCnA pin input is 1 */
#define _00008000_GPTn_GTIOCnB_FALL_GTIOCnA_1_ENABLE   (0x00008000UL) /* Enable at falling of the GTIOCnB pin input
                                                                         while the GTIOCnA pin input is 1*/
#define _0000C000_GPTn_GTIOCnB_FALL_ENABLE             (0x0000C000UL) /* Enable at falling of the GTIOCnB pin input */
/* MTU0 Trigger Count Start Enable (SSMTU0) */
#define _00000000_GPTn_SSMTU0_INPUT_DISABLE            (0x00000000UL) /* Disable count start by the MTU0 count start */
#define _00010000_GPTn_SSMTU0_INPUT_ENABLE             (0x00010000UL) /* Enable count start by the MTU0 count start */
/* MTU4 Trigger Count Start Enable (SSMTU4) */
#define _00000000_GPTn_SSMTU4_INPUT_DISABLE            (0x00000000UL) /* Disable count start by the MTU4 count start */
#define _00020000_GPTn_SSMTU4_INPUT_ENABLE             (0x00020000UL) /* Enable count start by the MTU4 count start */

/* Software Source Count Start Enable(CSTRT) */
/* Software Source Count Stop Enable(CSTOP) */
/* Software Source Counter Clear Enable(CCLR) */
#define _00000000_GPTn_SOFTWARE_SOURCE_DISABLE         (0x00000000UL) /* Disable count start / stop / clear / up / down
                                                                         by setting register */
#define _80000000_GPTn_SOFTWARE_SOURCE_ENABLE          (0x80000000UL) /* Enable count start / stop / clear / up / down
                                                                         by setting register */
/* Other Channel Source GTCCRA Input Capture Enable(ASOC) */
/* Other Channel Source GTCCRB Input Capture Enable(BSOC) */
#define _01000000_GPTn_INPUT_OTHERCHAN                 (0x01000000UL) /* Enable input capture by other channel factor */

/*
    General PWM Timer Control Register (GTCR)
*/
/* GTIOCnA input/output pin polarity reversal control (AINV) */
#define _00000000_GPTn_GTCIOCA_INVERT_DISABLE          (0x00000000UL) /* Not invert GTIOCnA input/output pin */
#define _00000010_GPTn_GTCIOCA_INVERT_ENABLE           (0x00000010UL) /* Invert GTIOCnA input/output pin */
/* GTIOCnB input/output pin polarity reversal control (BINV) */
#define _00000000_GPTn_GTCIOCB_INVERT_DISABLE          (0x00000000UL) /* Not invert GTIOCnB input/output pin */
#define _00000020_GPTn_GTCIOCB_INVERT_ENABLE           (0x00000020UL) /* Invert GTIOCnB input/output pin */
/* Input capture operation select at count stop (ICDS) */
#define _00000000_GPTn_INPUTCAP_COUNT_STOP             (0x00000000UL) /* Input capture is operated at count stop */
#define _00000100_GPTn_NO_INPUTCAP_COUNT_STOP          (0x00000100UL) /* Input capture is not operated at count stop */
/* Mode Select (MD[2:0]) */
#define _00000000_GPTn_MODE_SAW_WAVE_PWM               (0x00000000UL) /* Saw-wave PWM mode */
#define _00010000_GPTn_MODE_SAW_WAVE_ONESHOT           (0x00010000UL) /* Saw-wave one-shot mode */
#define _00040000_GPTn_MODE_TRIANGLE_WAVE_PWM_1        (0x00040000UL) /* Triangle-wave PWM mode 1 */
#define _00050000_GPTn_MODE_TRIANGLE_WAVE_PWM_2        (0x00050000UL) /* Triangle-wave PWM mode 2 */
#define _00060000_GPTn_MODE_TRIANGLE_WAVE_PWM_3        (0x00060000UL) /* Triangle-wave PWM mode 3 */
/* Timer Prescaler Select (TPCS[3:0]) */
#define _00000000_GPTn_COUNT_CLK_PCLKB                 (0x00000000UL) /* PCLKB */
#define _00800000_GPTn_COUNT_CLK_PCLKB_2               (0x00800000UL) /* PCLKB/2 */
#define _01000000_GPTn_COUNT_CLK_PCLKB_4               (0x01000000UL) /* PCLKB/4 */
#define _01800000_GPTn_COUNT_CLK_PCLKB_8               (0x01800000UL) /* PCLKB/8 */
#define _02000000_GPTn_COUNT_CLK_PCLKB_16              (0x02000000UL) /* PCLKB/16 */
#define _02800000_GPTn_COUNT_CLK_PCLKB_32              (0x02800000UL) /* PCLKB/32 */
#define _03000000_GPTn_COUNT_CLK_PCLKB_64              (0x03000000UL) /* PCLKB/64 */
#define _04000000_GPTn_COUNT_CLK_PCLKB_256             (0x04000000UL) /* PCLKB/256 */
#define _05000000_GPTn_COUNT_CLK_PCLKB_1024            (0x05000000UL) /* PCLKB/1024 */
#define _06000000_GPTn_COUNT_CLK_GTETRGA               (0x06000000UL) /* GTETRGA */

/*
    General PWM Timer Count Direction and Duty Setting Register (GTUDDTYC)
*/
/* Count Direction Setting (UD) */
#define _00000000_GPTn_COUNT_DOWN                      (0x00000000UL) /* GTCNT counts down */
#define _00000001_GPTn_COUNT_UP                        (0x00000001UL) /* GTCNT counts up */
/* Forcible Count Direction Setting (UDF) */
#define _00000000_GPTn_COUNT_DIR_NORMAL                (0x00000000UL) /* Not forcibly set */
#define _00000002_GPTn_COUNT_DIR_FORCE                 (0x00000002UL) /* Forcibly set */
/* GTIOCnA Pin Output Duty Setting(OADTY[1:0]) */
#define _00000000_GPTn_GTIOCnA_DUTYCYCLE_COMPARE       (0x00000000UL) /* Compare matches determine the duty cycle
                                                                         of the output on GTIOCnA pin */
#define _00020000_GPTn_GTIOCnA_DUTYCYCLE_0             (0x00020000UL) /* The duty cycle of the output on
                                                                         GTIOCnA pin is 0% */
#define _00030000_GPTn_GTIOCnA_DUTYCYCLE_100           (0x00030000UL) /* The duty cycle of the output on
                                                                         GTIOCnA pin is 100% */
/* GTIOCnA Pin Output Duty Forced Setting(OADTYF) */
#define _00000000_GPTn_GTIOCnA_DUTYFORCE_DISABLE       (0x00000000UL) /* Duty of pin output is not forcibly set */
#define _00040000_GPTn_GTIOCnA_DUTYFORCE_ENABLE        (0x00040000UL) /* Duty of pin output is forcibly set */
/* Output after Release of GTIOCnA Pin Output 0%/100% Duty Cycle Settings(OADTYR) */
#define _00000000_GPTn_GTIOCA_RELEASE_OUTPUTVALUE      (0x00000000UL) /* Output value when the duty cycle is set after
                                                                         release */
#define _00080000_GPTn_GTIOCA_RELEASE_COMPAREVALUE     (0x00080000UL) /* Compare match output value which is masked
                                                                         after release */
/* GTIOCnB Pin Output Duty Setting(OBDTY[1:0]) */
#define _00000000_GPTn_GTIOCnB_DUTYCYCLE_COMPARE       (0x00000000UL) /* Compare matches determine the duty cycle
                                                                         of the output on GTIOCnB pin */
#define _02000000_GPTn_GTIOCnB_DUTYCYCLE_0             (0x02000000UL) /* The duty cycle of the output on
                                                                         GTIOCnB pin is 0% */
#define _03000000_GPTn_GTIOCnB_DUTYCYCLE_100           (0x03000000UL) /* The duty cycle of the output on
                                                                         GTIOCnB pin is 100% */
/* GTIOCnB Pin Output Duty Forced Setting(OBDTYF) */
#define _00000000_GPTn_GTIOCnB_DUTYFORCE_DISABLE       (0x00000000UL) /* Duty of pin output is not forcibly set */
#define _04000000_GPTn_GTIOCnB_DUTYFORCE_ENABLE        (0x04000000UL) /* Duty of pin output is forcibly set */
/* Output after Release of GTIOCnB Pin Output 0%/100% Duty Cycle Settings(OBDTYR) */
#define _00000000_GPTn_GTIOCB_RELEASE_OUTPUTVALUE      (0x00000000UL) /* Output value when the duty cycle is set after
                                                                         release */
#define _08000000_GPTn_GTIOCB_RELEASE_COMPAREVALUE     (0x08000000UL) /* Compare match output value which is masked
                                                                         after release */
/* GTIOCnA, B Terminal Output 0%/100% Duty Setting Reflection Timing (OABDTYT) */
#define _00000000_GPTn_GTIOCnAB_VALLEY                 (0x00000000UL) /* GTIOCnA/B output 0%/100% duty is reflected at the valley */
#define _10000000_GPTn_GTIOCnAB_VALLEY_PEAK            (0x10000000UL) /* GTIOCnA/B output 0%/100% duty is reflected both the valley and the peak */
/*
    General PWM Timer I/O Control Register (GTIOR)
*/
/* GTIOCnA Pin Function Select (GTIOA[4:0]) */
#define _00000000_GPTn_GTIOCA_COMP_MATCH_RETAIN        (0x00000000UL) /* Output retained at compare match */
#define _00000001_GPTn_GTIOCA_COMP_MATCH_LOW           (0x00000001UL) /* Output low at compare match */
#define _00000002_GPTn_GTIOCA_COMP_MATCH_HIGH          (0x00000002UL) /* Output high at compare match */
#define _00000003_GPTn_GTIOCA_COMP_MATCH_TOGGLE        (0x00000003UL) /* Output toggled at compare match */
#define _00000000_GPTn_GTIOCA_CYCLE_END_RETAIN         (0x00000000UL) /* Output retained at cycle end */
#define _00000004_GPTn_GTIOCA_CYCLE_END_LOW            (0x00000004UL) /* Output low at cycle end */
#define _00000008_GPTn_GTIOCA_CYCLE_END_HIGH           (0x00000008UL) /* Output hight at cycle end */
#define _0000000C_GPTn_GTIOCA_CYCLE_END_TOGGLE         (0x0000000CUL) /* Output toggled at cycle end */
#define _00000000_GPTn_GTIOCA_INIT_OUT_LOW             (0x00000000UL) /* Initial output is low */
#define _00000010_GPTn_GTIOCA_INIT_OUT_HIGH            (0x00000010UL) /* Initial output is high */
/* Output Value at GTIOCnA Pin count stop (OADFLT) */
#define _00000000_GPTn_GTIOCA_OUTPUT_ON_STOP_0         (0x00000000UL) /* Outputs low when counting is stopped */
#define _00000040_GPTn_GTIOCA_OUTPUT_ON_STOP_1         (0x00000040UL) /* Outputs high when counting is stopped */
/* Output Retain at GTIOCnA Pin count start/stop (OAHLD) */
#define _00000000_GPTn_GTIOCA_OUTPUT_ON_START_SET      (0x00000000UL) /* Output at start/stop based on setting */
#define _00000080_GPTn_GTIOCA_OUTPUT_ON_START_RETAIN   (0x00000080UL) /* Output at start/stop is retained */
/* GTIOCnA Pin Output Enable (OAE) */
#define _00000000_GPTn_GTCIOCA_OUTPUT_DISABLE          (0x00000000UL) /* No pin output */
#define _00000100_GPTn_GTIOCnA_OUTPUT_ENABLE           (0x00000100UL) /* Pin output */
/* GTIOCnA Pin Negate Value Setting (OADF[1:0]) */
#define _00000000_GPTn_GTIOCnA_NEG_DISABEL             (0x00000000UL) /* None */
#define _00000200_GPTn_GTIOCnA_NEG_HIZ                 (0x00000200UL) /* Hi-Z state for output negation */
#define _00000400_GPTn_GTIOCnA_NEG_OUT0                (0x00000400UL) /* 0 for output negation */
#define _00000600_GPTn_GTIOCnA_NEG_OUT1                (0x00000600UL) /* 1 for output negation */
/* GTIOCnA Pin Input Noise Filter Enable (NFAEN) */
#define _00000000_GPTn_GTIOCnA_NOISE_FILTER_DISABLE    (0x00000000UL) /* The noise filter for GTIOCnA pin disabled */
#define _00002000_GPTn_GTIOCnA_NOISE_FILTER_ENABLE     (0x00002000UL) /* The noise filter for GTIOCnA pin enabled */
/* GTIOCnA Pin Input Noise Filter Sampling Clock Select (NFCSA[1:0]) */
#define _00000000_GPTn_NOISE_FILTERA_PCLKB             (0x00000000UL) /* PCLKB */
#define _00004000_GPTn_NOISE_FILTERA_PCLKB_4           (0x00004000UL) /* PCLKB/4 */
#define _00008000_GPTn_NOISE_FILTERA_PCLKB_16          (0x00008000UL) /* PCLKB/16 */
#define _0000C000_GPTn_NOISE_FILTERA_PCLKB_64          (0x0000C000UL) /* PCLKB/64 */
/* GTIOCnB Pin Function Select (GTIOB[4:0]) */
#define _00000000_GPTn_GTIOCB_COMP_MATCH_RETAIN        (0x00000000UL) /* Output retained at compare match */
#define _00010000_GPTn_GTIOCB_COMP_MATCH_LOW           (0x00010000UL) /* Output low at compare match */
#define _00020000_GPTn_GTIOCB_COMP_MATCH_HIGH          (0x00020000UL) /* Output high at compare match */
#define _00030000_GPTn_GTIOCB_COMP_MATCH_TOGGLE        (0x00030000UL) /* Output toggled at compare match */
#define _00000000_GPTn_GTIOCB_CYCLE_END_RETAIN         (0x00000000UL) /* Output retained at cycle end */
#define _00040000_GPTn_GTIOCB_CYCLE_END_LOW            (0x00040000UL) /* Output low at cycle end */
#define _00080000_GPTn_GTIOCB_CYCLE_END_HIGH           (0x00080000UL) /* Output hight at cycle end */
#define _000C0000_GPTn_GTIOCB_CYCLE_END_TOGGLE         (0x000C0000UL) /* Output toggled at cycle end */
#define _00000000_GPTn_GTIOCB_INIT_OUT_LOW             (0x00000000UL) /* Initial output is low */
#define _00100000_GPTn_GTIOCB_INIT_OUT_HIGH            (0x00100000UL) /* Initial output is high */
/* Output Value at GTIOCnB Pin count stop (OBDFLT) */
#define _00000000_GPTn_GTIOCB_OUTPUT_ON_STOP_0         (0x00000000UL) /* Outputs low when counting is stopped */
#define _00400000_GPTn_GTIOCB_OUTPUT_ON_STOP_1         (0x00400000UL) /* Outputs high when counting is stopped */
/* Output Retain at GTIOCnB Pin count start/stop (OBHLD) */
#define _00000000_GPTn_GTIOCB_OUTPUT_ON_START_SET      (0x00000000UL) /* Output at start/stop based on setting */
#define _00800000_GPTn_GTIOCB_OUTPUT_ON_START_RETAIN   (0x00800000UL) /* Output at start/stop is retained */
/* GTIOCnB Pin Output Enable (OBE) */
#define _00000000_GPTn_GTCIOCB_OUTPUT_DISABLE          (0x00000000UL) /* No pin output */
#define _01000000_GPTn_GTIOCnB_OUTPUT_ENABLE           (0x01000000UL) /* Pin output */
/* GTIOCnB Pin Negate Value Setting (OBDF[1:0]) */
#define _00000000_GPTn_GTIOCnB_NEG_DISABEL             (0x00000000UL) /* None */
#define _02000000_GPTn_GTIOCnB_NEG_HIZ                 (0x02000000UL) /* Hi-Z state for output negation */
#define _04000000_GPTn_GTIOCnB_NEG_OUT0                (0x04000000UL) /* 0 for output negation */
#define _06000000_GPTn_GTIOCnB_NEG_OUT1                (0x06000000UL) /* 1 for output negation */
/* GTIOCnB Pin Input Noise Filter Enable (NFBEN) */
#define _00000000_GPTn_GTIOCnB_NOISE_FILTER_DISABLE    (0x00000000UL) /* The noise filter for GTIOCnB pin disabled */
#define _20000000_GPTn_GTIOCnB_NOISE_FILTER_ENABLE     (0x20000000UL) /* The noise filter for GTIOCnB pin enabled */
/* GTIOCnA Pin Input Noise Filter Sampling Clock Select (NFCSB[1:0]) */
#define _00000000_GPTn_NOISE_FILTERB_PCLKB             (0x00000000UL) /* PCLKB */
#define _40000000_GPTn_NOISE_FILTERB_PCLKB_4           (0x40000000UL) /* PCLKB/4 */
#define _80000000_GPTn_NOISE_FILTERB_PCLKB_16          (0x80000000UL) /* PCLKB/16 */
#define _C0000000_GPTn_NOISE_FILTERB_PCLKB_64          (0xC0000000UL) /* PCLKB/64 */

/*
    General PWM timer Interrupt Output Setting Register (GTINTAD)
*/
/* GTCCRA Compare Match/input capture Interrupt Enable (GTINTA) */
#define _00000000_GPTn_GTCIA_INTERRUPT_DISABLE         (0x00000000UL) /* Interrupt request is disabled */
#define _00000001_GPTn_GTCIA_INTERRUPT_ENABLE          (0x00000001UL) /* Interrupt request is enabled */
/* GTCCRB Compare Match/input capture Interrupt Enable (GTINTB) */
#define _00000000_GPTn_GTCIB_INTERRUPT_DISABLE         (0x00000000UL) /* Interrupt request is disabled */
#define _00000002_GPTn_GTCIB_INTERRUPT_ENABLE          (0x00000002UL) /* Interrupt request is enabled */
/* GTCCRC Compare Match/input capture Interrupt Enable (GTINTC) */
#define _00000000_GPTn_GTCIC_INTERRUPT_DISABLE         (0x00000000UL) /* Interrupt request is disabled */
#define _00000004_GPTn_GTCIC_INTERRUPT_ENABLE          (0x00000004UL) /* Interrupt request is enabled */
/* GTCCRD Compare Match/input capture Interrupt Enable (GTINTD) */
#define _00000000_GPTn_GTCID_INTERRUPT_DISABLE         (0x00000000UL) /* Interrupt request is disabled */
#define _00000008_GPTn_GTCID_INTERRUPT_ENABLE          (0x00000008UL) /* Interrupt request is enabled */
/* GTCCRE Compare Match/input capture Interrupt Enable (GTINTE) */
#define _00000000_GPTn_GTCIE_INTERRUPT_DISABLE         (0x00000000UL) /* Interrupt request is disabled */
#define _00000010_GPTn_GTCIE_INTERRUPT_ENABLE          (0x00000010UL) /* Interrupt request is enabled */
/* GTCCRF Compare Match/input capture Interrupt Enable (GTINTF) */
#define _00000000_GPTn_GTCIF_INTERRUPT_DISABLE         (0x00000000UL) /* Interrupt request is disabled */
#define _00000020_GPTn_GTCIF_INTERRUPT_ENABLE          (0x00000020UL) /* Interrupt request is enabled */
/* GTPR Compare Match Interrupt Enable (GTINTPR[1:0]) */
#define _00000000_GPTn_GTCIV_INTERRUPT_DISABLE         (0x00000000UL) /* Interrupt request is disabled */
#define _00000040_GPTn_GTCIV_INTERRUPT_ENABLE          (0x00000040UL) /* Interrupt request is enabled */
#define _00000000_GPTn_GTCIU_INTERRUPT_DISABLE         (0x00000000UL) /* Interrupt request is disabled */
#define _00000080_GPTn_GTCIU_INTERRUPT_ENABLE          (0x00000080UL) /* Interrupt request is enabled */
/* GTADTRA Compare Match (Up-counting) A/D Converter start Request Enable (ADTRAUEN) */
#define _00000000_GPTn_ADTRA_UPCOUNTING_DISABLE        (0x00000000UL) /* A/D start request is disabled */
#define _00010000_GPTn_ADTRA_UPCOUNTING_ENABLE         (0x00010000UL) /* A/D start request is enabled */
/* GTADTRA Compare Match (Down-counting) A/D Converter start Request Enable (ADTRADEN) */
#define _00000000_GPTn_ADTRA_DOWNCOUNTING_DISABLE      (0x00000000UL) /* A/D start request is disabled */
#define _00020000_GPTn_ADTRA_DOWNCOUNTING_ENABLE       (0x00020000UL) /* A/D start request is enabled */
/* GTADTRB Compare Match (Up-counting) A/D Converter start Request Enable (ADTRBUEN) */
#define _00000000_GPTn_ADTRB_UPCOUNTING_DISABLE        (0x00000000UL) /* A/D start request is disabled */
#define _00040000_GPTn_ADTRB_UPCOUNTING_ENABLE         (0x00040000UL) /* A/D start request is enabled */
/* GTADTRB Compare Match (Down-counting) A/D Converter start Request Enable (ADTRBDEN) */
#define _00000000_GPTn_ADTRB_DOWNCOUNTING_DISABLE      (0x00000000UL) /* A/D start request is disabled */
#define _00080000_GPTn_ADTRB_DOWNCOUNTING_ENABLE       (0x00080000UL) /* A/D start request is enabled */
/* Dead Time Error Output Stop Detection Enable (GRPDTE) */
#define _00000000_GPTn_DEADTIME_OUTPUT_STOP_DISABLE    (0x00000000UL) /* Dead time error output stop detection
                                                                         disabled */
#define _10000000_GPTn_DEADTIME_OUTPUT_STOP_ENABLE     (0x10000000UL) /* Dead time error output stop detection
                                                                         enabled */
/* Simultaneous High Output Stop Detection Enable (GRPABH) */
#define _00000000_GPTn_SIMHIGH_OUTPUT_STOP_DISABLE     (0x00000000UL) /* Simultaneous high output stop detection
                                                                         disabled*/
#define _20000000_GPTn_SIMHIGH_OUTPUT_STOP_ENABLE      (0x20000000UL) /* Simultaneous high output stop detection
                                                                         enabled */
/* Simultaneous Low Output Stop Detection Enable (GRPABL) */
#define _00000000_GPTn_SIMLOW_OUTPUT_STOP_DISABLE      (0x00000000UL) /* Simultaneous low output stop detection
                                                                         disabled */
#define _40000000_GPTn_SIMLOW_OUTPUT_STOP_ENABLE       (0x40000000UL) /* Simultaneous low output stop detection
                                                                         enabled */

/*
    General PWM timer Buffer Enable Register (GTBER)
*/
/* GTCCRA/GTCCRB Registers Buffer Operation Disable (BD[0]) */
#define _00000000_GPTn_GTCCR_BUF_OP_ENABLE             (0x00000000UL) /* Buffer operation is enabled */
#define _00000001_GPTn_GTCCR_BUF_OP_DISABLE            (0x00000001UL) /* Buffer operation is disabled */
/* GTPR Register Buffer Operation Disable (BD[1]) */
#define _00000000_GPTn_GTPR_BUF_OP_ENABLE              (0x00000000UL) /* Buffer operation is enabled */
#define _00000002_GPTn_GTPR_BUF_OP_DISABLE             (0x00000002UL) /* Buffer operation is disabled */
/* GTADTRA/GTADTRB Registers Buffer Operation Disable (BD[2]) */
#define _00000000_GPTn_GTADTR_BUF_OP_ENABLE            (0x00000000UL) /* Buffer operation is enabled */
#define _00000004_GPTn_GTADTR_BUF_OP_DISABLE           (0x00000004UL) /* Buffer operation is disabled */
/* GTDVU/GTDVD Registers Buffer Operation Disable (BD[3]) */
#define _00000000_GPTn_GTDV_BUF_OP_ENABLE              (0x00000000UL) /* Buffer operation is enabled */
#define _00000008_GPTn_GTDV_BUF_OP_DISABLE             (0x00000008UL) /* Buffer operation is disabled */
/* GTCCRA Register Double Buffer Repeat Operation Enable (DBRTECA) */
#define _00000000_GPTn_GTCCRA_DOUBLEBUF_REPEAT_DISABLE (0x00000000UL) /* Double buffer repeat operation is disabled */
#define _00000100_GPTn_GTCCRA_DOUBLEBUF_REPEAT_ENABLE  (0x00000100UL) /* Double buffer repeat operation is enabled */
/* GTCCRA Register Double Buffer Repeat Operation Period Select (DBRTSCA) */
#define _00000000_GPTn_GTCCRA_DB_REPEAT_TROUGH         (0x00000000UL) /* Double buffer repeat with trough as cycle */
#define _00000200_GPTn_GTCCRA_DB_REPEAT_CREST          (0x00000200UL) /* Double buffer repeat with crest as cycle */
/* GTCCRB Register Double Buffer Repeat Operation Enable (DBRTECB) */
#define _00000000_GPTn_GTCCRB_DOUBLEBUF_REPEAT_DISABLE (0x00000000UL) /* Double buffer repeat operation is disabled */
#define _00000400_GPTn_GTCCRB_DOUBLEBUF_REPEAT_ENABLE  (0x00000400UL) /* Double buffer repeat operation is enabled */
/* GTCCRB Register Double Buffer Repeat Operation Period Select (DBRTSCB) */
#define _00000000_GPTn_GTCCRB_DB_REPEAT_TROUGH         (0x00000000UL) /* Double buffer repeat with trough as cycle */
#define _00000800_GPTn_GTCCRB_DB_REPEAT_CREST          (0x00000800UL) /* Double buffer repeat with crest as cycle */
/* GTADTRA Register Double Buffer Repeat Operation Enable (DBRTEADA) */
#define _00000000_GPTn_GTADTRA_DB_REPEAT_DISABLE       (0x00000000UL) /* Double buffer repeat operation is disabled */
#define _00001000_GPTn_GTADTRA_DB_REPEAT_ENABLE        (0x00001000UL) /* Double buffer repeat operation is enabled */
/* GTADTRA Register Double Buffer Repeat Operation Period Select (DBRTSADA) */
#define _00000000_GPTn_GTADTRA_DB_REPEAT_TROUGH        (0x00000000UL) /* Double buffer repeat with trough as cycle */
#define _00002000_GPTn_GTADTRA_DB_REPEAT_CREST         (0x00002000UL) /* Double buffer repeat with crest as cycle */
/* GTADTRB Register Double Buffer Repeat Operation Enable (DBRTEADB) */
#define _00000000_GPTn_GTADTRB_DB_REPEAT_DISABLE       (0x00000000UL) /* Double buffer repeat operation is disabled */
#define _00004000_GPTn_GTADTRB_DB_REPEAT_ENABLE        (0x00004000UL) /* Double buffer repeat operation is enabled */
/* GTADTRB Register Double Buffer Repeat Operation Period Select (DBRTSADB) */
#define _00000000_GPTn_GTADTRB_DB_REPEAT_TROUGH        (0x00000000UL) /* Double buffer repeat with trough as cycle */
#define _00008000_GPTn_GTADTRB_DB_REPEAT_CREST         (0x00008000UL) /* Double buffer repeat with crest as cycle */
/* GTCCRA Buffer Operation (CCRA[1:0]) */
#define _00000000_GPTn_GTCCRA_BUF_NONE                 (0x00000000UL) /* Buffer operation is not performed */
#define _00010000_GPTn_GTCCRA_BUF_SINGLE               (0x00010000UL) /* Single buffer operation */
#define _00020000_GPTn_GTCCRA_BUF_DOUBLE               (0x00020000UL) /* Double buffer operation */
/* GTCCRB Buffer Operation (CCRB[1:0]) */
#define _00000000_GPTn_GTCCRB_BUF_NONE                 (0x00000000UL) /* Buffer operation is not performed */
#define _00040000_GPTn_GTCCRB_BUF_SINGLE               (0x00040000UL) /* Single buffer operation */
#define _00080000_GPTn_GTCCRB_BUF_DOUBLE               (0x00080000UL) /* Double buffer operation */
/* GTPR Buffer Operation (PR[1:0]) */
#define _00000000_GPTn_GTPR_BUF_NONE                   (0x00000000UL) /* Buffer operation is not performed */
#define _00100000_GPTn_GTPR_BUF_SINGLE                 (0x00100000UL) /* Single buffer operation */
#define _00200000_GPTn_GTPR_BUF_DOUBLE                 (0x00200000UL) /* Double buffer operation */
/* GTCCRA and GTCCRB Forcible Buffer Operation (CCRSWT) */
#define _00000000_GPTn_GTCCR_BUF_TRANS_NORMAL          (0x00000000UL) /* Not forcibly perform buffer transfer */
#define _00400000_GPTn_GTCCR_BUF_TRANS_FORCE           (0x00400000UL) /* Forcibly perform buffer transfer */
/* GTADTRA Buffer Transfer Timing Select ADTTA[1:0] */
#define _00000000_GPTn_GTADTRA_BUF_TRANS_NONE          (0x00000000UL) /* No transfer */
#define _01000000_GPTn_GTADTRA_BUF_TRANS_OVRF_UDRF     (0x01000000UL) /* Transfer at overflow and underflow */
#define _01000000_GPTn_GTADTRA_BUF_TRANS_CREST         (0x01000000UL) /* Transfer at crest */
#define _02000000_GPTn_GTADTRA_BUF_TRANS_TROUGH        (0x02000000UL) /* Transfer at trough */
#define _03000000_GPTn_GTADTRA_BUF_TRANS_BOTH          (0x03000000UL) /* Transfer at both crest and trough */
/* GTADTRA Double Buffer Operation (ADTDA) */
#define _00000000_GPTn_GTADTRA_BUF_SINGLE              (0x00000000UL) /* Single buffer operation */
#define _04000000_GPTn_GTADTRA_BUF_DOUBLE              (0x04000000UL) /* Double buffer operation */
/* GTADTRB Buffer Transfer Timing Select ADTTB[1:0] */
#define _00000000_GPTn_GTADTRB_BUF_TRANS_NONE          (0x00000000UL) /* No transfer */
#define _10000000_GPTn_GTADTRB_BUF_TRANS_OVRF_UDRF     (0x10000000UL) /* Transfer at overflow and underflow */
#define _10000000_GPTn_GTADTRB_BUF_TRANS_CREST         (0x10000000UL) /* Transfer at crest */
#define _20000000_GPTn_GTADTRB_BUF_TRANS_TROUGH        (0x20000000UL) /* Transfer at trough */
#define _30000000_GPTn_GTADTRB_BUF_TRANS_BOTH          (0x30000000UL) /* Transfer at both crest and trough */
/* GTADTRB Double Buffer Operation (ADTDB) */
#define _00000000_GPTn_GTADTRB_BUF_SINGLE              (0x00000000UL) /* Single buffer operation */
#define _40000000_GPTn_GTADTRB_BUF_DOUBLE              (0x40000000UL) /* Double buffer operation */

/*
    General PWM timer Interrupt and A/D Converter start Request Skipping Setting Register (GTITC)
*/
/* GTCCRA Compare Match/input capture Interrupt Link (ITLA) */
#define _00000000_GPTn_GTCIA_INT_SKIP_DISABLE          (0x00000000UL) /* No skipping */
#define _00000001_GPTn_GTCIA_INT_SKIP_ENABLE           (0x00000001UL) /* Linked with GTCIV/GTCIU skipping */
/* GTCCRB Compare Match/input capture Interrupt Link (ITLB) */
#define _00000000_GPTn_GTCIB_INT_SKIP_DISABLE          (0x00000000UL) /* No skipping */
#define _00000002_GPTn_GTCIB_INT_SKIP_ENABLE           (0x00000002UL) /* Linked with GTCIV/GTCIU skipping */
/* GTCCRC Compare Match/input capture Interrupt Link (ITLC) */
#define _00000000_GPTn_GTCIC_INT_SKIP_DISABLE          (0x00000000UL) /* No skipping */
#define _00000004_GPTn_GTCIC_INT_SKIP_ENABLE           (0x00000004UL) /* Linked with GTCIV/GTCIU skipping */
/* GTCCRD Compare Match/input capture Interrupt Link (ITLD) */
#define _00000000_GPTn_GTCID_INT_SKIP_DISABLE          (0x00000000UL) /* No skipping */
#define _00000008_GPTn_GTCID_INT_SKIP_ENABLE           (0x00000008UL) /* Linked with GTCIV/GTCIU skipping */
/* GTCCRE Compare Match/input capture Interrupt Link (ITLE) */
#define _00000000_GPTn_GTCIE_INT_SKIP_DISABLE          (0x00000000UL) /* No skipping */
#define _00000010_GPTn_GTCIE_INT_SKIP_ENABLE           (0x00000010UL) /* Linked with GTCIV/GTCIU skipping */
/* GTCCRF Compare Match/input capture Interrupt Link (ITLF) */
#define _00000000_GPTn_GTCIF_INT_SKIP_DISABLE          (0x00000000UL) /* No skipping */
#define _00000020_GPTn_GTCIF_INT_SKIP_ENABLE           (0x00000020UL) /* Linked with GTCIV/GTCIU skipping */
/* GTCIV/GTCIU Interrupt Skipping Function Select (IVTC[1:0]) */
#define _00000000_GPTn_GTCI_SKIP_DISABLE               (0x00000000UL) /* Skipping is not performed */
#define _00000040_GPTn_GTCI_SKIP_OVRF_UDRF             (0x00000040UL) /* Skipping at overflow and underflow */
#define _00000040_GPTn_GTCI_SKIP_CREST                 (0x00000040UL) /* Skipping at crest */
#define _00000080_GPTn_GTCI_SKIP_TROUGH                (0x00000080UL) /* Skipping at trough */
#define _000000C0_GPTn_GTCI_SKIP_BOTH                  (0x000000C0UL) /* Skipping at both crest and trough */
/* GTCIV/GTCIU Interrupt Skipping count Select (IVTT[2:0]) */
#define _00000000_GPTn_GTCI_SKIPPING_COUNT_0           (0x00000000UL) /* Skipping is not performed */
#define _00000100_GPTn_GTCI_SKIP_COUNT_1               (0x00000100UL) /* Skipping count of 1 */
#define _00000200_GPTn_GTCI_SKIP_COUNT_2               (0x00000200UL) /* Skipping count of 2 */
#define _00000300_GPTn_GTCI_SKIP_COUNT_3               (0x00000300UL) /* Skipping count of 3 */
#define _00000400_GPTn_GTCI_SKIP_COUNT_4               (0x00000400UL) /* Skipping count of 4 */
#define _00000500_GPTn_GTCI_SKIP_COUNT_5               (0x00000500UL) /* Skipping count of 5 */
#define _00000600_GPTn_GTCI_SKIP_COUNT_6               (0x00000600UL) /* Skipping count of 6 */
#define _00000700_GPTn_GTCI_SKIP_COUNT_7               (0x00000700UL) /* Skipping count of 7 */
/* GTADTRA A/D Converter start Request Link (ADTAL) */
#define _00000000_GPTn_ADTRA_REQ_SKIP_DISABLE          (0x00000000UL) /* No skipping */
#define _00001000_GPTn_ADTRA_REQ_SKIP_ENABLE           (0x00001000UL) /* Linked with GTCIV/GTCIU skipping */
/* GTADTRB A/D Converter start Request Link (ADTBL) */
#define _00000000_GPTn_ADTRB_REQ_SKIP_DISABLE          (0x00000000UL) /* No skipping */
#define _00004000_GPTn_ADTRB_REQ_SKIP_ENABLE           (0x00004000UL) /* Linked with GTCIV/GTCIU skipping */

/*
    General PWM timer Dead Time Control Register (GTDTCR)
*/
/* Negative-Phase Waveform Setting (TDE) */
#define _00000000_GPTn_DEAD_TIME_DISABLE               (0x00000000UL) /* GTCCRB is set without dead time */
#define _00000001_GPTn_DEAD_TIME_ENABLE                (0x00000001UL) /* GTCCRB is auto-set with dead time */
/* GTDVU Buffer Operation Enable (TDBUE) */
#define _00000000_GPTn_GTDVU_BUF_DISABLE               (0x00000000UL) /* GTDVU buffer operation is disabled */
#define _00000010_GPTn_GTDVU_BUF_ENABLE                (0x00000010UL) /* GTDVU buffer operation is enabled */
/* GTDVD Buffer Operation Enable (TDBDE) */
#define _00000000_GPTn_GTDVD_BUF_DISABLE               (0x00000000UL) /* GTDVD buffer operation is disabled */
#define _00000020_GPTn_GTDVD_BUF_ENABLE                (0x00000020UL) /* GTDVD buffer operation is enabled */
/* GTDVD Setting (TDFER) */
#define _00000000_GPTn_GTDVD_VALUE_SEPARATE            (0x00000000UL) /* GTDVU and GTDVD are set separately */
#define _00000100_GPTn_GTDVD_VALUE_AUTO                (0x00000100UL) /* GTDVU value is auto-set to GTDVD */

/*
    General PWM Timer A/D Converter Start Request Signal Monitoring Register (GTADSMR)
*/
/* A/D Conversion Start Request Signal Monitor 0 Selection (ADSMS0[1:0]) */
#define _00000000_GPTn_GTADTRA_UP_COUNTING             (0x00000000UL) /* A/D conversion start request signal generated
                                                                         by the GTADTRA during up-counting */
#define _00000001_GPTn_GTADTRA_DOWN_COUNTING           (0x00000001UL) /* A/D conversion start request signal generated
                                                                         by the GTADTRA during down-counting */
#define _00000002_GPTn_GTADTRB_UP_COUNTING             (0x00000002UL) /* A/D conversion start request signal generated
                                                                         by the GTADTRB during up-counting */
#define _00000003_GPTn_GTADTRB_DOWN_COUNTING           (0x00000003UL) /* A/D conversion start request signal generated
                                                                         by the GTADTRB during down-counting */
/* A/D Conversion Start Request Signal Monitor 0 Output Enabling (ADSMEN0) */
#define _00000000_GPTn_AD_START_MONITOR0_DISABLE       (0x00000000UL) /* Output of A/D conversion start request
                                                                         signal monitor 0 is disabled */
#define _00000100_GPTn_AD_START_MONITOR0_ENABLE        (0x00000100UL) /* Output of A/D conversion start request
                                                                         signal monitor 0 is enabled */
/* A/D Conversion Start Request Signal Monitor 1 Selection (ADSMS1[1:0]) */
#define _00010000_GPTn_GTADTRA_DOWN_COUNTING           (0x00010000UL) /* A/D conversion start request signal generated
                                                                         by the GTADTRA during down-counting */
#define _00020000_GPTn_GTADTRB_UP_COUNTING             (0x00020000UL) /* A/D conversion start request signal generated
                                                                         by the GTADTRB during up-counting */
#define _00030000_GPTn_GTADTRB_DOWN_COUNTING           (0x00030000UL) /* A/D conversion start request signal generated
                                                                         by the GTADTRB during down-counting */
/* A/D Conversion Start Request Signal Monitor 1 Output Enabling (ADSMEN1) */
#define _00000000_GPTn_AD_START_MONITOR1_DISABLE       (0x00000000UL) /* Output of A/D conversion start request
                                                                         signal monitor 1 is disabled */
#define _01000000_GPTn_AD_START_MONITOR1_ENABLE        (0x01000000UL) /* Output of A/D conversion start request
                                                                         signal monitor 1 is enabled */

/*
    General PWM Timer Period Count Register (GTPC)
*/
/* Automatic Stop Function Enable (ASTP) */
#define _00000000_GPTn_AUTO_STOP_DISABLE               (0x00000000UL) /* Automatic function is disabled */
#define _00000100_GPTn_AUTO_STOP_ENABLE                (0x00000100UL) /* Automatic function is enabled */

/*
    General PWM Timer Buffer Enable Register 2 (GTBER2)
*/
/* Complementary PWM Mode 3,4 Double Buffer Select (CP3DB) */
#define _00000000_GPTn_DOUBLEBUF_DISABLE               (0x00000000UL) /* Disable double buffer function */
#define _01000000_GPTn_DOUBLEBUF_ENABLE                (0x01000000UL) /* Enable double buffer function */
/* GTIOCnA Output Level Buffer Transfer Timing Select (OLTTA[1:0]) */
#define _00000000_GPTn_GTIOCA_BUF_TRANS_NONE           (0x00000000UL) /* No transfer */
#define _04000000_GPTn_GTIOCA_BUF_TRANS_CREST          (0x04000000UL) /* Transfer at crest */
#define _08000000_GPTn_GTIOCA_BUF_TRANS_TROUGH         (0x08000000UL) /* Transfer at trough */
#define _0C000000_GPTn_GTIOCA_BUF_TRANS_BOTH           (0x0C000000UL) /* Transfer at both crest and trough */
/* GTIOCnB Output Level Buffer Transfer Timing Select (OLTTB[1:0]) */
#define _00000000_GPTn_GTIOCB_BUF_TRANS_NONE           (0x00000000UL) /* No transfer */
#define _10000000_GPTn_GTIOCB_BUF_TRANS_CREST          (0x10000000UL) /* Transfer at crest */
#define _20000000_GPTn_GTIOCB_BUF_TRANS_TROUGH         (0x20000000UL) /* Transfer at trough */
#define _30000000_GPTn_GTIOCB_BUF_TRANS_BOTH           (0x30000000UL) /* Transfer at both crest and trough */

/*
    General PWM Timer Inter Channel Cooperation Input Capture Control Register (GTICCR)
*/
/* Enable GTCCRA Register Compare Match/Input Capture as Source of Other Channel GTCCRA Input Capture (ICAFA) */
#define _00000000_GPTn_ICAFA_DISABLE                   (0x00000000UL) /* Disable */
#define _00000001_GPTn_ICAFA_ENABLE                    (0x00000001UL) /* Enable */
/* Enable GTCCRB Register Compare Match/Input Capture as Source of Other Channel GTCCRA Input Capture (ICAFB) */
#define _00000000_GPTn_ICAFB_DISABLE                   (0x00000000UL) /* Disable */
#define _00000002_GPTn_ICAFB_ENABLE                    (0x00000002UL) /* Enable */
/* Enable GTCCRC Register Compare Match/Input Capture as Source of Other Channel GTCCRA Input Capture (ICAFC) */
#define _00000000_GPTn_ICAFC_DISABLE                   (0x00000000UL) /* Disable */
#define _00000004_GPTn_ICAFC_ENABLE                    (0x00000004UL) /* Enable */
/* Enable GTCCRD Register Compare Match/Input Capture as Source of Other Channel GTCCRA Input Capture (ICAFD) */
#define _00000000_GPTn_ICAFD_DISABLE                   (0x00000000UL) /* Disable */
#define _00000008_GPTn_ICAFD_ENABLE                    (0x00000008UL) /* Enable */
/* Enable GTCCRE Register Compare Match/Input Capture as Source of Other Channel GTCCRA Input Capture (ICAFE) */
#define _00000000_GPTn_ICAFE_DISABLE                   (0x00000000UL) /* Disable */
#define _00000010_GPTn_ICAFE_ENABLE                    (0x00000010UL) /* Enable */
/* Enable GTCCRF Register Compare Match/Input Capture as Source of Other Channel GTCCRA Input Capture (ICAFF) */
#define _00000000_GPTn_ICAFF_DISABLE                   (0x00000000UL) /* Disable */
#define _00000020_GPTn_ICAFF_ENABLE                    (0x00000020UL) /* Enable */
/* Enable Overflow as Source of Other Channel GTCCRA Input Capture (ICAFPO) */
#define _00000000_GPTn_ICAFPO_DISABLE                  (0x00000000UL) /* Disable */
#define _00000040_GPTn_ICAFPO_ENABLE                   (0x00000040UL) /* Enable */
/* Enable Underflow as Source of Other Channel GTCCRA Input Capture (ICAFPU) */
#define _00000000_GPTn_ICAFPU_DISABLE                  (0x00000000UL) /* Disable */
#define _00000080_GPTn_ICAFPU_ENABLE                   (0x00000080UL) /* Enable */
/* Enable Count Clock as Source of Other Channel GTCCRA Input Capture (ICACLK) */
#define _00000000_GPTn_ICACLK_DISABLE                  (0x00000000UL) /* Disable */
#define _00000100_GPTn_ICACLK_ENABLE                   (0x00000100UL) /* Enable */
/* GTCCRA Input Capture Group Select (ICAGRP[1:0]) */
#define _00000000_GPTn_GTCCRA_INPUT_GROUPA             (0x00000000UL) /* Group A */
#define _00004000_GPTn_GTCCRA_INPUT_GROUPB             (0x00004000UL) /* Group B */
#define _00008000_GPTn_GTCCRA_INPUT_GROUPC             (0x00008000UL) /* Group C */
#define _0000C000_GPTn_GTCCRA_INPUT_GROUPD             (0x0000C000UL) /* Group D */
/* Enable GTCCRA Register Compare Match/Input Capture as Source of Other Channel GTCCRB Input Capture (ICBFA) */
#define _00000000_GPTn_ICBFA_DISABLE                   (0x00000000UL) /* Disable */
#define _00010000_GPTn_ICBFA_ENABLE                    (0x00010000UL) /* Enable */
/* Enable GTCCRB Register Compare Match/Input Capture as Source of Other Channel GTCCRB Input Capture (ICBFB) */
#define _00000000_GPTn_ICBFB_DISABLE                   (0x00000000UL) /* Disable */
#define _00020000_GPTn_ICBFB_ENABLE                    (0x00020000UL) /* Enable */
/* Enable GTCCRC Register Compare Match/Input Capture as Source of Other Channel GTCCRB Input Capture (ICBFC) */
#define _00000000_GPTn_ICBFC_DISABLE                   (0x00000000UL) /* Disable */
#define _00040000_GPTn_ICBFC_ENABLE                    (0x00040000UL) /* Enable */
/* Enable GTCCRD Register Compare Match/Input Capture as Source of Other Channel GTCCRB Input Capture (ICBFD) */
#define _00000000_GPTn_ICBFD_DISABLE                   (0x00000000UL) /* Disable */
#define _00080000_GPTn_ICBFD_ENABLE                    (0x00080000UL) /* Enable */
/* Enable GTCCRE Register Compare Match/Input Capture as Source of Other Channel GTCCRB Input Capture (ICBFE) */
#define _00000000_GPTn_ICBFE_DISABLE                   (0x00000000UL) /* Disable */
#define _00100000_GPTn_ICBFE_ENABLE                    (0x00100000UL) /* Enable */
/* Enable GTCCRF Register Compare Match/Input Capture as Source of Other Channel GTCCRB Input Capture (ICBFF) */
#define _00000000_GPTn_ICBFF_DISABLE                   (0x00000000UL) /* Disable */
#define _00200000_GPTn_ICBFF_ENABLE                    (0x00200000UL) /* Enable */
/* Enable Overflow as Source of Other Channel GTCCRB Input Capture (ICBFPO) */
#define _00000000_GPTn_ICBFPO_DISABLE                  (0x00000000UL) /* Disable */
#define _00400000_GPTn_ICBFPO_ENABLE                   (0x00400000UL) /* Enable */
/* Enable Underflow as Source of Other Channel GTCCRB Input Capture (ICBFPU) */
#define _00000000_GPTn_ICBFPU_DISABLE                  (0x00000000UL) /* Disable */
#define _00800000_GPTn_ICBFPU_ENABLE                   (0x00800000UL) /* Enable */
/* Enable Count Clock as Source of Other Channel GTCCRB Input Capture (ICBCLK) */
#define _00000000_GPTn_ICBCLK_DISABLE                  (0x00000000UL) /* Disable */
#define _01000000_GPTn_ICBCLK_ENABLE                   (0x01000000UL) /* Enable */
/* GTCCRB Input Capture Group Select (ICBGRP[1:0]) */
#define _00000000_GPTn_GTCCRB_INPUT_GROUPA             (0x00000000UL) /* Group A */
#define _40000000_GPTn_GTCCRB_INPUT_GROUPB             (0x40000000UL) /* Group B */
#define _80000000_GPTn_GTCCRB_INPUT_GROUPC             (0x80000000UL) /* Group C */
#define _C0000000_GPTn_GTCCRB_INPUT_GROUPD             (0xC0000000UL) /* Group D */
/*
    Interrupt source Priority Register n (IPRn)
*/
/* Interrupt Priority Level Select (IPR[3:0]) */
#define _00_GPT_PRIORITY_LEVEL0                        (0x00U) /* Level 0 (interrupt disabled) */
#define _01_GPT_PRIORITY_LEVEL1                        (0x01U) /* Level 1 */
#define _02_GPT_PRIORITY_LEVEL2                        (0x02U) /* Level 2 */
#define _03_GPT_PRIORITY_LEVEL3                        (0x03U) /* Level 3 */
#define _04_GPT_PRIORITY_LEVEL4                        (0x04U) /* Level 4 */
#define _05_GPT_PRIORITY_LEVEL5                        (0x05U) /* Level 5 */
#define _06_GPT_PRIORITY_LEVEL6                        (0x06U) /* Level 6 */
#define _07_GPT_PRIORITY_LEVEL7                        (0x07U) /* Level 7 */
#define _08_GPT_PRIORITY_LEVEL8                        (0x08U) /* Level 8 */
#define _09_GPT_PRIORITY_LEVEL9                        (0x09U) /* Level 9 */
#define _0A_GPT_PRIORITY_LEVEL10                       (0x0AU) /* Level 10 */
#define _0B_GPT_PRIORITY_LEVEL11                       (0x0BU) /* Level 11 */
#define _0C_GPT_PRIORITY_LEVEL12                       (0x0CU) /* Level 12 */
#define _0D_GPT_PRIORITY_LEVEL13                       (0x0DU) /* Level 13 */
#define _0E_GPT_PRIORITY_LEVEL14                       (0x0EU) /* Level 14 */
#define _0F_GPT_PRIORITY_LEVEL15                       (0x0FU) /* Level 15 (highest) */

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
/* Start user code for function. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#endif
