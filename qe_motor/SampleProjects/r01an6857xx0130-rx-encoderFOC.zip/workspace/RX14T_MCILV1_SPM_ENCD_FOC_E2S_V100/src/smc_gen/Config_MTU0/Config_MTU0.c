/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_MTU0.c
* Component Version: 1.12.0
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_MTU0.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_MTU0.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_MTU0_Create
* Description  : This function initializes the MTU0 channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU0_Create(void)
{
    /* Release MTU channel 0 from stop state */
    MSTP(MTU3) = 0U;

    /* Stop MTU channel 0 counter */
    MTU.TSTRA.BIT.CST0 = 0U;

    /* Set A/D conversion signal output for ADSM0, ADSM1 pins */
    MTU.TADSTRGR0.BYTE = _00_MTU_TADSMEN_DISABLE;
    MTU.TADSTRGR1.BYTE = _00_MTU_TADSMEN_DISABLE;

    /* Set TGIA/TGIB/TGIC/TGID interrupt priority level */
    IPR(MTU0, TGIA0) = _0D_MTU_PRIORITY_LEVEL13;

    /* MTU channel 0 is used as normal mode */
    MTU.TSYRA.BIT.SYNC0 = 0U;
    MTU0.TCR.BYTE = _00_MTU_PCLK_1 | _00_MTU_CKCL_DIS;
    MTU0.TCR2.BYTE = _00_MTU_PCLK_1;
    MTU0.TIER.BYTE = _00_MTU_TGIEA_DISABLE | _02_MTU_TGIEB_ENABLE | _00_MTU_TGIEC_DISABLE | _00_MTU_TGIED_DISABLE | 
                     _00_MTU_TCIEV_DISABLE | _00_MTU_TTGE_DISABLE;
    MTU0.TIER2.BYTE = _00_MTU_TGIEE_DISABLE | _00_MTU_TGIEF_DISABLE | _00_MTU_TTGE2_DISABLE;
    MTU0.TIORH.BYTE = _00_MTU_IOA_DISABLE | _C0_MTU_IOB_EX;
    MTU0.TIORL.BYTE = _00_MTU_IOC_DISABLE | _00_MTU_IOD_DISABLE;
    MTU0.TMDR1.BYTE = _00_MTU_NORMAL;
    MTU0.TGRA = _12BF_TGRA0_VALUE;
    MTU0.TGRC = _12BF_TGRC0_VALUE;
    MTU0.TGRD = _12BF_TGRD0_VALUE;
    MTU0.TGRE = _12BF_TGRE0_VALUE;
    MTU0.TGRF = _12BF_TGRF0_VALUE;

    R_Config_MTU0_Create_UserInit();
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU0_Start
* Description  : This function starts the MTU0 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU0_Start(void)
{
    /* Enable TGIB0 interrupt in ICU */
    IEN(MTU0, TGIB0) = 1U;
    
    /* Start MTU channel 0 counter */
    MTU.TSTRA.BIT.CST0 = 1U;
}

/***********************************************************************************************************************
* Function Name: R_Config_MTU0_Stop
* Description  : This function stops the MTU0 channel counter
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU0_Stop(void)
{
    /* Disable TGIB0 interrupt in ICU */
    IEN(MTU0, TGIB0) = 0U;
    
    /* Stop MTU channel 0 counter */
    MTU.TSTRA.BIT.CST0 = 0U;
}

/* Start user code for adding. Do not edit comment generated here */
/***********************************************************************************************************************
* Function Name : R_Config_MTU0_InterruptEnable
* Description   : Enables encoder interrupt
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void R_Config_MTU0_InterruptEnable(void)
{
    /* Encoder interrupt enable */
    if(0 == IEN(MTU0, TGIB0))
    {
        R_Config_MTU0_Start();
    }
} /* End of function R_Config_MTU0_InterruptEnable */

/***********************************************************************************************************************
* Function Name : R_Config_MTU0_InterruptDisable
* Description   : Disables encoder interrupt
* Arguments     : u1_id - Motor ID
* Return Value  : None
***********************************************************************************************************************/
void R_Config_MTU0_InterruptDisable(void)
{
      /* Encoder interrupt disable */
    if(1 == IEN(MTU0, TGIB0))
    {
        R_Config_MTU0_Stop();
    }
} /* End of function R_Config_MTU0_InterruptDisable */
/* End user code. Do not edit comment generated here */
