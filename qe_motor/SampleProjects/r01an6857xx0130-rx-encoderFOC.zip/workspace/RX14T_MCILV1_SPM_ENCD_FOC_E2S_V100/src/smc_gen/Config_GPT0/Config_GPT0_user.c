/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_GPT0_user.c
* Component Version: 1.5.2
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_GPT0.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_GPT0.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_GPT0_Create_UserInit
* Description  : This function adds user code after initializing the GPT0 channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_GPT0_Create_UserInit(void)
{
    /* Start user code for user init. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/***********************************************************************************************************************
* Function Name : R_Config_GPT0_TcntGet
* Description   : Get encoder timer count
* Arguments     : None
* Return Value  : Encoder timer count
***********************************************************************************************************************/
uint32_t R_Config_GPT0_TcntGet(void)
{
    uint32_t u4_temp;
    u4_temp = (uint32_t)GPTW0.GTCNT;
    return (u4_temp);
} /* End of function R_Config_GPT0_TcntGet */

/***********************************************************************************************************************
* Function Name : R_Config_GPT0_SpeedCalcTimerStart
* Description   : Starts speed calculation timer
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_Config_GPT0_SpeedCalcTimerStart(void)
{
    GPTW0.GTCLR.LONG = 0x00000008;
    GPTW0.GTCR.BIT.CST = 1;
} /* End of function R_Config_GPT0_SpeedCalcTimerStart */
/* End user code. Do not edit comment generated here */
