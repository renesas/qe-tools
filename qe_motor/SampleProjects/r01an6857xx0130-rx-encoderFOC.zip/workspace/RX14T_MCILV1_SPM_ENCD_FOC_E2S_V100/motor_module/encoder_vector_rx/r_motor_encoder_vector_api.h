/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_encoder_vector_api.h
* Description : Definitions of accessing driver processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_ENCODER_VECTOR_API_H
#define R_MOTOR_ENCODER_VECTOR_API_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_motor_module_cfg.h"
#include "r_motor_encoder_vector_statemachine.h"
#include "r_motor_current_api.h"
#include "r_motor_speed_api.h"
#include "r_motor_position_api.h"
#include "r_motor_sensor_api.h"
#include "r_motor_driver.h"
#include "r_motor_ipd_api.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Control loop mode */
#define     MOTOR_LOOP_POSITION          (0)
#define     MOTOR_LOOP_SPEED             (1)

/* Error status */
#define     MOTOR_ENCODER_VECTOR_ERROR_NONE              (0x0000)
#define     MOTOR_ENCODER_VECTOR_ERROR_OVER_CURRENT_HW   (0x0001)
#define     MOTOR_ENCODER_VECTOR_ERROR_OVER_VOLTAGE      (0x0002)
#define     MOTOR_ENCODER_VECTOR_ERROR_OVER_SPEED        (0x0004)
#define     MOTOR_ENCODER_VECTOR_ERROR_HALL_TIMEOUT      (0x0008)
#define     MOTOR_ENCODER_VECTOR_ERROR_BEMF_TIMEOUT      (0x0010)
#define     MOTOR_ENCODER_VECTOR_ERROR_HALL_PATTERN      (0x0020)
#define     MOTOR_ENCODER_VECTOR_ERROR_BEMF_PATTERN      (0x0040)
#define     MOTOR_ENCODER_VECTOR_ERROR_LOW_VOLTAGE       (0x0080)
#define     MOTOR_ENCODER_VECTOR_ERROR_OVER_CURRENT_SW   (0x0100)
#define     MOTOR_ENCODER_VECTOR_ERROR_UNKNOWN           (0xffff)

/* Angle adjust mode */
#define     MOTOR_ANGLE_ADJ_EXCIT          (0)
#define     MOTOR_ANGLE_ADJ_HALL           (1)

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
/* Control types */
typedef enum
{
    MOTOR_CTRL_TYPE_POS             = 0,
    MOTOR_CTRL_TYPE_SPEED           = 1
} e_mtr_ctrl_type_t;

/***********************************************************************************************************************
* Global structure / type definitions
***********************************************************************************************************************/
typedef struct
{
    uint8_t       u1_state_id_ref;              /* The d-axis current command status */
    uint8_t       u1_state_iq_ref;              /* The q-axis current command status */
    uint8_t       u1_state_speed_ref;           /* The speed command status */
    uint8_t       u1_direction;                 /* Reference rotation direction */
    uint8_t       u1_ctrl_loop_mode;            /* control loop select */
    uint8_t       u1_flag_ipd_use;              /* control method select */
    uint8_t       u1_encd_angle_adj_mode;       /* Encoder angle adjustment mode */
    uint8_t       u1_encd_angle_adj_status;     /* encoder angle adjustment status */
    uint16_t      u2_encd_angle_adj_time;       /* time of encoder angle adjustment */
    uint16_t      u2_encd_angle_adj_cnt;        /* counter of encoder angle adjustment */
    uint16_t      u2_error_status;              /* FOC error flags */
    uint16_t      u2_run_mode;                  /* Run mode */
    uint16_t      u2_encd_cpr;

    float         f4_vdc_ad;                    /* Bus voltage [V] */
    float         f4_iu_ad;                     /* U-phase current value [A] */
    float         f4_iv_ad;                     /* V-phase current value [A] */
    float         f4_iw_ad;                     /* W-phase current value [A] */
    float         f4_overcurrent_limit;         /* Over-current limit [A] */
    float         f4_overvoltage_limit;         /* Over-voltage limit [V] */
    float         f4_undervoltage_limit;        /* Under voltage limit [V]*/
    float         f4_overspeed_limit_rad;       /* motor speed limit [rad/s] */
    float         f4_max_speed_rc_fil_rpm;      /* Maximum speed command value of rc filter [rpm] (mechanical) */
    float         f4_rotor_angle_rad;

    st_current_output_t           st_current_output;
    st_speed_output_t             st_speed_output;
    st_position_output_t          st_position_output;
    st_sensor_encoder_output_t    st_sensor_encoder_output;
    st_sensor_hall_output_t       st_sensor_hall_output;

    /* Sub-modules */
    st_statemachine_t      st_stm;           /* Action structure */
    st_motor_parameter_t   st_motor;         /* Motor parameters structure */

    /* Other-modules */
    st_motor_driver_t       * p_st_driver;
    st_current_control_t    * p_st_cc;             /* Current control structure */
    st_speed_control_t      * p_st_sc;             /* Speed control structure */
    st_position_control_t   * p_st_pc;             /* Position & speed control structure */
    st_sensor_t             * p_st_sensor;         /* Encoder control structure */
    st_ipd_ctrl_t           * p_st_ipd;            /* IPD control structure */
} st_encoder_vector_control_t;

typedef struct
{
    uint8_t                 u1_encd_angle_adj_mode;
    uint16_t                u2_encd_cpr;
    float                   f4_overspeed_limit_rpm;
    st_motor_parameter_t    st_motor;
} st_encoder_vector_cfg_t;

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
extern st_encoder_vector_control_t g_st_encoder_vector;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_Open
* Description   : Open Encoder FOC Control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_Open(void);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_Close
* Description   : Close Encoder FOC Control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_Close(void);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_Reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_Reset(st_encoder_vector_control_t * p_st_encoder_vector);

/**********************************************************************************************************************
 * Function Name: R_MOTOR_ENCODER_VECTOR_ParameterUpdate
 * Description  : Update parameter for Encoder Vector Control
 * Arguments    : p_st_encoder_vector    - The pointer to the motor control management data structure
 *              : p_cfg                  - The pointer to the motor control management config structure
 * Return Value : None
 *********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_ParameterUpdate(st_encoder_vector_control_t * p_st_encoder_vector,
                                            st_encoder_vector_cfg_t * p_cfg);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_MotorStart
* Description   : Start to drive motor
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_MotorStart(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_MotorStop
* Description   : Stop driving motor
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_MotorStop(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_MotorReset
* Description   : Cancel error
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_MotorReset(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_ErrorSet
* Description   : Set error
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_ErrorSet(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_PositionSet
* Description   : Set position reference
* Arguments     : p_st_encoder_vector        - The pointer to the motor control management data structure
*                 f4_ref_position - position reference [degree]
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_PositionSet(st_encoder_vector_control_t * p_st_encoder_vector, float f4_ref_position);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_PositionGet
* Description   : Get position [degree]
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : position [degree]
***********************************************************************************************************************/
float R_MOTOR_ENCODER_VECTOR_PositionGet(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_SpeedSet
* Description   : Set speed reference
* Arguments     : p_st_encoder_vector     - The pointer to the motor control management data structure
*                 f4_ref_speed - speed reference [rpm]
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_SpeedSet(st_encoder_vector_control_t * p_st_encoder_vector, float f4_ref_speed);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_SpeedGet
* Description   : Get speed value
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : speed
***********************************************************************************************************************/
float R_MOTOR_ENCODER_VECTOR_SpeedGet(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_StatusGet
* Description   : Get status of motor control system
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : motor status
***********************************************************************************************************************/
uint8_t R_MOTOR_ENCODER_VECTOR_StatusGet(st_encoder_vector_control_t * p_st_encoder_vector);

/**********************************************************************************************************************
 * Function Name: R_MOTOR_ENCODER_VECTOR_ErrorStatusGet
 * Description  : Get current error status
 * Arguments    : p_st_encoder_vector    - The pointer to the motor control management data structure
 * Return Value : Error status
 *********************************************************************************************************************/
uint16_t R_MOTOR_ENCODER_VECTOR_ErrorStatusGet(st_encoder_vector_control_t * p_st_encoder_vector);

/**********************************************************************************************************************
 * Function Name: R_MOTOR_ENCODER_VECTOR_CtrlTypeSet
 * Description  : Set control type
 * Arguments    : p_st_encoder_vector    - The pointer to the motor control management data structure
 *                ctrl_type -
 *                   The control type that defined in e_mtr_ctrl_type_t
 * Return Value : None
 *********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_CtrlTypeSet(st_encoder_vector_control_t * p_st_encoder_vector, uint8_t ctrl_type);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_LoopModeStatusGet
* Description   : Get loop mode status
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : control loop mode status
***********************************************************************************************************************/
uint8_t R_MOTOR_ENCODER_VECTOR_LoopModeStatusGet(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_PositionCommandModeSet
* Description   : Set position status
* Arguments     : p_st_encoder_vector      - The pointer to the motor control management data structure
*                 u1_position_command_mode - Position command mode to set
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_PositionCommandModeSet(st_encoder_vector_control_t * p_st_encoder_vector,
                                                   uint8_t u1_position_command_mode);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_InPositionFlagGet
* Description   : Get Positioning Flag
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : positioning flag
***********************************************************************************************************************/
uint8_t R_MOTOR_ENCODER_VECTOR_InPositionFlagGet(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_PosSpeedInterrupt
* Description   : 500us interrupt handler of FOC control
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_PosSpeedInterrupt(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_CurrentInterrupt
* Description   : The carrier interrupt handler of FOC control
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_CurrentInterrupt(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_OverCurrentInterrupt
* Description   : POE interrupt handler
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_OverCurrentInterrupt(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_HallInterrupt
* Description   : Hall interrupt handler
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_HallInterrupt(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_EncoderInterrupt
* Description   : Encoder interrupt handler
* Arguments     : p_st_encoder_vector - The pointer to the motor control management data structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_EncoderInterrupt(st_encoder_vector_control_t * p_st_encoder_vector);

/***********************************************************************************************************************
* Function Name : R_MOTOR_ENCODER_VECTOR_IPDEnableSet
* Description   : Set IPD enable state
* Arguments     : p_st_encoder_vector  - The pointer to the motor control management data structure
*               : u1_enable - Whether enable IPD as position control method (0: Disable IPD, 1: Enable IPD)
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_ENCODER_VECTOR_IPDEnableSet(st_encoder_vector_control_t * p_st_encoder_vector, uint8_t u1_enable);

#endif /* R_MOTOR_ENCODER_VECTOR_API_H */
