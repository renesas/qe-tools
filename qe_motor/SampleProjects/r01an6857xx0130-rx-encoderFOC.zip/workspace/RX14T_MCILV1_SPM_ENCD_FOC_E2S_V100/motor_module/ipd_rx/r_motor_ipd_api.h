/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_ipd_api.h
* Description : Definitions of a IPD control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_IPD_API_H
#define R_MOTOR_IPD_API_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_motor_filter.h"
#include "r_motor_common.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
#define    IPD_LPF_OMEGA                        (200.0f)        /* Natural frequency for position LPF */
#define    IPD_LPF_ZETA                         (1.0f)          /* Damping ratio for position LPF */
#define    IPD_SPEED_RATIO                      (2.5f)          /* Speed gain ratio for IPD */
#define    IPD_POS_FF_RATIO                     (0.9f)          /* Position feed-forward ratio */
#define    IPD_POS_KP_RATIO                     (0.3f)          /* Position KP ratio */
#define    IPD_POS_ERR_INPUT_LIMIT              (10.0f)         /* Position error input limit [rad] */
#define    IPD_POS_ERR_INTEGRATOR_LIMIT_RATIO   (1.0f)          /* Position error integrator limit ratio */

/* IPD LPF on/off configure */
#define    IPD_LPF_OFF                          (0)             /* Position LPF OFF */
#define    IPD_LPF_ON                           (1)             /* Position LPF ON */
#define    IPD_LPF_FLAG                         (IPD_LPF_ON)    /* Initial set position LPF ON/OFF */

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    uint8_t  u1_ipd_lpf_flag;              /* 0 : LPF OFF(default) 1 : LPF ON */
    float    f4_ref_pos_pre_rad_ctrl;      /* Previous position value for control [rad] (mechanical) */
    float    f4_ipd_pos_k;                 /* Position control gain for IPD */
    float    f4_ipd_pos_1st_fb_rad;        /* Feed-back position [rad] (mechanical) */
    float    f4_ipd_pos_1st_fb_pre_rad;    /* Previous value of feed-back position [rad] (mechanical) */
    float    f4_ipd_pos_2nd_fb_rad;        /* Feed-back position [rad] (mechanical) */
    float    f4_ipd_ref_pos_rad;           /* IPD control reference [rad] (mechanical) */
    float    f4_ipd_err_rad;               /* IPD control error [rad] (mechanical) */
    float    f4_ipd_pos_fb_k;              /* Feedback gain for IPD */
    float    f4_ipd_pos_ff_rad;            /* Feed-forward position [rad] (mechanical) */
    float    f4_ipd_pos_ff_k;              /* Feed-forward position control gain */
    float    f4_ipd_pos_p_rad;             /* Proportional control [rad] (mechanical) */
    float    f4_ipd_pos_kp;                /* Position control gain Kp */
    float    f4_ipd_pos_kp_ratio;          /* Position control gain Kp ratio */
    float    f4_ipd_pos_ff_ratio;          /* Position feed-forward gain ratio */
    float    f4_ipd_speed_k;               /* Speed gain for IPD */
    float    f4_ipd_speed_k_ratio;         /* Speed gain for IPD gain ratio */
    float    f4_ipd_ref_speed_rad;         /* Reference speed [rad/s] (electrical) */
    float    f4_ipd_err_input_limit;       /* Position error input limit */
    float    f4_ipd_err_integrator_limit;  /* Position error integrator limit ratio */
    float    f4_ipd_lpf_omega;             /* Natural frequency for position LPF */
    float    f4_ipd_lpf_zeta;              /* Damping ratio for position LPF */
    st_2nd_order_lpf_t  st_ipd_2nd_lpf;    /* Second order LPF structure */
} st_ipd_ctrl_t;

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
extern st_ipd_ctrl_t       g_st_ipd;       /* IPD control structure */

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : R_MOTOR_IPD_Open
* Description   : Open IPD control module
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_IPD_Open(void);

/***********************************************************************************************************************
* Function Name : R_MOTOR_IPD_Close
* Description   : Close IPD control module
* Arguments     : none
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_IPD_Close(void);

/***********************************************************************************************************************
* Function Name : R_MOTOR_IPD_Reset
* Description   : Reset variables when IPD control
* Arguments     : p_st_ipd_ctrl         - The pointer to the IPD control structure
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_IPD_Reset(st_ipd_ctrl_t * p_st_ipd_ctrl);

/***********************************************************************************************************************
* Function Name : R_MOTOR_IPD_ParameterUpdate
* Description   : Set the IPD control parameter
* Arguments     : p_st_ipd_ctrl               - The pointer to the IPD control structure
*                 f4_ipd_pos_kp_ratio         - position control gain kp ratio
*                 f4_ipd_pos_ff_ratio         - position feed-forward gain ratio
*                 f4_ipd_speed_k_ratio        - speed gain for I-PD gain ratio
*                 f4_ipd_err_input_limit      - position error input limit
*                 f4_ipd_err_integrator_limit - position error integrator limit ratio
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_IPD_ParameterUpdate(st_ipd_ctrl_t * p_st_ipd_ctrl,
                                 float f4_ipd_pos_kp_ratio,
                                 float f4_ipd_pos_ff_ratio,
                                 float f4_ipd_speed_k_ratio,
                                 float f4_ipd_err_input_limit,
                                 float f4_ipd_err_integrator_limit);

/***********************************************************************************************************************
* Function Name : R_MOTOR_IPD_CtrlGainCalc
* Description   : Gain calculation for IPD control
* Arguments     : p_st_ipd_ctrl        - The pointer to the IPD control structure
*                 p_st_motor           - The pointer to the motor parameter structure
*                 f4_ipd_omega_hz      - The control frequency[Hz] of IPD controller
*                 f4_speed_ctrl_period - control period for speed loop
* Return Value  : none
***********************************************************************************************************************/
void R_MOTOR_IPD_CtrlGainCalc(st_ipd_ctrl_t * p_st_ipd_ctrl,
                              st_motor_parameter_t * p_st_motor,
                              float f4_ipd_omega_hz,
                              float f4_speed_ctrl_period);

/***********************************************************************************************************************
* Function Name : R_MOTOR_IPD_SpeedPCtrl
* Description   : Speed proportional control for IPD
* Arguments     : p_st_ipd_ctrl        - The pointer to the IPD control structure
*                 f4_ref_speed_rad     - command speed value [rad/s]
*                 f4_speed_rad         - speed [rad/s]
* Return Value  : f4_iq_ref_calc       - q axis current reference
***********************************************************************************************************************/
float R_MOTOR_IPD_SpeedPCtrl(st_ipd_ctrl_t * p_st_ipd_ctrl, float f4_ref_speed_rad, float f4_speed_rad);

/***********************************************************************************************************************
* Function Name : R_MOTOR_IPD_ErrorCalc
* Description   : position error calculation for IPD
* Arguments     : p_st_ipd_ctrl        - The pointer to the IPD control structure
*                 f4_pos_rad           - position [rad]
*                 f4_ref_pos_rad_ctrl  - command position value for control
* Return Value  : f4_pos_err           - position error [rad]
***********************************************************************************************************************/
float R_MOTOR_IPD_ErrorCalc(st_ipd_ctrl_t * p_st_ipd_ctrl, float f4_pos_rad, float f4_ref_pos_rad_ctrl);

/***********************************************************************************************************************
* Function Name : R_MOTOR_IPD_PositionCtrl
* Description   : IPD control
* Arguments     : p_st_ipd_ctrl         - The pointer to the IPD control structure
*                 f4_pos_err_rad        - The position error [rad]
*                 f4_pos_rad            - The position [rad]
*                 f4_iq_lim             - The maximum Iq reference [A]
* Return Value  : f4_speed_ref_calc_rad - Speed reference [rad/s]
***********************************************************************************************************************/
float R_MOTOR_IPD_PositionCtrl(st_ipd_ctrl_t * p_st_ipd_ctrl,
                               float f4_pos_err_rad,
                               float f4_pos_rad,
                               float f4_iq_lim);

/***********************************************************************************************************************
* Function Name : R_MOTOR_IPD_PositionSync
* Description   : Position proportional control for IPD
* Arguments     : p_st_ipd_ctrl          - The pointer to the IPD control structure
*                 f4_pos_rad             - The position [rad]
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_IPD_PositionSync(st_ipd_ctrl_t * p_st_ipd_ctrl, float f4_pos_rad);
#endif /* R_MOTOR_IPD_API_H */
