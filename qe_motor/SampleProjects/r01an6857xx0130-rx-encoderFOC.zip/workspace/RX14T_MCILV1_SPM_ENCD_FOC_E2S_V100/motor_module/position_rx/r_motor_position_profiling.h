/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_position_profiling.h
* Description : Definitions of a motor control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MOTOR_POSITION_PROFILING_H
#define R_MOTOR_POSITION_PROFILING_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <stdint.h>
#include "r_motor_module_cfg.h"
#include "r_motor_common.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Position profile initial parameters */
#define     POSITION_PROFILE_ACCEL_TIME             (0.3f)    /* Default acceleration time[s] of speed  */

/* Position profiling mode */
#define     POSITION_PROFILE_MODE_TRIANGLE          (0)       /* Triangle position profile mode */
#define     POSITION_PROFILE_MODE_TRAPEZOIDAL       (1)       /* Trapezoidal position profile mode */

/* Position profile status */
#define     POSITION_PROFILE_STATE_STEADY           (0)       /* Steady state     : idle, waiting for route setting */
#define     POSITION_PROFILE_STATE_TRANSITION       (1)       /* Transition state : generating position command */

/***********************************************************************************************************************
* Structure definitions
***********************************************************************************************************************/
typedef struct
{
    uint8_t   u1_state_pos_pf;                       /* Position profile status */
    uint8_t   u1_pos_ref_mode;                       /* Position reference mode */
    uint16_t  u2_interval_time;                      /* Interval time for profile */
    uint16_t  u2_interval_time_buff;                 /* Interval time buffer for profile */
    uint16_t  u2_interval_time_cnt;                  /* Interval time counter for profile */
    float     f4_ctrl_period;                        /* Control period [s] */
    float     f4_accel_time;                         /* Acceleration time */
    float     f4_accel_time_buff;                    /* Acceleration time buffer */
    float     f4_accel_time_inv;                     /*`inverse of acceleration time */
    float     f4_min_accel_time;                     /* Minimum acceleration time */
    float     f4_accel_max_speed;                    /* Maximum speed for acceleration */
    float     f4_accel_max_speed_buff;               /* Maximum speed buffer for acceleration */
    float     f4_time_sec;                           /* Timer counter for profiling */
    float     f4_pos_st_rad;                         /* Start position */
    float     f4_pos_ed_rad;                         /* End position */
    float     f4_pos_dt_rad;                         /* Position error for profile */
    float     f4_pos_dt_time_sec;                    /* Position error / max speed */
} st_position_profiling_t;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : motor_position_profile_init
* Description   : Initialize variables when motor position profiling initialize
* Arguments     : p_st_ppf       - The pointer to position profiling structure
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_init(st_position_profiling_t * p_st_ppf);

/***********************************************************************************************************************
* Function Name : motor_position_profile_reset
* Description   : Reset variables when motor control
* Arguments     : p_st_ppf       - The pointer to position profiling structure
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_reset(st_position_profiling_t * p_st_ppf);

/***********************************************************************************************************************
* Function Name : motor_position_profile_interval_time_set
* Description   : Set parameter for position change interval time
* Arguments     : p_st_ppf         - The pointer to position profiling structure
*                 u2_interval_time - Position change interval time
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_interval_time_set(st_position_profiling_t * p_st_ppf, uint16_t u2_interval_time);

/***********************************************************************************************************************
* Function Name : motor_position_profile_accel_time_set
* Description   : Set parameter for acceleration time
* Arguments     : p_st_ppf      - The pointer to position profiling structure
*                 f4_accel_time - Acceleration time
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_accel_time_set(st_position_profiling_t * p_st_ppf, float f4_accel_time);

/***********************************************************************************************************************
* Function Name : motor_position_profile_min_accel_time_set
* Description   : Set parameter for maximum acceleration time
* Arguments     : p_st_ppf          - The pointer to position profiling structure
*                 p_st_motor        - Motor parameter structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_min_accel_time_set(st_position_profiling_t * p_st_ppf, st_motor_parameter_t * p_st_motor);

/***********************************************************************************************************************
* Function Name : motor_position_profile_max_accel_speed_set
* Description   : Set parameter for maximum speed [rad/s]
* Arguments     : p_st_ppf         - The pointer to position profiling structure
*                 f4_max_speed_rad - Maximum speed [rad/s]
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_max_accel_speed_set(st_position_profiling_t * p_st_ppf, float f4_max_speed_rad);

/***********************************************************************************************************************
* Function Name : motor_position_profile_feed_forward_profile
* Description   : trapezoid profile for speed feed-forward
* Arguments     : p_st_ppf       - The pointer to position profiling structure
* Return Value  : reference speed (feed-forward)
***********************************************************************************************************************/
float motor_position_profile_feed_forward_profile(st_position_profiling_t * p_st_ppf);

/***********************************************************************************************************************
* Function Name : motor_position_profile_start
* Description   : position profile (trapezoid)
* Arguments     : p_st_ppf       - The pointer to position profiling structure
* Return Value  : reference position
***********************************************************************************************************************/
float motor_position_profile_start(st_position_profiling_t * p_st_ppf);

/***********************************************************************************************************************
* Function Name : motor_position_profile_set_route
* Description   : Set start point and end point of position profiling
* Arguments     : p_st_ppf     - The pointer to position profiling structure
*                 f4_start_rad - The start position [rad]
*                 f4_dest_rad  - The destination position [rad]
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_set_route(st_position_profiling_t * p_st_ppf, float f4_start_rad, float f4_dest_rad);

/***********************************************************************************************************************
* Function Name : motor_position_profile_ctrl_period_set
* Description   : Set control period [s]
* Arguments     : p_st_ppf       - The pointer to position profiling structure
*                 f4_ctrl_period - The control period [s]
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_ctrl_period_set(st_position_profiling_t * p_st_ppf, float f4_ctrl_period);
#endif /* R_MOTOR_POSITION_PROFILING_H */
