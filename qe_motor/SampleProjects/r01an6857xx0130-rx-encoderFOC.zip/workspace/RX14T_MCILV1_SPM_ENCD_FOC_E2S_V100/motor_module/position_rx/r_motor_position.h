/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_position.h
* Description : Definitions of a position control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 24.12.2021 1.00
***********************************************************************************************************************/
/* guard against multiple inclusion */
#ifndef R_MOTOR_POSITION_H
#define R_MOTOR_POSITION_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_motor_position_api.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : motor_position_p_control
* Description   : Position Proportional control
* Arguments     : p_st_pc        - The pointer to speed control structure
*                 f4_pos_err_rad - position error [rad]
* Return Value  : None
***********************************************************************************************************************/
float motor_position_p_control(st_position_control_t * p_st_pc, float f4_pos_err_rad);

/***********************************************************************************************************************
* Function Name : motor_position_speed_feed_forward_ratio_set
* Description   : Set parameter for speed feed-forward ratio
* Arguments     : p_st_pc           - The pointer to speed control structure
*                 f4_speed_ff_ratio - speed feed-forward ratio
* Return Value  : None
***********************************************************************************************************************/
void motor_position_speed_feed_forward_ratio_set(st_position_control_t * p_st_pc, float f4_speed_ff_ratio);

/***********************************************************************************************************************
* Function Name : motor_position_speed_feed_forward_calc
* Description   : speed feed-forward control
* Arguments     : p_st_pc               - The pointer to speed control structure
*                 f4_speed_ff_rad       - feed-forward speed [rad/s] (mechanical)
*                 f4_speed_ref_calc_rad - speed feed-forward gain ratio
* Return Value  : None
***********************************************************************************************************************/
float motor_position_speed_feed_forward_calc(st_position_control_t * p_st_pc,
                                             float f4_speed_ff_rad,
                                             float f4_speed_ref_calc_rad);

/***********************************************************************************************************************
* Function Name : motor_position_deadband_apply
* Description   : Apply position dead-band
* Arguments     : p_st_pc        - The pointer to speed control structure
*                 f4_pos_err_rad - position error [rad]
* Return Value  : None
***********************************************************************************************************************/
float motor_position_deadband_apply(st_position_control_t * p_st_pc, float f4_pos_err_rad);

/***********************************************************************************************************************
* Function Name : motor_position_p_gain_calc
* Description   : Gain calculation for position proportional control
* Arguments     : p_st_pc         - The pointer to speed control structure
*                 f4_pos_omega_hz - natural frequency for position loop
* Return Value  : None
***********************************************************************************************************************/
void motor_position_p_gain_calc(st_position_control_t * p_st_pc, float f4_pos_omega_hz);

#endif /* R_MOTOR_POSITION_H */
