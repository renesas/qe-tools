/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_position_api.c
* Description : Position control API
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/
/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <math.h>
#include "r_motor_position_api.h"
#include "r_motor_position.h"
#include "r_motor_module_cfg.h"

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
st_position_control_t     g_st_pc;           /* Position & speed control structure */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_Open
* Description   : Open position control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_Open(void)
{
    st_position_control_t * p_st_pc;
    p_st_pc = &g_st_pc;

    p_st_pc->p_st_ipd          = 0;
    p_st_pc->u2_pos_dead_band  = POSITION_CFG_DEAD_BAND;
    p_st_pc->u2_pos_band_limit = POSITION_CFG_BAND_LIMIT;

    /* Initialize position control variables */
    p_st_pc->u1_is_in_position               = MTR_FLG_CLR;
    p_st_pc->f4_ctrl_period                  = POSITION_CFG_CTRL_PERIOD;
    p_st_pc->u1_pos_command_mode             = POSITION_COMMAND_MODE_TRAPEZOID;
    p_st_pc->u1_ctrl_method_mode             = MOTOR_COMMON_CFG_IPD_CTRL;
    p_st_pc->f4_pos_rad                      = 0.0f;
    p_st_pc->f4_ref_pos_rad                  = 0.0f;
    p_st_pc->f4_ref_pos_pre_rad              = 0.0f;
    p_st_pc->f4_ref_pos_rad_ctrl             = 0.0f;
    p_st_pc->f4_pos_err_rad                  = 0.0f;
    p_st_pc->f4_speed_ff_rad                 = 0.0f;
    p_st_pc->f4_speed_ff_ratio               = POSITION_CFG_SPEED_FF_RATIO;
    p_st_pc->f4_max_speed_rad                = (MOTOR_CFG_MAX_SPEED_RPM * MTR_RPM2RAD);
    p_st_pc->f4_mech_angle_per_sensor_cnt    = 0.0f;
    p_st_pc->st_motor.u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS;
    p_st_pc->st_motor.f4_mtr_r               = MOTOR_CFG_RESISTANCE;
    p_st_pc->st_motor.f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE;
    p_st_pc->st_motor.f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE;
    p_st_pc->st_motor.f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX;
    p_st_pc->st_motor.f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA;
    p_st_pc->st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS;

    motor_position_p_gain_calc(p_st_pc, POSITION_CFG_OMEGA);
    motor_position_profile_init(&p_st_pc->st_ppf);
    R_MOTOR_POSITION_Reset(p_st_pc);
} /* End of function R_MOTOR_POSITION_Open */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_Close
* Description   : Close position control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_Close(void)
{
    st_position_control_t * p_st_pc;
    p_st_pc = &g_st_pc;

    R_MOTOR_POSITION_Reset(p_st_pc);
} /* End of function R_MOTOR_POSITION_Close */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_Reset
* Description   : Reset variables when motor position control
* Arguments     : p_st_pc            - The pointer to position control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_Reset(st_position_control_t * p_st_pc)
{
    p_st_pc->u1_active                   = MTR_FLG_CLR;
    p_st_pc->f4_ref_pos_rad              = 0.0f;
    p_st_pc->f4_ref_pos_pre_rad          = 0.0f;
    p_st_pc->f4_ref_pos_rad_ctrl         = 0.0f;
    p_st_pc->f4_pos_err_rad              = 0.0f;
    p_st_pc->f4_speed_ff_rad             = 0.0f;
    p_st_pc->f4_ref_speed_rad_output     = 0.0f;

    motor_position_profile_reset(&p_st_pc->st_ppf);
} /* End of function R_MOTOR_POSITION_Reset */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_Run
* Description   : Run the motor position control
* Arguments     : p_st_pc            - The pointer to position control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_Run(st_position_control_t * p_st_pc)
{
    p_st_pc->u1_active = MTR_FLG_SET;
} /* End of function R_MOTOR_POSITION_Run */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_ParameterSet
* Description   : Set the position control parameter
* Arguments     : p_st_pc             - The pointer to position control structure
*                 p_st_position_input - The pointer to position control input parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_ParameterSet(st_position_control_t * p_st_pc, const st_position_input_t * p_st_position_input)
{
    p_st_pc->f4_pos_rad = p_st_position_input->f4_position_rad;
} /* End of function R_MOTOR_POSITION_ParameterSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_ParameterGet
* Description   : Get the position control parameter
* Arguments     : p_st_pc              - The pointer to position control structure
*                 p_st_position_output - The pointer to position control output parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_ParameterGet(st_position_control_t * p_st_pc, st_position_output_t * p_st_position_output)
{
    p_st_position_output->f4_speed_ref    = p_st_pc->f4_ref_speed_rad_output;
    p_st_position_output->f4_position_err = p_st_pc->f4_pos_err_rad;
    p_st_position_output->u1_in_position  = p_st_pc->u1_is_in_position;
} /* End of function R_MOTOR_POSITION_ParameterGet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_ParameterUpdate
* Description   : Update the position control parameter
* Arguments     : p_st_pc            - The pointer to position control structure
*                 p_st_position_cfg  - The pointer to position control configuration parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_ParameterUpdate(st_position_control_t * p_st_pc, const st_position_cfg_t * p_st_position_cfg)
{
    p_st_pc->st_motor                     = p_st_position_cfg->st_motor;
    p_st_pc->u2_pos_dead_band             = p_st_position_cfg->u2_dead_band;
    p_st_pc->u2_pos_band_limit            = p_st_position_cfg->u2_band_limit;
    p_st_pc->f4_speed_ff_ratio            = p_st_position_cfg->f4_feedforward_ratio;
    p_st_pc->f4_ctrl_period               = p_st_position_cfg->f4_ctrl_period;
    p_st_pc->f4_mech_angle_per_sensor_cnt = p_st_position_cfg->f4_mech_angle_per_sensor_cnt;
    p_st_pc->f4_max_speed_rad             = p_st_position_cfg->f4_max_speed_rad;

    motor_position_profile_ctrl_period_set(&p_st_pc->st_ppf, p_st_pc->f4_ctrl_period);
    motor_position_profile_max_accel_speed_set(&p_st_pc->st_ppf, p_st_position_cfg->f4_posprof_max_speed_rad);
    motor_position_profile_min_accel_time_set(&p_st_pc->st_ppf, &p_st_pc->st_motor);
    motor_position_profile_accel_time_set(&p_st_pc->st_ppf, p_st_position_cfg->f4_accel_time);
    motor_position_profile_interval_time_set(&p_st_pc->st_ppf, p_st_position_cfg->u2_pos_interval_time);

    motor_position_p_gain_calc(p_st_pc, p_st_position_cfg->f4_position_omega_hz);
} /* End of function R_MOTOR_POSITION_ParameterUpdate */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_PositionCyclic
* Description   : The cyclic processing of position control
* Arguments     : p_st_pc         - The pointer to position control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_PositionCyclic(st_position_control_t * p_st_pc)
{
    float f4_ref_speed_rad_calc;
    float f4_pos_err_rad;
    float f4_speed_ff_rad = 0.0f;
    float f4_pos_err_abs_rad;
    float f4_in_pos_width_rad;
    float f4_iq_max;

    if (MTR_FLG_SET == p_st_pc->u1_active)
    {
        /* Update position reference and speed command feed-forward */
        switch (p_st_pc->u1_pos_command_mode)
        {
            case POSITION_COMMAND_MODE_ZERO:

                /* Position zero constant */
                p_st_pc->f4_ref_pos_rad_ctrl = 0.0f;
                f4_speed_ff_rad              = 0.0f;
                break;

            case POSITION_COMMAND_MODE_STEP:

                /* Update reference position */
                p_st_pc->f4_ref_pos_rad_ctrl = p_st_pc->f4_ref_pos_rad;

                /* Calculate speed feed-forward */
                f4_speed_ff_rad = (p_st_pc->f4_ref_pos_rad_ctrl - p_st_pc->f4_ref_pos_pre_rad) /
                                  p_st_pc->f4_ctrl_period;

                /* Store previous position command */
                p_st_pc->f4_ref_pos_pre_rad = p_st_pc->f4_ref_pos_rad_ctrl;
                break;

            case POSITION_COMMAND_MODE_TRAPEZOID:

                /* Check reference position update */
                if (p_st_pc->f4_ref_pos_pre_rad != p_st_pc->f4_ref_pos_rad)
                {
                    motor_position_profile_set_route(&p_st_pc->st_ppf,
                                                     p_st_pc->f4_ref_pos_pre_rad,
                                                     p_st_pc->f4_ref_pos_rad);
                    p_st_pc->f4_ref_pos_pre_rad = p_st_pc->f4_ref_pos_rad;
                }

                /* profiling reference position (trapezoid control) */
                p_st_pc->f4_ref_pos_rad_ctrl = motor_position_profile_start(&p_st_pc->st_ppf);
                f4_speed_ff_rad              = motor_position_profile_feed_forward_profile(&p_st_pc->st_ppf);
                break;

            default:
                /* Do Nothing */
                break;
        }

        /* Update speed command output */
        if (POSITION_CONTROL_PID == p_st_pc->u1_ctrl_method_mode)
        {
            f4_pos_err_rad          = p_st_pc->f4_ref_pos_rad_ctrl - p_st_pc->f4_pos_rad;
            p_st_pc->f4_pos_err_rad = motor_position_deadband_apply(p_st_pc, f4_pos_err_rad);
            f4_ref_speed_rad_calc   = motor_position_p_control(p_st_pc, p_st_pc->f4_pos_err_rad);
        }
        else if (POSITION_CONTROL_IPD == p_st_pc->u1_ctrl_method_mode)
        {
            f4_pos_err_rad = R_MOTOR_IPD_ErrorCalc(p_st_pc->p_st_ipd,
                                                   p_st_pc->f4_pos_rad,
                                                   p_st_pc->f4_ref_pos_rad_ctrl);
            p_st_pc->f4_pos_err_rad = motor_position_deadband_apply(p_st_pc, f4_pos_err_rad);

            /* Calculate maximum Iq and run IPD control */
            f4_iq_max             = p_st_pc->st_motor.f4_nominal_current_rms * MOTOR_COMMON_CFG_IA_MAX_CALC_MULT;
            f4_ref_speed_rad_calc = R_MOTOR_IPD_PositionCtrl(p_st_pc->p_st_ipd,
                                                             p_st_pc->f4_pos_err_rad,
                                                             p_st_pc->f4_pos_rad,
                                                             f4_iq_max);
        }
        else
        {
            f4_ref_speed_rad_calc = 0.0f;
        }

        f4_ref_speed_rad_calc = motor_position_speed_feed_forward_calc(p_st_pc,
                                                                       f4_speed_ff_rad,
                                                                       f4_ref_speed_rad_calc);

        /* Update in-position signal */
        f4_pos_err_abs_rad  = fabsf(p_st_pc->f4_ref_pos_rad - p_st_pc->f4_pos_rad);
        f4_in_pos_width_rad = p_st_pc->u2_pos_band_limit * p_st_pc->f4_mech_angle_per_sensor_cnt;

        if (f4_pos_err_abs_rad <= f4_in_pos_width_rad)
        {
            p_st_pc->u1_is_in_position = MTR_TRUE;
        }
        else
        {
            p_st_pc->u1_is_in_position = MTR_FALSE;
        }
    }
    else
    {
        p_st_pc->u1_is_in_position = MTR_FALSE;
        f4_ref_speed_rad_calc      = 0.0f;
    }

    if (POSITION_CONTROL_IPD != p_st_pc->u1_ctrl_method_mode)
    {
        p_st_pc->f4_ref_speed_rad_output = motor_filter_limitf_abs(f4_ref_speed_rad_calc, p_st_pc->f4_max_speed_rad);
    }
    else
    {
        p_st_pc->f4_ref_speed_rad_output = f4_ref_speed_rad_calc;
    }
} /* End of function R_MOTOR_POSITION_PositionCyclic */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_CommandModeSet
* Description   : Sets position command mode
* Arguments     : p_st_pc                  - The pointer to position control structure
*                 u1_position_command mode - Position command mode to set
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_CommandModeSet(st_position_control_t * p_st_pc, uint8_t u1_position_command_mode)
{
    /* Synchronize all position command output when position command mode were changed */
    if (p_st_pc->u1_pos_command_mode != u1_position_command_mode)
    {
        p_st_pc->f4_ref_pos_rad     = p_st_pc->f4_pos_rad;
        p_st_pc->f4_ref_pos_pre_rad = p_st_pc->f4_pos_rad;
        motor_position_profile_set_route(&p_st_pc->st_ppf,
                                         p_st_pc->f4_pos_rad,
                                         p_st_pc->f4_pos_rad);
        p_st_pc->u1_pos_command_mode = u1_position_command_mode;
    }
} /* End of function R_MOTOR_POSITION_CommandModeSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_PosRefSet
* Description   : Set parameter for position reference
* Arguments     : p_st_pc                - The pointer to position control structure
*                 f4_ref_position_deg    - The position reference [degree]
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_PosRefSet(st_position_control_t * p_st_pc, float f4_ref_position_deg)
{
    p_st_pc->f4_ref_pos_rad = f4_ref_position_deg * MTR_DEG2RAD;
} /* End of function R_MOTOR_POSITION_PosRefSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_IPDInstanceAddressSet
* Description   : Link the I-PD structure
* Arguments     : p_st_pc         - The pointer to position control structure
*                 p_st_ipd        - The pointer to the IPD control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_IPDInstanceAddressSet(st_position_control_t * p_st_pc, st_ipd_ctrl_t * p_st_ipd)
{
    p_st_pc->p_st_ipd = p_st_ipd;
} /* End of function R_MOTOR_POSITION_IPDInstanceAddressSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_IPDEnableSet
* Description   : Sets enable state of IPD control
* Arguments     : p_st_pc         - The pointer to position control structure
*                 u1_enable       - Enable(1)/disable(0) state to set
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_IPDEnableSet(st_position_control_t * p_st_pc, uint8_t u1_enable)
{
    if (MTR_ENABLE == u1_enable)
    {
        p_st_pc->u1_ctrl_method_mode = POSITION_CONTROL_IPD;
    }
    else
    {
        p_st_pc->u1_ctrl_method_mode = POSITION_CONTROL_PID;
    }
} /* End of function R_MOTOR_POSITION_IPDEnableSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_POSITION_Sync
* Description   : Synchronizes internal position data with given position command
* Arguments     : p_st_pc        - The pointer to speed control structure
*                 f4_pos_ref_rad - The position reference to set
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_POSITION_Sync(st_position_control_t * p_st_pc, float f4_pos_ref_rad)
{
    p_st_pc->f4_ref_pos_pre_rad  = f4_pos_ref_rad;
    p_st_pc->f4_ref_pos_rad      = f4_pos_ref_rad;
    p_st_pc->f4_ref_pos_rad_ctrl = f4_pos_ref_rad;
    R_MOTOR_IPD_PositionSync(p_st_pc->p_st_ipd, f4_pos_ref_rad);
    motor_position_profile_set_route(&p_st_pc->st_ppf,
                                     f4_pos_ref_rad,
                                     f4_pos_ref_rad);
} /* End of function R_MOTOR_POSITION_Sync */
