/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_position_profiling.c
* Description : Processes of a motor control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <math.h>

/* Main associated header file */
#include "r_motor_position_profiling.h"

/***********************************************************************************************************************
* Private functions definitions
***********************************************************************************************************************/
/* Triangle profile for position reference */
static float motor_position_triangle_profile(st_position_profiling_t * p_st_ppf);

/* Trapezoid profile for position reference */
static float motor_position_trapezoid_profile(st_position_profiling_t * p_st_ppf);

/***********************************************************************************************************************
* Function Name : motor_position_profile_init
* Description   : Initialize variables when motor position profiling initialize
* Arguments     : p_st_ppf       - The pointer to position profiling structure
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_init(st_position_profiling_t * p_st_ppf)
{
    st_motor_parameter_t st_motor;


    /* Initialize member of position profiling structure */
    p_st_ppf->u1_state_pos_pf         = POSITION_PROFILE_STATE_STEADY;
    p_st_ppf->u1_pos_ref_mode         = POSITION_PROFILE_MODE_TRIANGLE;
    p_st_ppf->u2_interval_time        = POSITION_CFG_INTERVAL_TIME;
    p_st_ppf->u2_interval_time_buff   = POSITION_CFG_INTERVAL_TIME;
    p_st_ppf->f4_ctrl_period          = POSITION_CFG_CTRL_PERIOD;
    p_st_ppf->f4_accel_time           = POSITION_PROFILE_ACCEL_TIME;
    p_st_ppf->f4_accel_time_buff      = POSITION_PROFILE_ACCEL_TIME;
    p_st_ppf->f4_accel_time_inv       = 1.0f / POSITION_PROFILE_ACCEL_TIME;
    p_st_ppf->f4_accel_max_speed      = (MOTOR_CFG_MAX_SPEED_RPM * MTR_RPM2RAD);
    p_st_ppf->f4_accel_max_speed_buff = (MOTOR_CFG_MAX_SPEED_RPM * MTR_RPM2RAD);

    /* Calculate minimum acceleration time with default motor parameter */
    st_motor.u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS;
    st_motor.f4_mtr_r               = MOTOR_CFG_RESISTANCE;
    st_motor.f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE;
    st_motor.f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE;
    st_motor.f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX;
    st_motor.f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA;
    st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS;
    motor_position_profile_min_accel_time_set(p_st_ppf, &st_motor);

    motor_position_profile_reset(p_st_ppf);
} /* End of function motor_position_profile_init */

/***********************************************************************************************************************
* Function Name : motor_position_profile_reset
* Description   : Reset variables when motor control
* Arguments     : p_st_ppf       - The pointer to position profiling structure
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_reset(st_position_profiling_t * p_st_ppf)
{
    /* Position profiling structure */
    p_st_ppf->f4_time_sec           = 0.0f;
    p_st_ppf->u2_interval_time_cnt  = 0;
    p_st_ppf->f4_pos_dt_rad         = 0.0f;
    p_st_ppf->f4_pos_st_rad         = 0.0f;
    p_st_ppf->f4_pos_ed_rad         = 0.0f;
    p_st_ppf->f4_pos_dt_time_sec    = 0.0f;
} /* End of function motor_position_profile_reset */

/***********************************************************************************************************************
* Function Name : motor_position_profile_interval_time_set
* Description   : Set parameter for position change interval time
* Arguments     : p_st_ppf         - The pointer to position profiling structure
*                 u2_interval_time - Position change interval time
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_interval_time_set(st_position_profiling_t * p_st_ppf, uint16_t u2_interval_time)
{
    p_st_ppf->u2_interval_time_buff = u2_interval_time;
} /* End of function motor_position_profile_interval_time_set */

/***********************************************************************************************************************
* Function Name : motor_position_profile_accel_time_set
* Description   : Set parameter for acceleration time
* Arguments     : p_st_ppf      - The pointer to position profiling structure
*                 f4_accel_time - Acceleration time
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_accel_time_set(st_position_profiling_t * p_st_ppf, float f4_accel_time)
{
    p_st_ppf->f4_accel_time_buff = f4_accel_time;
    if (p_st_ppf->f4_accel_time_buff <= p_st_ppf->f4_min_accel_time)
    {
        p_st_ppf->f4_accel_time_buff = p_st_ppf->f4_min_accel_time;
    }
} /* End of function motor_position_profile_accel_time_set */

/***********************************************************************************************************************
* Function Name : motor_position_profile_min_accel_time_set
* Description   : Set parameter for maximum acceleration time
* Arguments     : p_st_ppf        - The pointer to position profiling structure
*                 p_st_motor      - Motor parameter structure (pointer)
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_min_accel_time_set(st_position_profiling_t * p_st_ppf, st_motor_parameter_t * p_st_motor)
{
    float f4_ia_max;        /* Maximum current for Id and Iq */
    float f4_max_torque;    /* Maximum torque [Nm] */
    float f4_max_accel;     /* Maximum acceleration [rad/s^2] */

    f4_ia_max         = p_st_motor->f4_nominal_current_rms * MOTOR_COMMON_CFG_IA_MAX_CALC_MULT;
    f4_max_torque     = p_st_motor->u2_mtr_pp * p_st_motor->f4_mtr_m * f4_ia_max;
    f4_max_accel      = f4_max_torque / p_st_motor->f4_mtr_j;

    /* Calculate minimum acceleration time */
    p_st_ppf->f4_min_accel_time = p_st_ppf->f4_accel_max_speed_buff / f4_max_accel;
} /* End of function motor_position_profile_min_accel_time_set */

/***********************************************************************************************************************
* Function Name : motor_position_profile_max_accel_speed_set
* Description   : Set parameter for maximum speed [rad/s]
* Arguments     : p_st_ppf         - The pointer to position profiling structure
*                 f4_max_speed_rad - Maximum speed [rad/s]
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_max_accel_speed_set(st_position_profiling_t * p_st_ppf, float f4_max_speed_rad)
{
    p_st_ppf->f4_accel_max_speed_buff = f4_max_speed_rad;
} /* End of function motor_position_profile_max_accel_speed_set */

/***********************************************************************************************************************
* Function Name : motor_position_profile_feed_forward_profile
* Description   : trapezoid profile for speed feed-forward
* Arguments     : p_st_ppf       - The pointer to position profiling structure
* Return Value  : reference speed (feed-forward)
***********************************************************************************************************************/
float motor_position_profile_feed_forward_profile(st_position_profiling_t * p_st_ppf)
{
    float f4_speed_ff_rad;
    float f4_temp0;
    float f4_temp1;

    f4_speed_ff_rad = 0.0f;

    if (POSITION_PROFILE_MODE_TRIANGLE == p_st_ppf->u1_pos_ref_mode)
    {
        /* Speed feed-forward profile for triangle*/
        if (p_st_ppf->f4_time_sec <= p_st_ppf->f4_accel_time)
        {
            f4_speed_ff_rad = (p_st_ppf->f4_accel_max_speed * p_st_ppf->f4_time_sec) * p_st_ppf->f4_accel_time_inv;
        }
        else if ((p_st_ppf->f4_time_sec > p_st_ppf->f4_accel_time) &&
                 (p_st_ppf->f4_time_sec <= (2.0f * p_st_ppf->f4_accel_time)))
        {
            f4_temp0        = (p_st_ppf->f4_accel_max_speed * p_st_ppf->f4_time_sec) * p_st_ppf->f4_accel_time_inv;
            f4_speed_ff_rad = (2.0f * p_st_ppf->f4_accel_max_speed) - f4_temp0;
        }
        else
        {
            /* Do Nothing */
        }
    }
    else if (POSITION_PROFILE_MODE_TRAPEZOIDAL == p_st_ppf->u1_pos_ref_mode)
    {
        /* Speed feed-forward profile for trapezoidal*/
        if (p_st_ppf->f4_time_sec <= p_st_ppf->f4_accel_time)
        {
            f4_speed_ff_rad = (p_st_ppf->f4_accel_max_speed * p_st_ppf->f4_time_sec) * p_st_ppf->f4_accel_time_inv;
        }
        else if ((p_st_ppf->f4_time_sec > p_st_ppf->f4_accel_time) &&
                 (p_st_ppf->f4_time_sec <= p_st_ppf->f4_pos_dt_time_sec))
        {
            f4_speed_ff_rad = p_st_ppf->f4_accel_max_speed;
        }
        else if ((p_st_ppf->f4_time_sec > p_st_ppf->f4_pos_dt_time_sec) &&
                 (p_st_ppf->f4_time_sec <= (p_st_ppf->f4_pos_dt_time_sec + p_st_ppf->f4_accel_time)))
        {
            f4_temp0        = p_st_ppf->f4_pos_dt_rad * p_st_ppf->f4_accel_time_inv;
            f4_temp1        = p_st_ppf->f4_accel_max_speed * p_st_ppf->f4_time_sec * p_st_ppf->f4_accel_time_inv;
            f4_speed_ff_rad = p_st_ppf->f4_accel_max_speed + f4_temp0 - f4_temp1;
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return (f4_speed_ff_rad);
} /* End of function motor_position_profile_feed_forward_profile */

/***********************************************************************************************************************
* Function Name : motor_position_profile_start
* Description   : position profile (trapezoid)
* Arguments     : p_st_ppf       - The pointer to position profiling structure
* Return Value  : reference position
***********************************************************************************************************************/
float motor_position_profile_start(st_position_profiling_t * p_st_ppf)
{
    float f4_pos_dt_abs_rad;
    float f4_ref_pos_rad_calc;

    f4_ref_pos_rad_calc = p_st_ppf->f4_pos_st_rad;

    /* Position control reference state - steady state */
    if (POSITION_PROFILE_STATE_STEADY == p_st_ppf->u1_state_pos_pf)
    {
        /* Difference in reference position check */
        if (p_st_ppf->f4_pos_st_rad != p_st_ppf->f4_pos_ed_rad)
        {
            /* Update variables */
            p_st_ppf->f4_accel_max_speed = p_st_ppf->f4_accel_max_speed_buff;
            p_st_ppf->f4_accel_time      = p_st_ppf->f4_accel_time_buff;
            p_st_ppf->f4_accel_time_inv  = 1.0f / p_st_ppf->f4_accel_time;
            p_st_ppf->u2_interval_time   = p_st_ppf->u2_interval_time_buff;
            p_st_ppf->f4_time_sec        = 0.0f;
            p_st_ppf->f4_pos_dt_rad      = p_st_ppf->f4_pos_ed_rad - p_st_ppf->f4_pos_st_rad;
            f4_pos_dt_abs_rad            = fabsf(p_st_ppf->f4_pos_dt_rad);
            p_st_ppf->f4_pos_dt_time_sec = f4_pos_dt_abs_rad / p_st_ppf->f4_accel_max_speed;

            /* Trapezoid mode check */
            if ((p_st_ppf->f4_accel_time * p_st_ppf->f4_accel_max_speed) >= f4_pos_dt_abs_rad)
            {
                p_st_ppf->u1_pos_ref_mode    = POSITION_PROFILE_MODE_TRIANGLE;
                p_st_ppf->f4_accel_max_speed = p_st_ppf->f4_pos_dt_rad * p_st_ppf->f4_accel_time_inv;
            }
            else
            {
                p_st_ppf->u1_pos_ref_mode    = POSITION_PROFILE_MODE_TRAPEZOIDAL;
                p_st_ppf->f4_accel_max_speed = copysignf(p_st_ppf->f4_accel_max_speed, p_st_ppf->f4_pos_dt_rad);
            }
            p_st_ppf->u1_state_pos_pf = POSITION_PROFILE_STATE_TRANSITION;
        }
    }

    /* Position control reference state - transition state */
    if (POSITION_PROFILE_STATE_TRANSITION == p_st_ppf->u1_state_pos_pf)
    {
        if (POSITION_PROFILE_MODE_TRIANGLE == p_st_ppf->u1_pos_ref_mode)
        {
            /* Profiling triangle position reference */
            f4_ref_pos_rad_calc = motor_position_triangle_profile(p_st_ppf);
        }
        else if (POSITION_PROFILE_MODE_TRAPEZOIDAL == p_st_ppf->u1_pos_ref_mode)
        {
            /* Profiling trapezoid position reference */
            f4_ref_pos_rad_calc = motor_position_trapezoid_profile(p_st_ppf);
        }
        else
        {
            /* Do Nothing */
        }
        p_st_ppf->f4_time_sec += p_st_ppf->f4_ctrl_period;

        /* Reach the target position */
        if (p_st_ppf->f4_pos_st_rad == p_st_ppf->f4_pos_ed_rad)
        {
            /* Transition Interval Time */
            if (p_st_ppf->u2_interval_time <= p_st_ppf->u2_interval_time_cnt)
            {
                p_st_ppf->u2_interval_time_cnt = 0;
                p_st_ppf->u1_state_pos_pf      = POSITION_PROFILE_STATE_STEADY;
            }
            p_st_ppf->u2_interval_time_cnt++;
            f4_ref_pos_rad_calc = p_st_ppf->f4_pos_st_rad;
        }
    }

    return (f4_ref_pos_rad_calc);
} /* End of function motor_position_profile_start */

/***********************************************************************************************************************
* Function Name : motor_position_profile_set_route
* Description   : Set start point and end point of position profiling
* Arguments     : p_st_ppf     - The pointer to position profiling structure
*                 f4_start_rad - The start position [rad]
*                 f4_dest_rad  - The destination position [rad]
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_set_route(st_position_profiling_t * p_st_ppf, float f4_start_rad, float f4_dest_rad)
{
    p_st_ppf->f4_pos_st_rad = f4_start_rad;
    p_st_ppf->f4_pos_ed_rad = f4_dest_rad;
} /* End of function motor_position_profile_set_route */

/***********************************************************************************************************************
* Function Name : motor_position_profile_ctrl_period_set
* Description   : Set control period [s]
* Arguments     : p_st_ppf       - The pointer to position profiling structure
*                 f4_ctrl_period - The control period [s]
* Return Value  : None
***********************************************************************************************************************/
void motor_position_profile_ctrl_period_set(st_position_profiling_t * p_st_ppf, float f4_ctrl_period)
{
    p_st_ppf->f4_ctrl_period = f4_ctrl_period;
} /* End of function motor_position_profile_ctrl_period_set */

/***********************************************************************************************************************
* Function Name : motor_position_triangle_profile
* Description   : triangle profile for position reference
*               : Acceleration does not reach the maximum speed
*               : (f4_accel_max_ref_speed_rad * f4_accel_time) >= f4_pos_dt_rad
* Arguments     : p_st_ppf       - The pointer to position profiling structure
* Return Value  : reference position
***********************************************************************************************************************/
static float motor_position_triangle_profile(st_position_profiling_t * p_st_ppf)
{
    float f4_temp0;
    float f4_temp1;
    float f4_temp2;
    float f4_temp3;
    float f4_pos_ref;

    f4_pos_ref = p_st_ppf->f4_pos_st_rad;

    if (p_st_ppf->f4_time_sec <= p_st_ppf->f4_accel_time)
    {
        f4_temp0   = p_st_ppf->f4_time_sec * p_st_ppf->f4_time_sec;
        f4_temp0   = p_st_ppf->f4_accel_max_speed * f4_temp0;
        f4_temp1   = 0.5f * p_st_ppf->f4_accel_time_inv;
        f4_temp0   = f4_temp0 * f4_temp1;
        f4_pos_ref = f4_temp0 + p_st_ppf->f4_pos_st_rad;
    }                                                             /* Rise section for triangle */
    else if ((p_st_ppf->f4_time_sec > p_st_ppf->f4_accel_time) &&
             (p_st_ppf->f4_time_sec <= (2.0f * p_st_ppf->f4_accel_time)))
    {
        f4_temp0   = 2.0f * p_st_ppf->f4_accel_max_speed;
        f4_temp0   = f4_temp0 * p_st_ppf->f4_time_sec;
        f4_temp1   = p_st_ppf->f4_time_sec * p_st_ppf->f4_time_sec;
        f4_temp1   = p_st_ppf->f4_accel_max_speed * f4_temp1;
        f4_temp2   = 0.5f * p_st_ppf->f4_accel_time_inv;
        f4_temp1   = -(f4_temp1 * f4_temp2);
        f4_temp2   = p_st_ppf->f4_pos_dt_rad * 0.5f;
        f4_temp3   = p_st_ppf->f4_accel_max_speed * p_st_ppf->f4_accel_time;
        f4_temp3   = 3.0f * f4_temp3;
        f4_temp3   = -(f4_temp3 * 0.5f);
        f4_pos_ref = f4_temp0 + f4_temp1 + f4_temp3 + f4_temp2 + p_st_ppf->f4_pos_st_rad;
    }                                                             /* Reduce the speed */
    else if (p_st_ppf->f4_time_sec > (2.0f * p_st_ppf->f4_accel_time))  /* Reach the target position */
    {
        p_st_ppf->f4_pos_st_rad = p_st_ppf->f4_pos_ed_rad;
        f4_pos_ref = p_st_ppf->f4_pos_st_rad;
    }
    else
    {
        /* Do Nothing */
    }

    return (f4_pos_ref);
} /* End of function motor_position_triangle_profile */

/***********************************************************************************************************************
* Function Name : motor_position_trapezoid_profile
* Description   : trapezoid profile for position reference
*               : Acceleration reach the maximum speed
*               : (f4_accel_max_ref_speed_rad * f4_accel_time) <  f4_pos_dt_rad
* Arguments     : p_st_ppf       - The pointer to position profiling structure
* Return Value  : reference position
***********************************************************************************************************************/
static float motor_position_trapezoid_profile(st_position_profiling_t * p_st_ppf)
{
    float f4_temp0;
    float f4_temp1;
    float f4_temp2;
    float f4_temp3;
    float f4_temp4;
    float f4_temp5;
    float f4_pos_ref;

    f4_pos_ref = p_st_ppf->f4_pos_st_rad;

    if (p_st_ppf->f4_time_sec <= p_st_ppf->f4_accel_time)
    {
        f4_temp0   = p_st_ppf->f4_time_sec * p_st_ppf->f4_time_sec;
        f4_temp0   = p_st_ppf->f4_accel_max_speed * f4_temp0;
        f4_temp1   = 0.5f * p_st_ppf->f4_accel_time_inv;
        f4_temp0   = f4_temp0 * f4_temp1;
        f4_pos_ref = f4_temp0 + p_st_ppf->f4_pos_st_rad;
    }                                                                              /* Speed up */
    else if ((p_st_ppf->f4_time_sec > p_st_ppf->f4_accel_time) &&
             (p_st_ppf->f4_time_sec <= p_st_ppf->f4_pos_dt_time_sec))
    {
        f4_temp0   = p_st_ppf->f4_accel_max_speed * p_st_ppf->f4_time_sec;
        f4_temp1   = p_st_ppf->f4_accel_max_speed * p_st_ppf->f4_accel_time;
        f4_temp1   = -(f4_temp1 * 0.5f);
        f4_pos_ref = f4_temp0 + f4_temp1 + p_st_ppf->f4_pos_st_rad;
    }                                                                              /* Constant speed */
    else if ((p_st_ppf->f4_time_sec > p_st_ppf->f4_pos_dt_time_sec) &&
             (p_st_ppf->f4_time_sec <= (p_st_ppf->f4_pos_dt_time_sec + p_st_ppf->f4_accel_time)))
    {
        f4_temp0   = p_st_ppf->f4_accel_max_speed * p_st_ppf->f4_time_sec;
        f4_temp1   = p_st_ppf->f4_time_sec * p_st_ppf->f4_time_sec;
        f4_temp1   = p_st_ppf->f4_accel_max_speed * f4_temp1;
        f4_temp2   = 0.5f * p_st_ppf->f4_accel_time_inv;
        f4_temp1   = -(f4_temp1 * f4_temp2);
        f4_temp2   = p_st_ppf->f4_pos_dt_rad * p_st_ppf->f4_time_sec;
        f4_temp2   = f4_temp2 * p_st_ppf->f4_accel_time_inv;;
        f4_temp3   = p_st_ppf->f4_accel_max_speed * p_st_ppf->f4_accel_time;
        f4_temp3   = -(f4_temp3 * 0.5f);
        f4_temp4   = p_st_ppf->f4_pos_dt_rad * p_st_ppf->f4_pos_dt_rad;
        f4_temp5   = 0.5f * p_st_ppf->f4_accel_time_inv;
        f4_temp4   = -((f4_temp4 * f4_temp5) / p_st_ppf->f4_accel_max_speed);
        f4_pos_ref = f4_temp0 + f4_temp1 + f4_temp2 + f4_temp3 + f4_temp4 + p_st_ppf->f4_pos_st_rad;
    }                                                                              /* Reduce the speed */
    else if (p_st_ppf->f4_time_sec > (p_st_ppf->f4_pos_dt_time_sec + p_st_ppf->f4_accel_time))
    {
        p_st_ppf->f4_pos_st_rad = p_st_ppf->f4_pos_ed_rad;
        f4_pos_ref              = p_st_ppf->f4_pos_st_rad;
    }                                                                              /* Reach the target position */
    else
    {
        /* Do Nothing */
    }

    return (f4_pos_ref);
} /* End of function motor_position_trapezoid_profile */
