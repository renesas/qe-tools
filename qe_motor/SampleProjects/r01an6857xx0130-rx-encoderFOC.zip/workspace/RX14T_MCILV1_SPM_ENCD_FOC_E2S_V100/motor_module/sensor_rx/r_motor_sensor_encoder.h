/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_sensor_encoder.h
* Description : Definitions of encoder control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_SENSOR_ENCODER_H
#define R_MOTOR_SENSOR_ENCODER_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_motor_common.h"
#include "r_motor_sensor_api.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* position and speed calculation mode */
#define SENSOR_ENCD_PS_CALC_ENCD_INTERRUPT (0)
#define SENSOR_ENCD_PS_CALC_CTRL_INTERRUPT (1)

/* encoder configuration */
#define SENSOR_ENCD_ZEROSPEED_PW      (20000000)     /* encoder pulse width[counts] considered as zero speed */
#define SENSOR_ENCD_ANGLE_DIFF        (MTR_TWOPI / (float)MOTOR_COMMON_SENSOR_ENCD_CPR)
                                                     /* encoder minimum angle [rad]*/
#define SENSOR_ENCD_CALC_AVG          (SENSOR_ENCD_CNTAVG * SENSOR_CFG_ENCD_TIMER_FREQ * 1000000.0f)
                                                     /* encoder avg calc parameter */
#define SENSOR_ENCD_HS_SPEED_LPF_PARAM     (0.1f)    /* Highspeed mode speed LPF parameter */
#define SENSOR_ENCD_PS_CALC_CHANGE_CNT     (8)       /* counts for mode change of position speed calculation */

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_mech_param_set
* Description   : Set encoder pulse (quad edge evaluation)
* Arguments     : p_st_sensor      - The pointer to sensor structure
*                 u2_encd_cpr_mech - encoder pulse (quad edge evaluation)
* Return Value  : None
***********************************************************************************************************************/
void motor_sensor_encoder_mech_param_set(st_sensor_t *p_st_sensor, uint16_t u2_encd_cpr_mech);

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_sw_hs_speed_rad_set
* Description   : Set toggle speed for high speed mode
* Arguments     : p_st_sensor             - The pointer to sensor structure
*                 f4_encd_hs_sw_speed_rpm - toggle speed for high speed mode [rpm]
* Return Value  : None
***********************************************************************************************************************/
void motor_sensor_encoder_sw_hs_speed_rad_set(st_sensor_t *p_st_sensor,
                                              float f4_encd_hs_sw_speed_rpm);

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_sw_hs_speed_margin_rad_set
* Description   : Set margin of toggle speed for high speed mode [rad/s]
* Arguments     : p_st_sensor                    - The pointer to sensor structure
*                 f4_encd_hs_sw_speed_margin_rpm - margin of toggle speed for high speed mode [rpm]
* Return Value  : None
***********************************************************************************************************************/
void motor_sensor_encoder_sw_hs_speed_margin_rad_set(st_sensor_t *p_st_sensor,
                                                     float f4_encd_hs_sw_speed_margin_rpm);

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_hs_speed_calc
* Description   : Calculate speed
* Arguments     : p_st_sensor    - The pointer to sensor structure
*                 f4_pos_err     - position error [rad]
*                 f4_ctrl_period - control period
* Return Value  : None 
***********************************************************************************************************************/
void motor_sensor_encoder_hs_speed_calc(st_sensor_t *p_st_sensor, float f4_pos_err, float f4_ctrl_period);

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_hs_encd_interrupt_switch
* Description   : Swich encoder interrupt process
* Arguments     : p_st_sensor      - The pointer to sensor structure
*                 f4_speed_rad     - speed [rad/s]
* Return Value  : None 
***********************************************************************************************************************/
void motor_sensor_encoder_hs_encd_interrupt_switch(st_sensor_t *p_st_sensor, float f4_speed_rad);

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_hs_ctrl_interrupt_switch
* Description   : Switch carrier innterupt process
* Arguments     : p_st_sensor      - The pointer to sensor structure
*                 f4_speed_rad - speed [rad/s]
* Return Value  : None 
***********************************************************************************************************************/
void motor_sensor_encoder_hs_ctrl_interrupt_switch(st_sensor_t *p_st_sensor, float f4_speed_rad);

#endif /* R_MOTOR_SENSOR_ENCODER_H */
