/***********************************************************************************************************************
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_sensor_encoder.c
* Description : Processes of encoder control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <math.h>

/* Main associated header file */
#include "r_motor_sensor_encoder.h"

/* Main associated header file */
#include "r_smc_entry.h"
#include "r_motor_module_cfg.h"
#include "r_motor_common.h"
#include "r_motor_filter.h"

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_mech_param_set
* Description   : Set related parameters to encoder (quad edge evaluation)
* Arguments     : p_st_sensor      - The pointer to sensor structure
*                 u2_encd_cpr_mech - encoder pulse (quad edge evaluation)
* Return Value  : None
***********************************************************************************************************************/
void motor_sensor_encoder_mech_param_set(st_sensor_t *p_st_sensor, uint16_t u2_encd_cpr_mech)
{
    /* encoder counts per revolution (mechanical) */
    p_st_sensor->st_ec.u2_encd_cpr_mech = u2_encd_cpr_mech;
    /* inverse number of encoder counts per revolution (mechanical) */
    p_st_sensor->st_ec.f4_encd_cpr_mech_inv = 1.0f / (float)p_st_sensor->st_ec.u2_encd_cpr_mech;
    /* angle of encoder 1 pulse width */
    p_st_sensor->st_ec.f4_encd_angle_diff = MTR_TWOPI * p_st_sensor->st_ec.f4_encd_cpr_mech_inv;
} /* End of function motor_sensor_encoder_mech_param_set */

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_sw_hs_speed_rad_set
* Description   : Set toggle speed for high speed mode
* Arguments     : p_st_sensor              - The pointer to sensor structure
*                 f4_encd_hs_sw_speed_rpm  - toggle speed for high speed mode [rpm]
* Return Value  : None
***********************************************************************************************************************/
void motor_sensor_encoder_sw_hs_speed_rad_set(st_sensor_t *p_st_sensor, float f4_encd_hs_sw_speed_rpm)
{
    p_st_sensor->st_ehc.f4_encd_hs_sw_speed_rad = f4_encd_hs_sw_speed_rpm * MTR_RPM2RAD;
} /* End of function motor_sensor_encoder_sw_hs_speed_rad_set */

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_sw_hs_speed_margin_rad_set
* Description   : Set margin of toggle speed for high speed mode [rad/s]
* Arguments     : p_st_sensor                    - The pointer to sensor structure
*                 f4_encd_hs_sw_speed_margin_rpm - margin of toggle speed for high speed mode [rpm]
* Return Value  : None
***********************************************************************************************************************/
void motor_sensor_encoder_sw_hs_speed_margin_rad_set(st_sensor_t *p_st_sensor, float f4_encd_hs_sw_speed_margin_rpm)
{
    p_st_sensor->st_ehc.f4_encd_hs_sw_speed_margin_rad = f4_encd_hs_sw_speed_margin_rpm * MTR_RPM2RAD;
} /* End of function motor_sensor_encoder_sw_hs_speed_margin_rad_set */

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_hs_speed_calc
* Description   : Calculate speed
* Arguments     : p_st_sensor    - The pointer to sensor structure
*                 f4_pos_err     - position error [rad]
*                 f4_ctrl_period - control period
* Return Value  : None 
***********************************************************************************************************************/
void motor_sensor_encoder_hs_speed_calc(st_sensor_t *p_st_sensor, float f4_pos_err, float f4_ctrl_period)
{
    float    f4_temp_speed_rad;

    f4_temp_speed_rad                            = f4_pos_err / f4_ctrl_period;
    p_st_sensor->st_ehc.f4_encd_hs_pos_pre_rad   = p_st_sensor->st_ehc.f4_encd_hs_pos_rad;
    p_st_sensor->st_ehc.f4_encd_hs_speed_rad     = motor_filter_lpff(f4_temp_speed_rad,
                                                   p_st_sensor->st_ehc.f4_encd_hs_speed_pre_rad,
                                                   SENSOR_ENCD_HS_SPEED_LPF_PARAM);
    p_st_sensor->st_ehc.f4_encd_hs_speed_pre_rad = p_st_sensor->st_ehc.f4_encd_hs_speed_rad;
} /* End of function motor_sensor_encoder_hs_speed_calc */

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_hs_encd_interrupt_switch
* Description   : Switch interrupt process of encoder interrupt
* Arguments     : p_st_sensor      - The pointer to sensor structure
*                 f4_speed_rad     - speed [rad/s]
* Return Value  : None 
***********************************************************************************************************************/
void motor_sensor_encoder_hs_encd_interrupt_switch(st_sensor_t *p_st_sensor, float f4_speed_rad)
{
    float f4_temp;

    f4_temp = p_st_sensor->st_ehc.f4_encd_hs_sw_speed_rad - p_st_sensor->st_ehc.f4_encd_hs_sw_speed_margin_rad;
    if (f4_temp > fabsf(f4_speed_rad))
    {
clrpsw_i();
        p_st_sensor->EncdInterruptEnable();
setpsw_i();
        p_st_sensor->st_ehc.u1_encd_interrupt_on_flag = MTR_FLG_SET;
        p_st_sensor->st_ehc.u1_encd_pos_speed_calc_cnt++;
        if (p_st_sensor->st_ehc.u1_encd_pos_speed_calc_cnt >= SENSOR_ENCD_PS_CALC_CHANGE_CNT)
        {
            p_st_sensor->st_ehc.u1_encd_pos_speed_calc_mode = SENSOR_ENCD_PS_CALC_ENCD_INTERRUPT;
            p_st_sensor->st_ehc.u1_encd_pos_speed_calc_cnt  = 0;
        }
    }
    else
    {
clrpsw_i();
        p_st_sensor->EncdInterruptDisable();
setpsw_i();
    }
} /* End of function motor_sensor_encoder_hs_encd_interrupt_switch */

/***********************************************************************************************************************
* Function Name : motor_sensor_encoder_hs_ctrl_interrupt_switch
* Description   : Switch carrier innterupt process
* Arguments     : p_st_sensor      - The pointer to sensor structure
*                 f4_speed_rad     - speed [rad/s]
* Return Value  : None 
***********************************************************************************************************************/
void motor_sensor_encoder_hs_ctrl_interrupt_switch(st_sensor_t *p_st_sensor, float f4_speed_rad)
{
    if (p_st_sensor->st_ehc.f4_encd_hs_sw_speed_rad <= fabsf(f4_speed_rad))
    {
        p_st_sensor->st_ehc.u1_encd_pos_speed_calc_mode = SENSOR_ENCD_PS_CALC_CTRL_INTERRUPT;
        p_st_sensor->st_ehc.u1_encd_pos_speed_calc_cnt  = 0;
clrpsw_i();
        p_st_sensor->EncdInterruptDisable();
setpsw_i();
    }
} /* End of function motor_sensor_encoder_hs_ctrl_interrupt_switch */
