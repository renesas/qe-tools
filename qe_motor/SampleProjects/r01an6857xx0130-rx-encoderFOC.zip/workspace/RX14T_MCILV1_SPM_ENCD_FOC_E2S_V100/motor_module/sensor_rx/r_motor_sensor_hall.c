/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_sensor_hall.c
* Description : Processes of a hall control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */

/* Main associated header file */
#include "r_smc_entry.h"
#include "r_motor_module_cfg.h"
#include "r_motor_common.h"
#include "r_motor_sensor_hall.h"
#include "r_motor_sensor_encoder.h"

/***********************************************************************************************************************
* Function Name : motor_sensor_hall_angle_edge_set
* Description   : Process for hall edge angle set
* Arguments     : u1_hall_signal - hall signal
                  u1_pre_hall_signal - previous value of hall signal
* Return Value  : Rotor angle of signal detected for hall sensor
***********************************************************************************************************************/
float motor_sensor_hall_angle_edge_set(uint8_t u1_hall_signal, uint8_t u1_pre_hall_signal)
{
    float f4_hall_angle_rad;

    switch (u1_pre_hall_signal)
    {
        case SENSOR_HALL_W: /* (1) */
            if (SENSOR_HALL_VW == u1_hall_signal) /* (1 -> 3) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_330;
            }
            else if (SENSOR_HALL_UW == u1_hall_signal) /* (1 -> 5) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_30;
            }
            else
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ERROR;
            }
        break;

        case SENSOR_HALL_UW: /* (5) */
            if (SENSOR_HALL_W == u1_hall_signal) /* (5 -> 1) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_30;
            }
            else if (SENSOR_HALL_U == u1_hall_signal) /* (5 -> 4) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_90;
            }
            else
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ERROR;
            }
        break;

        case SENSOR_HALL_U: /* (4) */
            if (SENSOR_HALL_UW == u1_hall_signal) /* (4 -> 5) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_90;
            }
            else if (SENSOR_HALL_UV == u1_hall_signal) /* (4 -> 6) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_150;
            }
            else
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ERROR;
            }
        break;

        case SENSOR_HALL_UV: /* (6) */
            if (SENSOR_HALL_U == u1_hall_signal) /* (6 -> 4) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_150;
            }
            else if (SENSOR_HALL_V == u1_hall_signal) /* (6 -> 2) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_210;
            }
            else
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ERROR;
            }
        break;

        case SENSOR_HALL_V: /* (2) */
            if (SENSOR_HALL_UV == u1_hall_signal) /* (2 -> 6) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_210;
            }
            else if (SENSOR_HALL_VW == u1_hall_signal) /* (2 -> 3) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_270;
            }
            else
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ERROR;
            }
        break;

        case SENSOR_HALL_VW: /* (3) */
            if (SENSOR_HALL_V == u1_hall_signal) /* (3 -> 2) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_270;
            }
            else if (SENSOR_HALL_W == u1_hall_signal) /* (3 -> 1) */
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_330;
            }
            else
            {
                f4_hall_angle_rad = SENSOR_HALL_EDGE_ERROR;
            }
        break;

        default:
            f4_hall_angle_rad = SENSOR_HALL_EDGE_ERROR;
        break;
    }

    return (f4_hall_angle_rad);
} /* End of function motor_sensor_hall_angle_edge_set */

/***********************************************************************************************************************
* Function Name : motor_sensor_hall_angle_set
* Description   : Process for hall sensor interrupt
* Arguments     : u1_hall_signal - hall signal
* Return Value  : Rotor angle of signal detected for hall sensor
***********************************************************************************************************************/
float motor_sensor_hall_angle_set(uint8_t u1_hall_signal)
{
    float f4_hall_angle_rad;

    switch (u1_hall_signal)
    {
        case SENSOR_HALL_W:  /* (1) */
            f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_30 - (30.0f * MTR_DEG2RAD);
        break;
        
        case SENSOR_HALL_UW: /* (5) */
            f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_90 - (30.0f * MTR_DEG2RAD);
        break;

        case SENSOR_HALL_U:  /* (4) */
            f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_150 - (30.0f * MTR_DEG2RAD);
        break;

        case SENSOR_HALL_UV: /* (6) */
            f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_210 - (30.0f * MTR_DEG2RAD);
        break;

        case SENSOR_HALL_V:  /* (2) */
            f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_270 - (30.0f * MTR_DEG2RAD);
        break;

        case SENSOR_HALL_VW: /* (3) */
            f4_hall_angle_rad = SENSOR_HALL_EDGE_ANGLE_330 - (30.0f * MTR_DEG2RAD);
        break;
        
        default:
            f4_hall_angle_rad = SENSOR_HALL_EDGE_ERROR;
        break;
    }

    return (f4_hall_angle_rad);
} /* End of function motor_sensor_hall_angle_set */
