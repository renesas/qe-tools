/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_sensor_api.h
* Description : Definitions of sensor API
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/* guard against multiple inclusion */
#ifndef R_MOTOR_SENSOR_API_H
#define R_MOTOR_SENSOR_API_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_motor_common.h"

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define SENSOR_ENCD_ANGLE_ADJ_TIME          (256)          /* encoder angle adjustment time */
#define SENSOR_ENCD_CNTAVG                  (4)            /* encoder pulse width average */

#define SENSOR_HALL_EDGE_ERROR              (1)
#define SENSOR_ENCD_NUMB_OF_TIME            (2)
                                    /* the number of times of encoder interrupt for control period */
/* Calculation method of SENSOR_ENCD_NUMB_OF_TIME                   */
/* Pcpu : Acceptable CPU occupancy of carrier interrupt[%]          */
/* Ta   : processing time of carrier interrupt[s]                   */
/* Tb   : processing time of encoder interrupt[s]                   */
/* SENSOR_ENCD_NUMB_OF_TIME = (Pcpu x control period - Ta) / Tb     */

#define SENSOR_ENCD_HS_CHANGE_RPM  ((SENSOR_ENCD_NUMB_OF_TIME * 60) / (MOTOR_COMMON_CTRL_PERIOD * MOTOR_COMMON_SENSOR_ENCD_CPR))
                                    /* toggle speed for high speed mode [rpm] (mechanical) */
#define SENSOR_ENCD_HS_CHANGE_RAD  ((float)(SENSOR_ENCD_HS_CHANGE_RPM * MTR_RPM2RAD))
                                    /* toggle speed for high speed mode [rad/s] (electrical) */
#define SENSOR_ENCD_HS_CHANGE_MARGIN_RPM    (150)
                                    /* margin of toggle speed for high speed mode [rpm] (mechanical)*/
#define SENSOR_ENCD_HS_CHANGE_MARGIN_RAD    (SENSOR_ENCD_HS_CHANGE_MARGIN_RPM * MTR_RPM2RAD)
                                    /* margin of toggle speed for high speed mode [rad/s] (electrical) */

/* Control loop mode */
#define SENSOR_ENCD_LOOP_POSITION           (0)
#define SENSOR_ENCD_LOOP_SPEED              (1)

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
typedef struct
{
    /* encoder */
    uint16_t u2_encd_pre_phase_cnt;                      /* previous value of encoder phase counter */
    uint32_t u4_encd_timer_cap_tcnt;                     /* current resister value */
    uint32_t u4_encd_timer_cap_pre_tcnt;                 /* previous resister value */
    uint16_t u2_encd_timer_cnt_num;                      /* u4_encd_timer_cnt_buff index */
    uint16_t u2_encd_cpr_mech;                           /* encoder counts per revolution (mechanical) */
    uint32_t u4_encd_timer_cnt_buff[SENSOR_ENCD_CNTAVG]; /* stored width of captured pulses */
    uint32_t u4_encd_pulse_width;                 /* stored captured pulse width */
    uint32_t u4_encd_pulse_width_buff;            /* stored captured pulse width buffer */
    uint32_t u4_encd_pulse_width_sum;             /* sum of last 4 pulse width */
    int32_t  s4_encd_angle_cnt;                   /* counter of encoder position */
    float    f4_encd_angle_diff;                  /* angle of encoder 1 pulse width */
    float    f4_encd_cpr_mech_inv;                /* inverse number of encoder counts per revolution (mechanical) */
    float    f4_encd_speed_pre_rad;               /* encoder speed of previous edge detection */
    float    f4_encd_speed_rad;                   /* encoder speed of current edge detection [rad/s] (mechanical) */
    float    f4_encd_pos_rad;                     /* encoder rotor position angle [rad] (mechanical) */
} st_encoder_t;

typedef struct
{
    /* encoder high speed */
    uint8_t  u1_encd_pos_speed_calc_mode;             /* position and speed calculation mode */
    uint8_t  u1_encd_interrupt_on_flag;               /* flag of encoder interrupt */
    uint8_t  u1_encd_pos_speed_calc_cnt;              /*`change counter */
    uint16_t u2_encd_hs_pre_phase_cnt;                /* previous value of encoder phase counter for high speed mode */
    int32_t  s4_encd_hs_angle_cnt;                    /* counter of encoder position for high speed mode  */
    float    f4_encd_hs_pos_rad;                      /* encoder rotor position angle [rad]
                                                         (mechanical) for high speed mode */
    float    f4_encd_hs_pos_pre_rad;                  /* previous value of encoder rotor position angle [rad]
                                                         (mechanical) for high speed mode */
    float    f4_encd_hs_speed_rad;                    /* encoder speed of current edge detection [rad/s] (mechanical)
                                                         for high speed mode */
    float    f4_encd_hs_speed_pre_rad;                /* previous value of encoder speed of current edge detection
                                                         [rad/s] (mechanical) for high speed mode */
    float    f4_encd_hs_sw_speed_rad;                 /* toggle speed for high speed mode [rad/s] (mechanical) */
    float    f4_encd_hs_sw_speed_margin_rad;          /* margin of toggle speed for high speed mode [rad/s]
                                                         (mechanical)*/
} st_encoder_highspeed_t;

typedef struct
{
    /* Hall */
    uint8_t  u1_hall_signal;                    /* Hall signal */
    uint8_t  u1_hall_pre_signal;                /* Previous value of hall signal */
    uint8_t  u1_hall_interrupt_flg;             /* Flag of hall interrupt */
    float    f4_hall_angle_rad;                 /* Using hall signal to set rotor initial angle [rad] */
} st_hall_t;

typedef struct
{
    uint8_t       u1_ctrl_loop_mode;
    float         f4_ctrl_period;               /* The control period */
    st_encoder_t            st_ec;              /* Encoder control structure */
    st_encoder_highspeed_t  st_ehc;             /* Encoder high speed control structure */
    st_hall_t               st_hc;              /* Hall control structure */
    st_motor_parameter_t    st_motor;           /* Motor mapameter structure */

    uint16_t (*EncdCntDataGet)(void);
    void (*EncdCntDataSet)(uint16_t u2_cnt_value);
    void (*EncdInterruptEnable)(void);
    void (*EncdInterruptDisable)(void);
    void (*EncdTimerStart)(void);
    uint32_t (*EncdTimerGet)(void);
    uint8_t (*HallSignalGet)(void);
    void (*HallUEnable)(void);
    void (*HallVEnable)(void);
    void (*HallWEnable)(void);
    void (*HallUDisable)(void);
    void (*HallVDisable)(void);
    void (*HallWDisable)(void);
} st_sensor_t;

extern st_sensor_t g_st_sensor;

typedef struct
{
    uint8_t     u1_ctrl_loop_mode;
    uint16_t    u2_encd_cpr;
    float       f4_hs_change_speed_rpm;
    float       f4_hs_change_margin_rpm;
    float       f4_ctrl_period;                 /* The control period */
    st_motor_parameter_t   st_motor;
} st_sensor_encoder_cfg_t;

typedef struct
{
    uint16_t (*EncdCntDataGet)(void);
    void (*EncdCntDataSet)(uint16_t u2_cnt_value);
    void (*EncdInterruptEnable)(void);
    void (*EncdInterruptDisable)(void);
    void (*EncdTimerStart)(void);
    uint32_t (*EncdTimerGet)(void);
    uint8_t (*HallSignalGet)(void);
    void (*HallUEnable)(void);
    void (*HallVEnable)(void);
    void (*HallWEnable)(void);
    void (*HallUDisable)(void);
    void (*HallVDisable)(void);
    void (*HallWDisable)(void);
} st_encoder_driver_cfg_t;

typedef struct
{
    float    f4_speed_rad;
    float    f4_pos_rad;
} st_sensor_encoder_output_t;

typedef struct
{
    float    f4_hall_angle_rad;
} st_sensor_hall_output_t;

/***********************************************************************************************************************
Exported global variables
***********************************************************************************************************************/
extern st_sensor_t g_st_sensor;

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_Open
* Description   : Open sensor module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_Open(void);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_Close
* Description   : Close sensor module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_Close(void);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_Reset
* Description   : Reset variables when encoder control start
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_Reset(st_sensor_t *p_st_sensor);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_ParameterGet
* Description   : Get variables when motor encoder control
* Arguments     : p_st_sensor         - The pointer to sensor structure
*                 p_st_encoder_output - The pointer to sensor output parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_ParameterGet(st_sensor_t *p_st_sensor, st_sensor_encoder_output_t *p_st_encoder_output);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_ParameterUpdate
* Description   : Update the sensor parameter
* Arguments     : p_st_sensor      - The pointer to sensor structure
*                 p_st_encoder_cfg - The pointer to sensor configuration parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_ParameterUpdate(st_sensor_t *p_st_sensor, const st_sensor_encoder_cfg_t *p_st_encoder_cfg);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_DriverParameterUpdate
* Description   : Update the sensor parameter
* Arguments     : p_st_sensor      - The pointer to sensor structure
*                 p_st_encoder_driver_cfg - The pointer to encoder driver configuration parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_DriverParameterUpdate(st_sensor_t *p_st_sensor,
        const st_encoder_driver_cfg_t *p_st_encoder_driver_cfg);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_PosSpdCalcInterrupt
* Description   : Rotor angle adjust process for carrier interrupt
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_PosSpdCalcInterrupt(st_sensor_t *p_st_sensor);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_PosSpdCalc
* Description   : calculate rotor position and speed
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_PosSpdCalc(st_sensor_t *p_st_sensor);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_ENCODER_HsCountDiffCalc
* Description   : Calculate the difference of encoder count
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_ENCODER_HsCountDiffCalc(st_sensor_t *p_st_sensor);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_HALL_ParameterGet
* Description   : Get variables when motor encoder control
* Arguments     : p_st_hc          - The pointer to hall control structure
*                 p_st_hall_output - The pointer to hall output parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_ParameterGet(st_hall_t *p_st_hc, st_sensor_hall_output_t *p_st_hall_output);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_HALL_AngleAdjustInit
* Description   : Initialize rotor angle using hall sensor signal
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : rotor angle of signal detected for hall sensor
***********************************************************************************************************************/
float R_MOTOR_SENSOR_HALL_AngleAdjustInit(st_sensor_t *p_st_sensor);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_HALL_AdjustInterrupt
* Description   : Rotor angle adjust process for Hall interrupt
* Arguments     : p_st_sensor  - The pointer to sensor structure
*                 u1_direction - rotational direction
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_AdjustInterrupt(st_sensor_t *p_st_sensor, uint8_t u1_direction);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_HALL_InterruptEnable
* Description   : Enables external(Hall) interrupt
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_InterruptEnable(st_sensor_t *p_st_sensor);

/***********************************************************************************************************************
* Function Name : R_MOTOR_SENSOR_HALL_InterruptDisable
* Description   : Disables external(Hall) interrupt
* Arguments     : p_st_sensor - The pointer to sensor structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_InterruptDisable(st_sensor_t *p_st_sensor);

#endif /* R_MOTOR_SENSOR_API_H */
