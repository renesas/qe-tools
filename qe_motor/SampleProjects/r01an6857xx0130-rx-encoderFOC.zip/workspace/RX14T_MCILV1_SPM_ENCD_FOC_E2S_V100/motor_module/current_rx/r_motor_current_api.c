/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_current_api.c
* Description : The current control module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 24.12.2021 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_motor_current.h"
#include "r_motor_current_api.h"

/***********************************************************************************************************************
* Exported global variables
***********************************************************************************************************************/
st_current_control_t      g_st_cc;           /* Current control structure */

/***********************************************************************************************************************
* Function Name : R_MOTOR_CURRENT_Open
* Description   : Open current control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_CURRENT_Open(void)
{
    float f4_pwm_period_us;
    float f4_duty_cycle_deadtime;
    float f4_max_duty_cycle;
    float f4_min_duty_cycle;
    st_current_control_t *p_st_cc;
    p_st_cc = &g_st_cc;

    p_st_cc->u1_flag_volt_err_comp_use       = CURRENT_CFG_VOLT_ERR_COMP;
    p_st_cc->u1_state_id_ref                 = CURRENT_STATE_ID_ZERO_CONST;
    p_st_cc->u1_state_iq_ref                 = CURRENT_STATE_IQ_ZERO_CONST;
    p_st_cc->u1_flag_offset_calc             = MTR_FLG_CLR;
    p_st_cc->u2_offset_calc_time             = CURRENT_CFG_OFFSET_CALC_TIME;
    p_st_cc->u2_crnt_offset_cnt              = 0;
    p_st_cc->f4_offset_iu                    = 0.0f;
    p_st_cc->f4_offset_iw                    = 0.0f;
    p_st_cc->f4_sum_iu_ad                    = 0.0f;
    p_st_cc->f4_sum_iw_ad                    = 0.0f;
    p_st_cc->f4_id_up_step                   = MOTOR_COMMON_ID_UP_STEP_RATE;
    p_st_cc->f4_ol_ref_id                    = CURRENT_CFG_REF_ID_OPENLOOP;
    p_st_cc->f4_speed_rad                    = 0.0f;
    p_st_cc->f4_rotor_angle_input_rad        = 0.0f;
    p_st_cc->f4_va_max                       = 0.0f;
    p_st_cc->f4_ctrl_period                  = MOTOR_COMMON_CTRL_PERIOD;
    p_st_cc->f4_id_ref_buff                  = 0.0f;
    p_st_cc->f4_lim_iq                       = MOTOR_COMMON_LIMIT_IQ;
    p_st_cc->st_pi_id.f4_ilimit              = CURRENT_CFG_PI_INTEGRAL_LIMIT_VD;
    p_st_cc->st_pi_iq.f4_ilimit              = CURRENT_CFG_PI_INTEGRAL_LIMIT_VQ;
    p_st_cc->st_motor.u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS;
    p_st_cc->st_motor.f4_mtr_r               = MOTOR_CFG_RESISTANCE;
    p_st_cc->st_motor.f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE;
    p_st_cc->st_motor.f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE;
    p_st_cc->st_motor.f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX;
    p_st_cc->st_motor.f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA;
    p_st_cc->st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS;

    /* Current pi control gain */
    motor_current_pi_gain_calc(p_st_cc, CURRENT_CFG_OMEGA, CURRENT_CFG_ZETA);
    /* Modulation */
    motor_current_mod_init(&(p_st_cc->st_mod));
    /* Voltage error compensation */
    motor_current_volt_err_comp_init(&(p_st_cc->st_volt_comp),VERROR_COMP_USE_UVW);
    /* Rotor angle parameter set */
    motor_current_rotor_angle_init(&(p_st_cc->st_rotor_angle));

    f4_pwm_period_us = (1000.0f / MOTOR_MCU_CFG_CARRIER_FREQ);
    f4_duty_cycle_deadtime = INVERTER_CFG_DEADTIME / f4_pwm_period_us;
    f4_min_duty_cycle = f4_duty_cycle_deadtime;
    f4_max_duty_cycle = (1.0f - (f4_duty_cycle_deadtime + (MOTOR_COMMON_AD_SAMPLING_TIME / f4_pwm_period_us)));
    motor_current_mod_max_duty_set(&p_st_cc->st_mod, f4_max_duty_cycle);
    motor_current_mod_min_duty_set(&p_st_cc->st_mod, f4_min_duty_cycle);
    motor_current_mod_volt_err_ratio_set(&p_st_cc->st_mod, f4_duty_cycle_deadtime);
    motor_current_volt_err_vlimit_set(&p_st_cc->st_volt_comp, CURRENT_VERR_COMP_LIMIT);

    R_MOTOR_CURRENT_Reset(p_st_cc);
} /* End of function R_MOTOR_CURRENT_Open */

/***********************************************************************************************************************
* Function Name : R_MOTOR_CURRENT_Close
* Description   : Close current control module
* Arguments     : None
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_CURRENT_Close(void)
{
    st_current_control_t *p_st_cc;
    p_st_cc = &g_st_cc;

    R_MOTOR_CURRENT_Reset(p_st_cc);

} /* End of function R_MOTOR_CURRENT_Close */

/***********************************************************************************************************************
* Function Name : R_MOTOR_CURRENT_Reset
* Description   : Resets current control module
* Arguments     : p_st_cc - The pointer to the current control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_CURRENT_Reset(st_current_control_t *p_st_cc)
{
    p_st_cc->u1_active           = MTR_FLG_CLR;

    p_st_cc->f4_vd_ref           = 0.0f;
    p_st_cc->f4_vq_ref           = 0.0f;
    p_st_cc->f4_ref_id_ctrl      = 0.0f;
    p_st_cc->f4_ref_iq_ctrl      = 0.0f;
    p_st_cc->f4_id_ref           = 0.0f;
    p_st_cc->f4_iq_ref           = 0.0f;
    p_st_cc->f4_id_ad            = 0.0f;
    p_st_cc->f4_iq_ad            = 0.0f;

    p_st_cc->st_pi_id.f4_err     = 0.0f;
    p_st_cc->st_pi_iq.f4_err     = 0.0f;
    p_st_cc->st_pi_id.f4_refi    = 0.0f;
    p_st_cc->st_pi_iq.f4_refi    = 0.0f;

    p_st_cc->f4_vdc_ad           = 0.0f;
    p_st_cc->f4_refu             = 0.0f;
    p_st_cc->f4_refv             = 0.0f;
    p_st_cc->f4_refw             = 0.0f;
    p_st_cc->f4_iu_ad            = 0.0f;
    p_st_cc->f4_iv_ad            = 0.0f;
    p_st_cc->f4_iw_ad            = 0.0f;
    p_st_cc->f4_modu             = 0.0f;
    p_st_cc->f4_modv             = 0.0f;
    p_st_cc->f4_modw             = 0.0f;

    motor_current_rotor_angle_reset(&(p_st_cc->st_rotor_angle));
} /* End of function R_MOTOR_CURRENT_Reset */

/***********************************************************************************************************************
* Function Name : R_MOTOR_CURRENT_Run
* Description   : Run current control module
* Arguments     : p_st_cc - The pointer to the current control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_CURRENT_Run(st_current_control_t *p_st_cc)
{
    p_st_cc->u1_active           = MTR_FLG_SET;
} /* End of function R_MOTOR_CURRENT_Run */

/***********************************************************************************************************************
* Function Name : R_MOTOR_CURRENT_ParameterSet
* Description   : Set the current control parameter
* Arguments     : p_st_cc            - The pointer to the current control structure
*                 p_st_current_input - The pointer to the current input parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_CURRENT_ParameterSet(st_current_control_t *p_st_cc, const st_current_input_t * p_st_current_input)
{
    p_st_cc->u1_state_id_ref = p_st_current_input->u1_state_id_ref;
    p_st_cc->u1_state_iq_ref = p_st_current_input->u1_state_iq_ref;
    p_st_cc->f4_iu_ad        = p_st_current_input->f4_iu_ad;
    p_st_cc->f4_iv_ad        = p_st_current_input->f4_iv_ad;
    p_st_cc->f4_iw_ad        = p_st_current_input->f4_iw_ad;
    p_st_cc->f4_vdc_ad       = p_st_current_input->f4_vdc_ad;
    p_st_cc->f4_iq_ref       = p_st_current_input->f4_iq_ref;
    p_st_cc->f4_id_ref       = p_st_current_input->f4_id_ref;
    p_st_cc->f4_speed_rad    = p_st_current_input->f4_speed_rad;
    p_st_cc->f4_rotor_angle_input_rad = p_st_current_input->f4_rotor_angle_rad;
} /* End of function R_MOTOR_CURRENT_ParameterSet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_CURRENT_ParameterGet
* Description   : Get the current control parameter
* Arguments     : p_st_cc             - The pointer to the current control structure
*                 p_st_current_output - The pointer to the current control output parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_CURRENT_ParameterGet(st_current_control_t *p_st_cc, st_current_output_t *p_st_current_output)
{
    p_st_current_output->f4_modu             = p_st_cc->f4_modu;
    p_st_current_output->f4_modv             = p_st_cc->f4_modv;
    p_st_current_output->f4_modw             = p_st_cc->f4_modw;
    p_st_current_output->f4_va_max           = p_st_cc->f4_va_max;
    p_st_current_output->u1_flag_offset_calc = p_st_cc->u1_flag_offset_calc;
    p_st_current_output->f4_neutral_duty     = p_st_cc->st_mod.f4_neutral_duty;
} /* End of function R_MOTOR_CURRENT_ParameterGet */

/***********************************************************************************************************************
* Function Name : R_MOTOR_CURRENT_ParameterUpdate
* Description   : Update the current control parameter
* Arguments     : p_st_cc          - The pointer to the current control structure
*                 p_st_current_cfg - The pointer to the current control configuration parameter structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_CURRENT_ParameterUpdate(st_current_control_t *p_st_cc, const st_current_cfg_t *p_st_current_cfg)
{
    float f4_ia_max;
    p_st_cc->u1_flag_volt_err_comp_use = p_st_current_cfg->u1_flag_volt_err_comp_use;
    p_st_cc->u2_offset_calc_time = p_st_current_cfg->u2_offset_calc_time;
    p_st_cc->f4_ctrl_period      = p_st_current_cfg->f4_ctrl_period;
    p_st_cc->f4_ol_ref_id        = p_st_current_cfg->f4_ol_ref_id;
    p_st_cc->f4_id_up_step       = p_st_current_cfg->f4_id_up_step;
    p_st_cc->st_motor            = p_st_current_cfg->st_motor;
    f4_ia_max                    = p_st_cc->st_motor.f4_nominal_current_rms * MOTOR_COMMON_CFG_IA_MAX_CALC_MULT;
    p_st_cc->f4_lim_iq           = f4_ia_max;

    /* The dq-axis current PI gains */
    motor_current_pi_gain_calc(p_st_cc, p_st_current_cfg->f4_current_omega_hz, p_st_current_cfg->f4_current_zeta);
} /* End of function R_MOTOR_CURRENT_ParameterUpdate */

/***********************************************************************************************************************
* Function Name : R_MOTOR_CURRENT_CurrentCyclic
* Description   : The cyclic processing of current control
* Arguments     : p_st_cc       - The cyclic processing of current control
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_CURRENT_CurrentCyclic(st_current_control_t *p_st_cc)
{
    float f4_angle_rad;

    if (MTR_FLG_SET == p_st_cc->u1_active)
    {
        motor_current_mod_vdc_set(&p_st_cc->st_mod, p_st_cc->f4_vdc_ad);

        p_st_cc->f4_ref_iq_ctrl = motor_current_reference_iq_set(p_st_cc);
        p_st_cc->f4_ref_id_ctrl = motor_current_reference_id_set(p_st_cc);

        /*=============================================*/
        /*     Coordinate transformation (UVW->dq)     */
        /*=============================================*/
        motor_current_rotor_angle_update(&p_st_cc->st_rotor_angle, p_st_cc->f4_rotor_angle_input_rad);
        motor_current_transform_uvw_dq_abs(&p_st_cc->st_rotor_angle, &(p_st_cc->f4_iu_ad), &(p_st_cc->f4_id_ad));

        /*====================================*/
        /*     Feedback control (Current)     */
        /*====================================*/
        motor_current_pi_control(p_st_cc);

        /*============================*/
        /*     Decoupling control     */
        /*============================*/
        motor_current_decoupling(p_st_cc, p_st_cc->f4_speed_rad, &(p_st_cc->st_motor));

        /*======================*/
        /* Limit voltage vector */
        /*======================*/
        motor_current_volt_limit(p_st_cc);

        /* Phase value considering voltage conversion timing */
        f4_angle_rad = motor_current_control_smpldly_comp(p_st_cc, p_st_cc->f4_rotor_angle_input_rad,
                p_st_cc->f4_speed_rad);
        motor_current_rotor_angle_update(&p_st_cc->st_rotor_angle, f4_angle_rad);

        /*=================================================*/
        /*     Coordinate transformation (dq->uvw)         */
        /*=================================================*/
        motor_current_transform_dq_uvw_abs(&p_st_cc->st_rotor_angle, &(p_st_cc->f4_vd_ref), &p_st_cc->f4_refu);

        /*====================================*/
        /*     Voltage error compensation     */
        /*====================================*/
        if ((MTR_FLG_SET == p_st_cc->u1_flag_volt_err_comp_use) && (MTR_FLG_SET == p_st_cc->u1_flag_offset_calc))
        {
            float f4_iuvw_ref[3];
            motor_current_transform_dq_uvw_abs(&p_st_cc->st_rotor_angle, &(p_st_cc->f4_ref_id_ctrl), f4_iuvw_ref);
            motor_current_volt_err_comp_main(&(p_st_cc->st_volt_comp),
                    &p_st_cc->f4_refu, f4_iuvw_ref, p_st_cc->f4_vdc_ad);
        }

        /*==================================*/
        /*     Space vector modulation      */
        /*==================================*/
        motor_current_mod_start(&(p_st_cc->st_mod), &p_st_cc->f4_refu, &p_st_cc->f4_modu);
    }
} /* End of function R_MOTOR_CURRENT_CurrentCyclic */

/***********************************************************************************************************************
* Function Name : R_MOTOR_CURRENT_OffsetCalibration
* Description   : Measures the current offset
* Arguments     : p_st_cc - The pointer to the current control structure
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_CURRENT_OffsetCalibration(st_current_control_t *p_st_cc)
{
    p_st_cc->f4_offset_iu = 0.0f;
    p_st_cc->f4_offset_iw = 0.0f;
    /*==================================*/
    /*    Current offset calibration    */
    /*==================================*/
    p_st_cc->u2_crnt_offset_cnt++;
    if (p_st_cc->u2_offset_calc_time <= p_st_cc->u2_crnt_offset_cnt)
    {
        p_st_cc->u1_flag_offset_calc = MTR_FLG_SET;
        p_st_cc->u2_crnt_offset_cnt  = p_st_cc->u2_offset_calc_time;
        p_st_cc->f4_offset_iu = p_st_cc->f4_sum_iu_ad / p_st_cc->u2_offset_calc_time;
        p_st_cc->f4_offset_iw = p_st_cc->f4_sum_iw_ad / p_st_cc->u2_offset_calc_time;
    }
    else
    {
        p_st_cc->f4_sum_iu_ad += p_st_cc->f4_iu_ad;
        p_st_cc->f4_sum_iw_ad += p_st_cc->f4_iw_ad;
    }
} /* End of function R_MOTOR_CURRENT_OffsetCalibration */

/***********************************************************************************************************************
* Function Name : R_MOTOR_CURRENT_CurrentOffsetRemove
* Description   : Calibrates the current offset
* Arguments     : p_st_cc - The pointer to the current control structure
*                 p_f4_iu - The pointer to measured phase u current
*                 p_f4_iw - The pointer to measured phase w current
* Return Value  : None
***********************************************************************************************************************/
void R_MOTOR_CURRENT_CurrentOffsetRemove(st_current_control_t *p_st_cc, float *p_f4_iu, float *p_f4_iw)
{
    /* Current offset adjustment */
    *p_f4_iu = (*p_f4_iu) - p_st_cc->f4_offset_iu;
    *p_f4_iw = (*p_f4_iw) - p_st_cc->f4_offset_iw;
} /* End of function R_MOTOR_CURRENT_CurrentOffsetRemove */

/**********************************************************************************************************************
 * Function Name: R_MOTOR_CURRENT_VoltErrCompParamSet
 * Description  : Set voltage error compensation parameters
 * Arguments    : p_st_cc -
 *                   The pointer to the current control structure
 *                crnt_array -
 *                   The current array [A]
 *                volterr_array
 *                   The voltage error array [V]
 *                ref_voltage
 *                   The DC bus voltage that table created for
 * Return Value : None
 *********************************************************************************************************************/
void R_MOTOR_CURRENT_VoltErrCompParamSet(st_current_control_t *p_st_cc,
                                         const float *crnt_array,
                                         const float *volterr_array,
                                         float ref_voltage)
{
    motor_current_volt_err_comp_table_set(&p_st_cc->st_volt_comp, crnt_array, volterr_array, ref_voltage);
} /* End of function R_MOTOR_CURRENT_VoltErrCompParamSet */
