/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_hall_vector_manager.h
* Description : Definitions of motor control processes
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 30.10.2024 1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* guard against multiple inclusion */
#ifndef R_MOTOR_HALL_VECTOR_MANAGER_H
#define R_MOTOR_HALL_VECTOR_MANAGER_H

#include <stdint.h>
#include "r_motor_hall_vector_api.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Run mode */
#define     MOTOR_HALL_VECTOR_MODE_OFFSET_ADJUST       (0)
#define     MOTOR_HALL_VECTOR_MODE_DRIVE               (1)

/* Offset adjust mode */
#define     MOTOR_HALL_VECTOR_OFAJ_CURRENT_OFFSET      (0)
#define     MOTOR_HALL_VECTOR_OFAJ_FIN                 (1)

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name : motor_hall_vector_default_init
* Description   : Initializes motor drive modules with default configuration
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_default_init(st_hall_vector_control_t * p_st_hall_vector);

/***********************************************************************************************************************
* Function Name : motor_hall_vector_reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_reset(st_hall_vector_control_t * p_st_hall_vector);

/***********************************************************************************************************************
* Function Name : motor_hall_vector_error_process
* Description   : Sets error flags and trigger error event when u2_error_flag is not zero
* Arguments     : st_foc - The pointer to the FOC data structure
*                 u2_error_flag - The error flags of the errors to report
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_error_process(st_hall_vector_control_t * p_st_hall_vector, uint16_t u2_error_flag);

/***********************************************************************************************************************
* Function Name : motor_hall_vector_decide_direction
* Description   : Updates direction by sign of electrical speed
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_decide_direction(st_hall_vector_control_t * p_st_hall_vector);

/***********************************************************************************************************************
* Function Name : motor_hall_vector_angle_speed_select
* Description   : Angle and speed detection
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_angle_speed_select(st_hall_vector_control_t * p_st_hall_vector);

/***********************************************************************************************************************
* Function Name : motor_hall_vector_ref_state_update
* Description   : Set references state
* Arguments     : st_foc - The pointer to the FOC data structure
* Return Value  : none
***********************************************************************************************************************/
void motor_hall_vector_ref_state_update(st_hall_vector_control_t * p_st_hall_vector);

/***********************************************************************************************************************
* Function Name : motor_hall_vector_nominal_current_set
* Description   : Setup current related limit values by the nominal current of motor
* Arguments     : st_foc - The pointer to the FOC current control structure
*               : f4_nominal_current_rms - The nominal current[Arms] of motor
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_nominal_current_set(st_hall_vector_control_t * p_st_hall_vector, float f4_nominal_current_rms);

/***********************************************************************************************************************
* Function Name : motor_hall_vector_module_activate
* Description   : Activate modules
* Arguments     : p_st_hall_vector - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_module_activate(st_hall_vector_control_t * p_st_hall_vector);
#endif /* R_MOTOR_HALL_VECTOR_MANAGER_H */
