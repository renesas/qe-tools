/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_hall_vector_action.c
* Description : The implementations of action functions required by FOC state machine
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 30.10.2024 1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <stdint.h>

/* Main associated header file */
#include "r_motor_hall_vector_api.h"
#include "r_motor_hall_vector_manager.h"

/* Project headers */
#include "r_motor_common.h"
#include "r_motor_hall_vector_statemachine.h"
#include "r_motor_driver.h"

/***********************************************************************************************************************
* Function Name : motor_hall_vector_act_active
* Description   : Activates the motor control system and enables PWM output
* Arguments     : p_st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t motor_hall_vector_act_active(st_statemachine_t * p_st_stm, void * p_param)
{
    st_hall_vector_control_t * p_st_foc = p_param;

    motor_hall_vector_reset(p_st_foc);             /* Initialize variables when motor control start */
    p_st_foc->u1_flag_charge_cap =  MTR_FLG_SET;           /* Start detecting under voltage error */
    motor_hall_vector_ref_state_update(p_st_foc);
    motor_hall_vector_module_activate(p_st_foc);
    R_MOTOR_DRIVER_BldcDutySet(p_st_foc->p_st_driver, 0.5f, 0.5f, 0.5f);
    if (p_st_foc->u1_offset_adjust_mode != MOTOR_HALL_VECTOR_OFAJ_CURRENT_OFFSET)
    {
        R_MOTOR_DRIVER_PWMControlStart(p_st_foc->p_st_driver); /* PWM output enable */
    }

    return (0);
} /* End of function motor_hall_vector_act_active */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_act_inactive
* Description   : Deactivates the motor control system and disables PWM output
* Arguments     : p_st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t motor_hall_vector_act_inactive(st_statemachine_t * p_st_stm, void * p_param)
{
    st_hall_vector_control_t * p_st_foc = p_param;

    R_MOTOR_DRIVER_PWMControlStop(p_st_foc->p_st_driver);                   /* PWM output disable */
    R_MOTOR_DRIVER_BldcDutySet(p_st_foc->p_st_driver, 0.5f, 0.5f, 0.5f);
    motor_hall_vector_reset(p_st_foc);                  /* Initialize variables when motor control start */

    return (0);
} /* End of function motor_hall_vector_act_inactive */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_act_nowork
* Description   : The empty dummy function used to fill the blank in action table
* Arguments     : p_st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : Always success (0)
***********************************************************************************************************************/
uint8_t motor_hall_vector_act_nowork(st_statemachine_t * p_st_stm, void * p_param)
{
    /* Do Nothing */

    return (0);
} /* End of function motor_hall_vector_act_nowork */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_act_reset
* Description   : Resets the configurations to default and clear error flags
* Arguments     : p_st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t motor_hall_vector_act_reset(st_statemachine_t * p_st_stm, void * p_param)
{
    st_hall_vector_control_t * p_st_foc = p_param;

    p_st_foc->u2_error_status = MOTOR_ERROR_NONE;
    motor_hall_vector_default_init(p_st_foc);

    return (0);
} /* End of function motor_hall_vector_act_reset */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_act_error
* Description   : Executes the post-processing (include stopping the PWM output) when an error has been detected
* Arguments     : p_st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t motor_hall_vector_act_error(st_statemachine_t * p_st_stm, void * p_param)
{
    st_hall_vector_control_t * p_st_foc = p_param;

    R_MOTOR_DRIVER_PWMControlStop(p_st_foc->p_st_driver);                       /* PWM output disable */

    return (0);
} /* End of function motor_hall_vector_act_error */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_act_error_cancel
* Description   : Resets the configurations to default and clear error flags
* Arguments     : p_st_stm - The pointer to the state machine structure
*                 p_param - The pointer to the FOC structure
* Return Value  : The result of action, Always success(0)
***********************************************************************************************************************/
uint8_t motor_hall_vector_act_error_cancel(st_statemachine_t * p_st_stm, void * p_param)
{
    st_hall_vector_control_t * p_st_foc = p_param;

    p_st_foc->u2_error_status = MOTOR_ERROR_NONE;
    motor_hall_vector_reset(p_st_foc);

    return (0);
} /* End of function motor_hall_vector_act_error_cancel */
