/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2024 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_motor_module_cfg.h
* Description  : Compile-time configurations
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 30.10.2024 1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_MOTOR_MODULE_CFG_H
#define R_MOTOR_MODULE_CFG_H

#include "r_motor_common.h"
#include "r_motor_targetmotor_cfg.h"
#include "r_motor_inverter_cfg.h"
#include "r_smc_entry.h"
/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/**
 * Middle ware Layer Configurations
 */
/*
 * Software system configurations
 */
/*
 * for MCU
 */
#define     MOTOR_MCU_CFG_PWM_TIMER_FREQ        (120.0f)                        /* PWM timer frequency [MHz] */
#define     MOTOR_MCU_CFG_CARRIER_FREQ          (20.0f)                         /* Carrier wave frequency [kHz] */
#define     MOTOR_MCU_CFG_INTR_DECIMATION       (0)                             /* Interrupt skipping number */
#define     MOTOR_MCU_CFG_AD_FREQ               (60.0f)                         /* A/D frequency [MHz] */
#define     MOTOR_MCU_CFG_AD_SAMPLING_CYCLE     (2.0f * (7.25f + 63.0f))        /* twice the (Scan start processing time(tD) + sample-and-hold processing time(tSPLSH)) [cycle] */
#define     MOTOR_MCU_CFG_AD12BIT_DATA          (4095.0f)                       /* A/D 12Bit data */
#define     MOTOR_MCU_CFG_ADC_OFFSET            (0x7FF)                         /* A/D offset */

#if defined(__TFU)
#define     MOTOR_MCU_CFG_TFU_OPTIMIZE          (MTR_ENABLE)                    /* TFU Optimization */
#else
#define     MOTOR_MCU_CFG_TFU_OPTIMIZE          (MTR_DISABLE)
#endif


/*
 * Motor control common configurations
 */
#define MOTOR_TYPE_BLDC     /* The motor used is BLDC. */

/* Select control loop mode
* - MOTOR_LOOP_SPEED(default)
*/
#define     MOTOR_COMMON_CFG_LOOP_MODE                  (MOTOR_LOOP_SPEED)

#define     MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT    (2.0f)

#define     MOTOR_COMMON_CFG_IA_MAX_CALC_MULT           (MTR_SQRT_3)

/* Vector */
/**
 *  Delay in [sec] before starting adjust current offset after power on
 * */
#define     MOTOR_COMMON_CFG_AUTO_OFFSET_ADJUST_DELAY    (0.5f)

/*
 * for Current Module(current_rx)
 */
/* Defines whether use voltage error compensation in FOC */
#define     CURRENT_CFG_VOLT_ERR_COMP           (MTR_ENABLE)

/* Select modulation method
* - MOD_METHOD_SPWM
* - MOD_METHOD_SVPWM(default)
*/
#define     CURRENT_CFG_MODULATION_METHOD       (MOD_METHOD_SVPWM)

#define     CURRENT_CFG_OFFSET_CALC_TIME        (512.0f)                             /* Current offset calculation time */
#define     CURRENT_CFG_OFFSET_CALC_WAIT        (4000)                               /* Counter for current offset detection start timing */
#define     CURRENT_CFG_PERIOD_MAG_VALUE        (0.5f)                               /* Period magnification value for coordinate transformation */
#define     CURRENT_CFG_PI_INTEGRAL_LIMIT_VD    (INVERTER_CFG_INPUT_V * 0.5f)        /* Current PI integral term limit for vd */
#define     CURRENT_CFG_PI_INTEGRAL_LIMIT_VQ    (INVERTER_CFG_INPUT_V * 0.5f)        /* Current PI integral term limit for vq */
#define     CURRENT_CFG_OMEGA                   (300.0f)                             /* natural frequency for current loop */
#define     CURRENT_CFG_ZETA                    (1.0f)                               /* damping ratio for current loop */
#define     CURRENT_CFG_RATE_LIMIT              (0.0004f)                            /* The change limit of current command in manual mode */


/*
 * for Speed Module(speed_rx)
 */
/* Defines whether use flux-weakening in FOC */
#define     SPEED_CFG_FLUX_WEAKENING            (MTR_ENABLE)

#define     SPEED_CFG_CTRL_PERIOD               (0.0005f)       /* control period for speed loop */
#define     SPEED_CFG_OMEGA                     (5.0f)          /* natural frequency for speed loop */
#define     SPEED_CFG_ZETA                      (1.0f)          /* damping ratio for speed loop */
#define     SPEED_CFG_SPEED_LIMIT_RPM           (2850.0f)       /* over speed limit [rpm] (mechanical angle) */
#define     SPEED_CFG_RATE_LIMIT_RPM            (1000.0f)       /* Rate limit of speed change [rpm/s] */
#define     SPEED_CFG_FRICTION_BRAKE_SPEED      (1.0f)          /* The brake speed for friction compensation */
#define     SPEED_CFG_FRICTION_COULOMBS         (0.15f)         /* The Iq to compensate coulombs friction [A] */
#define     SPEED_CFG_FRICTION_STATIC           (0.3f)          /* The Iq to compensate static friction [A] */
#define     SPEED_CFG_FRICTION_VISCOUS_COEF     (0.0f)          /* The Iq based viscous friction [A/(rad/s)] */

/*
 * Hall Sensor Configuration
 */
/* HALL Sensor module */
/** The sampling frequency of hall sensor module [kHz], which is the same of current control */
#define     SENSOR_HALL_CFG_CTRL_FREQ                 ((MOTOR_MCU_CFG_CARRIER_FREQ) / (MOTOR_MCU_CFG_INTR_DECIMATION + 1))

/** The number of pole pairs of hall sensor, which is the same as the number of pole pairs of motor */
#define     SENSOR_HALL_CFG_HALL_POLEPAIRS            (MOTOR_CFG_POLE_PAIRS)

/** The hall signal values assumed to be read by driver function  (@ref DRIVER_HALL_CFG_FUNC_GET_HALL_SIGNAL),
 *  when the rotor is in the respective sector 1 ~ 6 */
#define     SENSOR_HALL_CFG_PATTERN_1                 (1)   /* Hall effect sensor signal pattern1 */
#define     SENSOR_HALL_CFG_PATTERN_2                 (5)   /* Hall effect sensor signal pattern2 */
#define     SENSOR_HALL_CFG_PATTERN_3                 (4)   /* Hall effect sensor signal pattern3 */
#define     SENSOR_HALL_CFG_PATTERN_4                 (6)   /* Hall effect sensor signal pattern4 */
#define     SENSOR_HALL_CFG_PATTERN_5                 (2)   /* Hall effect sensor signal pattern5 */
#define     SENSOR_HALL_CFG_PATTERN_6                 (3)   /* Hall effect sensor signal pattern6 */

/** The angle correction value[rad],  will be added to the estimated angle */
#define     SENSOR_HALL_CFG_ANGLE_CORRECT             (0.0f)/* Default angle correction [rad] */

/** Default counts for period of hall signal to reset */
#define     SENSOR_HALL_CFG_DEFAULT_COUNTS            (4000)

/** Maximum counts of sample period, also, the speed will be estimated as 0 when the interval of hall signal change
 *  is above this value */
#define     SENSOR_HALL_CFG_MAXIMUM_PERIOD            (5000)

/** Speed mixing switching threshold in [rad/s], the weight of more precise speed estimation will increase
 *  very fast above this value */
#define     SENSOR_HALL_CFG_SPEED_MIX_TH              (SPEED_CFG_OMEGA * MTR_TWOPI * 30.0f / 6.0f)

/** Speed mixing deviation threshold (0 ~ 1), if the deviation ratio is above this value,
  *  the weight of faster speed estimation will be increased */
#define     SENSOR_HALL_CFG_SPEED_DEVIATION_TOLERANCE (0.1f)

/** The default value of speed select @ref motor_sensor_hall_speed_select_t */
#define     SENSOR_HALL_CFG_SPEED_SELECT              (MOTOR_SENSOR_HALL_SPEED_SELECT_AUTO)

/** HALL Driver function */
#define     DRIVER_HALL_CFG_FUNC_GET_HALL_SIGNAL      (R_Config_PORT_GetHallSignal)

/*
 * for Driver Module(driver_rx)
 */
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_START        (R_Config_MOTOR_StartTimerCtrl)
                                                        /* The StartTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_PWM_OUTPUT_STOP         (R_Config_MOTOR_StopTimerCtrl)
                                                        /* The StopTimerCtrl function of motor component */
#define     DRIVER_CFG_FUNC_ADC_DATA_GET            (R_Config_MOTOR_AdcGetConvVal)
                                                        /* The AdcGetConvVal function of motor component */
#define     DRIVER_CFG_FUNC_DUTY_SET                (R_Config_MOTOR_UpdDuty)
                                                        /* The UpdDuty function of motor component */
/*
 * other
 */
#define     MOTOR_COMMON_AD_SAMPLING_TIME       (MOTOR_MCU_CFG_AD_SAMPLING_CYCLE / MOTOR_MCU_CFG_AD_FREQ)
                                                        /* A/D sampling time [us] */
#define     MOTOR_COMMON_CARRIER_SET_BASE       ((uint16_t)(MOTOR_MCU_CFG_PWM_TIMER_FREQ * 1000 / MOTOR_MCU_CFG_CARRIER_FREQ / 2))
#define     MOTOR_COMMON_DEADTIME_SET           ((uint16_t)(INVERTER_CFG_DEADTIME * MOTOR_MCU_CFG_PWM_TIMER_FREQ))
                                                        /* Setting value of deadtime */
#define     MOTOR_COMMON_CTRL_PERIOD            ((MOTOR_MCU_CFG_INTR_DECIMATION + 1) / (MOTOR_MCU_CFG_CARRIER_FREQ * 1000))
                                                        /* Control period */
/****** Macro of current control*****/
#define     MOTOR_COMMON_PI_INTEGRAL_LIMIT_IQ   (MOTOR_CFG_NOMINAL_CURRENT_RMS * MTR_SQRT_3)
                                                        /* speed PI integral term limit for iq */
#define     MOTOR_COMMON_LIMIT_IQ               (MOTOR_CFG_NOMINAL_CURRENT_RMS * MTR_SQRT_3)
                                                        /* speed PI limit for iq */
#define     MOTOR_COMMON_CURRENT_OBS_LIMIT      (MOTOR_CFG_NOMINAL_CURRENT_RMS * MTR_SQRT_3 * 3.0f)
                                                        /* Integration limit value of voltage disturbance estimate */
#define     MOTOR_COMMON_OVERCURRENT_LIMIT      (MOTOR_CFG_NOMINAL_CURRENT_RMS * MTR_SQRT_2 * MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT)
                                                        /* Over current limit [A] */

#endif /* R_MOTOR_MODULE_CFG_H */
