/*
* Copyright (c) 2016 - 2025 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/

/***********************************************************************************************************************
* File Name        : Config_PORT.c
* Component Version: 2.4.1
* Device(s)        : R5F514T5AxFM
* Description      : This file implements device driver for Config_PORT.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_PORT.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_motor_common.h"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_PORT_Create
* Description  : This function initializes the PORT
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_PORT_Create(void)
{
    /* Set PORT9 registers */
    PORT9.ODR0.BYTE = _00_Pm1_CMOS_OUTPUT;
    PORT9.ODR1.BYTE = _00_Pm4_CMOS_OUTPUT | _00_Pm5_CMOS_OUTPUT | _00_Pm6_CMOS_OUTPUT | _00_Pm7_CMOS_OUTPUT;
    PORT9.PCR.BYTE = _00_Pm0_PULLUP_OFF | _00_Pm2_PULLUP_OFF | _00_Pm3_PULLUP_OFF;
    PORT9.PMR.BYTE = _00_Pm0_PIN_GPIO | _00_Pm2_PIN_GPIO | _00_Pm3_PIN_GPIO;
    PORT9.PDR.BYTE = _00_Pm0_MODE_INPUT | _00_Pm2_MODE_INPUT | _00_Pm3_MODE_INPUT;

    /* Set PORTD registers */
    PORTD.PODR.BYTE = _08_Pm3_OUTPUT_1 | _10_Pm4_OUTPUT_1 | _40_Pm6_OUTPUT_1;
    PORTD.ODR0.BYTE = _00_Pm3_CMOS_OUTPUT;
    PORTD.ODR1.BYTE = _00_Pm4_CMOS_OUTPUT | _00_Pm5_CMOS_OUTPUT | _00_Pm6_CMOS_OUTPUT;
    PORTD.PCR.BYTE = _00_Pm7_PULLUP_OFF;
    PORTD.PMR.BYTE = _00_Pm3_PIN_GPIO | _00_Pm4_PIN_GPIO | _00_Pm6_PIN_GPIO | _00_Pm7_PIN_GPIO;
    PORTD.PDR.BYTE = _08_Pm3_MODE_OUTPUT | _10_Pm4_MODE_OUTPUT | _40_Pm6_MODE_OUTPUT | _00_Pm7_MODE_INPUT | 
                     _07_PDRD_DEFAULT;

    /* Set PORTE registers */
    PORTE.PMR.BYTE = _00_Pm2_PIN_GPIO;

    R_Config_PORT_Create_UserInit();
}

/* Start user code for adding. Do not edit comment generated here */
/******************************************************************************
* Function Name : R_Config_PORT_GetSW1
* Description   : Get state of SW1
* Arguments     : none
* Return Value  : state of SW1
******************************************************************************/
uint8_t R_Config_PORT_GetSW1(void)
{
    return(PORTD.PIDR.BIT.B7);
} /* End of function R_Config_PORT_GetSW1 */

/******************************************************************************
* Function Name : R_Config_PORT_GetSW2
* Description   : Get state of SW2
* Arguments     : none
* Return Value  : state of SW2
******************************************************************************/
uint8_t R_Config_PORT_GetSW2(void)
{
    return (PORTE.PIDR.BIT.B2);
} /* End of function R_Config_PORT_GetSW2 */

/******************************************************************************
* Function Name : R_Config_PORT_Led1_on
* Description   : Turn on LED1
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_Config_PORT_Led1_on(void)
{
    PORTD.PODR.BIT.B3 = MTR_LED_ON;
} /* End of function R_Config_PORT_Led1_on */

/******************************************************************************
* Function Name : R_Config_PORT_Led2_on
* Description   : Turn on LED2
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_Config_PORT_Led2_on(void)
{
    PORTD.PODR.BIT.B4 = MTR_LED_ON;
} /* End of function R_Config_PORT_Led2_on */

/******************************************************************************
* Function Name : R_Config_PORT_Led1_off
* Description   : Turn off LED1
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_Config_PORT_Led1_off(void)
{
    PORTD.PODR.BIT.B3 = MTR_LED_OFF;
} /* End of function R_Config_PORT_Led1_off */

/******************************************************************************
* Function Name : R_Config_PORT_Led2_off
* Description   : Turn off LED2
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_Config_PORT_Led2_off(void)
{
    PORTD.PODR.BIT.B4 = MTR_LED_OFF;
} /* End of function R_Config_PORT_Led2_off */

/******************************************************************************
* Function Name : R_Config_PORT_Led3_on
* Description   : Turn on LED3
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_Config_PORT_Led3_on(void)
{
    PORTD.PODR.BIT.B6 = MTR_LED_ON;
} /* End of function R_Config_PORT_Led1_on */

/******************************************************************************
* Function Name : R_Config_PORT_Led3_off
* Description   : Turn off LED2
* Arguments     : none
* Return Value  : none
******************************************************************************/
void R_Config_PORT_Led3_off(void)
{
    PORTD.PODR.BIT.B6 = MTR_LED_OFF;
} /* End of function R_Config_PORT_Led2_off */

/******************************************************************************
* Function Name : R_Config_PORT_GetHallSignal
* Description   : Get the bits of each hall signals from IO port respectively
* Arguments     : u1_bit_u - The address to store the U signal
*                 u1_bit_v - The address to store the V signal
*                 u1_bit_w - The address to store the W signal
* Return Value  : none
******************************************************************************/
void R_Config_PORT_GetHallSignal(uint8_t * u1_bit_u, uint8_t * u1_bit_v, uint8_t * u1_bit_w)
{
    *u1_bit_u = PORT9.PIDR.BIT.B2;
    *u1_bit_v = PORT9.PIDR.BIT.B3;
    *u1_bit_w = PORT9.PIDR.BIT.B0;
}

/* End user code. Do not edit comment generated here */
