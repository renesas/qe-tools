#ifndef __ICS2_RX14T_H__
#define __ICS2_RX14T_H__

#include <stdint.h>

#define   ICS_SCI1_PB5_PB6   (0x10U)
#define   ICS_SCI5_P23_P24   (0x50U)


void     ics2_init(void * addr, uint8_t port, uint8_t level, uint8_t speed, uint8_t mode);
void     ics2_watchpoint(void);
uint32_t ics2_version(void);

void ics_int_sci_rxi(void);
void ics_int_sci_eri(void);

#endif /* __ICS2_RX14T_H__ */
