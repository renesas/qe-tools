/**********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/******************************************************************************************************************//**
 * @file          r_motor_hall_vector_api.h
 * @version       1.00
 * @brief         The APIs for hall effect sensor vector control
 *********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 30.10.2024 1.00     First Release
***********************************************************************************************************************/
/**********************************************************************************************************************
 * Includes <System Includes> , "Project Includes"
 *********************************************************************************************************************/
/* Guard against multiple inclusion */
#ifndef R_MOTOR_HALL_VECTOR_API_H
#define R_MOTOR_HALL_VECTOR_API_H

#include <stdint.h>
#include <stdbool.h>
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"
#include "r_motor_driver.h"
#include "r_motor_sensor_hall_api.h"
#include "r_motor_current_api.h"
#include "r_motor_speed_api.h"
#include "r_motor_hall_vector_statemachine.h"

/*******************************************************************************************************************//**
 * @defgroup MOTOR_HALL_VECTOR Hall Vector Control Module
 * @brief    Vector control base on the angle/speed estimation from 3 phase unipolar type Hall Efferct Sensor
 * @section  Overview
 *            | Item                  | Description                                       |
 *            | ----------------------|---------------------------------------------------|
 *            | Motor Control         | Vector Control (FOC)                              |
 *            | Rotor Angle           | Hall Effect Sensor (interpolated by zeroth order) |
 *            | Speed                 | Speed estimation (hall signal change interval)    |
 *            | Current Control       | PI type current control                           |
 *            | Speed Control         | PI type speed control                             |
 *            | Position Control      | Not Supported                                     |
 **********************************************************************************************************************/
/*******************************************************************************************************************//**
 * @defgroup MOTOR_HALL_VECTOR_API Hall Vector Control API
 * @ingroup MOTOR_HALL_VECTOR
 * @brief The functions that is supposed to be called from the application layer to control the motor using the Hall-
 * Vector control algorithm.
 * @{
 **********************************************************************************************************************/
/**********************************************************************************************************************
 * Macro definitions
 *********************************************************************************************************************/
/**
 * @defgroup MOTOR_HALL_VECTOR_API_LOOP_MODE Control Loop Mode
 * @brief The type of top-level control loop
 * @{
 *  */
#define     MOTOR_LOOP_CURRENT_ID           (0) ///< Open-loop current control loop mode
#define     MOTOR_LOOP_CURRENT_IQ           (1) ///< Closed-loop torque control loop mode
#define     MOTOR_LOOP_SPEED                (2) ///< Closed-loop speed control loop mode
#define     MOTOR_LOOP_POSITION             (3) ///< Closed-loop position control loop mode, @warning Not supported
/** @} */

/**
 * @defgroup MOTOR_HALL_VECTOR_API_ERROR_STATUS Error status
 * @brief The error status of the motor control
 * @{
 */
#define     MOTOR_ERROR_NONE                (0x0000)    ///< No error
#define     MOTOR_ERROR_OVER_CURRENT_HW     (0x0001)    ///< Over-current error detected by hardware
#define     MOTOR_ERROR_OVER_VOLTAGE        (0x0002)    ///< Over-voltage error
#define     MOTOR_ERROR_OVER_SPEED          (0x0004)    ///< Over-speed error
#define     MOTOR_ERROR_UNDER_VOLTAGE       (0x0080)    ///< Under voltage error
#define     MOTOR_ERROR_OVER_CURRENT_SW     (0x0100)    ///< Over-current error detected by software
#define     MOTOR_ERROR_OVER_TEMPERATURE    (0x0200)    ///< Over-temperature error
#define     MOTOR_ERROR_UNKNOWN             (0xffff)    ///< Undefined error
/** @} */

/**********************************************************************************************************************
 * Global structure
 *********************************************************************************************************************/
/**
 * @defgroup MOTOR_HALL_VECTOR_API_CTRL_TYPE Control types 
 * @brief The type of control/calibration to be performed, represent a combination of run mode and control loop mode.
 * @{
 */
typedef enum
{
    MOTOR_CTRL_TYPE_POS             = 0,     ///< Position control, @warning Not supported
    MOTOR_CTRL_TYPE_SPEED           = 1,     ///< Speed control
    MOTOR_CTRL_TYPE_TORQUE          = 2,     ///< Torque control
    MOTOR_CTRL_TYPE_VOLTAGE         = 3,     ///< (Open-loop) Constant Voltage control, @warning Not supported
    MOTOR_CTRL_TYPE_CURRENT         = 4,     ///< (Open-loop) Constant Current control
    MOTOR_CTRL_TYPE_ADJ_CRNT_OFFSET = 5,     ///< Adjust current offset
} e_mtr_ctrl_type_t;
/** @} */

/**
 * @brief The main data structure of Hall Vector Control module
 */
typedef struct st_hall_vector_control
{
    uint8_t  u1_state_id_ref;                 ///< The d-axis current command status
    uint8_t  u1_state_iq_ref;                 ///< The q-axis current command status
    uint8_t  u1_state_speed_ref;              ///< The speed command status
    uint8_t  u1_state_open_loop;              ///< The open-loop state flag, 0:closed loop mode, 1:open-loop mode

    uint8_t  u1_direction;                    ///< Reference rotation direction
    uint8_t  u1_ctrl_loop_mode;               ///< Control loop select

    uint8_t  u1_offset_adjust_mode;           ///< Offset adjust mode
    uint8_t  u1_flag_offset_calc;             ///< Flags whether use q-axis current command value management

    uint16_t u2_error_status;                 ///< Error status
    uint16_t u2_error_status_mask;            ///< Error status bit mask
    uint16_t u2_run_mode;                     ///< Run mode
    uint8_t  u1_flag_charge_cap;              ///< Flags whether use capacitor charge completed
    float    f4_time_elapsed_power_on;        ///< Time elapsed [s] after power on

    float    f4_vdc_ad;                       ///< Bus voltage [V]
    float    f4_iu_ad;                        ///< U-phase current value [A]
    float    f4_iv_ad;                        ///< V-phase current value [A]
    float    f4_iw_ad;                        ///< W-phase current value [A]
    float    f4_overcurrent_limit;            ///< Over-current limit [A]
    float    f4_overvoltage_limit;            ///< Over-voltage limit [V]
    float    f4_undervoltage_limit;           ///< Under-voltage limit [V]
    float    f4_overspeed_limit_rad;          ///< Over-speed limit [rad/s]
    float    f4_user_open_loop_current;       ///< Current command value for open-loop current control [A]
    float    f4_user_torque_nm;               ///< Torque command value for torque control [Nm]
    float    f4_open_loop_angle_rad;          ///< Angle for open-loop control [rad]
    float    f4_rotor_angle_rad;              ///< Rotor angle [rad]

    /* Rotor angle offset adjustment related member */
    float    f4_rotor_angle_offset_rad;       ///< Angle offset [rad](electrical)

    /**
     * @brief Function to get the Hall signal from the IOPORT
     * @param[in] u1_bit_u The bit value of U-phase Hall signal
     * @param[in] u1_bit_v The bit value of V-phase Hall signal
     * @param[in] u1_bit_w The bit value of W-phase Hall signal
     * @return None
     */
    void     (*HallSignalGet)(uint8_t * u1_bit_u, uint8_t * u1_bit_v, uint8_t * u1_bit_w);

    /* Input-output data structure */
    st_current_output_t         st_current_output; ///< The output of current control module
    st_speed_output_t           st_speed_output;   ///< The output of speed control module
    st_sensor_hall_output_t     st_sensor_output;  ///< The output of sensor module

    /* Sub-modules */
    st_statemachine_t           st_stm;            ///<  Motor driver state machine structure
    st_motor_parameter_t        st_motor;          ///<  Motor parameters structure

    /* Modules */
    st_motor_driver_t         * p_st_driver;       ///<  Motor driver structure
    st_current_control_t      * p_st_cc;           ///<  Current control structure
    st_speed_control_t        * p_st_sc;           ///<  Speed control structure
    st_sensor_hall_t          * p_st_sensor_hall;  ///<  Sensor module structure
} st_hall_vector_control_t;

/**
 * @brief The configuration input data structure
 * @see   R_MOTOR_HALL_VECTOR_ParameterUpdate
 */
typedef struct
{
    float                f4_overspeed_limit_rpm; ///< Over-speed limit [rpm]
    st_motor_parameter_t st_motor;               ///< Motor parameters @see st_motor_parameter_t
} st_hall_vector_cfg_t;

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/
extern st_hall_vector_control_t    g_st_hall_vector;

/**********************************************************************************************************************
 * Global function definitions
 *********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_Open(void);
void R_MOTOR_HALL_VECTOR_Close(void);
void R_MOTOR_HALL_VECTOR_Reset(st_hall_vector_control_t * p_st_hall_vector);
void R_MOTOR_HALL_VECTOR_ParameterUpdate(st_hall_vector_control_t * p_st_hall_vector,
                                             st_hall_vector_cfg_t * p_st_hall_vector_cfg);
void R_MOTOR_HALL_VECTOR_MotorStart(st_hall_vector_control_t * p_st_hall_vector);
void R_MOTOR_HALL_VECTOR_MotorStop(st_hall_vector_control_t * p_st_hall_vector);
void R_MOTOR_HALL_VECTOR_MotorReset(st_hall_vector_control_t * p_st_hall_vector);
void R_MOTOR_HALL_VECTOR_MotorErrorCancel(st_hall_vector_control_t * p_st_hall_vector);
void R_MOTOR_HALL_VECTOR_ErrorSet(st_hall_vector_control_t * p_st_hall_vector, uint16_t u2_error_flags);
void R_MOTOR_HALL_VECTOR_ErrorCheckSet(st_hall_vector_control_t * p_st_hall_vector,
                                           uint16_t u2_error_status,
                                           uint8_t  u1_enable);
void R_MOTOR_HALL_VECTOR_SpeedSet(st_hall_vector_control_t * p_st_hall_vector, float f4_ref_speed);
float R_MOTOR_HALL_VECTOR_SpeedGet(st_hall_vector_control_t * p_st_hall_vector);
uint8_t R_MOTOR_HALL_VECTOR_StatusGet(st_hall_vector_control_t * p_st_hall_vector);
uint16_t R_MOTOR_HALL_VECTOR_ErrorStatusGet(st_hall_vector_control_t * p_st_hall_vector);
void R_MOTOR_HALL_VECTOR_CtrlTypeSet(st_hall_vector_control_t * p_st_hall_vector, uint8_t u1_ctrl_type);
uint8_t R_MOTOR_HALL_VECTOR_LoopModeStatusGet(st_hall_vector_control_t * p_st_hall_vector);
void R_MOTOR_HALL_VECTOR_RotorAngleOffsetSet(st_hall_vector_control_t * p_st_hall_vector,
                                                float eangle_offset_rad);
void R_MOTOR_HALL_VECTOR_CurrentOffsetSet(st_hall_vector_control_t * p_st_hall_vector,
                                              float f4_iu_offset,
                                              float f4_iw_offset);
void R_MOTOR_HALL_VECTOR_CurrentOpenLoopSet(st_hall_vector_control_t * p_st_hall_vector,
                                                float f4_open_loop_current,
                                                float f4_ref_speed_rpm);
void R_MOTOR_HALL_VECTOR_TorqueSet(st_hall_vector_control_t * p_st_hall_vector, float f4_torque_nm);
uint8_t R_MOTOR_HALL_VECTOR_OffsetCalibrationStatusGet(st_hall_vector_control_t * p_st_hall_vector);
void R_MOTOR_HALL_VECTOR_DriverSet(st_hall_vector_control_t * p_st_hall_vector,
                                   void (*p_func_driver)(uint8_t * u1_bit_u, uint8_t * u1_bit_v, uint8_t * u1_bit_w));
void R_MOTOR_HALL_VECTOR_SpeedInterrupt(st_hall_vector_control_t * p_st_hall_vector);
void R_MOTOR_HALL_VECTOR_CurrentInterrupt(st_hall_vector_control_t * p_st_hall_vector);
void R_MOTOR_HALL_VECTOR_OverCurrentInterrupt(st_hall_vector_control_t * p_st_hall_vector);

#endif /* R_MOTOR_HALL_VECTOR_API_H */
