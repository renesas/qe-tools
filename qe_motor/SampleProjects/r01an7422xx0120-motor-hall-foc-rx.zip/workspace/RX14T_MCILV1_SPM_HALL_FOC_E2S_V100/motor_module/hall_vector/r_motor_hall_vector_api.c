/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/******************************************************************************************************************//**
 * @file          r_motor_hall_vector_api.c
 * @version       1.00
 * @brief         The APIs for hall effect sensor vector control
 *********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 30.10.2024 1.00     First Release
***********************************************************************************************************************/

/**********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
 *********************************************************************************************************************/
/* Standard library headers */
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

/* Main associated header file */
#include "r_motor_hall_vector_api.h"
#include "r_motor_hall_vector_manager.h"    /* Private header */

/* Module headers */
#include "r_motor_driver.h"
#include "r_motor_current_api.h"
#include "r_motor_speed_api.h"

/* Submodule headers */
#include "r_motor_hall_vector_statemachine.h"
#include "r_motor_hall_vector_protection.h"

/* General library headers */
#include "r_motor_common.h"
#include "r_motor_module_cfg.h"
/*******************************************************************************************************************//**
 * @addtogroup MOTOR_HALL_VECTOR_API
 * @{
 **********************************************************************************************************************/
/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/
st_hall_vector_control_t g_st_hall_vector;

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
/*******************************************************************************************************************//**
 * @brief  Create a instance of vector Control, initialize the the pre-allocated instance @ref g_st_hall_vector
 * @param  None
 * @return None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_Open(void)
{
    R_MOTOR_CURRENT_Open();
    R_MOTOR_SPEED_Open();
    R_MOTOR_SENSOR_HALL_Open();
    R_MOTOR_DRIVER_Open();

    /* Store address of dependent module instances, module is accessed with these pointers outside this function */
    g_st_hall_vector.p_st_cc       = &g_st_cc;
    g_st_hall_vector.p_st_sc       = &g_st_sc;
    g_st_hall_vector.p_st_sensor_hall = &g_st_sensor_hall;
    g_st_hall_vector.p_st_driver   = &g_st_driver;

    motor_hall_vector_statemachine_init(&g_st_hall_vector.st_stm);
    motor_hall_vector_default_init(&g_st_hall_vector);
} /* End of function R_MOTOR_HALL_VECTOR_Open */

/*******************************************************************************************************************//**
 * @brief  Close the pre-allocated instance @ref g_st_hall_vector
 * @param  None
 * @return None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_Close(void)
{
    R_MOTOR_CURRENT_Close();
    R_MOTOR_SPEED_Close();
    R_MOTOR_SENSOR_HALL_Close();
    R_MOTOR_DRIVER_Close();

} /* End of function R_MOTOR_HALL_VECTOR_Close */

/*******************************************************************************************************************//**
 * @brief     Reset the specified instance to stop state
 * @note      The parameters will not be reset, use @ref R_MOTOR_HALL_VECTOR_MotorReset to reset all parameters to default
 * @param     p_st_hall_vector The pointer to the FOC data structure
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_Reset(st_hall_vector_control_t * p_st_hall_vector)
{
    motor_hall_vector_reset(p_st_hall_vector);
} /* End of function R_MOTOR_HALL_VECTOR_Reset */

/*******************************************************************************************************************//**
 * @brief     Update parameters
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @param[in] p_st_hall_vector_cfg The pointer to the parameter structure
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_ParameterUpdate(st_hall_vector_control_t * p_st_hall_vector,
                                         st_hall_vector_cfg_t     * p_st_hall_vector_cfg)
{
    if (NULL == p_st_hall_vector)
    {
        return;
    }

    if (motor_hall_vector_statemachine_get_status(&p_st_hall_vector->st_stm) == STATEMACHINE_STATE_RUN)
    {
        return;
    }

    p_st_hall_vector->st_motor               = p_st_hall_vector_cfg->st_motor;
    p_st_hall_vector->f4_overspeed_limit_rad = p_st_hall_vector_cfg->f4_overspeed_limit_rpm * MTR_RPM2RAD;

    motor_hall_vector_nominal_current_set(&g_st_hall_vector,
            p_st_hall_vector->st_motor.f4_nominal_current_rms);
} /* End of function R_MOTOR_HALL_VECTOR_ParameterUpdate */

/*******************************************************************************************************************//**
 * @brief     Start to drive motor
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_MotorStart(st_hall_vector_control_t * p_st_hall_vector)
{
    motor_hall_vector_statemachine_event(&p_st_hall_vector->st_stm,
                                             p_st_hall_vector,
                                             STATEMACHINE_EVENT_RUN);
} /* End of function R_MOTOR_HALL_VECTOR_MotorStart */

/*******************************************************************************************************************//**
 * @brief     Stop driving motor
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_MotorStop(st_hall_vector_control_t * p_st_hall_vector)
{
    motor_hall_vector_statemachine_event(&p_st_hall_vector->st_stm,
                                             p_st_hall_vector,
                                             STATEMACHINE_EVENT_STOP);
} /* End of function R_MOTOR_HALL_VECTOR_MotorStop */

/*******************************************************************************************************************//**
 * @brief     Cancel error and reset parameters
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_MotorReset(st_hall_vector_control_t * p_st_hall_vector)
{
    motor_hall_vector_statemachine_event(&p_st_hall_vector->st_stm,
                                             p_st_hall_vector,
                                             STATEMACHINE_EVENT_RESET);
} /* End of function R_MOTOR_HALL_VECTOR_MotorReset */

/*******************************************************************************************************************//**
 * @brief     Cancel error without reset any parameters
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_MotorErrorCancel(st_hall_vector_control_t * p_st_hall_vector)
{
    motor_hall_vector_statemachine_event(&p_st_hall_vector->st_stm,
                                             p_st_hall_vector,
                                             STATEMACHINE_EVENT_ERROR_CANCEL);
} /* End of function R_MOTOR_HALL_VECTOR_MotorErrorCancel */

/*******************************************************************************************************************//**
 * @brief     Set error with given error flags
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @param     u2_error_flags       The error flags to set
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_ErrorSet(st_hall_vector_control_t * p_st_hall_vector, uint16_t u2_error_flags)
{
    p_st_hall_vector->u2_error_status |= (u2_error_flags & p_st_hall_vector->u2_error_status_mask);
    if (p_st_hall_vector->u2_error_status != MOTOR_ERROR_NONE)
    {
        motor_hall_vector_statemachine_event(&p_st_hall_vector->st_stm,
                                              p_st_hall_vector,
                                              STATEMACHINE_EVENT_ERROR);
    }
} /* End of function R_MOTOR_HALL_VECTOR_ErrorSet */

/*******************************************************************************************************************//**
 * @brief     Enable/disables selected protections
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @param[in] u2_error_status      The error status of the protection to be enabled/disabled
 * @param[in] u1_enable            MTR_DISABLE(0): Disables the protection
 *                                 MTR_ENABLE(1) and else:  Enables the protection
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_ErrorCheckSet(st_hall_vector_control_t * p_st_hall_vector,
                                           uint16_t u2_error_status,
                                           uint8_t  u1_enable)
{
    uint16_t u2_error_mask;

    u2_error_mask = p_st_hall_vector->u2_error_status_mask;
    if (MTR_DISABLE == u1_enable)
    {
        u2_error_mask &= (~u2_error_status);
    }
    else if (MTR_ENABLE == u1_enable)
    {
        u2_error_mask |= (u2_error_status);
    }
    else
    {
        /* Do nothing */
    }

    p_st_hall_vector->u2_error_status_mask = u2_error_mask;
} /* End of function R_MOTOR_HALL_VECTOR_ErrorCheckSet */

/*******************************************************************************************************************//**
 * @brief     Set speed command [rpm]
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @param[in] f4_ref_speed         The speed command [rpm]
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_SpeedSet(st_hall_vector_control_t * p_st_hall_vector, float f4_ref_speed)
{
    if (NULL == p_st_hall_vector)
    {
        return;
    }

    /* Set reference speed */
    R_MOTOR_SPEED_SpdRefSet(p_st_hall_vector->p_st_sc, f4_ref_speed);
} /* End of function R_MOTOR_HALL_VECTOR_SpeedSet */

/*******************************************************************************************************************//**
 * @brief     Get current motor speed
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    Motor speed[rpm]
 **********************************************************************************************************************/
float R_MOTOR_HALL_VECTOR_SpeedGet(st_hall_vector_control_t * p_st_hall_vector)
{
    if (NULL == p_st_hall_vector)
    {
        return (0.0f);
    }

    return (p_st_hall_vector->st_sensor_output.f4_speed_rad * MTR_RAD2RPM);
} /* End of function R_MOTOR_HALL_VECTOR_SpeedGet */

/*******************************************************************************************************************//**
 * @brief     Get current motor status
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    Motor status
 **********************************************************************************************************************/
uint8_t R_MOTOR_HALL_VECTOR_StatusGet(st_hall_vector_control_t * p_st_hall_vector)
{
    uint8_t u1_status;

    if (NULL == p_st_hall_vector)
    {
        return (STATEMACHINE_STATE_STOP);
    }

    u1_status = motor_hall_vector_statemachine_get_status(&p_st_hall_vector->st_stm);

    return (u1_status);
} /* End of function R_MOTOR_HALL_VECTOR_StatusGet */

/*******************************************************************************************************************//**
 * @brief     Get current error status
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    Error status @ref MOTOR_HALL_VECTOR_API_ERROR_STATUS
 **********************************************************************************************************************/
uint16_t R_MOTOR_HALL_VECTOR_ErrorStatusGet(st_hall_vector_control_t * p_st_hall_vector)
{
    uint16_t u2_error_status;

    if (NULL == p_st_hall_vector)
    {
        return (MOTOR_ERROR_NONE);
    }

    u2_error_status = p_st_hall_vector->u2_error_status;

    return (u2_error_status);
} /* End of function R_MOTOR_HALL_VECTOR_ErrorStatusGet */

/*******************************************************************************************************************//**
 * @brief     Set control type
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @param[in] u1_ctrl_type         The control type that defined in @ref e_mtr_ctrl_type_t
 * @return    None
 * @see       MOTOR_HALL_VECTOR_API_CTRL_TYPE
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_CtrlTypeSet(st_hall_vector_control_t * p_st_hall_vector, uint8_t u1_ctrl_type)
{
    if (NULL == p_st_hall_vector)
    {
        return;
    }

    if (motor_hall_vector_statemachine_get_status(&p_st_hall_vector->st_stm) == STATEMACHINE_STATE_RUN)
    {
        return;
    }

    switch (u1_ctrl_type)
    {
        case MOTOR_CTRL_TYPE_SPEED:
        {
            p_st_hall_vector->u1_ctrl_loop_mode = MOTOR_LOOP_SPEED;
            p_st_hall_vector->u2_run_mode       = MOTOR_HALL_VECTOR_MODE_DRIVE;
            break;
        }
        case MOTOR_CTRL_TYPE_TORQUE:
        {
            p_st_hall_vector->u1_ctrl_loop_mode = MOTOR_LOOP_CURRENT_IQ;
            p_st_hall_vector->u2_run_mode       = MOTOR_HALL_VECTOR_MODE_DRIVE;
            break;
        }
        case MOTOR_CTRL_TYPE_CURRENT:
        {
            p_st_hall_vector->u1_ctrl_loop_mode = MOTOR_LOOP_CURRENT_ID;
            p_st_hall_vector->u2_run_mode       = MOTOR_HALL_VECTOR_MODE_DRIVE;
            break;
        }
        case MOTOR_CTRL_TYPE_ADJ_CRNT_OFFSET:
        {
            p_st_hall_vector->u1_offset_adjust_mode = MOTOR_HALL_VECTOR_OFAJ_CURRENT_OFFSET;
            p_st_hall_vector->u2_run_mode           = MOTOR_HALL_VECTOR_MODE_OFFSET_ADJUST;
            break;
        }
        case MOTOR_CTRL_TYPE_POS:
        default:
        {
            /* Do nothing */
        }
    }
} /* End of function R_MOTOR_HALL_VECTOR_CtrlTypeSet */

/*******************************************************************************************************************//**
 * @brief     Get the current mode of control-loop
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    Current control loop mode , see @ref MOTOR_HALL_VECTOR_API_LOOP_MODE
 **********************************************************************************************************************/
uint8_t R_MOTOR_HALL_VECTOR_LoopModeStatusGet(st_hall_vector_control_t * p_st_hall_vector)
{
    if (NULL == p_st_hall_vector)
    {
        return (0);
    }

    return (p_st_hall_vector->u1_ctrl_loop_mode);
} /* End of function R_MOTOR_HALL_VECTOR_LoopModeStatusGet */

/*******************************************************************************************************************//**
 * @brief     Set rotor angle offset
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @param[in] f4_eangle_offset_rad The rotor angle offset (electrical angle) [rad]
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_RotorAngleOffsetSet(st_hall_vector_control_t * p_st_hall_vector,
                                                 float f4_eangle_offset_rad)
{
    if (NULL == p_st_hall_vector)
    {
        return;
    }

    p_st_hall_vector->f4_rotor_angle_offset_rad = f4_eangle_offset_rad;
} /* End of function R_MOTOR_HALL_VECTOR_RotorAngleOffsetSet */

/*******************************************************************************************************************//**
 * @brief     Set AD current offset
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @param[in] f4_iu_offset         The current offset for Iu
 * @param[in] f4_iw_offset         The current offset for Iw
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_CurrentOffsetSet(st_hall_vector_control_t * p_st_hall_vector,
                                              float f4_iu_offset,
                                              float f4_iw_offset)
{
    R_MOTOR_CURRENT_CurrentOffsetSet(p_st_hall_vector->p_st_cc, f4_iu_offset, f4_iw_offset);
} /* End of function R_MOTOR_HALL_VECTOR_CurrentOffsetSet */

/*******************************************************************************************************************//**
 * @brief     Set commands for constant current open-loop
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @param[in] f4_open_loop_current The current command for open-loop mode [A]
 * @param[in] f4_ref_speed_rpm     The speed command for open-loop mode[rpm]
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_CurrentOpenLoopSet(st_hall_vector_control_t * p_st_hall_vector,
                                                float f4_open_loop_current,
                                                float f4_ref_speed_rpm)
{
    if (NULL == p_st_hall_vector)
    {
        return;
    }

    p_st_hall_vector->f4_user_open_loop_current = f4_open_loop_current;
    R_MOTOR_SPEED_SpdRefSet(p_st_hall_vector->p_st_sc, f4_ref_speed_rpm);
} /* End of function R_MOTOR_HALL_VECTOR_CurrentOpenLoopSet */

/*******************************************************************************************************************//**
 * @brief     Set torque command for torque control mode
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @param[in] f4_torque_nm         The torque command [Nm]
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_TorqueSet(st_hall_vector_control_t * p_st_hall_vector, float f4_torque_nm)
{
    if (NULL == p_st_hall_vector)
    {
        return;
    }

    /* Calculate torque, may be inaccurate on IPM motor */
    p_st_hall_vector->f4_user_torque_nm = f4_torque_nm;
} /* End of function R_MOTOR_HALL_VECTOR_TorqueSet */

/*******************************************************************************************************************//**
 * @brief     Get offset calibration status
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    Offset calibration status
 *             - 0: Calibration incomplete
 *             - 1: Calibration completed
 **********************************************************************************************************************/
uint8_t R_MOTOR_HALL_VECTOR_OffsetCalibrationStatusGet(st_hall_vector_control_t * p_st_hall_vector)
{
    uint8_t u1_offset_cal_finished_flag;

    if (NULL == p_st_hall_vector)
    {
        return MTR_FALSE;
    }

    /* Cast the result to uint8_t */
    u1_offset_cal_finished_flag =
            (uint8_t)(MOTOR_HALL_VECTOR_OFAJ_FIN == p_st_hall_vector->u1_offset_adjust_mode);

    return (u1_offset_cal_finished_flag);
} /* End of function R_MOTOR_HALL_VECTOR_OffsetCalibrationStatusGet */

/*******************************************************************************************************************//**
 * @brief     Set the driver function for hall sensor
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @param[in] p_func_driver        The driver function which store hall signal bits in u1_bit_u,v,w respectively
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_DriverSet(st_hall_vector_control_t * p_st_hall_vector,
                                   void (*p_func_driver)(uint8_t * u1_bit_u, uint8_t * u1_bit_v, uint8_t * u1_bit_w))
{
    if (p_func_driver)
    {
        p_st_hall_vector->HallSignalGet = p_func_driver;
    }
}

/*******************************************************************************************************************//**
 * @brief     Interrupt handler for long interval processes such as position and speed control
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_SpeedInterrupt(st_hall_vector_control_t * p_st_hall_vector)
{
    st_speed_input_t st_speed_input;

    if (NULL == p_st_hall_vector)
    {
        return;
    }

    /* Set references */
    if (STATEMACHINE_STATE_STOP == motor_hall_vector_statemachine_get_status(&p_st_hall_vector->st_stm))
    {
        if ((p_st_hall_vector->f4_time_elapsed_power_on >= MOTOR_COMMON_CFG_AUTO_OFFSET_ADJUST_DELAY) &&
            (MTR_FLG_CLR == p_st_hall_vector->u1_flag_offset_calc))
        {
            R_MOTOR_HALL_VECTOR_CtrlTypeSet(&g_st_hall_vector, MOTOR_CTRL_TYPE_ADJ_CRNT_OFFSET);
            R_MOTOR_HALL_VECTOR_MotorStart(&g_st_hall_vector);
            p_st_hall_vector->u1_flag_offset_calc = MTR_FLG_SET;
        }
        else
        {
            p_st_hall_vector->f4_time_elapsed_power_on += SPEED_CFG_CTRL_PERIOD;
        }

        /* Setting of references state */
        motor_hall_vector_ref_state_update(p_st_hall_vector);
    }
    else if (STATEMACHINE_STATE_RUN == motor_hall_vector_statemachine_get_status(&p_st_hall_vector->st_stm))
    {
        /* Decide direction */
        motor_hall_vector_decide_direction(p_st_hall_vector);

        /* Id, Iq, speed, position references setting */
        switch (p_st_hall_vector->u2_run_mode)
        {
            case MOTOR_HALL_VECTOR_MODE_DRIVE:
            {
                st_speed_input.u1_state_speed_ref = p_st_hall_vector->u1_state_speed_ref;
                /* Since position module dose not exists, the speed command from position module is not available */
                st_speed_input.f4_ref_speed_rad   = 0.0f;
                st_speed_input.f4_speed_rad       = p_st_hall_vector->st_sensor_output.f4_speed_lpf_rad;
                st_speed_input.f4_va_max          = p_st_hall_vector->st_current_output.f4_va_max;
                R_MOTOR_SPEED_ParameterSet(p_st_hall_vector->p_st_sc, &st_speed_input);
                R_MOTOR_SPEED_SpeedCyclic(p_st_hall_vector->p_st_sc);
                R_MOTOR_SPEED_ParameterGet(p_st_hall_vector->p_st_sc, &p_st_hall_vector->st_speed_output);
                break;
            }

            /* These cases are intentionally merged */
            case MOTOR_HALL_VECTOR_MODE_OFFSET_ADJUST:
            default:
            {
                /* Do Nothing */
                break;
            }
        }
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function R_MOTOR_HALL_VECTOR_SpeedInterrupt */

/*******************************************************************************************************************//**
 * @brief     The carrier interrupt handler of FOC control
 * @note      This function should be called in the AD conversion complete interrupt handler
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_CurrentInterrupt(st_hall_vector_control_t * p_st_hall_vector)
{
    st_current_input_t  st_current_input;
    st_sensor_hall_input_t st_sensor_input;
    uint8_t             u1_flag_offset_calib_finished;

    if (NULL == p_st_hall_vector)
    {
        return;
    }

    R_MOTOR_DRIVER_BldcAnalogGet(p_st_hall_vector->p_st_driver,
                                 &p_st_hall_vector->f4_iu_ad,
                                 &p_st_hall_vector->f4_iw_ad,
                                 &p_st_hall_vector->f4_vdc_ad);

    /* current offset adjustment */
    R_MOTOR_CURRENT_CurrentOffsetRemove(p_st_hall_vector->p_st_cc,
                                        &p_st_hall_vector->f4_iu_ad,
                                        &p_st_hall_vector->f4_iw_ad);

    /* V-phase current calculation */
    p_st_hall_vector->f4_iv_ad = -(p_st_hall_vector->f4_iu_ad + p_st_hall_vector->f4_iw_ad);

    /* Error check */
    motor_hall_vector_error_check(p_st_hall_vector);

    /* Get angle and speed from sensor module */
    p_st_hall_vector->HallSignalGet(&st_sensor_input.u1_hall_sensor_bit_u,
                                    &st_sensor_input.u1_hall_sensor_bit_v,
                                    &st_sensor_input.u1_hall_sensor_bit_w);
    R_MOTOR_SENSOR_HALL_ParameterSet(p_st_hall_vector->p_st_sensor_hall, &st_sensor_input);
    R_MOTOR_SENSOR_HALL_Cyclic(p_st_hall_vector->p_st_sensor_hall);
    R_MOTOR_SENSOR_HALL_ParameterGet(p_st_hall_vector->p_st_sensor_hall, &p_st_hall_vector->st_sensor_output);

    /* Convert mechanical angle and speed to electrical angle*/
    motor_hall_vector_angle_speed_select(p_st_hall_vector);

    /* SYSTEM MODE is ACTIVE */
    if (STATEMACHINE_STATE_RUN == motor_hall_vector_statemachine_get_status(&p_st_hall_vector->st_stm))
    {
        /* Connect sensor and other module to current module */
        st_current_input.u1_state_id_ref    = p_st_hall_vector->u1_state_id_ref;
        st_current_input.u1_state_iq_ref    = p_st_hall_vector->u1_state_iq_ref;
        st_current_input.f4_rotor_angle_rad = p_st_hall_vector->f4_rotor_angle_rad;
        st_current_input.f4_iu_ad           = p_st_hall_vector->f4_iu_ad;
        st_current_input.f4_iv_ad           = p_st_hall_vector->f4_iv_ad;
        st_current_input.f4_iw_ad           = p_st_hall_vector->f4_iw_ad;
        st_current_input.f4_vdc_ad          = p_st_hall_vector->f4_vdc_ad;

        if (MTR_FALSE == p_st_hall_vector->u1_state_open_loop)
        {
            st_current_input.f4_speed_rad = p_st_hall_vector->st_sensor_output.f4_speed_lpf_rad
                                            * p_st_hall_vector->st_motor.u2_mtr_pp;
        }
        else
        {
            st_current_input.f4_speed_rad = 0.0f;
        }

        st_current_input.f4_id_ref        = p_st_hall_vector->st_speed_output.f4_id_ref;
        st_current_input.f4_iq_ref        = p_st_hall_vector->st_speed_output.f4_iq_ref;
        st_current_input.f4_id_ref_manual = p_st_hall_vector->f4_user_open_loop_current;
        st_current_input.f4_iq_ref_manual = p_st_hall_vector->f4_user_torque_nm /
                                            (p_st_hall_vector->st_motor.u2_mtr_pp *
                                             p_st_hall_vector->st_motor.f4_mtr_m);
        R_MOTOR_CURRENT_ParameterSet(p_st_hall_vector->p_st_cc, &st_current_input);

        /* Calculate offset current values */
        if (MOTOR_HALL_VECTOR_OFAJ_CURRENT_OFFSET == p_st_hall_vector->u1_offset_adjust_mode)
        {
            /* Current offset calibration */
            R_MOTOR_CURRENT_OffsetCalibration(p_st_hall_vector->p_st_cc, &u1_flag_offset_calib_finished);
            if (MTR_FLG_SET == u1_flag_offset_calib_finished)
            {
                p_st_hall_vector->u1_offset_adjust_mode = MOTOR_HALL_VECTOR_OFAJ_FIN;
                R_MOTOR_HALL_VECTOR_MotorStop(p_st_hall_vector);
            }
        }
        else
        {
            R_MOTOR_CURRENT_CurrentCyclic(p_st_hall_vector->p_st_cc);
            R_MOTOR_CURRENT_ParameterGet(p_st_hall_vector->p_st_cc, &p_st_hall_vector->st_current_output);
        }
        R_MOTOR_DRIVER_BldcDutySet(p_st_hall_vector->p_st_driver,
                                   p_st_hall_vector->st_current_output.f4_modu,
                                   p_st_hall_vector->st_current_output.f4_modv,
                                   p_st_hall_vector->st_current_output.f4_modw);

    }
    else
    {
        /* Do nothing */
    }
} /* End of function R_MOTOR_HALL_VECTOR_CurrentInterrupt */

/*******************************************************************************************************************//**
 * @brief     The hardware over-current interrupt handler, to inform the FOC module of over-current event
 * @param     p_st_hall_vector     The pointer to the FOC data structure
 * @return    None
 **********************************************************************************************************************/
void R_MOTOR_HALL_VECTOR_OverCurrentInterrupt(st_hall_vector_control_t * p_st_hall_vector)
{
    /*  */
    if (NULL == p_st_hall_vector)
    {
        return;
    }

    motor_hall_vector_error_process(p_st_hall_vector, MOTOR_ERROR_OVER_CURRENT_HW);
} /* End of function R_MOTOR_HALL_VECTOR_OverCurrentInterrupt */
/*******************************************************************************************************************//**
 * @} (end addtogroup MOTOR_HALL_VECTOR_API)
 **********************************************************************************************************************/
