/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2026 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/******************************************************************************************************************//**
 * @file          r_motor_speed_friction_comp.h
 * @version       1.00
 * @brief         Friction compensation module, calculate the feed-forward value base on friction model
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * History : DD.MM.YYYY Version  Description
 *         : 30.10.2024 1.00     First Release
 *********************************************************************************************************************/
#ifndef R_MOTOR_SPEED_FRICTION_COMP_H
#define R_MOTOR_SPEED_FRICTION_COMP_H

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include <stdint.h>

/*******************************************************************************************************************//**
 * @ingroup MOTOR_SPEED
 * @defgroup MOTOR_SPEED_FRICTION_COMPENSATION Friction Compensation
 * @brief Calculate the torque or Iq feed-forward value to compensate static/coulombs/viscous friction
 * @{
 **********************************************************************************************************************/

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/
/** The friction compensation structure to store the information about friction model */
typedef struct st_friction_comp
{
    /* Parameters (with default value) */
    /** Static friction speed threshold in [rad/s], speed command under this speed will be considered stop and hold */
    float f4_static_friction_speed_th_rad;

    /** The torque or current (iq) to compensate the static friction when the directly detected speed is slower than
     *  the threshold */
    float f4_static_friction_torque_current;
    float f4_coulombs_friction_torque_current; ///< The torque or current (iq) to compensate the coulomb friction

    float f4_viscous_friction_coef;            ///< Viscous friction coefficient
    float f4_output;                           ///< The output value @note in the same unit with parameters
} st_friction_comp_t;

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/
void  motor_speed_friction_comp_init(st_friction_comp_t * p_st_friction_comp);
void  motor_speed_friction_comp_static_friction_set(st_friction_comp_t * p_st_friction_comp,
                                                    float f4_static_friction,
                                                    float f4_brake_speed_th);
void  motor_speed_friction_comp_viscous_coef_set(st_friction_comp_t * p_st_friction_comp, float f4_viscous_coef);
void  motor_speed_friction_comp_coulombs_friction_set(st_friction_comp_t * p_st_friction_comp,
                                                      float f4_coulombs_friction);
float motor_speed_friction_comp_calc_ff(st_friction_comp_t * p_st_friction_comp,
                                        float f4_speed_rad,
                                        float f4_speed_cmd_rad);
/*******************************************************************************************************************//**
 * @} (end defgroup MOTOR_SPEED_FRICTION_COMPENSATION)
 **********************************************************************************************************************/
#endif /* R_MOTOR_SPEED_FRICTION_COMP_H */
