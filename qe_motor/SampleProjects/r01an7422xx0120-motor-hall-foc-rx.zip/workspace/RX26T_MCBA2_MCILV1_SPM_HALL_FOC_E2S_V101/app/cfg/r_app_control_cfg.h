/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_app_control_cfg.h
* Description : Compile-time configurations
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 30.10.2024 1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_APP_CONTROL_CFG_H
#define R_APP_CONTROL_CFG_H

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/* Select UI */
#define     MAIN_UI_RMW                 (0)         /* ICS (Analyzer) */
#define     MAIN_UI_BOARD               (1)         /* Board */
#define     MAIN_UI_SIZE                (2)         /* Number of UI */

/* Defines the UI used as default UI (MAIN_UI_BOARD/MAIN_UI_RMW)*/
#define     APP_CFG_USE_UI  (MAIN_UI_RMW)

/* design parameter */
#define     APP_CFG_FREQ_BAND_LIMIT     (3.0f)                       /* Motor control natural frequency limit */
#define     APP_CFG_MAX_CURRENT_OMEGA   (1500.0f)                    /* Max natural frequency of current loop [Hz] */
#define     APP_CFG_MIN_OMEGA           (1.0f)                       /* Min natural frequency of speed loop [Hz] */

/* Select SCI port
   ICS_SCI1_PD3_PD5    (0x10U)
   ICS_SCI5_PD7_PE0    (0x50U)
   ICS_SCI5_PB5_PB6    (0x51U)
   ICS_SCI6_P81_P80    (0x60U)
   ICS_SCI6_PB2_PB1    (0x61U)
   ICS_SCI12_PD4_PD6   (0xC0U)
   ICS_SCI12_P01_P00   (0xC1U)
   ICS_SCI12_P81_P80   (0xC2U)
   ICS_SCI12_P23_P22   (0xC3U)
   ICS_SCI12_PB5_PB6   (0xC4U)
 */
#define APP_CFG_SCI_CH_SELECT     (ICS_SCI6_P81_P80)

#define     ICS_DECIMATION                  (5)         /* ICS watch skipping number */

/* for ICS */
#define     ICS_INT_LEVEL                   (6)         /* interrupt priority level */
#define     ICS_BRR                         (251)       /* baudrate select */
#define     ICS_INT_MODE                    (1)         /* mode select */

#endif /* R_APP_CONTROL_CFG_H */
