/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/******************************************************************************************************************//**
 * @file          r_app_rmw.c
 * @version       1.00
 * @brief         Provide interface allowing user drive motor through Renesas Motor Workbench
 * @note          This RMW module is for Hall Vector module
 *********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 30.10.2024 1.00
***********************************************************************************************************************/

/* Guard against multiple inclusion */
#ifndef R_APP_RMW_H
#define R_APP_RMW_H
/*******************************************************************************************************************//**
 * @defgroup RMW_UI RMW User Interfaces
 * @brief    RMW User Interfaces, this module will drive motor (call APIs of motor modules)
 *           according to the command from RMW, e.g. start/stop motor, change control parameters
 * @{
 **********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include "r_app_rmw_mcu.h"
#include "r_smc_entry.h"
#include "r_app_control_cfg.h"
#include "r_motor_hall_vector_api.h"

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
/*******************************************************************************************************************//**
 * @ingroup  RMW_UI
 * @defgroup RMW_UI_COMMAND RMW UI Commands/Modes
 * @brief    Command and Mode definitions for RMW UI,
 * @details  Write the value to @ref com_u1_system_mode to executed command or start motor with the specified mode.@n
 *           Command: @ref com_u1_system_mode will return to 0 when the action finished@n
 *           Mode: @ref com_u1_system_mode will remain unchanged, unless error occurs
 * @{
 **********************************************************************************************************************/
#define     RMW_SYSMODE_STOP                (0) ///< Stop Command
#define     RMW_SYSMODE_POSITION            (1) ///< Position Control Mode (Not Available)
#define     RMW_SYSMODE_SPEED               (2) ///< Speed Control Mode
#define     RMW_SYSMODE_TORQUE              (3) ///< Torque Control Mode
#define     RMW_SYSMODE_CURRENT_OL          (4) ///< Open-loop Control Mode
#define     RMW_SYSMODE_CLEAR_ERROR         (5) ///< Clear error without reset parameters
#define     RMW_SYSMODE_ADJ_ALL             (6) ///< Execute all calibration available
#define     RMW_SYSMODE_ADJ_SAVE            (7) ///< Save settings to data flash  (Not Available)
#define     RMW_SYSMODE_ADJ_CRNT            (8) ///< Adjust current offset
/*******************************************************************************************************************//**
 * @}
 **********************************************************************************************************************/

/***********************************************************************************************************************
* Global structure
***********************************************************************************************************************/
/**
 * @brief   Buffer data structure for COM variables
 * @details The COM parameters will be gathered to @ref g_st_rmw_input_buffer in this data structure before applied
 *          to the motor module.
 *  */
typedef struct st_rmw_param_buffer
{
    /* Offset parameters */
    uint16_t    u2_offset_calc_time;            ///< Buffer for @ref com_u2_offset_calc_time
    float       f4_offset_rotor_rad;            ///< Buffer for @ref com_f4_offset_rotor_rad

    /* Motor parameters */
    st_motor_parameter_t st_motor;              ///< Buffer for Motor parameters, see @ref st_motor_parameter_t
    float       f4_max_speed_rpm;               ///< Buffer for @ref com_f4_max_speed_rpm

    float       f4_friction_comp_static;        ///< Buffer for @ref com_f4_friction_comp_static
    float       f4_friction_comp_brake_speed;   ///< Buffer for @ref com_f4_friction_comp_brake_speed.
    float       f4_friction_comp_coulombs;      ///< Buffer for @ref com_f4_friction_comp_coulombs
    float       f4_friction_comp_viscous;       ///< Buffer for @ref com_f4_friction_comp_viscous.

    /* Sensor parameters */
    float       f4_hall_spdmix_elec_speed_th;   ///< Buffer for @ref com_f4_hall_spdmix_elec_speed_th
    float       f4_hall_spdmix_dev_th;          ///< Buffer for @ref com_f4_hall_spdmix_dev_th
    float       f4_hall_angle_correct_rad;      ///< Buffer for @ref com_f4_hall_angle_correct_rad
    uint8_t     u1_hall_speed_select;           ///< Buffer for @ref com_u1_hall_speed_select

    /* Current control */
    float       f4_current_omega_hz;            ///< Buffer for @ref com_f4_current_omega_hz
    float       f4_current_zeta;                ///< Buffer for @ref com_f4_current_zeta

    /* Speed control */
    float       f4_speed_omega_hz;              ///< Buffer for @ref com_f4_speed_omega_hz
    float       f4_speed_zeta;                  ///< Buffer for @ref com_f4_speed_zeta
    float       f4_ref_speed_rpm;               ///< Buffer for @ref com_f4_ref_speed_rpm
    float       f4_speed_rate_limit_rpm;        ///< Buffer for @ref com_f4_speed_rate_limit_rpm
    float       f4_overspeed_limit_rpm;         ///< Buffer for @ref com_f4_overspeed_limit_rpm

    /* Torque control */
    float       f4_torque_ref_nm;               ///< Buffer for @ref com_f4_torque_ref_nm

    /* Open-loop control */
    float       f4_ol_crnt_ref;                 ///< Buffer for @ref com_f4_ol_crnt_ref

    /* Optional functions */

    /* Voltage error compensation */
    uint8_t     u1_flag_volt_err_comp_use;      ///< Buffer for @ref com_u1_flag_volt_err_comp_use

    /* Flux-weakening control */
    uint8_t     u1_flag_fluxwkn_use;            ///< Buffer for @ref com_u1_flag_fluxwkn_use
} st_rmw_param_buffer_t;

/***********************************************************************************************************************
* External global variables
***********************************************************************************************************************/
/* Export COM variables */
/* Operation variables */
extern uint8_t      com_u1_system_mode;
extern uint8_t      g_u1_system_mode;
extern uint8_t      com_u1_enable_write;
extern uint8_t      g_u1_enable_write;
extern uint8_t      com_u1_sw_userif;
extern uint8_t      g_u1_sw_userif;

/* Offset parameters */
extern uint16_t     com_u2_offset_calc_time;
extern float        com_f4_offset_rotor_rad;

/* Motor parameters */
extern uint16_t     com_u2_mtr_pp;
extern float        com_f4_mtr_r;
extern float        com_f4_mtr_ld;
extern float        com_f4_mtr_lq;
extern float        com_f4_mtr_m;
extern float        com_f4_mtr_j;
extern float        com_f4_nominal_current_rms;
extern float        com_f4_max_speed_rpm;

/* Control parameters */
/* Sensor parameters */
extern float       com_f4_hall_spdmix_elec_speed_th;
extern float       com_f4_hall_spdmix_dev_th;
extern float       com_f4_hall_angle_correct;
extern float       com_f4_hall_speed_select;

/* Current control */
extern float        com_f4_current_omega_hz;
extern float        com_f4_current_zeta;

/* Speed control */
extern float        com_f4_speed_omega_hz;
extern float        com_f4_speed_zeta;
extern float        com_f4_ref_speed_rpm;
extern float        com_f4_speed_rate_limit_rpm;
extern float        com_f4_overspeed_limit_rpm;

/* Torque control */
extern float        com_f4_torque_ref_nm;

/* Open-loop control */
extern float        com_f4_ol_crnt_ref;

/* Optional functions */
/* Friction compensation */
extern float        com_f4_friction_comp_static;
extern float        com_f4_friction_comp_brake_speed;
extern float        com_f4_friction_comp_coulombs;
extern float        com_f4_friction_comp_viscous;
/* Voltage error compensation */
extern uint8_t      com_u1_flag_volt_err_comp_use;

/* Flux-weakening control */
extern uint8_t      com_u1_flag_fluxwkn_use;

/***********************************************************************************************************************
* Global function definitions
***********************************************************************************************************************/
void r_app_rmw_ui_init(void);
void r_app_rmw_ui_mainloop(void);
void r_app_rmw_copy_com_to_buffer(void);
void r_app_rmw_interrupt_handler(void);

/*******************************************************************************************************************//**
 * @} (end of defgroup RMW_UI)
 **********************************************************************************************************************/
#endif /* R_APP_RMW_H */
