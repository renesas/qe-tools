/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/******************************************************************************************************************//**
 * @file          r_app_rmw_mcu.h
 * @Version       1.0
 * @brief         .
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * History : DD.MM.YYYY Version  Description
 *         : 30.10.2024 1.00     First Release
 *********************************************************************************************************************/
#ifndef RMW_R_APP_RMW_MCU_H_
#define RMW_R_APP_RMW_MCU_H_
/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include "r_smc_entry.h"
#include "r_app_control_cfg.h"

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define     ICS_SCI_CH_SELECT               (APP_CFG_SCI_CH_SELECT)
#if     defined(BSP_MCU_RX13T)
    #include "ICS2_RX13T.h"
#elif   defined(BSP_MCU_RX23T)
    #include "ICS_RX23T.h"
#elif   defined(BSP_MCU_RX24T)
    #include "ICS_RX24T.h"
#elif   defined(BSP_MCU_RX24U)
    #include "ICS_RX24U.h"
#elif   defined(BSP_MCU_RX26T)
    #include "ICS2_RX26T.h"
#elif   defined(BSP_MCU_RX66T)
    #include "ICS2_RX66T.h"
#elif   defined(BSP_MCU_RX72T)
    #include "ICS2_RX72T.h"
#elif   defined(BSP_MCU_RX72M)
    #include "ICS2_RX72M.h"
#else
    #error Please select a valid CPU board by defining a <MCU>_<MRSSK> macro in r_motor_module_cfg.h
#endif


#if     defined(BSP_MCU_RX13T)                  /* for RX13T */
#if (ICS_SCI_CH_SELECT == ICS_SCI1_PD3_PD5)     /* SCI1 PD3/TXD1 PD5/RXD1 */
    #define ICS_INT_ERI    VECT(SCI1,ERI1)
    #define ICS_INT_RXI    VECT(SCI1,RXI1)
    #define ICS_INT_TXI    VECT(SCI1,TXI1)
    #define ICS_INT_TEI    VECT(SCI1,TEI1)
    #define ICS_CTRL_PORT  (ICS_SCI1_PD3_PD5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI1_PB6_PB7)   /* SCI1 PB6/TXD1 PB7/RXD1 */
    #define ICS_INT_ERI    VECT(SCI1,ERI1)
    #define ICS_INT_RXI    VECT(SCI1,RXI1)
    #define ICS_INT_TXI    VECT(SCI1,TXI1)
    #define ICS_INT_TEI    VECT(SCI1,TEI1)
    #define ICS_CTRL_PORT  (ICS_SCI1_PB6_PB7)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PB6_PB7)   /* SCI5 PB6/TXD5 PB7/RXD5 */
    #define ICS_INT_ERI    VECT(SCI5,ERI5)
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_INT_TEI    VECT(SCI5,TEI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PB6_PB7)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PB2_PB1)   /* SCI5 PB2/TXD5 PB1/RXD5 */
    #define ICS_INT_ERI    VECT(SCI5,ERI5)
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_INT_TEI    VECT(SCI5,TEI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PB2_PB1)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_P23_P24)   /* SCI5 P23/TXD5 P24/RXD5 */
    #define ICS_INT_ERI    VECT(SCI5,ERI5)
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_INT_TEI    VECT(SCI5,TEI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_P23_P24)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_P80_P94)  /* SCI12 P80/TXD12 P94/RXD12 */
    #define ICS_INT_ERI    VECT(SCI12,ERI12)
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_INT_TEI    VECT(SCI12,TEI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_P80_P94)
#else
    #error Please select a valid SCI channel
#endif

#elif   defined(BSP_MCU_RX23T)                  /* for RX23T */
#if (ICS_SCI_CH_SELECT == ICS_SCI1_PD3_PD5)     /* SCI1 PD3/TXD1 PD5/RXD1 */
    #define ICS_INT_ERI    VECT(SCI1,ERI1)
    #define ICS_INT_RXI    VECT(SCI1,RXI1)
    #define ICS_INT_TXI    VECT(SCI1,TXI1)
    #define ICS_INT_TEI    VECT(SCI1,TEI1)
    #define ICS_CTRL_PORT  (ICS_SCI1_PD3_PD5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PB5_PB6)   /* SCI5 PB5/TXD5 PB6/RXD5 */
    #define ICS_INT_ERI    VECT(SCI5,ERI5)
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_INT_TEI    VECT(SCI5,TEI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PB5_PB6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PB2_PB1)   /* SCI5 PB2/TXD5 PB1/RXD5 */
    #define ICS_INT_ERI    VECT(SCI5,ERI5)
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_INT_TEI    VECT(SCI5,TEI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PB2_PB1)
#else
    #error Please select a valid SCI channel
#endif

#elif   defined(BSP_MCU_RX24T)                  /* for RX24T */
#if (ICS_SCI_CH_SELECT == ICS_SCI1_PD3_PD5)     /* SCI1 PD3/TXD1 PD5/RXD1 */
    #define ICS_INT_ERI    VECT(SCI1,ERI1)
    #define ICS_INT_RXI    VECT(SCI1,RXI1)
    #define ICS_INT_TXI    VECT(SCI1,TXI1)
    #define ICS_INT_TEI    VECT(SCI1,TEI1)
    #define ICS_CTRL_PORT  (ICS_SCI1_PD3_PD5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PB5_PB6)   /* SCI5 PB5/TXD5 PB6/RXD5 */
    #define ICS_INT_ERI    VECT(SCI5,ERI5)
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_INT_TEI    VECT(SCI5,TEI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PB5_PB6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_PB2_PB1)   /* SCI6 PB2/TXD6 PB1/RXD6 */
    #define ICS_INT_ERI    VECT(SCI6,ERI6)
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_INT_TEI    VECT(SCI6,TEI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_PB2_PB1)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_PB0_PA5)   /* SCI6 PB0/TXD6 PA5/RXD6 */
    #define ICS_INT_ERI    VECT(SCI6,ERI6)
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_INT_TEI    VECT(SCI6,TEI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_PB0_PA5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_P81_P80)   /* SCI6 P81/TXD6 P80/RXD6 */
    #define ICS_INT_ERI    VECT(SCI6,ERI6)
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_INT_TEI    VECT(SCI6,TEI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_P81_P80)
#else
    #error Please select a valid SCI channel
#endif

#elif   defined(BSP_MCU_RX24U)                  /* for RX24U */
#if (ICS_SCI_CH_SELECT == ICS_SCI1_PD3_PD5)     /* SCI1 PD3/TXD1 PD5/RXD1 */
    #define ICS_INT_ERI    VECT(SCI1,ERI1)
    #define ICS_INT_RXI    VECT(SCI1,RXI1)
    #define ICS_INT_TXI    VECT(SCI1,TXI1)
    #define ICS_INT_TEI    VECT(SCI1,TEI1)
    #define ICS_CTRL_PORT  (ICS_SCI1_PD3_PD5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PB5_PB6)   /* SCI5 PB5/TXD5 PB6/RXD5 */
    #define ICS_INT_ERI    VECT(SCI5,ERI5)
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_INT_TEI    VECT(SCI5,TEI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PB5_PB6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_PB2_PB1)   /* SCI6 PB2/TXD6 PB1/RXD6 */
    #define ICS_INT_ERI    VECT(SCI6,ERI6)
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_INT_TEI    VECT(SCI6,TEI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_PB2_PB1)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_PB0_PA5)   /* SCI6 PB0/TXD6 PA5/RXD6 */
    #define ICS_INT_ERI    VECT(SCI6,ERI6)
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_INT_TEI    VECT(SCI6,TEI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_PB0_PA5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_P81_P80)   /* SCI6 P81/TXD6 P80/RXD6 */
    #define ICS_INT_ERI    VECT(SCI6,ERI6)
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_INT_TEI    VECT(SCI6,TEI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_P81_P80)
#else
    #error Please select a valid SCI channel
#endif

#elif   defined(BSP_MCU_RX26T)                  /* for RX26T */
#if (ICS_SCI_CH_SELECT == ICS_SCI1_PD3_PD5)     /* SCI1 PD3/TXD1 PD5/RXD1 */
    #define ICS_INT_RXI    VECT(SCI1,RXI1)
    #define ICS_INT_TXI    VECT(SCI1,TXI1)
    #define ICS_CTRL_PORT  (ICS_SCI1_PD3_PD5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PD7_PE0)   /* SCI5 PD7/TXD5 PE0/RXD5 */
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PD7_PE0)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PB5_PB6)   /* SCI5 PB5/TXD5 PB6/RXD5 */
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PB5_PB6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_P81_P80)   /* SCI6 P81/TXD6 P80/RXD6 */
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_P81_P80)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_PB2_PB1)   /* SCI6 PB2/TXD6 PB1/RXD6 */
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_PB2_PB1)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_PD4_PD6)  /* SCI12 PD4/TXD12 PD6/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_PD4_PD6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_P01_P00)  /* SCI12 P01/TXD12 P00/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_P01_P00)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_P81_P80)  /* SCI12 P81/TXD12 P80/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_P81_P80)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_P23_P22)  /* SCI12 P23/TXD12 P22/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_P23_P22)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_PB5_PB6)  /* SCI12 PB5/TXD12 PB6/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_PB5_PB6)
#else
    #error Please select a valid SCI channel
#endif

#elif   defined(BSP_MCU_RX66T)                  /* for RX66T */
#if (ICS_SCI_CH_SELECT == ICS_SCI1_PD3_PD5)     /* SCI1 PD3/TXD1 PD5/RXD1 */
    #define ICS_INT_RXI    VECT(SCI1,RXI1)
    #define ICS_INT_TXI    VECT(SCI1,TXI1)
    #define ICS_CTRL_PORT  (ICS_SCI1_PD3_PD5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PD7_PE0)   /* SCI5 PD7/TXD5 PE0/RXD5 */
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PD7_PE0)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PB5_PB6)   /* SCI5 PB5/TXD5 PB6/RXD5 */
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PB5_PB6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_PB0_PB1)   /* SCI6 PB0/TXD6 PB1/RXD6 */
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_PB0_PB1)
#elif (ICS_SCI_CH_SELECT == ICS_SCI8_PD0_PD1)   /* SCI8 PD0/TXD8 PD1/RXD8 */
    #define ICS_INT_RXI    VECT(SCI8,RXI8)
    #define ICS_INT_TXI    VECT(SCI8,TXI8)
    #define ICS_CTRL_PORT  (ICS_SCI8_PD0_PD1)
#elif (ICS_SCI_CH_SELECT == ICS_SCI8_PC1_PC0)   /* SCI8 PC1/TXD8 PC0/RXD8 */
    #define ICS_INT_RXI    VECT(SCI8,RXI8)
    #define ICS_INT_TXI    VECT(SCI8,TXI8)
    #define ICS_CTRL_PORT  (ICS_SCI8_PC1_PC0)
#elif (ICS_SCI_CH_SELECT == ICS_SCI8_PA4_PA5)   /* SCI8 PA4/TXD8 PA5/RXD8 */
    #define ICS_INT_RXI    VECT(SCI8,RXI8)
    #define ICS_INT_TXI    VECT(SCI8,TXI8)
    #define ICS_CTRL_PORT  (ICS_SCI8_PA4_PA5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI8_P23_P22)   /* SCI8 P23/TXD8 P22/RXD8 */
    #define ICS_INT_RXI    VECT(SCI8,RXI8)
    #define ICS_INT_TXI    VECT(SCI8,TXI8)
    #define ICS_CTRL_PORT  (ICS_SCI8_P23_P22)
#elif (ICS_SCI_CH_SELECT == ICS_SCI9_P01_P00)   /* SCI9 P01/TXD9 P00/RXD9 */
    #define ICS_INT_RXI    VECT(SCI9,RXI9)
    #define ICS_INT_TXI    VECT(SCI9,TXI9)
    #define ICS_CTRL_PORT  (ICS_SCI9_P01_P00)
#elif (ICS_SCI_CH_SELECT == ICS_SCI9_PA3_PA2)   /* SCI9 PA3/TXD9 PA2/RXD9 */
    #define ICS_INT_RXI    VECT(SCI9,RXI9)
    #define ICS_INT_TXI    VECT(SCI9,TXI9)
    #define ICS_CTRL_PORT  (ICS_SCI9_PA3_PA2)
#elif (ICS_SCI_CH_SELECT == ICS_SCI9_PG1_PG0)   /* SCI9 PG1/TXD9 PG0/RXD9 */
    #define ICS_INT_RXI    VECT(SCI9,RXI9)
    #define ICS_INT_TXI    VECT(SCI9,TXI9)
    #define ICS_CTRL_PORT  (ICS_SCI9_PG1_PG0)
#elif (ICS_SCI_CH_SELECT == ICS_SCI11_PD3_PD5)  /* SCI11 PD3/TXD11 PD5/RXD11 */
    #define ICS_INT_RXI    VECT(SCI11,RXI11)
    #define ICS_INT_TXI    VECT(SCI11,TXI11)
    #define ICS_CTRL_PORT  (ICS_SCI11_PD3_PD5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI11_PB5_PB6)  /* SCI11 PB5/TXD11 PB6/RXD11 */
    #define ICS_INT_RXI    VECT(SCI11,RXI11)
    #define ICS_INT_TXI    VECT(SCI11,TXI11)
    #define ICS_CTRL_PORT  (ICS_SCI11_PB5_PB6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI11_PA0_PA1)  /* SCI11 PA0/TXD11 PA1/RXD11 */
    #define ICS_INT_RXI    VECT(SCI11,RXI11)
    #define ICS_INT_TXI    VECT(SCI11,TXI11)
    #define ICS_CTRL_PORT  (ICS_SCI11_PA0_PA1)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_PB5_PB6)  /* SCI12 PB5/TXD12 PB6/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_PB5_PB6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_P23_P22)  /* SCI12 P23/TXD12 P22/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_P23_P22)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_P01_P00)  /* SCI12 P01/TXD12 P00/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_P01_P00)
#else
    #error Please select a valid SCI channel
#endif

#elif   defined(BSP_MCU_RX72T)                  /* for RX72T */
#if (ICS_SCI_CH_SELECT == ICS_SCI1_PD3_PD5)     /* SCI1 PD3/TXD1 PD5/RXD1 */
    #define ICS_INT_RXI    VECT(SCI1,RXI1)
    #define ICS_INT_TXI    VECT(SCI1,TXI1)
    #define ICS_CTRL_PORT  (ICS_SCI1_PD3_PD5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PD7_PE0)   /* SCI5 PD7/TXD5 PE0/RXD5 */
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PD7_PE0)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PB5_PB6)   /* SCI5 PB5/TXD5 PB6/RXD5 */
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PB5_PB6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_PB0_PB1)   /* SCI6 PB0/TXD6 PB1/RXD6 */
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_PB0_PB1)
#elif (ICS_SCI_CH_SELECT == ICS_SCI8_PD0_PD1)   /* SCI8 PD0/TXD8 PD1/RXD8 */
    #define ICS_INT_RXI    VECT(SCI8,RXI8)
    #define ICS_INT_TXI    VECT(SCI8,TXI8)
    #define ICS_CTRL_PORT  (ICS_SCI8_PD0_PD1)
#elif (ICS_SCI_CH_SELECT == ICS_SCI8_PC1_PC0)   /* SCI8 PC1/TXD8 PC0/RXD8 */
    #define ICS_INT_RXI    VECT(SCI8,RXI8)
    #define ICS_INT_TXI    VECT(SCI8,TXI8)
    #define ICS_CTRL_PORT  (ICS_SCI8_PC1_PC0)
#elif (ICS_SCI_CH_SELECT == ICS_SCI8_PA4_PA5)   /* SCI8 PA4/TXD8 PA5/RXD8 */
    #define ICS_INT_RXI    VECT(SCI8,RXI8)
    #define ICS_INT_TXI    VECT(SCI8,TXI8)
    #define ICS_CTRL_PORT  (ICS_SCI8_PA4_PA5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI8_P23_P22)   /* SCI8 P23/TXD8 P22/RXD8 */
    #define ICS_INT_RXI    VECT(SCI8,RXI8)
    #define ICS_INT_TXI    VECT(SCI8,TXI8)
    #define ICS_CTRL_PORT  (ICS_SCI8_P23_P22)
#elif (ICS_SCI_CH_SELECT == ICS_SCI9_P01_P00)   /* SCI9 P01/TXD9 P00/RXD9 */
    #define ICS_INT_RXI    VECT(SCI9,RXI9)
    #define ICS_INT_TXI    VECT(SCI9,TXI9)
    #define ICS_CTRL_PORT  (ICS_SCI9_P01_P00)
#elif (ICS_SCI_CH_SELECT == ICS_SCI9_PA3_PA2)   /* SCI9 PA3/TXD9 PA2/RXD9 */
    #define ICS_INT_RXI    VECT(SCI9,RXI9)
    #define ICS_INT_TXI    VECT(SCI9,TXI9)
    #define ICS_CTRL_PORT  (ICS_SCI9_PA3_PA2)
#elif (ICS_SCI_CH_SELECT == ICS_SCI9_PG1_PG0)   /* SCI9 PG1/TXD9 PG0/RXD9 */
    #define ICS_INT_RXI    VECT(SCI9,RXI9)
    #define ICS_INT_TXI    VECT(SCI9,TXI9)
    #define ICS_CTRL_PORT  (ICS_SCI9_PG1_PG0)
#elif (ICS_SCI_CH_SELECT == ICS_SCI11_PD3_PD5)  /* SCI11 PD3/TXD11 PD5/RXD11 */
    #define ICS_INT_RXI    VECT(SCI11,RXI11)
    #define ICS_INT_TXI    VECT(SCI11,TXI11)
    #define ICS_CTRL_PORT  (ICS_SCI11_PD3_PD5)
#elif (ICS_SCI_CH_SELECT == ICS_SCI11_PB5_PB6)  /* SCI11 PB5/TXD11 PB6/RXD11 */
    #define ICS_INT_RXI    VECT(SCI11,RXI11)
    #define ICS_INT_TXI    VECT(SCI11,TXI11)
    #define ICS_CTRL_PORT  (ICS_SCI11_PB5_PB6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI11_PA0_PA1)  /* SCI11 PA0/TXD11 PA1/RXD11 */
    #define ICS_INT_RXI    VECT(SCI11,RXI11)
    #define ICS_INT_TXI    VECT(SCI11,TXI11)
    #define ICS_CTRL_PORT  (ICS_SCI11_PA0_PA1)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_PB5_PB6)  /* SCI12 PB5/TXD12 PB6/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_PB5_PB6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_P23_P22)  /* SCI12 P23/TXD12 P22/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_P23_P22)
#elif (ICS_SCI_CH_SELECT == ICS_SCI12_P01_P00)  /* SCI12 P01/TXD12 P00/RXD12 */
    #define ICS_INT_RXI    VECT(SCI12,RXI12)
    #define ICS_INT_TXI    VECT(SCI12,TXI12)
    #define ICS_CTRL_PORT  (ICS_SCI12_P01_P00)
#else
    #error Please select a valid SCI channel
#endif

#elif   defined(BSP_MCU_RX72M)                  /* for RX72M */
#if (ICS_SCI_CH_SELECT == ICS_SCI1_PF0_PF2)     /* SCI1 PF0/TXD1 PF2/RXD1 */
    #define ICS_INT_RXI    VECT(SCI1,RXI1)
    #define ICS_INT_TXI    VECT(SCI1,TXI1)
    #define ICS_CTRL_PORT  (ICS_SCI1_PF0_PF2)
#elif (ICS_SCI_CH_SELECT == ICS_SCI2_P50_P52)   /* SCI2 P50/TXD2 P52/RXD2 */
    #define ICS_INT_RXI    VECT(SCI2,RXI2)
    #define ICS_INT_TXI    VECT(SCI2,TXI2)
    #define ICS_CTRL_PORT  (ICS_SCI2_P50_P52)
#elif (ICS_SCI_CH_SELECT == ICS_SCI3_P23_P25)   /* SCI3 P23/TXD3 P25/RXD3 */
    #define ICS_INT_RXI    VECT(SCI3,RXI3)
    #define ICS_INT_TXI    VECT(SCI3,TXI3)
    #define ICS_CTRL_PORT  (ICS_SCI3_P23_P25)
#elif (ICS_SCI_CH_SELECT == ICS_SCI4_PB1_PB0)   /* SCI4 PB1/TXD4 PB0/RXD4 */
    #define ICS_INT_RXI    VECT(SCI4,RXI4)
    #define ICS_INT_TXI    VECT(SCI4,TXI4)
    #define ICS_CTRL_PORT  (ICS_SCI4_PB1_PB0)
#elif (ICS_SCI_CH_SELECT == ICS_SCI5_PA4_PA3)   /* SCI5 PA4/TXD5 PA3/RXD5 */
    #define ICS_INT_RXI    VECT(SCI5,RXI5)
    #define ICS_INT_TXI    VECT(SCI5,TXI5)
    #define ICS_CTRL_PORT  (ICS_SCI5_PA4_PA3)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_P00_P01)   /* SCI6 P00/TXD6 P01/RXD6 */
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_P00_P01)
#elif (ICS_SCI_CH_SELECT == ICS_SCI6_PB1_PB0)   /* SCI6 PB1/TXD6 PB0/RXD6 */
    #define ICS_INT_RXI    VECT(SCI6,RXI6)
    #define ICS_INT_TXI    VECT(SCI6,TXI6)
    #define ICS_CTRL_PORT  (ICS_SCI6_PB1_PB0)
#elif (ICS_SCI_CH_SELECT == ICS_SCI8_PJ2_PC6)   /* SCI8 PJ2/TXD8 PC6/RXD8 */
    #define ICS_INT_RXI    VECT(SCI8,RXI8)
    #define ICS_INT_TXI    VECT(SCI8,TXI8)
    #define ICS_CTRL_PORT  (ICS_SCI8_PJ2_PC6)
#elif (ICS_SCI_CH_SELECT == ICS_SCI8_PJ2_PJ1)   /* SCI8 PJ2/TXD8 PJ1/RXD8 */
    #define ICS_INT_RXI    VECT(SCI8,RXI8)
    #define ICS_INT_TXI    VECT(SCI8,TXI8)
    #define ICS_CTRL_PORT  (ICS_SCI8_PJ2_PJ1)
#else
    #error Please select a valid SCI channel
#endif

#else
    #error Please select a valid CPU board
#endif
/**********************************************************************************************************************
 Global Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/

#endif /* RMW_R_APP_RMW_MCU_H_ */
