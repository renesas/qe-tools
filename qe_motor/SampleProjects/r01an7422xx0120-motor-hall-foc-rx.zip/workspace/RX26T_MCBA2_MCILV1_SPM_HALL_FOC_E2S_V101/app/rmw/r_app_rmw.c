/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/******************************************************************************************************************//**
 * @file          r_app_rmw.c
 * @version       1.00
 * @brief         Provide interface allowing user drive motor through Renesas Motor Workbench
 * @note          This RMW module is for Hall Vector module
 *********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version
*         : 30.10.2024 1.00
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <machine.h>

/* Main associated header file */
#include "r_app_rmw.h"
#include "r_motor_module_cfg.h"
#include "r_motor_hall_vector_api.h"

/*******************************************************************************************************************//**
 * @addtogroup RMW_UI
 * @{
 **********************************************************************************************************************/

/***********************************************************************************************************************
* Macro definitions
***********************************************************************************************************************/
#define     APP_RMW_PRV_CONF_MOTOR_TYPE ("Brushless DC Motor")          ///< "Motor type" to be displayed in main window
#define     APP_RMW_PRV_CONF_CONTROL    ("Hall Sensor Vector Control")  ///< "Control" to be displayed in main window
#define     APP_RMW_PRV_CONF_INVERTER   ("MCI-LV-1")                    ///< Motor type  to be displayed in main window

/***********************************************************************************************************************
 Typedef definitions
 **********************************************************************************************************************/

/***********************************************************************************************************************
* Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
st_rmw_param_buffer_t   g_st_rmw_input_buffer;                          ///< Structure for ICS input
uint8_t     g_u1_update_param_flag = 0;                                 ///< Update commands and configurations flag
uint16_t    g_u2_conf_hw           = 0x0000;                            ///< Legacy information variable, DO NOT REMOVE
uint16_t    g_u2_conf_sw           = 0x0000;                            ///< Legacy information variable, DO NOT REMOVE
uint16_t    g_u2_conf_tool         = 0x0000;                            ///< Legacy information variable, DO NOT REMOVE
uint8_t     g_u1_conf_motor_type[] = APP_RMW_PRV_CONF_MOTOR_TYPE;       ///< String to be displayed as Motor Type
uint8_t     g_u1_conf_control[]    = APP_RMW_PRV_CONF_CONTROL;          ///< String to be displayed as Control
uint8_t     g_u1_conf_inverter[]   = APP_RMW_PRV_CONF_INVERTER;         ///< String to be displayed as Inverter
uint8_t     g_u1_conf_motor_type_len = sizeof(g_u1_conf_motor_type) - 1;///< Length of the Motor Type string
uint8_t     g_u1_conf_control_len    = sizeof(g_u1_conf_control) - 1;   ///< Length of the Control string
uint8_t     g_u1_conf_inverter_len   = sizeof(g_u1_conf_inverter) - 1;  ///< Length of the Inverter string

/* Operation variables */
/**
 * System mode & command input
 * @ingroup RMW_UI_COMMAND
 * @see RMW_UI_COMMAND
 */
uint8_t     com_u1_system_mode;

/**
 * System mode & command
 * @ingroup RMW_UI_COMMAND
 * @see RMW_UI_COMMAND
 */
uint8_t     g_u1_system_mode;

/*******************************************************************************************************************//**
 * @defgroup RMW_UI_WRITE_PARAMETER COM Parameter Apply Switch
 * @brief   COM Parameter Apply Switch
 * @details @ref RMW_UI_COM_PARAM will be applied, when @ref com_u1_enable_write equals to @ref g_u1_enable_write.
 *
 * @{
 **********************************************************************************************************************/
/**
 * @brief Parameter write switch
 * @see   RMW_UI_WRITE_PARAMETER
 */
uint8_t     com_u1_enable_write;

/**
 * @brief If this value equals to @ref com_u1_enable_write, parameters will be applied and this value will be toggled
 * @see   RMW_UI_WRITE_PARAMETER
 */
uint8_t     g_u1_enable_write;

/*******************************************************************************************************************//**
 * @}
 **********************************************************************************************************************/
/**
 * @defgroup UI_SELECTION  UI Selection
 * @brief The active UI, write to @ref com_u1_sw_userif to change the active UI
 *        |  UI    | Value |
 *        | ---    | ---   |
 *        |RMW UI  | 0     |
 *        |Board UI| 1     |
 * @{
 */
uint8_t     com_u1_sw_userif;               ///<  User interface switch
uint8_t     g_u1_sw_userif;                 ///<  User interface switch
/** @} *//* End of name UI Selection*/

/*******************************************************************************************************************//**
 * @defgroup RMW_UI_COM_PARAM  COM Parameters
 * @brief   COM Parameters requires manual apply
 * @details These parameters will be applied in after the control cyclic process
 * @{
 **********************************************************************************************************************/
/* Offset parameters */
uint16_t    com_u2_offset_calc_time;        ///<  Current offset calculation time
float       com_f4_offset_rotor_rad;        ///<  The rotor angle offset (electrical angle) [rad]

/* Motor parameters */
uint16_t    com_u2_mtr_pp;                  ///<  Pole pairs
float       com_f4_mtr_r;                   ///<  Resistance [ohm]
float       com_f4_mtr_ld;                  ///<  d-axis inductance [H]
float       com_f4_mtr_lq;                  ///<  q-axis inductance [H]
float       com_f4_mtr_m;                   ///<  Permanent magnetic flux [Wb]
float       com_f4_mtr_j;                   ///<  Rotor inertia [kgm^2]
float       com_f4_nominal_current_rms;     ///<  The nominal current[Arms]
float       com_f4_max_speed_rpm;           ///<  Maximum speed [rpm]

/* Sensor parameters */
/**
 * COM variable
 * @copydoc st_sensor_hall_cfg_t::f4_spd_mix_switch_th
 * @see     st_sensor_hall_cfg_t::f4_spd_mix_switch_th */
float       com_f4_hall_spdmix_elec_speed_th;

/**
 * COM variable
 * @copydoc st_sensor_hall_cfg_t::f4_spd_mix_dev_th
 * @see     st_sensor_hall_cfg_t::f4_spd_mix_dev_th */
float       com_f4_hall_spdmix_dev_th;

/**
 * COM variable
 * @copydoc st_sensor_hall_cfg_t::f4_angle_correct
 * @see     st_sensor_hall_cfg_t::f4_angle_correct */
float       com_f4_hall_angle_correct;

/**
 * COM variable
 * @copydoc st_sensor_hall_cfg_t::u1_speed_select
 * @see     st_sensor_hall_cfg_t::u1_speed_select */
float       com_f4_hall_speed_select;

/* Control parameters */
/* Current control */
float       com_f4_current_omega_hz;        ///<  Natural frequency for current loop [Hz]
float       com_f4_current_zeta;            ///<  Damping ratio for current loop

/* Speed control */
float       com_f4_speed_omega_hz;          ///<  Natural frequency for speed loop [Hz]
float       com_f4_speed_zeta;              ///<  Damping ratio for speed loop
float       com_f4_speed_rate_limit_rpm;    ///<  Limit of speed change [rpm/s]
float       com_f4_overspeed_limit_rpm;     ///<  Over-speed limit [rpm] (mechanical)

/* Friction compensation */
/** COM variable
 * @copydoc st_friction_comp_cfg_t::u1_f4_static_friction_torque_current
 * @see     st_friction_comp_cfg_t::u1_f4_static_friction_torque_current
 * @see     R_MOTOR_SPEED_FrictionParameterUpdate
 */
float       com_f4_friction_comp_static;

/** COM variable
 * @copydoc st_friction_comp_cfg_t::f4_static_friction_torque_current
 * @see     st_friction_comp_cfg_t::f4_static_friction_torque_current
 * @see     R_MOTOR_SPEED_FrictionParameterUpdate
 */
float       com_f4_friction_comp_brake_speed;

/** COM variable
 * @copydoc st_friction_comp_cfg_t::f4_coulombs_friction_troque_current
 * @see     st_friction_comp_cfg_t::f4_coulombs_friction_troque_current
 * @see     R_MOTOR_SPEED_FrictionParameterUpdate
 */
float       com_f4_friction_comp_coulombs;

/** COM variable
 * @copydoc st_friction_comp_cfg_t::f4_viscous_friction_coef
 * @see     st_friction_comp_cfg_t::f4_viscous_friction_coef
 * @see     R_MOTOR_SPEED_FrictionParameterUpdate
 *  */
float       com_f4_friction_comp_viscous;


/* Open-loop control */
float       com_f4_ol_crnt_ref;             ///<  Open-loop current command [A]

/* Optional functions */
/* Voltage error compensation */
uint8_t     com_u1_flag_volt_err_comp_use;  ///<  Flags whether use voltage error compensation

/* Flux-weakening control */
uint8_t     com_u1_flag_fluxwkn_use;        ///<  Flags whether use flux-weakening
/*******************************************************************************************************************//**
 * @} (end defgroup RMW_UI_COM_PARAM)
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @defgroup RMW_UI_CMD_VAL COM Command Values
 * @brief COM Command Values that will be applied instantly.
 * @details These command values will be applied in @ref r_app_rmw_update_command
 *
 * @{
 **********************************************************************************************************************/
float       com_f4_ref_speed_rpm;   ///< Motor speed reference [rpm] (mechanical)
float       com_f4_torque_ref_nm;   ///< Torque command [Nm]
/*******************************************************************************************************************//**
 * @} (end defgroup RMW_UI_CMD_VAL)
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Private global variables and functions
 **********************************************************************************************************************/
static uint8_t  s_u1_cnt_ics = 0;                   ///<  Counter for period of calling "scope_watchpoint"
static void r_app_rmw_system_mode(void);
static void r_app_rmw_check_com_input(void);
static void r_app_rmw_update_params(void);
static void r_app_rmw_update_command(void);

/*******************************************************************************************************************//**
 * @brief  Initialize RMW UI.
 * @param  None
 * @return None
 **********************************************************************************************************************/
void r_app_rmw_ui_init(void)
{
    /* Operation variables */
    com_u1_system_mode  = RMW_SYSMODE_STOP;
    g_u1_system_mode    = RMW_SYSMODE_STOP;
    com_u1_enable_write = 0;
    g_u1_enable_write   = 0;
    com_u1_sw_userif    = APP_CFG_USE_UI;
    g_u1_sw_userif      = APP_CFG_USE_UI;

    /* Offset parameters */
    com_u2_offset_calc_time = CURRENT_CFG_OFFSET_CALC_TIME;
    com_f4_offset_rotor_rad = 0.0f;

    /* Motor parameters */
    com_u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS;
    com_f4_mtr_r               = MOTOR_CFG_RESISTANCE;
    com_f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE;
    com_f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE;
    com_f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX;
    com_f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA;
    com_f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS;
    com_f4_max_speed_rpm       = MOTOR_CFG_MAX_SPEED_RPM;

    /* Control parameters */
    /* Sensor module */
    com_f4_hall_angle_correct        = SENSOR_HALL_CFG_ANGLE_CORRECT;
    com_f4_hall_spdmix_dev_th        = SENSOR_HALL_CFG_SPEED_DEVIATION_TOLERANCE;
    com_f4_hall_spdmix_elec_speed_th = SENSOR_HALL_CFG_SPEED_MIX_TH;
    com_f4_hall_speed_select         = SENSOR_HALL_CFG_SPEED_SELECT;

    /* Current control */
    com_f4_current_omega_hz = CURRENT_CFG_OMEGA;
    com_f4_current_zeta     = CURRENT_CFG_ZETA;

    /* Speed control */
    com_f4_speed_omega_hz       = SPEED_CFG_OMEGA;
    com_f4_speed_zeta           = SPEED_CFG_ZETA;
    com_f4_ref_speed_rpm        = 0.0f;
    com_f4_speed_rate_limit_rpm = SPEED_CFG_RATE_LIMIT_RPM;
    com_f4_overspeed_limit_rpm  = SPEED_CFG_SPEED_LIMIT_RPM;
    com_f4_friction_comp_brake_speed = SPEED_CFG_FRICTION_BRAKE_SPEED;
    com_f4_friction_comp_coulombs = SPEED_CFG_FRICTION_COULOMBS;
    com_f4_friction_comp_static = SPEED_CFG_FRICTION_STATIC;
    com_f4_friction_comp_viscous = SPEED_CFG_FRICTION_VISCOUS_COEF;

    /* Torque control */
    com_f4_torque_ref_nm = 0.0f;

    /* Open-loop control */
    com_f4_ol_crnt_ref = 0.0f;

    /* Optional functions */


    /* Voltage error compensation */
    com_u1_flag_volt_err_comp_use = CURRENT_CFG_VOLT_ERR_COMP;

    /* Flux-weakening control */
    com_u1_flag_fluxwkn_use = SPEED_CFG_FLUX_WEAKENING;
} /* End of function r_app_rmw_ui_init */

/*******************************************************************************************************************//**
 * @brief  RMW communication main-loop process
 * @param  None
 * @return None
 **********************************************************************************************************************/
void r_app_rmw_ui_mainloop(void)
{
    r_app_rmw_system_mode();
} /* End of function r_app_rmw_ui_mainloop */

/*******************************************************************************************************************//**
 * @brief  Store COM parameters to the input buffer (@ref g_st_rmw_input_buffer)
 * @param  None
 * @return None
 * @see    RMW_UI_COM_PARAM
 **********************************************************************************************************************/
void r_app_rmw_copy_com_to_buffer(void)
{
    r_app_rmw_check_com_input();

    /***** When com_s2_enable_sw and g_u1_enable_write are same value, rewrite enable. *****/
    if (com_u1_enable_write == g_u1_enable_write)
    {
        /* Offset parameters */
        g_st_rmw_input_buffer.u2_offset_calc_time = com_u2_offset_calc_time;
        g_st_rmw_input_buffer.f4_offset_rotor_rad = com_f4_offset_rotor_rad;

        /* Motor parameters */
        g_st_rmw_input_buffer.st_motor.u2_mtr_pp              = com_u2_mtr_pp;
        g_st_rmw_input_buffer.st_motor.f4_mtr_r               = com_f4_mtr_r;
        g_st_rmw_input_buffer.st_motor.f4_mtr_ld              = com_f4_mtr_ld;
        g_st_rmw_input_buffer.st_motor.f4_mtr_lq              = com_f4_mtr_lq;
        g_st_rmw_input_buffer.st_motor.f4_mtr_m               = com_f4_mtr_m;
        g_st_rmw_input_buffer.st_motor.f4_mtr_j               = com_f4_mtr_j;
        g_st_rmw_input_buffer.st_motor.f4_nominal_current_rms = com_f4_nominal_current_rms;
        g_st_rmw_input_buffer.f4_max_speed_rpm                = com_f4_max_speed_rpm;

        /* Control parameters */
        /* Sensor */
        g_st_rmw_input_buffer.f4_hall_angle_correct_rad = com_f4_hall_angle_correct;
        g_st_rmw_input_buffer.f4_hall_spdmix_dev_th = com_f4_hall_spdmix_dev_th;
        g_st_rmw_input_buffer.f4_hall_spdmix_elec_speed_th = com_f4_hall_spdmix_elec_speed_th;
        g_st_rmw_input_buffer.u1_hall_speed_select = com_f4_hall_speed_select;

        /* Current control */
        g_st_rmw_input_buffer.f4_current_omega_hz = com_f4_current_omega_hz;
        g_st_rmw_input_buffer.f4_current_zeta     = com_f4_current_zeta;

        /* Speed control */
        g_st_rmw_input_buffer.f4_speed_omega_hz            = com_f4_speed_omega_hz;
        g_st_rmw_input_buffer.f4_speed_zeta                = com_f4_speed_zeta;
        g_st_rmw_input_buffer.f4_ref_speed_rpm             = com_f4_ref_speed_rpm;
        g_st_rmw_input_buffer.f4_speed_rate_limit_rpm      = com_f4_speed_rate_limit_rpm;
        g_st_rmw_input_buffer.f4_overspeed_limit_rpm       = com_f4_overspeed_limit_rpm;
        g_st_rmw_input_buffer.f4_friction_comp_brake_speed = com_f4_friction_comp_brake_speed;
        g_st_rmw_input_buffer.f4_friction_comp_coulombs    = com_f4_friction_comp_coulombs;
        g_st_rmw_input_buffer.f4_friction_comp_static      = com_f4_friction_comp_static;
        g_st_rmw_input_buffer.f4_friction_comp_viscous     = com_f4_friction_comp_viscous;

        /* Torque control */
        g_st_rmw_input_buffer.f4_torque_ref_nm = com_f4_torque_ref_nm;

        /* Open-loop control */
        g_st_rmw_input_buffer.f4_ol_crnt_ref = com_f4_ol_crnt_ref;

        /* Optional functions */


        /* Voltage error compensation */
        g_st_rmw_input_buffer.u1_flag_volt_err_comp_use = com_u1_flag_volt_err_comp_use;

        /* Flux-weakening control */
        g_st_rmw_input_buffer.u1_flag_fluxwkn_use = com_u1_flag_fluxwkn_use;

        /* copy variables com to ICS input */
        g_u1_update_param_flag = 1;
        g_u1_enable_write     ^= 1;                     /* change every time 0 and 1 */
    }
} /* End of function r_app_rmw_copy_com_to_buffer */


/*******************************************************************************************************************//**
 * @brief  Process for ICS(Analyzer), decimate ICS watch point function, update COM parameters if flag is set,
 *         or update COM commands if flag is not set
 * @param  None
 * @return None
 * @note   This function should be called after motor control interrupt, so the parameters will not be updated partially
 **********************************************************************************************************************/
void r_app_rmw_interrupt_handler(void)
{
    s_u1_cnt_ics++;

    /* Decimation of ICS call */
    if (ICS_DECIMATION < s_u1_cnt_ics)
    {
        s_u1_cnt_ics = 0;

        /* Call ICS */
        ics2_watchpoint();
    }

    /* Update commands and configurations when trigger flag is set */
    if (1 == g_u1_update_param_flag)
    {
        r_app_rmw_update_params();
        g_u1_update_param_flag = 0;
    }
    else
    {
        if (MAIN_UI_RMW == g_u1_sw_userif)
        {
            r_app_rmw_update_command();
        }
    }
} /* End of function r_app_rmw_interrupt_handler */


/*******************************************************************************************************************//**
 * @brief  Process system mode command
 * @param  None
 * @return None
 * @see    RMW_UI_COMMAND_
 **********************************************************************************************************************/
static void r_app_rmw_system_mode(void)
{
    static uint8_t s_u1_offset_cal_status;
    if (g_u1_system_mode != com_u1_system_mode)
    {
        /* Actions on mode changing */
        switch (com_u1_system_mode)
        {
            case RMW_SYSMODE_STOP:
                /* Stop motor anyway */
                R_MOTOR_HALL_VECTOR_MotorStop(&g_st_hall_vector);
                g_u1_system_mode = RMW_SYSMODE_STOP;
                break;

            case RMW_SYSMODE_SPEED:
                R_MOTOR_HALL_VECTOR_CtrlTypeSet(&g_st_hall_vector, MOTOR_CTRL_TYPE_SPEED);
                R_MOTOR_HALL_VECTOR_MotorStart(&g_st_hall_vector);
                g_u1_system_mode = RMW_SYSMODE_SPEED;
                break;

            case RMW_SYSMODE_TORQUE:
                R_MOTOR_HALL_VECTOR_CtrlTypeSet(&g_st_hall_vector, MOTOR_CTRL_TYPE_TORQUE);
                R_MOTOR_HALL_VECTOR_MotorStart(&g_st_hall_vector);
                g_u1_system_mode = RMW_SYSMODE_TORQUE;
                break;

            case RMW_SYSMODE_CURRENT_OL:
                R_MOTOR_HALL_VECTOR_CtrlTypeSet(&g_st_hall_vector, MOTOR_CTRL_TYPE_CURRENT);
                R_MOTOR_HALL_VECTOR_MotorStart(&g_st_hall_vector);
                g_u1_system_mode = RMW_SYSMODE_CURRENT_OL;
                break;

            case RMW_SYSMODE_ADJ_CRNT:
                R_MOTOR_HALL_VECTOR_CtrlTypeSet(&g_st_hall_vector, MOTOR_CTRL_TYPE_ADJ_CRNT_OFFSET);
                R_MOTOR_HALL_VECTOR_MotorStart(&g_st_hall_vector);
                g_u1_system_mode = RMW_SYSMODE_ADJ_CRNT;
                break;

            case RMW_SYSMODE_CLEAR_ERROR:
                R_MOTOR_HALL_VECTOR_MotorErrorCancel(&g_st_hall_vector);
                g_u1_system_mode = RMW_SYSMODE_STOP;
                com_u1_system_mode = RMW_SYSMODE_STOP;
                break;

            case RMW_SYSMODE_POSITION:
            default:
                break;
        }
    }
    else
    {
        uint8_t status;
        status = R_MOTOR_HALL_VECTOR_StatusGet(&g_st_hall_vector);

        /* Actions on specific modes */
        switch (com_u1_system_mode)
        {
            case RMW_SYSMODE_STOP:
            case RMW_SYSMODE_POSITION:
            case RMW_SYSMODE_SPEED:
            case RMW_SYSMODE_TORQUE:
            case RMW_SYSMODE_CURRENT_OL:
            case RMW_SYSMODE_CLEAR_ERROR:

                /* These statements are intensively merged */
                if (STATEMACHINE_STATE_ERROR == status)
                {
                    com_u1_system_mode = RMW_SYSMODE_STOP;
                    g_u1_system_mode = RMW_SYSMODE_STOP;
                }
                break;
            case RMW_SYSMODE_ADJ_CRNT:

                /* Check INACTIVE flag for control system */
                s_u1_offset_cal_status = R_MOTOR_HALL_VECTOR_OffsetCalibrationStatusGet(&g_st_hall_vector);
                if (MTR_TRUE == s_u1_offset_cal_status)
                {
                    com_u1_system_mode = RMW_SYSMODE_STOP;
                }

                break;
            default:
                break;
        }
    }
} /* End of function r_app_rmw_system_mode */

/*******************************************************************************************************************//**
 * @brief  Check COM parameters inputs, ensure the gap between outer and inner control loop
 * @param  None
 * @return None
 * @see    RMW_UI_COM_PARAM
 **********************************************************************************************************************/
static void r_app_rmw_check_com_input(void)
{
    float f4_temp0;

    /**************************/
    /*    limit variables     */
    /**************************/
    com_f4_ref_speed_rpm = motor_filter_limitf_abs(com_f4_ref_speed_rpm, com_f4_max_speed_rpm);

    /* current natural frequency limit 1Hz ~ 1000Hz */
    com_f4_current_omega_hz = motor_filter_limitf(com_f4_current_omega_hz,
                                                  APP_CFG_MAX_CURRENT_OMEGA,
                                                  APP_CFG_MIN_OMEGA);

    /* natural frequency & damping ratio for speed control loop */
    f4_temp0 = com_f4_current_omega_hz / APP_CFG_FREQ_BAND_LIMIT;
    if (f4_temp0 < com_f4_speed_omega_hz)
    {
        com_f4_speed_omega_hz = f4_temp0;

        /* speed natural frequency minimum limit 1Hz */
        com_f4_speed_omega_hz = motor_filter_lower_limitf(com_f4_speed_omega_hz, APP_CFG_MIN_OMEGA);
    }
} /* End of function r_app_rmw_check_com_input */

/*******************************************************************************************************************//**
 * @brief  Apply parameters in buffer through API
 * @param  None
 * @return None
 * @see    RMW_UI_COM_PARAM
 **********************************************************************************************************************/
static void r_app_rmw_update_params(void)
{
    st_rmw_param_buffer_t *p_st_rmw_input = &g_st_rmw_input_buffer;

    st_current_cfg_t              st_cur_cfg;
    st_speed_cfg_t                st_spd_cfg;
    st_friction_comp_cfg_t        st_friction_cfg;
    st_sensor_hall_cfg_t          st_sensor_hall_cfg;
    st_hall_vector_cfg_t          st_hall_vector_cfg;

    /* Commands */
    R_MOTOR_HALL_VECTOR_TorqueSet(&g_st_hall_vector, p_st_rmw_input->f4_torque_ref_nm);
    R_MOTOR_HALL_VECTOR_SpeedSet(&g_st_hall_vector, p_st_rmw_input->f4_ref_speed_rpm);
    R_MOTOR_HALL_VECTOR_CurrentOpenLoopSet(&g_st_hall_vector,
                                               p_st_rmw_input->f4_ol_crnt_ref,
                                               p_st_rmw_input->f4_ref_speed_rpm);

    /* Manager module */
    st_hall_vector_cfg.st_motor               = p_st_rmw_input->st_motor;
    st_hall_vector_cfg.f4_overspeed_limit_rpm = p_st_rmw_input->f4_overspeed_limit_rpm;
    R_MOTOR_HALL_VECTOR_ParameterUpdate(&g_st_hall_vector, &st_hall_vector_cfg);
    R_MOTOR_HALL_VECTOR_RotorAngleOffsetSet(&g_st_hall_vector, p_st_rmw_input->f4_offset_rotor_rad);

    /* Sensor module */
    st_sensor_hall_cfg.f4_sampling_freq_khz = SENSOR_HALL_CFG_CTRL_FREQ;;
    st_sensor_hall_cfg.f4_angle_correct     = p_st_rmw_input->f4_hall_angle_correct_rad;
    st_sensor_hall_cfg.f4_spd_mix_dev_th    = p_st_rmw_input->f4_hall_spdmix_dev_th;
    st_sensor_hall_cfg.f4_spd_mix_switch_th = p_st_rmw_input->f4_hall_spdmix_elec_speed_th;
    st_sensor_hall_cfg.u2_default_counts    = SENSOR_HALL_CFG_DEFAULT_COUNTS;
    st_sensor_hall_cfg.u2_maximum_period    = SENSOR_HALL_CFG_MAXIMUM_PERIOD;
    st_sensor_hall_cfg.u1_hall_polepairs    = (uint8_t)p_st_rmw_input->st_motor.u2_mtr_pp;
    st_sensor_hall_cfg.u1_speed_select      = p_st_rmw_input->u1_hall_speed_select;
    R_MOTOR_SENSOR_HALL_ParameterUpdate(&g_st_sensor_hall, &st_sensor_hall_cfg);

    /* Current Module */
    st_cur_cfg.u2_offset_calc_time       = p_st_rmw_input->u2_offset_calc_time;
    st_cur_cfg.f4_ctrl_period            = MOTOR_COMMON_CTRL_PERIOD;
    st_cur_cfg.f4_current_omega_hz       = p_st_rmw_input->f4_current_omega_hz;
    st_cur_cfg.f4_current_zeta           = p_st_rmw_input->f4_current_zeta;
    st_cur_cfg.u1_flag_volt_err_comp_use = p_st_rmw_input->u1_flag_volt_err_comp_use;
    st_cur_cfg.st_motor                  = p_st_rmw_input->st_motor;
    R_MOTOR_CURRENT_ParameterUpdate(&g_st_cc, &st_cur_cfg);

    /* Speed module */
    st_spd_cfg.st_motor                = p_st_rmw_input->st_motor;
    st_spd_cfg.u1_flag_fluxwkn_use     = p_st_rmw_input->u1_flag_fluxwkn_use;
    st_spd_cfg.f4_max_speed_rpm        = p_st_rmw_input->f4_max_speed_rpm;
    st_spd_cfg.f4_speed_ctrl_period    = SPEED_CFG_CTRL_PERIOD;
    st_spd_cfg.f4_speed_rate_limit_rpm = p_st_rmw_input->f4_speed_rate_limit_rpm;
    st_spd_cfg.f4_speed_omega_hz       = p_st_rmw_input->f4_speed_omega_hz;
    st_spd_cfg.f4_speed_zeta           = p_st_rmw_input->f4_speed_zeta;
    R_MOTOR_SPEED_ParameterUpdate(&g_st_sc, &st_spd_cfg);

    /* Speed module -> Friction Compensation */
    st_friction_cfg.f4_static_friction_torque_current   = p_st_rmw_input->f4_friction_comp_static;
    st_friction_cfg.f4_static_friction_speed_th_rad     = p_st_rmw_input->f4_friction_comp_brake_speed;
    st_friction_cfg.f4_coulombs_friction_troque_current = p_st_rmw_input->f4_friction_comp_coulombs;
    st_friction_cfg.f4_viscous_friction_coef            = p_st_rmw_input->f4_friction_comp_viscous;
    R_MOTOR_SPEED_FrictionParameterUpdate(&g_st_sc, &st_friction_cfg);
} /* End of function r_app_rmw_update_params */


/*******************************************************************************************************************//**
 * @brief  Transfer COM command values to motor module
 * @param  None
 * @return None
 * @see    RMW_UI_CMD_VAL
 **********************************************************************************************************************/
static void r_app_rmw_update_command(void)
{
    if (RMW_SYSMODE_SPEED == g_u1_system_mode)
    {
        R_MOTOR_HALL_VECTOR_SpeedSet(&g_st_hall_vector, com_f4_ref_speed_rpm);
    }
    else if (RMW_SYSMODE_TORQUE == g_u1_system_mode)
    {
        R_MOTOR_HALL_VECTOR_TorqueSet(&g_st_hall_vector, com_f4_torque_ref_nm);
    }
    else
    {
        /* Do Nothing */
    }
} /* End of function r_app_rmw_update_command */

/*******************************************************************************************************************//**
 * @} (end addtogroup RMW_UI)
 **********************************************************************************************************************/

