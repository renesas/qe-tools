/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/******************************************************************************************************************//**
 * @file          r_motor_sensor_hall_api.c
 * @version       1.00
 * @brief         Angle/speed estimation with hall effect sensor signal inputs
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * History : DD.MM.YYYY Version  Description
 *         : 30.10.2024 1.00     First Release
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include <math.h>
#include "r_motor_sensor_hall_api.h"
#include "r_motor_module_cfg.h"
/*******************************************************************************************************************//**
 * @addtogroup MOTOR_SENSOR_HALL
 * @{
 **********************************************************************************************************************/
/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define     MOTOR_SENSOR_HALL_PRV_TWOPI         (3.14159265358979F * 2.0f)              ///< 2 pi [rad]
#define     MOTOR_SENSOR_HALL_PRV_30DEG_IN_RAD  (MOTOR_SENSOR_HALL_PRV_TWOPI / 12.0f)   ///< pi / 6 [rad] = 30[deg] /
#define     MOTOR_SENSOR_HALL_PRV_U_SHIFT       (2)       ///< Bit position of U signal
#define     MOTOR_SENSOR_HALL_PRV_V_SHIFT       (1)       ///< Bit position of V signal
#define     MOTOR_SENSOR_HALL_PRV_W_SHIFT       (0)       ///< Bit position of W signal

/**********************************************************************************************************************
 Local Typedef definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/
st_sensor_hall_t g_st_sensor_hall; ///< The pre-allocated hall sensor instance

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static float r_motor_sensor_hall_speed_mixed_calc(st_sensor_hall_t * const p_hall, float f4_speed_fast, float f4_speed_precision);
static float r_motor_sensor_hall_clamp01(float f4_input);

/*******************************************************************************************************************//**
 * @brief  Initialize the Hall sensor module with default parameters.
 * @param  None
 * @note   This function will initialize @ref g_st_sensor_hall
 * @return None
 **********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_Open(void)
{
    st_sensor_hall_t * p_hall    = (st_sensor_hall_t *) &g_st_sensor_hall;
    st_sensor_hall_cfg_t * p_cfg = &(p_hall->st_cfg);

    p_hall->u1_hall_pattern[0]           = SENSOR_HALL_CFG_PATTERN_1;
    p_hall->u1_hall_pattern[1]           = SENSOR_HALL_CFG_PATTERN_2;
    p_hall->u1_hall_pattern[2]           = SENSOR_HALL_CFG_PATTERN_3;
    p_hall->u1_hall_pattern[3]           = SENSOR_HALL_CFG_PATTERN_4;
    p_hall->u1_hall_pattern[4]           = SENSOR_HALL_CFG_PATTERN_5;
    p_hall->u1_hall_pattern[5]           = SENSOR_HALL_CFG_PATTERN_6;
    p_hall->u1_hall_pattern[6]           = p_hall->u1_hall_pattern[0];
    p_cfg->u1_speed_select               = SENSOR_HALL_CFG_SPEED_SELECT;
    p_cfg->f4_sampling_freq_khz          = SENSOR_HALL_CFG_CTRL_FREQ;
    p_cfg->f4_angle_correct              = SENSOR_HALL_CFG_ANGLE_CORRECT;
    p_cfg->u2_default_counts             = SENSOR_HALL_CFG_DEFAULT_COUNTS;
    p_cfg->u2_maximum_period             = SENSOR_HALL_CFG_MAXIMUM_PERIOD;
    p_cfg->u1_hall_polepairs             = SENSOR_HALL_CFG_HALL_POLEPAIRS;
    p_cfg->f4_spd_mix_dev_th             = SENSOR_HALL_CFG_SPEED_MIX_TH;
    p_cfg->f4_spd_mix_switch_th          = SENSOR_HALL_CFG_SPEED_DEVIATION_TOLERANCE;

    R_MOTOR_SENSOR_HALL_Reset(p_hall);
}

/*******************************************************************************************************************//**
 * @brief  Close the hall sensor module.
 * @param  None
 * @return None
 **********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_Close (void)
{
    st_sensor_hall_t * p_hall = (st_sensor_hall_t *) &g_st_sensor_hall;

    R_MOTOR_SENSOR_HALL_Reset(p_hall);
}


/*******************************************************************************************************************//**
 * @brief Reset the intermediate variables of the hall sensor module. Hall sensor module do not need reset in motor start-up
 * @param[in] p_hall   The pointer to the hall sensor instance, @ref st_sensor_hall_t
 **********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_Reset (st_sensor_hall_t * const p_hall)
{
    st_sensor_hall_cfg_t * p_cfg = &(p_hall->st_cfg);
    uint8_t i;

    p_hall->u1_hall_signal      = 0U;
    p_hall->u1_last_hall_signal = 0U;
    p_hall->direction           = MOTOR_SENSOR_HALL_DIRECTION_CW;
    p_hall->last_direction      = MOTOR_SENSOR_HALL_DIRECTION_CW;
    p_hall->u2_carrier_count    = 0U;
    p_hall->u1_period_counter   = 0U;
    p_hall->f4_angle             = 0.0f;
    p_hall->f4_angle_per_count   = 0.0f;
    p_hall->f4_calculated_speed  = 0.0f;
    p_hall->f4_calculated_speed_last_pulse = 0.0f;
    p_hall->f4_calculated_speed_movavg     = 0.0f;
    p_hall->f4_output_angle_rad  = 0.0f;
    p_hall->f4_output_speed_rad  = 0.0f;
    p_hall->f4_weight            = 0.0f;

    p_hall->st_input.u1_hall_sensor_bit_u    = 0;
    p_hall->st_input.u1_hall_sensor_bit_v    = 0;
    p_hall->st_input.u1_hall_sensor_bit_w    = 0;

    for (i = 0; i < MOTOR_SENSOR_HALL_NUM_OF_SECTORS; i++)
    {
        p_hall->u2_hall_period[i] = p_cfg->u2_default_counts;
    }
}

/*******************************************************************************************************************//**
 * @brief Update the parameters of the hall sensor module
 * @param[in] p_hall   The pointer to the hall sensor instance, @ref st_sensor_hall_t
 * @param[in] p_cfg    The pointer to the configuration structure, @ref st_sensor_hall_cfg_t
 **********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_ParameterUpdate (st_sensor_hall_t * const p_hall, st_sensor_hall_cfg_t const * const p_cfg)
{
    p_hall->st_cfg = (*p_cfg);

}

/*******************************************************************************************************************//**
 * @brief Set the input of hall sensor module
 * @param[in] p_hall               The pointer to the hall sensor instance, @ref st_sensor_hall_t
 * @param[in] p_st_sensor_input    The pointer to the input structure, @ref st_sensor_hall_input_t
 **********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_ParameterSet (st_sensor_hall_t * const p_hall,
                                       st_sensor_hall_input_t * const p_st_sensor_input)

{
    uint32_t u4_temp_level       = 0U;
    p_hall->st_input = (*p_st_sensor_input);

    u4_temp_level = p_hall->st_input.u1_hall_sensor_bit_u;
    p_hall->u1_hall_signal  = (uint8_t) (u4_temp_level << MOTOR_SENSOR_HALL_PRV_U_SHIFT);
    u4_temp_level = p_hall->st_input.u1_hall_sensor_bit_v;
    p_hall->u1_hall_signal |= (uint8_t) (u4_temp_level << MOTOR_SENSOR_HALL_PRV_V_SHIFT);
    u4_temp_level = p_hall->st_input.u1_hall_sensor_bit_w;
    p_hall->u1_hall_signal |= (uint8_t) (u4_temp_level << MOTOR_SENSOR_HALL_PRV_W_SHIFT);
}

/*******************************************************************************************************************//**
 * @brief Set the output of hall sensor module
 * @param[in] p_hall               The pointer to the hall sensor instance, @ref st_sensor_hall_t
 * @param[in] p_st_sensor_output    The pointer to the output structure, @ref st_sensor_hall_input_t
 **********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_ParameterGet(st_sensor_hall_t * const p_hall,
                                      st_sensor_hall_output_t * p_st_sensor_hall_output)
{
    p_st_sensor_hall_output->f4_angle_rad = p_hall->f4_output_angle_rad;
    p_st_sensor_hall_output->f4_speed_rad = p_hall->f4_output_speed_rad / p_hall->st_cfg.u1_hall_polepairs;
    p_st_sensor_hall_output->f4_speed_lpf_rad = p_st_sensor_hall_output->f4_speed_rad;
}

/*******************************************************************************************************************//**
 * @brief The cyclic processing of hall sensor module. Contains angle estimation and speed calculation.
 * @pre   Call the R_MOTOR_SENSOR_HALL_ParameterSet to set the input for this cycle, @ref st_sensor_hall_input_t
 * @post  Call the R_MOTOR_SENSOR_HALL_ParameterGet to get the output for this cycle, @ref st_sensor_hall_output_t
 * @param[in] p_hall  The pointer to the hall sensor instance, @ref st_sensor_hall_t
 **********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_Cyclic (st_sensor_hall_t * const p_hall)
{
    st_sensor_hall_cfg_t * p_cfg = &p_hall->st_cfg;
    uint32_t u4_uvw_sum          = 0U;
    float    f4_temp_angle       = 0.0f;
    uint8_t  i                   = 0U;
    float    f4_est_speed_max    = 0.0f;
    float    f4_speed_reversal_factor = 1.0f;

    /* Previous Hall signal is invalid in the first run */
    /* Acquire Hall signal as last hall signal to continue */
    if (0U == p_hall->u1_last_hall_signal)
    {
        /* Hall sensor signal acquisition */
        p_hall->u1_last_hall_signal = p_hall->u1_hall_signal;
        return;
    }

    /* Count time with limitation */
    p_hall->u2_carrier_count++;
    if (p_hall->u2_carrier_count > p_cfg->u2_maximum_period)
    {
        p_hall->u2_carrier_count = p_cfg->u2_maximum_period;
    }

    /* Speed & angle estimation */
    /* At the boundary of hall signal change */
    if (p_hall->u1_hall_signal != p_hall->u1_last_hall_signal)
    {
        /* Rotation direction judge */
        p_hall->last_direction = p_hall->direction;

        for (i = 1; i < MOTOR_SENSOR_HALL_NUM_OF_SECTORS + 1; i++)
        {
            if (p_hall->u1_hall_signal == p_hall->u1_hall_pattern[i])
            {
                if (p_hall->u1_last_hall_signal == p_hall->u1_hall_pattern[i - 1])
                {
                    p_hall->direction = MOTOR_SENSOR_HALL_DIRECTION_CW;
                }
            }
        }

        for (i = 0; i < MOTOR_SENSOR_HALL_NUM_OF_SECTORS; i++)
        {
            if (p_hall->u1_hall_signal == p_hall->u1_hall_pattern[i])
            {
                if (p_hall->u1_last_hall_signal == p_hall->u1_hall_pattern[i + 1])
                {
                    p_hall->direction = MOTOR_SENSOR_HALL_DIRECTION_CCW;
                }
            }
        }

        p_hall->u2_hall_period[p_hall->u1_period_counter] = p_hall->u2_carrier_count;
        p_hall->u1_period_counter++;

        if (p_hall->u1_period_counter >= MOTOR_SENSOR_HALL_NUM_OF_SECTORS)
        {
            p_hall->u1_period_counter = 0;
        }

        /* When the change of rotational direction happens */
        if (p_hall->last_direction != p_hall->direction)
        {
            /* Once the period is set to fix value */
            p_hall->u2_hall_period[0] = p_cfg->u2_default_counts;
            p_hall->u2_hall_period[1] = p_cfg->u2_default_counts;
            p_hall->u2_hall_period[2] = p_cfg->u2_default_counts;
            p_hall->u2_hall_period[3] = p_cfg->u2_default_counts;
            p_hall->u2_hall_period[4] = p_cfg->u2_default_counts;
            p_hall->u2_hall_period[5] = p_cfg->u2_default_counts;
            f4_speed_reversal_factor = 0.0f;
        }
        else
        {
            f4_speed_reversal_factor = 1.0f;
        }

        u4_uvw_sum = (uint32_t) p_hall->u2_hall_period[0] + (uint32_t) p_hall->u2_hall_period[1] +
                     (uint32_t) p_hall->u2_hall_period[2] + (uint32_t) p_hall->u2_hall_period[3] +
                     (uint32_t) p_hall->u2_hall_period[4] + (uint32_t) p_hall->u2_hall_period[5];

        /* Increase direction */
        if (MOTOR_SENSOR_HALL_DIRECTION_CW == p_hall->direction)
        {
            p_hall->f4_angle           = -(MOTOR_SENSOR_HALL_PRV_30DEG_IN_RAD);
            p_hall->f4_angle_per_count = (MOTOR_SENSOR_HALL_PRV_TWOPI / (float) u4_uvw_sum);
        }
        /* Decrease direction */
        else
        {
            p_hall->f4_angle           = MOTOR_SENSOR_HALL_PRV_30DEG_IN_RAD;
            p_hall->f4_angle_per_count = -(MOTOR_SENSOR_HALL_PRV_TWOPI / (float) u4_uvw_sum);
        }

        /* Calculate the speed by the time interval between last two edges before */
        p_hall->f4_calculated_speed_last_pulse = (MOTOR_SENSOR_HALL_PRV_TWOPI / 6.0f) * f4_speed_reversal_factor
                                               * (p_cfg->f4_sampling_freq_khz * 1000.0f)
                                               / (p_hall->u2_carrier_count);
        if (MOTOR_SENSOR_HALL_DIRECTION_CCW == p_hall->direction)
        {
            p_hall->f4_calculated_speed_last_pulse = -p_hall->f4_calculated_speed_last_pulse;
        }
        p_hall->f4_calculated_speed_movavg = p_hall->f4_angle_per_count * (p_cfg->f4_sampling_freq_khz * 1000.0f);

        /* Select the speed output */
        switch (p_hall->st_cfg.u1_speed_select)
        {
            case MOTOR_SENSOR_HALL_SPEED_SELECT_MOVAVG:
                p_hall->f4_calculated_speed = p_hall->f4_calculated_speed_movavg;
                break;

            case MOTOR_SENSOR_HALL_SPEED_SELECT_LAST_PULSE:
                p_hall->f4_calculated_speed = p_hall->f4_calculated_speed_last_pulse;
                break;

            case MOTOR_SENSOR_HALL_SPEED_SELECT_AUTO:
            default:
                p_hall->f4_calculated_speed = r_motor_sensor_hall_speed_mixed_calc(p_hall,
                                                                               p_hall->f4_calculated_speed_last_pulse,
                                                                               p_hall->f4_calculated_speed_movavg);
                break;
        }

        p_hall->u2_carrier_count = 0U;
    }
    /* During the same hall signal is detected */
    else
    {
        p_hall->f4_angle = p_hall->f4_angle + p_hall->f4_angle_per_count;
        if (p_hall->f4_angle > MOTOR_SENSOR_HALL_PRV_30DEG_IN_RAD)
        {
            p_hall->f4_angle = MOTOR_SENSOR_HALL_PRV_30DEG_IN_RAD;
        }
        else if (p_hall->f4_angle < -(MOTOR_SENSOR_HALL_PRV_30DEG_IN_RAD))
        {
            p_hall->f4_angle = -(MOTOR_SENSOR_HALL_PRV_30DEG_IN_RAD);
        }
        else
        {
            /* Do nothing */
        }

        /* Calculate estimated maximum speed by time elapse after last edge */
        f4_est_speed_max = (1.0f + p_cfg->f4_spd_mix_dev_th) * (MOTOR_SENSOR_HALL_PRV_TWOPI / 6.0f) / p_hall->u2_carrier_count
                * (p_cfg->f4_sampling_freq_khz * 1000.0f);
        if (f4_est_speed_max >= 1.0f)
        {
            if (p_hall->f4_calculated_speed > f4_est_speed_max)
            {
                p_hall->f4_calculated_speed = f4_est_speed_max;
            }
            else if (p_hall->f4_calculated_speed < -f4_est_speed_max)
            {
                p_hall->f4_calculated_speed = -f4_est_speed_max;
            }
        }

        /* If the time elapsed reach the maximum, the speed should be assumed as 0 */
        if (p_hall->u2_carrier_count == p_cfg->u2_maximum_period)
        {
            p_hall->f4_calculated_speed = 0.0f;
        }
    }

    /* Set the angle according to hall signal */
    f4_temp_angle = p_cfg->f4_angle_correct + p_hall->f4_angle;
    for (i = 0; i < MOTOR_SENSOR_HALL_NUM_OF_SECTORS; i++)
    {
        if (p_hall->u1_hall_signal == p_hall->u1_hall_pattern[i])
        {
            f4_temp_angle += (MOTOR_SENSOR_HALL_PRV_TWOPI / MOTOR_SENSOR_HALL_NUM_OF_SECTORS) * i;
        }
    }

    /* Converted angle within 0..2PI */
    if (f4_temp_angle > MOTOR_SENSOR_HALL_PRV_TWOPI)
    {
        f4_temp_angle = f4_temp_angle - MOTOR_SENSOR_HALL_PRV_TWOPI;
    }
    else if (f4_temp_angle < 0.0f)
    {
        f4_temp_angle = f4_temp_angle + MOTOR_SENSOR_HALL_PRV_TWOPI;
    }
    else
    {
        /* Do nothing */
    }

    /* Position acquisition (hall sensor) */
    p_hall->u1_last_hall_signal = p_hall->u1_hall_signal;
    p_hall->f4_output_speed_rad = p_hall->f4_calculated_speed;
    p_hall->f4_output_angle_rad = f4_temp_angle;
}

/*******************************************************************************************************************//**
 * @brief Update the Hall signal pattern
 * @param[in] p_hall                    The pointer to the hall sensor instance, @ref st_sensor_hall_t
 * @param[in] p_u1_hall_signal_pattern  The pointer to the pattern array, the array should be like the following
 *                                    e.g
 *                                    uint8_t u1_hall_signal_pattern[6] = {1,5,4,6,2,3}; // within 1~6, unique
 *                                    R_MOTOR_SENSOR_HALL_SignalPatternUpdate(p_hall, u1_hall_signal_pattern)
 **********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_SignalPatternUpdate(st_sensor_hall_t * const p_hall,
                                             uint8_t const * const p_u1_hall_signal_pattern)
{
    int32_t i;
    for (i = 0; i < MOTOR_SENSOR_HALL_NUM_OF_SECTORS; i++)
    {
        p_hall->u1_hall_pattern[i] = p_u1_hall_signal_pattern[i];
    }
    p_hall->u1_hall_pattern[MOTOR_SENSOR_HALL_NUM_OF_SECTORS] = p_hall->u1_hall_pattern[0];
}

/***********************************************************************************************************************
 * Private Functions
 **********************************************************************************************************************/
/*******************************************************************************************************************//**
 * @brief Clamp the input value with minimum 0 and maximum 1.
 * @param[in] f4_input              The input value
 * @return The clamped value within the range 0 ~ 1.0
 **********************************************************************************************************************/
static float r_motor_sensor_hall_clamp01(float f4_input)
{
    if (f4_input < 0.0f)
    {
        return (0.0f);
    }
    else if (f4_input > 1.0f)
    {
        return (1.0f);
    }
    else
    {
        return (f4_input);
    }
}

/*******************************************************************************************************************//**
 * Calculate the weighted speed from low latency speed estimation and high precision speed estimation, tend to use
 * low latency speed estimation in low-speed or high deviation condition, and high precision speed estimation
 * in high-speed.
 * This function will be called when @ref st_sensor_hall_t::u1_speed_select is MOTOR_SENSOR_HALL_SPEED_SELECT_AUTO
 * @param[in] p_hall               The pointer to the hall sensor instance, @ref st_sensor_hall_t
 * @param[in] f4_speed_fast        The low latency speed estimation [rad/s]
 * @param[in] f4_speed_precision   The high precision speed estimation [rad/s]
 * @return The weighted speed [rad/s]
 **********************************************************************************************************************/
static float r_motor_sensor_hall_speed_mixed_calc(st_sensor_hall_t * const p_hall, float f4_speed_fast, float f4_speed_precision)
{
    float f4_speed_ret = 0.0f;
    float f4_1_over_speed_fast;
    float f4_speed_ratio;
    float f4_speed_dev_ratio;
    float f4_weight_fast;

    /* Add 0.01 to the denominator, to avoid division by zero */
    f4_1_over_speed_fast = 1.0f / (fabsf(f4_speed_fast) + 0.01f);
    f4_speed_ratio       = p_hall->st_cfg.f4_spd_mix_switch_th * f4_1_over_speed_fast;
    f4_speed_dev_ratio   = fabsf(f4_speed_precision - f4_speed_fast) * f4_1_over_speed_fast;

    /* Calculate the weight of fast speed
     * weight_fast(absolute speed term)  = speed_ratio^4
     * weight_fast(speed deviation term) = speed_dev_ratio - threshold, clamped to range 0 ~ 1 */
    f4_weight_fast = f4_speed_ratio * f4_speed_ratio;
    f4_weight_fast = f4_weight_fast * f4_weight_fast;
    f4_weight_fast += r_motor_sensor_hall_clamp01((f4_speed_dev_ratio - p_hall->st_cfg.f4_spd_mix_dev_th));

    /* Clamp the weight of low latency estimation to range 0 ~ 1 */
    f4_weight_fast = r_motor_sensor_hall_clamp01(f4_weight_fast);

    /* Return the weighted speed, and save the weight for monitoring */
    f4_speed_ret = f4_speed_fast * f4_weight_fast + f4_speed_precision * (1.0f - f4_weight_fast);
    p_hall->f4_weight = f4_weight_fast;

    return (f4_speed_ret);
}
/*******************************************************************************************************************//**
 * @} (end addtogroup MOTOR_SENSOR_HALL)
 **********************************************************************************************************************/
