/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/******************************************************************************************************************//**
 * @file          r_motor_sensor_hall_api.c
 * @version       1.00
 * @brief         Angle/speed estimation with hall effect sensor signal inputs
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * History : DD.MM.YYYY Version  Description
 *         : 30.10.2024 1.00     First Release
 *********************************************************************************************************************/
#ifndef R_MOTOR_SENSOR_HALL_API_H
#define R_MOTOR_SENSOR_HALL_API_H

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include <stdint.h>

/*******************************************************************************************************************//**
 * @ingroup HALL_VECTOR
 * @defgroup MOTOR_SENSOR_HALL Hall Effect Sensor
 * @brief The angle/speed estimation with uni-polar digital type hall effect sensor signal
 * @{
 **********************************************************************************************************************/

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
#define MOTOR_SENSOR_HALL_NUM_OF_SECTORS    (6) ///< Number of sectors in 1 round (electrical)

/***********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/
/** Direction definitions */
typedef enum e_sensor_hall_direction
{
    MOTOR_SENSOR_HALL_DIRECTION_CW  = 1, ///< Rotation direction clockwise
    MOTOR_SENSOR_HALL_DIRECTION_CCW = 0, ///< Rotation direction counter clockwise
} motor_sensor_hall_direction_t;

/** Speed estimation post-process method definitions */
typedef enum e_sensor_hall_speed_select
{
    MOTOR_SENSOR_HALL_SPEED_SELECT_AUTO        = 0, ///< Use the weighted average (weights depend on speed and difference)
    MOTOR_SENSOR_HALL_SPEED_SELECT_MOVAVG      = 1, ///< Use moving averaged speed as output
    MOTOR_SENSOR_HALL_SPEED_SELECT_LAST_PULSE  = 2, ///< Use the latest speed as output
} motor_sensor_hall_speed_select_t;

/** The input structure, see @ref R_MOTOR_SENSOR_HALL_ParameterSet */
typedef struct st_sensor_hall_input
{
    uint8_t u1_hall_sensor_bit_u; ///< Hall U-signal input port
    uint8_t u1_hall_sensor_bit_v; ///< Hall V-signal input port
    uint8_t u1_hall_sensor_bit_w; ///< Hall W-signal input port
} st_sensor_hall_input_t;

/** The output structure, see @ref R_MOTOR_SENSOR_HALL_ParameterGet */
typedef struct st_sensor_hall_output
{
    float f4_angle_rad;     ///< Angle[rad] (0~2pi, electrical)
    float f4_speed_rad;     ///< Speed[rad/s] (mechanical)
    float f4_speed_lpf_rad; ///< Speed processed with internal LPF [rad/s] (mechanical)
} st_sensor_hall_output_t;

/** Configuration input structure, @ref R_MOTOR_SENSOR_HALL_ParameterUpdate */
typedef struct st_sensor_hall_cfg
{
    float    f4_sampling_freq_khz; ///< Sampling frequency [kHz]
    float    f4_angle_correct;     ///< The angle correction value[rad],  will be added to the estimated angle

    /** Speed mixing deviation threshold (0 ~ 1), if the deviation ratio is above this value,
     *  the weight of faster speed estimation will be increased */
    float    f4_spd_mix_dev_th;

    /** Speed mixing switching threshold in [rad/s], the weight of more precise speed estimation will increase
     *  very fast above this value */
    float    f4_spd_mix_switch_th;
    uint16_t u2_default_counts;    ///< Default counts for period of hall signal to reset
    uint16_t u2_maximum_period;    ///< Maximum counts of hall signal period
    uint8_t  u1_hall_polepairs;    ///< Hall pole pairs
    uint8_t  u1_speed_select;      ///< Speed output selection @ref motor_sensor_hall_speed_select_t
} st_sensor_hall_cfg_t;

/** SENSE_HALL control block. */
typedef struct st_sensor_hall
{
    uint32_t open;
    st_sensor_hall_input_t   st_input;                              ///< Input parameter structure
    st_sensor_hall_cfg_t     st_cfg;                                ///< Configuration parameters
    uint8_t u1_hall_pattern[MOTOR_SENSOR_HALL_NUM_OF_SECTORS + 1];  ///< The order of hall signal pattern
    motor_sensor_hall_direction_t direction;                        ///< Rotation direction
    motor_sensor_hall_direction_t last_direction;                   ///< Last rotation direction
    uint8_t u1_hall_signal;                                         ///< Hall signal pattern
    uint8_t u1_last_hall_signal;                                    ///< Last hall signal pattern
    uint8_t  u1_period_counter;                                     ///< Counter for above array
    uint16_t u2_hall_period[MOTOR_SENSOR_HALL_NUM_OF_SECTORS];      ///< Array of carrier count to calculate 2PI
    uint16_t u2_carrier_count;                                      ///< Carrier count
    float    f4_angle;                                              ///< Rotor angle [rad]
    float    f4_angle_per_count;                                    ///< Angle per 1 count
    float    f4_calculated_speed;                                   ///< The electrical speed selected by u1_speed_select [rad/s]
    float    f4_calculated_speed_last_pulse;                        ///< The electrical speed calculated by last pulse [rad/s]
    float    f4_calculated_speed_movavg;                            ///< The electrical speed calculated by moving average [rad/s]
    float    f4_output_angle_rad;                                   ///< Output angle [rad/s]
    float    f4_output_speed_rad;                                   ///< Output speed [rad/s]
    float    f4_weight;                                             ///< The weight of speed estimated by last pulse
} st_sensor_hall_t;

/**********************************************************************************************************************
 External global variables
 *********************************************************************************************************************/
extern st_sensor_hall_t g_st_sensor_hall;

/**********************************************************************************************************************
 Exported global functions
 *********************************************************************************************************************/
void R_MOTOR_SENSOR_HALL_Open (void);
void R_MOTOR_SENSOR_HALL_Close (void);
void R_MOTOR_SENSOR_HALL_Reset (st_sensor_hall_t * const p_hall);
void R_MOTOR_SENSOR_HALL_ParameterSet (st_sensor_hall_t * const p_hall,
                                       st_sensor_hall_input_t * const p_st_sensor_input);
void R_MOTOR_SENSOR_HALL_ParameterGet (st_sensor_hall_t * const p_hall,
                                st_sensor_hall_output_t * p_st_sensor_hall_output);
void R_MOTOR_SENSOR_HALL_ParameterUpdate (st_sensor_hall_t * const p_hall,
                                         st_sensor_hall_cfg_t const * const p_cfg);
void R_MOTOR_SENSOR_HALL_Cyclic (st_sensor_hall_t * const p_hall);
void R_MOTOR_SENSOR_HALL_SignalPatternUpdate (st_sensor_hall_t * const p_hall,
                                             uint8_t const * const u1_hall_signal_pattern);
/*******************************************************************************************************************//**
 * @} (end defgroup MOTOR_SENSOR_HALL)
 **********************************************************************************************************************/
#endif /* R_MOTOR_SENSOR_HALL_API_H */
