/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name   : r_motor_hall_vector_manager.c
* Description : The processes of motor control
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 30.10.2024 1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
* Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* Standard library headers */
#include <math.h>

/* Main associated header file */
#include "r_motor_hall_vector_manager.h"
#include "r_motor_hall_vector_api.h"

/* Project headers */
#include "r_motor_common.h"
#include "r_motor_speed_api.h"
#include "r_motor_sensor_hall_api.h"
#include "r_motor_driver.h"

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static float motor_hall_vector_angle_rotation(float f4_input);

/***********************************************************************************************************************
* Function Name : motor_hall_vector_default_init
* Description   : Initializes motor drive modules with default configuration
* Arguments     : p_st_hall_vector - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_default_init(st_hall_vector_control_t * p_st_hall_vector)
{
    st_current_cfg_t              st_current_cfg;
    st_speed_cfg_t                st_speed_cfg;
    st_motor_driver_cfg_t         st_driver_cfg;
    st_friction_comp_cfg_t        st_friction_comp_cfg;
    st_sensor_hall_cfg_t          st_sensor_hall_cfg;
    uint8_t                       u1_hall_signal_pattern[6];

    /* Initialize member of motor parameter structure, will be referenced after */
    p_st_hall_vector->st_motor.u2_mtr_pp              = MOTOR_CFG_POLE_PAIRS;
    p_st_hall_vector->st_motor.f4_mtr_r               = MOTOR_CFG_RESISTANCE;
    p_st_hall_vector->st_motor.f4_mtr_ld              = MOTOR_CFG_D_INDUCTANCE;
    p_st_hall_vector->st_motor.f4_mtr_lq              = MOTOR_CFG_Q_INDUCTANCE;
    p_st_hall_vector->st_motor.f4_mtr_m               = MOTOR_CFG_MAGNETIC_FLUX;
    p_st_hall_vector->st_motor.f4_mtr_j               = MOTOR_CFG_ROTOR_INERTIA;
    p_st_hall_vector->st_motor.f4_nominal_current_rms = MOTOR_CFG_NOMINAL_CURRENT_RMS;

    /* Initialize flag and states */
    p_st_hall_vector->u1_state_id_ref       = CURRENT_STATE_ID_ZERO_CONST;
    p_st_hall_vector->u1_state_iq_ref       = CURRENT_STATE_IQ_ZERO_CONST;
    p_st_hall_vector->u1_state_speed_ref    = SPEED_STATE_ZERO_CONST;
    p_st_hall_vector->u1_state_open_loop    = MTR_FALSE;
    p_st_hall_vector->u1_direction          = MTR_CW;
    p_st_hall_vector->u1_ctrl_loop_mode     = MOTOR_COMMON_CFG_LOOP_MODE;
    p_st_hall_vector->u1_offset_adjust_mode = MOTOR_HALL_VECTOR_OFAJ_FIN;
    p_st_hall_vector->u1_flag_offset_calc   = MTR_FLG_CLR;

    /* This flag should not be reset if it is already set, clear the flag if memory area was not zero cleared */
    if (MTR_FLG_SET != p_st_hall_vector->u1_flag_charge_cap)
    {
        p_st_hall_vector->u1_flag_charge_cap = MTR_FLG_CLR;
    }
    p_st_hall_vector->u2_run_mode          = MOTOR_HALL_VECTOR_MODE_DRIVE;
    p_st_hall_vector->u2_error_status      = MOTOR_ERROR_NONE;
    p_st_hall_vector->u2_error_status_mask = 0xFFFF;

    p_st_hall_vector->f4_vdc_ad             = 0.0f;
    p_st_hall_vector->f4_iu_ad              = 0.0f;
    p_st_hall_vector->f4_iv_ad              = 0.0f;
    p_st_hall_vector->f4_iw_ad              = 0.0f;

    p_st_hall_vector->f4_overcurrent_limit      = p_st_hall_vector->st_motor.f4_nominal_current_rms *
                                                      MOTOR_COMMON_CFG_IA_MAX_CALC_MULT *
                                                      MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT;
    p_st_hall_vector->f4_overvoltage_limit      = INVERTER_CFG_OVERVOLTAGE_LIMIT;
    p_st_hall_vector->f4_undervoltage_limit     = INVERTER_CFG_UNDERVOLTAGE_LIMIT;
    p_st_hall_vector->f4_overspeed_limit_rad    = (SPEED_CFG_SPEED_LIMIT_RPM * MTR_RPM2RAD);
    p_st_hall_vector->f4_rotor_angle_rad        = 0.0f;
    p_st_hall_vector->f4_user_open_loop_current = 0.0f;
    p_st_hall_vector->f4_user_torque_nm         = 0.0f;

    /* Initialize members for offset calibration */
    p_st_hall_vector->f4_time_elapsed_power_on   = 0.0f;
    p_st_hall_vector->f4_rotor_angle_offset_rad  = 0.0f;

    /* Initialize sensor output (will not be reset in the reset function) */
    p_st_hall_vector->st_sensor_output.f4_speed_rad     = 0.0f;
    p_st_hall_vector->st_sensor_output.f4_angle_rad     = 0.0f;
    p_st_hall_vector->st_sensor_output.f4_speed_lpf_rad = 0.0f;

    p_st_hall_vector->HallSignalGet = DRIVER_HALL_CFG_FUNC_GET_HALL_SIGNAL;

    /* Set parameters for current control */
    st_current_cfg.u2_offset_calc_time       = CURRENT_CFG_OFFSET_CALC_TIME;
    st_current_cfg.f4_ctrl_period            = MOTOR_COMMON_CTRL_PERIOD;
    st_current_cfg.f4_current_omega_hz       = CURRENT_CFG_OMEGA;
    st_current_cfg.f4_current_zeta           = CURRENT_CFG_ZETA;
    st_current_cfg.u1_flag_volt_err_comp_use = CURRENT_CFG_VOLT_ERR_COMP;
    st_current_cfg.st_motor                  = p_st_hall_vector->st_motor;
    R_MOTOR_CURRENT_ParameterUpdate(p_st_hall_vector->p_st_cc, &st_current_cfg);

    /* Set parameters for voltage error compensation*/
    float  f4_volterr_array[VERR_COMP_ARY_SIZE] =
    {
        INVERTER_CFG_COMP_V0,
        INVERTER_CFG_COMP_V1,
        INVERTER_CFG_COMP_V2,
        INVERTER_CFG_COMP_V3,
        INVERTER_CFG_COMP_V4,
    };
    float  f4_crnt_array[VERR_COMP_ARY_SIZE] =
    {
        INVERTER_CFG_COMP_I0,
        INVERTER_CFG_COMP_I1,
        INVERTER_CFG_COMP_I2,
        INVERTER_CFG_COMP_I3,
        INVERTER_CFG_COMP_I4
    };
    R_MOTOR_CURRENT_VoltErrCompParamSet(p_st_hall_vector->p_st_cc,
                                        f4_crnt_array,
                                        f4_volterr_array,
                                        INVERTER_CFG_INPUT_V);

    /* Set parameters for speed control */
    st_speed_cfg.st_motor                 = p_st_hall_vector->st_motor;
    st_speed_cfg.u1_flag_fluxwkn_use      = SPEED_CFG_FLUX_WEAKENING;
    st_speed_cfg.f4_speed_ctrl_period     = SPEED_CFG_CTRL_PERIOD;
    st_speed_cfg.f4_max_speed_rpm         = MOTOR_CFG_MAX_SPEED_RPM;
    st_speed_cfg.f4_speed_rate_limit_rpm  = SPEED_CFG_RATE_LIMIT_RPM;
    st_speed_cfg.f4_speed_omega_hz        = SPEED_CFG_OMEGA;
    st_speed_cfg.f4_speed_zeta            = SPEED_CFG_ZETA;
    R_MOTOR_SPEED_ParameterUpdate(p_st_hall_vector->p_st_sc, &st_speed_cfg);

    st_friction_comp_cfg.f4_coulombs_friction_troque_current = 0.0f;
    st_friction_comp_cfg.f4_static_friction_speed_th_rad = 0.0f;
    st_friction_comp_cfg.f4_static_friction_torque_current = 0.0f;
    st_friction_comp_cfg.f4_viscous_friction_coef = 0.0f;
    R_MOTOR_SPEED_FrictionParameterUpdate(p_st_hall_vector->p_st_sc, &st_friction_comp_cfg);

    st_sensor_hall_cfg.f4_sampling_freq_khz = SENSOR_HALL_CFG_CTRL_FREQ;
    st_sensor_hall_cfg.f4_angle_correct     = SENSOR_HALL_CFG_ANGLE_CORRECT;
    st_sensor_hall_cfg.f4_spd_mix_dev_th    = SENSOR_HALL_CFG_SPEED_DEVIATION_TOLERANCE;
    st_sensor_hall_cfg.f4_spd_mix_switch_th = SENSOR_HALL_CFG_SPEED_MIX_TH;
    st_sensor_hall_cfg.u2_default_counts    = SENSOR_HALL_CFG_DEFAULT_COUNTS;
    st_sensor_hall_cfg.u2_maximum_period    = SENSOR_HALL_CFG_MAXIMUM_PERIOD;
    st_sensor_hall_cfg.u1_hall_polepairs    = SENSOR_HALL_CFG_HALL_POLEPAIRS;
    st_sensor_hall_cfg.u1_speed_select      = SENSOR_HALL_CFG_SPEED_SELECT;
    R_MOTOR_SENSOR_HALL_ParameterUpdate(p_st_hall_vector->p_st_sensor_hall, &st_sensor_hall_cfg);

    u1_hall_signal_pattern[0]              = SENSOR_HALL_CFG_PATTERN_1;
    u1_hall_signal_pattern[1]              = SENSOR_HALL_CFG_PATTERN_2;
    u1_hall_signal_pattern[2]              = SENSOR_HALL_CFG_PATTERN_3;
    u1_hall_signal_pattern[3]              = SENSOR_HALL_CFG_PATTERN_4;
    u1_hall_signal_pattern[4]              = SENSOR_HALL_CFG_PATTERN_5;
    u1_hall_signal_pattern[5]              = SENSOR_HALL_CFG_PATTERN_6;
    R_MOTOR_SENSOR_HALL_SignalPatternUpdate(p_st_hall_vector->p_st_sensor_hall,
                                            u1_hall_signal_pattern);

    /* Set parameters for driver */
    st_driver_cfg.ADCDataGet           = DRIVER_CFG_FUNC_ADC_DATA_GET;
    st_driver_cfg.BLDCDutySet          = DRIVER_CFG_FUNC_DUTY_SET;
    st_driver_cfg.PWMOutputStart       = DRIVER_CFG_FUNC_PWM_OUTPUT_START;
    st_driver_cfg.PWMOutputStop        = DRIVER_CFG_FUNC_PWM_OUTPUT_STOP;
    st_driver_cfg.f4_shunt_ohm         = INVERTER_CFG_SHUNT_RESIST;
    st_driver_cfg.f4_volt_gain         = INVERTER_CFG_VOLTAGE_GAIN;
    st_driver_cfg.f4_crnt_amp_gain     = INVERTER_CFG_CURRENT_AMP_GAIN;
    st_driver_cfg.f4_pwm_period_cnt    = MOTOR_COMMON_CARRIER_SET_BASE;
    st_driver_cfg.f4_pwm_dead_time_cnt = MOTOR_COMMON_DEADTIME_SET;
    R_MOTOR_DRIVER_ParameterUpdate(p_st_hall_vector->p_st_driver, &st_driver_cfg);

    /* Reset motor */
    motor_hall_vector_reset(p_st_hall_vector);
} /* End of function motor_hall_vector_default_init */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_reset
* Description   : Resets motor drive modules, configurations will not be reset
* Arguments     : p_st_hall_vector - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_reset(st_hall_vector_control_t * p_st_hall_vector)
{
    /* Reset current offset calibration temporary data */
    p_st_hall_vector->f4_open_loop_angle_rad = 0.0f;

    /* Current output reset */
    p_st_hall_vector->st_current_output.f4_modu             = 0.0f;
    p_st_hall_vector->st_current_output.f4_modv             = 0.0f;
    p_st_hall_vector->st_current_output.f4_modw             = 0.0f;
    p_st_hall_vector->st_current_output.f4_va_max           = 0.0f;
    p_st_hall_vector->st_current_output.u1_flag_offset_calc = MTR_FLG_CLR;

    /* Speed output reset */
    p_st_hall_vector->st_speed_output.f4_id_ref             = 0.0f;
    p_st_hall_vector->st_speed_output.f4_iq_ref             = 0.0f;
    p_st_hall_vector->st_speed_output.f4_ref_speed_rad_ctrl = 0.0f;


    R_MOTOR_CURRENT_Reset(p_st_hall_vector->p_st_cc);
    R_MOTOR_SPEED_Reset(p_st_hall_vector->p_st_sc);

} /* End of function motor_hall_vector_reset */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_error_process
* Description   : Sets error flags and trigger error event when u2_error_flag is not zero
* Arguments     : p_st_hall_vector - The pointer to the FOC data structure
*                 u2_error_flag - The error flags of the errors to report
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_error_process(st_hall_vector_control_t * p_st_hall_vector, uint16_t u2_error_flag)
{
    if (MOTOR_ERROR_NONE != u2_error_flag)
    {
        p_st_hall_vector->u2_error_status |= u2_error_flag;
        motor_hall_vector_statemachine_event(&p_st_hall_vector->st_stm,
                                                 p_st_hall_vector,
                                                 STATEMACHINE_EVENT_ERROR);
    }
} /* End of function motor_hall_vector_error_process */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_decide_direction
* Description   : Decide direction
* Arguments     : p_st_hall_vector - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_decide_direction(st_hall_vector_control_t * p_st_hall_vector)
{
    float f4_speed = p_st_hall_vector->st_sensor_output.f4_speed_lpf_rad;

    if (0.0f <= f4_speed)
    {
        p_st_hall_vector->u1_direction = MTR_CW;
    }
    else if (0.0f > f4_speed)
    {
        p_st_hall_vector->u1_direction = MTR_CCW;
    }
    else
    {
        /* Do nothing */
    }
} /* End of function motor_hall_vector_decide_direction */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_ref_state_update
* Description   : Set references state
* Arguments     : p_st_hall_vector - The pointer to the FOC data structure
* Return Value  : none
***********************************************************************************************************************/
void motor_hall_vector_ref_state_update(st_hall_vector_control_t * p_st_hall_vector)
{
    /* Setting of references state */
    switch (p_st_hall_vector->u2_run_mode)
    {
        case MOTOR_HALL_VECTOR_MODE_OFFSET_ADJUST:
        {
            p_st_hall_vector->p_st_cc->f4_id_ref = p_st_hall_vector->p_st_cc->f4_lim_iq;
            p_st_hall_vector->u1_state_speed_ref = SPEED_STATE_ZERO_CONST;
            p_st_hall_vector->u1_state_id_ref    = CURRENT_STATE_ID_MANUAL;
            p_st_hall_vector->u1_state_iq_ref    = CURRENT_STATE_IQ_ZERO_CONST;
            p_st_hall_vector->u1_state_open_loop = MTR_TRUE;
            break;
        }

        case MOTOR_HALL_VECTOR_MODE_DRIVE:
        {
            p_st_hall_vector->u1_offset_adjust_mode = MOTOR_HALL_VECTOR_OFAJ_FIN;
            switch (p_st_hall_vector->u1_ctrl_loop_mode)
            {
                /* Current Loop mode (ID) */
                case MOTOR_LOOP_CURRENT_ID:
                {
                    p_st_hall_vector->u1_state_speed_ref = SPEED_STATE_MANUAL;
                    p_st_hall_vector->u1_state_iq_ref    = CURRENT_STATE_IQ_ZERO_CONST;
                    p_st_hall_vector->u1_state_id_ref    = CURRENT_STATE_ID_MANUAL;
                    p_st_hall_vector->u1_state_open_loop = MTR_TRUE;
                    break;
                }

                /* Current Loop mode (IQ) */
                case MOTOR_LOOP_CURRENT_IQ:
                {
                    p_st_hall_vector->u1_state_speed_ref = SPEED_STATE_ZERO_CONST;
                    p_st_hall_vector->u1_state_iq_ref    = CURRENT_STATE_IQ_MANUAL;
                    p_st_hall_vector->u1_state_id_ref    = CURRENT_STATE_ID_ZERO_CONST;
                    p_st_hall_vector->u1_state_open_loop = MTR_FALSE;
                    break;
                }

                /* Speed Loop mode */
                case MOTOR_LOOP_SPEED:
                {
                    p_st_hall_vector->u1_state_speed_ref = SPEED_STATE_MANUAL;
                    p_st_hall_vector->u1_state_iq_ref    = CURRENT_STATE_IQ_SPEED_PI_OUTPUT;
                    p_st_hall_vector->u1_state_id_ref    = CURRENT_STATE_ID_INPUT;
                    p_st_hall_vector->u1_state_open_loop = MTR_FALSE;
                    break;
                }

                /* Position Loop mode is not supported */
                case MOTOR_LOOP_POSITION:
                default:
                {
                    /* Do nothing */
                }
            }
            break;
        }

        default:
        {
            /* Do nothing */
        }
    }
} /* End of function motor_hall_vector_ref_state_update */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_nominal_current_set
* Description   : Setup current related limit values by the nominal current of motor
* Arguments     : p_st_hall_vector - The pointer to the FOC current control structure
*                 f4_nominal_current_rms - The nominal current[Arms] of motor
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_nominal_current_set(st_hall_vector_control_t * p_st_hall_vector,
                                                float f4_nominal_current_rms)
{
    p_st_hall_vector->f4_overcurrent_limit = (f4_nominal_current_rms * MOTOR_COMMON_CFG_IA_MAX_CALC_MULT) *
                                                 MOTOR_COMMON_CFG_OVERCURRENT_MARGIN_MULT;
    if (p_st_hall_vector->f4_overcurrent_limit > (INVERTER_CFG_CURRENT_LIMIT))
    {
        p_st_hall_vector->f4_overcurrent_limit = INVERTER_CFG_CURRENT_LIMIT;
    }
} /* End of function motor_hall_vector_nominal_current_set */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_angle_speed_select
* Description   : Angle and speed detection
* Arguments     : p_st_hall_vector - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_angle_speed_select(st_hall_vector_control_t * p_st_hall_vector)
{
    float f4_angle_rad = 0.0f;

    if (MOTOR_HALL_VECTOR_MODE_OFFSET_ADJUST == p_st_hall_vector->u2_run_mode)
    {
        /* No alignment required for hall sensor based FOC */
    }
    else if ((MOTOR_HALL_VECTOR_MODE_DRIVE == p_st_hall_vector->u2_run_mode) &&
             (MTR_FALSE == p_st_hall_vector->u1_state_open_loop))
    {
        f4_angle_rad = p_st_hall_vector->st_sensor_output.f4_angle_rad;
    }
    else if ((MOTOR_HALL_VECTOR_MODE_DRIVE == p_st_hall_vector->u2_run_mode) &&
             (MTR_TRUE == p_st_hall_vector->u1_state_open_loop))
    {
        p_st_hall_vector->f4_open_loop_angle_rad = p_st_hall_vector->f4_open_loop_angle_rad
            + (MOTOR_COMMON_CTRL_PERIOD * p_st_hall_vector->st_motor.u2_mtr_pp
                    * p_st_hall_vector->st_speed_output.f4_ref_speed_rad_ctrl);

        /* Limit angle value of one rotation */
        p_st_hall_vector->f4_open_loop_angle_rad =
                motor_hall_vector_angle_rotation(p_st_hall_vector->f4_open_loop_angle_rad);
        f4_angle_rad = p_st_hall_vector->f4_open_loop_angle_rad;
    }
    else
    {
        /* Do nothing */
    }

    p_st_hall_vector->f4_rotor_angle_rad = f4_angle_rad;
} /* End of function motor_hall_vector_angle_speed_select */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_module_activate
* Description   : Activate modules
* Arguments     : p_st_hall_vector - The pointer to the FOC data structure
* Return Value  : None
***********************************************************************************************************************/
void motor_hall_vector_module_activate(st_hall_vector_control_t * p_st_hall_vector)
{
    /* Setting of references state */
    switch (p_st_hall_vector->u2_run_mode)
    {
        case MOTOR_HALL_VECTOR_MODE_OFFSET_ADJUST:
        {
            R_MOTOR_CURRENT_Run(p_st_hall_vector->p_st_cc);
            break;
        }

        case MOTOR_HALL_VECTOR_MODE_DRIVE:
        {
            p_st_hall_vector->u1_offset_adjust_mode = MOTOR_HALL_VECTOR_OFAJ_FIN;
            switch (p_st_hall_vector->u1_ctrl_loop_mode)
            {
                /* Current Loop mode (ID) */
                case MOTOR_LOOP_CURRENT_ID:
                {
                    R_MOTOR_CURRENT_Run(p_st_hall_vector->p_st_cc);
                    R_MOTOR_SPEED_Run(p_st_hall_vector->p_st_sc);
                    break;
                }

                /* Current Loop mode (IQ) */
                case MOTOR_LOOP_CURRENT_IQ:
                {
                    R_MOTOR_CURRENT_Run(p_st_hall_vector->p_st_cc);
                    break;
                }

                /* Speed Loop mode */
                case MOTOR_LOOP_SPEED:
                {
                    R_MOTOR_CURRENT_Run(p_st_hall_vector->p_st_cc);
                    R_MOTOR_SPEED_Run(p_st_hall_vector->p_st_sc);
                    break;
                }

                /* Position Loop mode is not supported */
                case MOTOR_LOOP_POSITION:
                default:
                {
                    /* Do nothing */
                }
            }
            break;
        }

        default:
        {
            /* Do nothing */
        }
    }
} /* End of function motor_hall_vector_module_activate */

/***********************************************************************************************************************
* Function Name : motor_hall_vector_angle_rotation
* Description   : Calculate the floating-point remainder of input/(2Pi)
* Arguments     : f4_input - The input angle [rad](within -2pi ~ 4Pi)
* Return Value  : The remainder of input/(2Pi)
***********************************************************************************************************************/
static float motor_hall_vector_angle_rotation(float f4_input)
{
    float f4_ret = f4_input;

    /* Limit angle value of one rotation */
    if (f4_input >= MTR_TWOPI)
    {
        f4_ret = f4_input - MTR_TWOPI;
    }
    else if (f4_input < 0.0f)
    {
        f4_ret = f4_input + MTR_TWOPI;
    }
    else
    {
        /* Do nothing */
    }

    return f4_ret;
} /* End of function motor_hall_vector_angle_rotation */
