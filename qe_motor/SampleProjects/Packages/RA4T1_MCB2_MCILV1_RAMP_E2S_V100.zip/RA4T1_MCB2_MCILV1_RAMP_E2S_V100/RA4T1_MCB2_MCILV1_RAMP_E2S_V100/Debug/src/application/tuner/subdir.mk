################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/application/tuner/tuner_gui.c 

C_DEPS += \
./src/application/tuner/tuner_gui.d 

OBJS += \
./src/application/tuner/tuner_gui.o 

SREC += \
RA4T1_MCB2_MCILV1_RAMP_E2S_V100.srec 

MAP += \
RA4T1_MCB2_MCILV1_RAMP_E2S_V100.map 


# Each subdirectory must supply rules for building sources it contributes
src/application/tuner/%.o: ../src/application/tuner/%.c
	$(file > $@.in,-mcpu=cortex-m33 -mthumb -mfloat-abi=hard -mfpu=fpv5-sp-d16 -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -gdwarf-4 -D_RENESAS_RA_ -D_RA_CORE=CM33 -D_RA_ORDINAL=1 -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/inc" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/inc/instances" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/lib/rm_motor_ctrllib" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_pm_foc" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_control" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_hal_driver" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_tuner_pm" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_trajectory_linear" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra_gen" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/src" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/src/application" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/src/application/main" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/src/application/user_interface" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/src/application/user_interface/ics" -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/src/application/tuner" -I"." -I"C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA6T3/RA4T1_MCB2_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include" -std=c99 -fstack-usage -fdump-rtl-pro_and_epilogue -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

