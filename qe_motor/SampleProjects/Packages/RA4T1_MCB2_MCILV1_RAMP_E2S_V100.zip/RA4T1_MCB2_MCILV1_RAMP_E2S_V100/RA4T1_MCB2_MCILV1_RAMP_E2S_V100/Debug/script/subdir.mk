################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
LINKER_SCRIPT += \
../script/fsp.ld 

SREC += \
RA4T1_MCB2_MCILV1_RAMP_E2S_V100.srec 

MAP += \
RA4T1_MCB2_MCILV1_RAMP_E2S_V100.map 


# Each subdirectory must supply rules for building sources it contributes

