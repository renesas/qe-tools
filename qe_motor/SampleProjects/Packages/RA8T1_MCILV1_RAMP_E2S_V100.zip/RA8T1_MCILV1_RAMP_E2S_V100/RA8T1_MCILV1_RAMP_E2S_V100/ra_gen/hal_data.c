/* generated HAL source file - do not edit */
#include "hal_data.h"

poeg_instance_ctrl_t g_poeg0_ctrl;
const poeg_cfg_t g_poeg0_cfg =
{ .trigger = (poeg_trigger_t) (POEG_TRIGGER_PIN | POEG_TRIGGER_SOFTWARE),
  .polarity = POEG_GTETRG_POLARITY_ACTIVE_LOW,
  .noise_filter = POEG_GTETRG_NOISE_FILTER_CLK_SOURCE_DIV_32,
  .channel = 0,
  .ipl = (0),
  .p_callback = g_poe_overcurrent,
  .p_context = NULL,
#if defined(VECTOR_NUMBER_POEG0_EVENT)
    .irq       = VECTOR_NUMBER_POEG0_EVENT,
#else
  .irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const poeg_instance_t g_poeg0 =
{ .p_ctrl = &g_poeg0_ctrl, .p_cfg = &g_poeg0_cfg, .p_api = &g_poeg_on_poeg };
const motor_trajectory_linear_extended_cfg_t g_motor0_trajectory_linear_extend =
{ .cycle_time_sec = 0.0005F, .bypass_mode = false, .force_align = false };

motor_trajectory_linear_ctrl_t g_motor0_trajectory_linear_ctrl;

const motor_trajectory_cfg_t g_motor0_trajectory_linear_cfg =
{ .p_user_callback = NULL,
  .p_user_callback_args = NULL,
  .p_extend = (void*) &g_motor0_trajectory_linear_extend,
  .p_context = NULL, };
const motor_trajectory_instance_t g_motor0_trajectory_linear =
{ .p_ctrl = &g_motor0_trajectory_linear_ctrl, .p_cfg = &g_motor0_trajectory_linear_cfg, .p_api =
          &g_motor_trajectory_on_motor_trajectory_linear, };
agt_instance_ctrl_t g_timer3_ctrl;
const agt_extended_cfg_t g_timer3_extend =
{ .count_source = AGT_CLOCK_PCLKB,
  .agto = AGT_PIN_CFG_DISABLED,
  .agtoab_settings_b.agtoa = AGT_PIN_CFG_DISABLED,
  .agtoab_settings_b.agtob = AGT_PIN_CFG_DISABLED,
  .measurement_mode = AGT_MEASURE_DISABLED,
  .agtio_filter = AGT_AGTIO_FILTER_NONE,
  .enable_pin = AGT_ENABLE_PIN_NOT_USED,
  .trigger_edge = AGT_TRIGGER_EDGE_RISING,
  .counter_bit_width = AGT_COUNTER_BIT_WIDTH_16, };
const timer_cfg_t g_timer3_cfg =
{ .mode = TIMER_MODE_PERIODIC,
/* Actual period: 0.0005 seconds. Actual duty: 50%. */.period_counts = (uint32_t) 0x7530,
  .duty_cycle_counts = 0x3a98, .source_div = (timer_source_div_t) 0, .channel = 0, .p_callback = rm_motor_outer_cyclic,
  /** If NULL then do not add & */
#if defined(g_motor0_pm_foc)
    .p_context           = g_motor0_pm_foc,
#else
  .p_context = (void*) &g_motor0_pm_foc,
#endif
  .p_extend = &g_timer3_extend,
  .cycle_end_ipl = (10),
#if defined(VECTOR_NUMBER_AGT0_INT)
    .cycle_end_irq       = VECTOR_NUMBER_AGT0_INT,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer3 =
{ .p_ctrl = &g_timer3_ctrl, .p_cfg = &g_timer3_cfg, .p_api = &g_timer_on_agt };
motor_sensor_bemf_instance_ctrl_t g_motor0_sensor_bemf_ctrl;
const motor_sensor_bemf_extended_cfg_t g_motor0_sensor_bemf_extend =
{ .ol_param.f4_ol_id_ref = 0.5F,
  .ol_param.f4_ol_id_up_step = 0.5F / 256,
  .ol_param.f4_ol_id_down_step = 0.5F / 500,
  .ol_param.f4_ol_iq_down_step_ratio = 1.0F,
  .ol_param.f4_id_down_speed_mech_rad = 600.0F * MOTOR_FUNDLIB_TWOPI_60,
  .ol_param.f4_id_up_speed_mech_rad = 400.0F * MOTOR_FUNDLIB_TWOPI_60,
  .ol_param.f4_opl2less_sw_time = 0.025F,
  .ol_param.f4_switch_phase_err_rad = 10.0F * MOTOR_FUNDLIB_RAD_TRANS,

  .ol_sub_param.f_damp_comp_gain = 0.0F,
  .ol_sub_param.f_fb_speed_limit_rate = 0.2F,
  .ol_sub_param.st_ed_lpf.f4_pre_output = 0.0F,
  .ol_sub_param.st_ed_lpf.f4_pre_input = 0.0F,

  .ol_sub_param.st_ed_lpf.f4_omega_t = 0.0F,
  .ol_sub_param.st_ed_lpf.f4_gain_ka = 0.0F,
  .ol_sub_param.st_ed_lpf.f4_gain_kb = 0.0F,
  .d_param.ed_hpf_omega = 2.5F,
  .d_param.ol_damping_zeta = 1.0F,

  .openloop_damping = MOTOR_MCSENSOR_OPENLOOP_DAMPING_ENABLE,
  .less_switch = MOTOR_MCSENSOR_LESS_SWITCH_ENABLE,
  .e_obs_omega = 1000.0F,
  .e_obs_zeta = 1.0F,
  .pll_est_omega = 20.0F,
  .pll_est_zeta = 1.0F, };

const motor_sensor_cfg_t g_motor0_sensor_bemf_cfg =
{ .p_context = NULL, .p_extend = &g_motor0_sensor_bemf_extend, };

/* Instance structure to use Motor Angle module. */
const motor_sensor_instance_t g_motor0_sensor_bemf =
{ .p_ctrl = &g_motor0_sensor_bemf_ctrl, .p_cfg = &g_motor0_sensor_bemf_cfg, .p_api =
          &g_motor_sensor_on_motor_sensor_bemf };
gpt_instance_ctrl_t g_timer2_ctrl;
#if 1
const gpt_extended_pwm_cfg_t g_timer2_pwm_extend =
{ .trough_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT3_COUNTER_UNDERFLOW)
    .trough_irq             = VECTOR_NUMBER_GPT3_COUNTER_UNDERFLOW,
#else
  .trough_irq = FSP_INVALID_VECTOR,
#endif
  .poeg_link = GPT_POEG_LINK_POEG0,
  .output_disable = (gpt_output_disable_t) (GPT_OUTPUT_DISABLE_NONE),
  .adc_trigger = (gpt_adc_trigger_t) (GPT_ADC_TRIGGER_NONE),
  .dead_time_count_up = (uint32_t) (0.5F * 120),
  .dead_time_count_down = (uint32_t) (0.5F * 120),
  .adc_a_compare_match = 0,
  .adc_b_compare_match = 0,
  .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
  .interrupt_skip_count = GPT_INTERRUPT_SKIP_COUNT_0,
  .interrupt_skip_adc = GPT_INTERRUPT_SKIP_ADC_NONE,
  .gtioca_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z,
  .gtiocb_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z, };
#endif
const gpt_extended_cfg_t g_timer2_extend =
        { .gtioca =
        { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_LOW },
          .gtiocb =
          { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_HIGH },
          .start_source = (gpt_source_t) (GPT_SOURCE_NONE), .stop_source = (gpt_source_t) (GPT_SOURCE_NONE), .clear_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .count_up_source = (gpt_source_t) (GPT_SOURCE_NONE), .count_down_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .capture_b_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_ipl = (BSP_IRQ_DISABLED), .capture_b_ipl =
                  (BSP_IRQ_DISABLED),
          .compare_match_c_ipl = (BSP_IRQ_DISABLED), .compare_match_d_ipl = (BSP_IRQ_DISABLED), .compare_match_e_ipl =
                  (BSP_IRQ_DISABLED),
          .compare_match_f_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT3_CAPTURE_COMPARE_A)
    .capture_a_irq         = VECTOR_NUMBER_GPT3_CAPTURE_COMPARE_A,
#else
          .capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT3_CAPTURE_COMPARE_B)
    .capture_b_irq         = VECTOR_NUMBER_GPT3_CAPTURE_COMPARE_B,
#else
          .capture_b_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT3_COMPARE_C)
    .compare_match_c_irq   = VECTOR_NUMBER_GPT3_COMPARE_C,
#else
          .compare_match_c_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT3_COMPARE_D)
    .compare_match_d_irq   = VECTOR_NUMBER_GPT3_COMPARE_D,
#else
          .compare_match_d_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT3_COMPARE_E)
    .compare_match_e_irq   = VECTOR_NUMBER_GPT3_COMPARE_E,
#else
          .compare_match_e_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT3_COMPARE_F)
    .compare_match_f_irq   = VECTOR_NUMBER_GPT3_COMPARE_F,
#else
          .compare_match_f_irq = FSP_INVALID_VECTOR,
#endif
          .compare_match_value =
          { (uint32_t) 0x0, /* CMP_A */
            (uint32_t) 0x0, /* CMP_B */
            (uint32_t) 0x0, /* CMP_C */
            (uint32_t) 0x0, /* CMP_D */
            (uint32_t) 0x0, /* CMP_E */
            (uint32_t) 0x0, /* CMP_F */},
          .compare_match_status = ((0U << 5U) | (0U << 4U) | (0U << 3U) | (0U << 2U) | (0U << 1U) | 0U), .capture_filter_gtioca =
                  GPT_CAPTURE_FILTER_NONE,
          .capture_filter_gtiocb = GPT_CAPTURE_FILTER_NONE,
#if 1
          .p_pwm_cfg = &g_timer2_pwm_extend,
#else
    .p_pwm_cfg             = NULL,
#endif
#if 1
          .gtior_setting.gtior_b.gtioa = (0U << 4U) | (0U << 2U) | (3U << 0U),
          .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_LOW, .gtior_setting.gtior_b.oahld = 0U, .gtior_setting.gtior_b.oae =
                  (uint32_t) true,
          .gtior_setting.gtior_b.oadf = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z, .gtior_setting.gtior_b.nfaen =
                  ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
          .gtior_setting.gtior_b.nfcsa = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U), .gtior_setting.gtior_b.gtiob = (1U
                  << 4U) | (0U << 2U) | (3U << 0U),
          .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_HIGH, .gtior_setting.gtior_b.obhld = 0U, .gtior_setting.gtior_b.obe =
                  (uint32_t) true,
          .gtior_setting.gtior_b.obdf = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z, .gtior_setting.gtior_b.nfben =
                  ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
          .gtior_setting.gtior_b.nfcsb = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
    .gtior_setting.gtior = 0U,
#endif

          .gtioca_polarity = GPT_GTIOC_POLARITY_NORMAL,
          .gtiocb_polarity = GPT_GTIOC_POLARITY_NORMAL, };

const timer_cfg_t g_timer2_cfg =
{ .mode = TIMER_MODE_TRIANGLE_WAVE_SYMMETRIC_PWM,
/* Actual period: 0.00005 seconds. Actual duty: 50%. */.period_counts = (uint32_t) 0xbb8,
  .duty_cycle_counts = 0x5dc, .source_div = (timer_source_div_t) 0, .channel = 3, .p_callback = NULL,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = (void*) &NULL,
#endif
  .p_extend = &g_timer2_extend,
  .cycle_end_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT3_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT3_COUNTER_OVERFLOW,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer2 =
{ .p_ctrl = &g_timer2_ctrl, .p_cfg = &g_timer2_cfg, .p_api = &g_timer_on_gpt };
gpt_instance_ctrl_t g_timer1_ctrl;
#if 1
const gpt_extended_pwm_cfg_t g_timer1_pwm_extend =
{ .trough_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT2_COUNTER_UNDERFLOW)
    .trough_irq             = VECTOR_NUMBER_GPT2_COUNTER_UNDERFLOW,
#else
  .trough_irq = FSP_INVALID_VECTOR,
#endif
  .poeg_link = GPT_POEG_LINK_POEG0,
  .output_disable = (gpt_output_disable_t) (GPT_OUTPUT_DISABLE_NONE),
  .adc_trigger = (gpt_adc_trigger_t) (GPT_ADC_TRIGGER_NONE),
  .dead_time_count_up = (uint32_t) (0.5F * 120),
  .dead_time_count_down = (uint32_t) (0.5F * 120),
  .adc_a_compare_match = 0,
  .adc_b_compare_match = 0,
  .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
  .interrupt_skip_count = GPT_INTERRUPT_SKIP_COUNT_0,
  .interrupt_skip_adc = GPT_INTERRUPT_SKIP_ADC_NONE,
  .gtioca_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z,
  .gtiocb_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z, };
#endif
const gpt_extended_cfg_t g_timer1_extend =
        { .gtioca =
        { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_LOW },
          .gtiocb =
          { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_HIGH },
          .start_source = (gpt_source_t) (GPT_SOURCE_NONE), .stop_source = (gpt_source_t) (GPT_SOURCE_NONE), .clear_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .count_up_source = (gpt_source_t) (GPT_SOURCE_NONE), .count_down_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .capture_b_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_ipl = (BSP_IRQ_DISABLED), .capture_b_ipl =
                  (BSP_IRQ_DISABLED),
          .compare_match_c_ipl = (BSP_IRQ_DISABLED), .compare_match_d_ipl = (BSP_IRQ_DISABLED), .compare_match_e_ipl =
                  (BSP_IRQ_DISABLED),
          .compare_match_f_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_A)
    .capture_a_irq         = VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_A,
#else
          .capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_B)
    .capture_b_irq         = VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_B,
#else
          .capture_b_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT2_COMPARE_C)
    .compare_match_c_irq   = VECTOR_NUMBER_GPT2_COMPARE_C,
#else
          .compare_match_c_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT2_COMPARE_D)
    .compare_match_d_irq   = VECTOR_NUMBER_GPT2_COMPARE_D,
#else
          .compare_match_d_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT2_COMPARE_E)
    .compare_match_e_irq   = VECTOR_NUMBER_GPT2_COMPARE_E,
#else
          .compare_match_e_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT2_COMPARE_F)
    .compare_match_f_irq   = VECTOR_NUMBER_GPT2_COMPARE_F,
#else
          .compare_match_f_irq = FSP_INVALID_VECTOR,
#endif
          .compare_match_value =
          { (uint32_t) 0x0, /* CMP_A */
            (uint32_t) 0x0, /* CMP_B */
            (uint32_t) 0x0, /* CMP_C */
            (uint32_t) 0x0, /* CMP_D */
            (uint32_t) 0x0, /* CMP_E */
            (uint32_t) 0x0, /* CMP_F */},
          .compare_match_status = ((0U << 5U) | (0U << 4U) | (0U << 3U) | (0U << 2U) | (0U << 1U) | 0U), .capture_filter_gtioca =
                  GPT_CAPTURE_FILTER_NONE,
          .capture_filter_gtiocb = GPT_CAPTURE_FILTER_NONE,
#if 1
          .p_pwm_cfg = &g_timer1_pwm_extend,
#else
    .p_pwm_cfg             = NULL,
#endif
#if 1
          .gtior_setting.gtior_b.gtioa = (0U << 4U) | (0U << 2U) | (3U << 0U),
          .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_LOW, .gtior_setting.gtior_b.oahld = 0U, .gtior_setting.gtior_b.oae =
                  (uint32_t) true,
          .gtior_setting.gtior_b.oadf = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z, .gtior_setting.gtior_b.nfaen =
                  ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
          .gtior_setting.gtior_b.nfcsa = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U), .gtior_setting.gtior_b.gtiob = (1U
                  << 4U) | (0U << 2U) | (3U << 0U),
          .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_HIGH, .gtior_setting.gtior_b.obhld = 0U, .gtior_setting.gtior_b.obe =
                  (uint32_t) true,
          .gtior_setting.gtior_b.obdf = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z, .gtior_setting.gtior_b.nfben =
                  ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
          .gtior_setting.gtior_b.nfcsb = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
    .gtior_setting.gtior = 0U,
#endif

          .gtioca_polarity = GPT_GTIOC_POLARITY_NORMAL,
          .gtiocb_polarity = GPT_GTIOC_POLARITY_NORMAL, };

const timer_cfg_t g_timer1_cfg =
{ .mode = TIMER_MODE_TRIANGLE_WAVE_SYMMETRIC_PWM,
/* Actual period: 0.00005 seconds. Actual duty: 50%. */.period_counts = (uint32_t) 0xbb8,
  .duty_cycle_counts = 0x5dc, .source_div = (timer_source_div_t) 0, .channel = 2, .p_callback = NULL,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = (void*) &NULL,
#endif
  .p_extend = &g_timer1_extend,
  .cycle_end_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT2_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT2_COUNTER_OVERFLOW,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer1 =
{ .p_ctrl = &g_timer1_ctrl, .p_cfg = &g_timer1_cfg, .p_api = &g_timer_on_gpt };
gpt_instance_ctrl_t g_timer0_ctrl;
#if 1
const gpt_extended_pwm_cfg_t g_timer0_pwm_extend =
{ .trough_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT5_COUNTER_UNDERFLOW)
    .trough_irq             = VECTOR_NUMBER_GPT5_COUNTER_UNDERFLOW,
#else
  .trough_irq = FSP_INVALID_VECTOR,
#endif
  .poeg_link = GPT_POEG_LINK_POEG0,
  .output_disable = (gpt_output_disable_t) (GPT_OUTPUT_DISABLE_NONE),
  .adc_trigger = (gpt_adc_trigger_t) (GPT_ADC_TRIGGER_DOWN_COUNT_START_ADC_A | GPT_ADC_TRIGGER_NONE),
  .dead_time_count_up = (uint32_t) (0.5F * 120),
  .dead_time_count_down = (uint32_t) (0.5F * 120),
  .adc_a_compare_match = 0,
  .adc_b_compare_match = 0,
  .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
  .interrupt_skip_count = GPT_INTERRUPT_SKIP_COUNT_0,
  .interrupt_skip_adc = GPT_INTERRUPT_SKIP_ADC_NONE,
  .gtioca_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z,
  .gtiocb_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z, };
#endif
const gpt_extended_cfg_t g_timer0_extend =
        { .gtioca =
        { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_LOW },
          .gtiocb =
          { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_HIGH },
          .start_source = (gpt_source_t) (GPT_SOURCE_NONE), .stop_source = (gpt_source_t) (GPT_SOURCE_NONE), .clear_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .count_up_source = (gpt_source_t) (GPT_SOURCE_NONE), .count_down_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .capture_b_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_ipl = (BSP_IRQ_DISABLED), .capture_b_ipl =
                  (BSP_IRQ_DISABLED),
          .compare_match_c_ipl = (BSP_IRQ_DISABLED), .compare_match_d_ipl = (BSP_IRQ_DISABLED), .compare_match_e_ipl =
                  (BSP_IRQ_DISABLED),
          .compare_match_f_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT5_CAPTURE_COMPARE_A)
    .capture_a_irq         = VECTOR_NUMBER_GPT5_CAPTURE_COMPARE_A,
#else
          .capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT5_CAPTURE_COMPARE_B)
    .capture_b_irq         = VECTOR_NUMBER_GPT5_CAPTURE_COMPARE_B,
#else
          .capture_b_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT5_COMPARE_C)
    .compare_match_c_irq   = VECTOR_NUMBER_GPT5_COMPARE_C,
#else
          .compare_match_c_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT5_COMPARE_D)
    .compare_match_d_irq   = VECTOR_NUMBER_GPT5_COMPARE_D,
#else
          .compare_match_d_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT5_COMPARE_E)
    .compare_match_e_irq   = VECTOR_NUMBER_GPT5_COMPARE_E,
#else
          .compare_match_e_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT5_COMPARE_F)
    .compare_match_f_irq   = VECTOR_NUMBER_GPT5_COMPARE_F,
#else
          .compare_match_f_irq = FSP_INVALID_VECTOR,
#endif
          .compare_match_value =
          { (uint32_t) 0x0, /* CMP_A */
            (uint32_t) 0x0, /* CMP_B */
            (uint32_t) 0x0, /* CMP_C */
            (uint32_t) 0x0, /* CMP_D */
            (uint32_t) 0x0, /* CMP_E */
            (uint32_t) 0x0, /* CMP_F */},
          .compare_match_status = ((0U << 5U) | (0U << 4U) | (0U << 3U) | (0U << 2U) | (0U << 1U) | 0U), .capture_filter_gtioca =
                  GPT_CAPTURE_FILTER_NONE,
          .capture_filter_gtiocb = GPT_CAPTURE_FILTER_NONE,
#if 1
          .p_pwm_cfg = &g_timer0_pwm_extend,
#else
    .p_pwm_cfg             = NULL,
#endif
#if 0
    .gtior_setting.gtior_b.gtioa  = (0U << 4U) | (0U << 2U) | (3U << 0U),
    .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.oahld  = 0U,
    .gtior_setting.gtior_b.oae    = (uint32_t) true,
    .gtior_setting.gtior_b.oadf   = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z,
    .gtior_setting.gtior_b.nfaen  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsa  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
    .gtior_setting.gtior_b.gtiob  = (1U << 4U) | (0U << 2U) | (3U << 0U),
    .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_HIGH,
    .gtior_setting.gtior_b.obhld  = 0U,
    .gtior_setting.gtior_b.obe    = (uint32_t) true,
    .gtior_setting.gtior_b.obdf   = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z,
    .gtior_setting.gtior_b.nfben  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsb  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
          .gtior_setting.gtior = 0U,
#endif

          .gtioca_polarity = GPT_GTIOC_POLARITY_NORMAL,
          .gtiocb_polarity = GPT_GTIOC_POLARITY_NORMAL, };

const timer_cfg_t g_timer0_cfg =
{ .mode = TIMER_MODE_TRIANGLE_WAVE_SYMMETRIC_PWM,
/* Actual period: 0.00005 seconds. Actual duty: 50%. */.period_counts = (uint32_t) 0xbb8,
  .duty_cycle_counts = 0x5dc, .source_div = (timer_source_div_t) 0, .channel = 5, .p_callback = NULL,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = (void*) &NULL,
#endif
  .p_extend = &g_timer0_extend,
  .cycle_end_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT5_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT5_COUNTER_OVERFLOW,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer0 =
{ .p_ctrl = &g_timer0_ctrl, .p_cfg = &g_timer0_cfg, .p_api = &g_timer_on_gpt };
gpt_three_phase_instance_ctrl_t g_three_phase0_ctrl;
const three_phase_cfg_t g_three_phase0_cfg =
{ .buffer_mode = (THREE_PHASE_BUFFER_MODE_SINGLE), .p_timer_instance =
{ &g_timer0, &g_timer1, &g_timer2 },
  .callback_ch = THREE_PHASE_CHANNEL_U, .channel_mask = (1 << 5) | (1 << 2) | (1 << 3), .p_context = NULL, .p_extend =
          NULL, };
/* Instance structure to use this module. */
const three_phase_instance_t g_three_phase0 =
{ .p_ctrl = &g_three_phase0_ctrl, .p_cfg = &g_three_phase0_cfg, .p_api = &g_gpt_three_phase_on_gpt_three_phase };
adc_instance_ctrl_t g_adc0_ctrl;
const adc_extended_cfg_t g_adc0_cfg_extend =
{ .add_average_count = ADC_ADD_OFF,
  .clearing = ADC_CLEAR_AFTER_READ_OFF,
  .trigger = ADC_START_SOURCE_ELC_AD0 /* AD0 for Group A. AD1 for Group B */,
  .trigger_group_b = ADC_START_SOURCE_DISABLED,
  .double_trigger_mode = ADC_DOUBLE_TRIGGER_DISABLED,
  .adc_vref_control = ADC_VREF_CONTROL_VREFH,
  .enable_adbuf = 0,
#if defined(VECTOR_NUMBER_ADC0_WINDOW_A)
    .window_a_irq        = VECTOR_NUMBER_ADC0_WINDOW_A,
#else
  .window_a_irq = FSP_INVALID_VECTOR,
#endif
  .window_a_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_ADC0_WINDOW_B)
    .window_b_irq      = VECTOR_NUMBER_ADC0_WINDOW_B,
#else
  .window_b_irq = FSP_INVALID_VECTOR,
#endif
  .window_b_ipl = (BSP_IRQ_DISABLED), };
const adc_cfg_t g_adc0_cfg =
{ .unit = 0, .mode = ADC_MODE_SINGLE_SCAN, .resolution = ADC_RESOLUTION_12_BIT, .alignment =
          (adc_alignment_t) ADC_ALIGNMENT_RIGHT,
  .trigger = (adc_trigger_t) 0xF, // Not used
  .p_callback = NULL,
  /** If NULL then do not add & */
#if defined(g_motor0_hal_driver)
    .p_context           = g_motor0_hal_driver,
#else
  .p_context = (void*) &g_motor0_hal_driver,
#endif
  .p_extend = &g_adc0_cfg_extend,
#if defined(VECTOR_NUMBER_ADC0_SCAN_END)
    .scan_end_irq        = VECTOR_NUMBER_ADC0_SCAN_END,
#else
  .scan_end_irq = FSP_INVALID_VECTOR,
#endif
  .scan_end_ipl = (5),
#if defined(VECTOR_NUMBER_ADC0_SCAN_END_B)
    .scan_end_b_irq      = VECTOR_NUMBER_ADC0_SCAN_END_B,
#else
  .scan_end_b_irq = FSP_INVALID_VECTOR,
#endif
  .scan_end_b_ipl = (BSP_IRQ_DISABLED), };
#if ((0) | (0))
const adc_window_cfg_t g_adc0_window_cfg =
{
    .compare_mask        =  0,
    .compare_mode_mask   =  0,
    .compare_cfg         = (adc_compare_cfg_t) ((0) | (0) | (0) | (ADC_COMPARE_CFG_EVENT_OUTPUT_OR)),
    .compare_ref_low     = 0,
    .compare_ref_high    = 0,
    .compare_b_channel   = (ADC_WINDOW_B_CHANNEL_0),
    .compare_b_mode      = (ADC_WINDOW_B_MODE_LESS_THAN_OR_OUTSIDE),
    .compare_b_ref_low   = 0,
    .compare_b_ref_high  = 0,
};
#endif
const adc_channel_cfg_t g_adc0_channel_cfg =
{ .scan_mask = ADC_MASK_CHANNEL_0 | ADC_MASK_CHANNEL_1 | ADC_MASK_CHANNEL_2 | ADC_MASK_CHANNEL_7 | ADC_MASK_CHANNEL_8
        | 0,
  .scan_mask_group_b = 0, .priority_group_a = ADC_GROUP_A_PRIORITY_OFF, .add_mask = 0, .sample_hold_mask =
          ADC_MASK_CHANNEL_0 | ADC_MASK_CHANNEL_1 | ADC_MASK_CHANNEL_2 | 0,
  .sample_hold_states = 24,
#if ((0) | (0))
    .p_window_cfg        = (adc_window_cfg_t *) &g_adc0_window_cfg,
#else
  .p_window_cfg = NULL,
#endif
        };
/* Instance structure to use this module. */
const adc_instance_t g_adc0 =
{ .p_ctrl = &g_adc0_ctrl, .p_cfg = &g_adc0_cfg, .p_channel_cfg = &g_adc0_channel_cfg, .p_api = &g_adc_on_adc };
/* Motor Hal Driver Configuration */
motor_hal_driver_instance_ctrl_t g_motor0_hal_driver_ctrl;

const motor_hal_driver_extended_cfg_t g_motor0_hal_driver_extend =
{ .pwm_timer_freq = 120,
  .pwm_carrier_freq = 1000.0F / 50,
  .carrier_base = (uint32_t) (120 * 50 / 2),
  .deadtime = (uint32_t) (0.5F * 120),
  .current_range = 16.5F,
  .v_dc_range = 73.26F,
  .voltage_range = 73.26F,
  .ad_resolution = 0xFFF,
  .sf_ad_current = (ccal_num_t) CCAL_DIV (16.5F, (ccal_num_t) 0xFFF, 32),
  .sf_ad_vdc = (ccal_num_t) CCAL_DIV (73.26F, (ccal_num_t) 0xFFF, 32),
  .sf_ad_voltage = (ccal_num_t) CCAL_DIV (73.26F, (ccal_num_t) 0xFFF, 32),
  .ad_current_offset = 0x7FF,
  .ad_voltage_offset = 0x0,
  .ad_vdc_offset = 0x0,
  .ad_voltage_conversion = 1.0F,
  .offset_calc_count = 512,
  .charge_bootstrap_time = 100,
  .modulation_method = MOTOR_HAL_DRIVER_MODULATION_METHOD_SVPWM,
  .port_up = (bsp_io_port_pin_t) BSP_IO_PORT_01_PIN_15,
  .port_un = (bsp_io_port_pin_t) BSP_IO_PORT_06_PIN_09,
  .port_vp = (bsp_io_port_pin_t) BSP_IO_PORT_01_PIN_13,
  .port_vn = (bsp_io_port_pin_t) BSP_IO_PORT_01_PIN_14,
  .port_wp = (bsp_io_port_pin_t) BSP_IO_PORT_03_PIN_00,
  .port_wn = (bsp_io_port_pin_t) BSP_IO_PORT_01_PIN_12,
  .shunt = MOTOR_HAL_DRIVER_SHUNT_TYPE_2_SHUNT,
  .difference_minimum = 300,
  .adjust_adc_delay = 240,
  .trigger_phase = MOTOR_HAL_DRIVER_PHASE_U_PHASE,
  .adc_group = (adc_group_mask_t) 0,
  .mod_param.v_dc = 24.0F,
  .mod_param.voltage_error_ratio = (ccal_num_t) (0.5F / 50),
  .mod_param.max_duty = 0.9375F,
  .mod_param.min_duty = (ccal_num_t) (0.5F / 50),
  .mod_param.neutral_duty = 0.5F,
  .mod_param.saturation_flag = 0U,

  .i_u_ad_ch = (adc_channel_t) 0,
  .i_v_ad_ch = (adc_channel_t) 1,
  .i_w_ad_ch = (adc_channel_t) 2,
  .v_dc_ad_ch = (adc_channel_t) 8,
  .v_u_ad_ch = (adc_channel_t) 6,
  .v_v_ad_ch = (adc_channel_t) 5,
  .v_w_ad_ch = (adc_channel_t) 5,
  .i_u_ad_unit = 0,
  .i_v_ad_unit = 0,
  .i_w_ad_unit = 0,
  .v_dc_ad_unit = 0,
  .v_u_ad_unit = 1,
  .v_v_ad_unit = 0,
  .v_w_ad_unit = 1,

  .interrupt_adc = MOTOR_HAL_DRIVER_SELECT_ADC_INSTANCE_FIRST,

#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
  .p_shared_cfg = NULL,
#else
  .p_shared_cfg = &RA_NOT_DEFINED_extend_cfg,
#endif
#undef RA_NOT_DEFINED

        };

const motor_hal_driver_cfg_t g_motor0_hal_driver_cfg =
{
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == g_adc0)
  .p_adc_instance = NULL,
#else
  .p_adc_instance = &g_adc0,
#endif
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
  .p_adc2_instance = NULL,
#else
  .p_adc2_instance = &RA_NOT_DEFINED,
#endif
#undef RA_NOT_DEFINED
  .p_three_phase_instance = &g_three_phase0,
  .p_callback = rm_motor_inner_cyclic, .p_context = (void*) &g_motor0_pm_foc, .p_extend = &g_motor0_hal_driver_extend, };

/* Instance structure to use Motor Hal Driver module. */
const motor_hal_driver_instance_t g_motor0_hal_driver =
{ .p_ctrl = &g_motor0_hal_driver_ctrl, .p_cfg = &g_motor0_hal_driver_cfg, .p_api =
          &g_motor_hal_driver_on_motor_hal_driver, };
/////// Tuner instance
motor_tuner_pm_instance_ctrl_t g_motor0_tuner_pm_ctrl;
const motor_tuner_pm_extend_cfg_t g_motor0_tuner_pm_extend_cfg =
{ .tuner_rdiff_cfg =
{ .vd_step_lsb = (1.0F),
  .target_current_a = 0.6F,
  .target_current_b = 0.8F,
  .target_current_margin = (0.05F),
  .vd_step_wait_ms = 5.0F,
  .stab_wait = 10.0F,
  .measure_wait_ms = (50.0F),
  .measure_time_ms = (200.0F),
  .reset_time_ms = (10.0F),
  .vd_adjust_timeout = (5) },
  .tuner_ldq_cfg =
  { .reset_time_ms = (10.0F),
    .rld_freq = 200.0F,
    .rld_vd_amp_coef = (0.1F),
    .rld_vd_offset_coef = (0.3F),
    .rld_dft_measure_num = (32.0F),
    .ldq_init_assumption = (0.001F),
    .stab_time_coef = (20.0F),
    .rld_rls_measure_offset_time = (100.0F),
    .rld_rls_measure_num = (32.0F),
    .lq_freq = 1000.0F,
    .lq_vq_amp_coef = (0.05F),
    .lq_vd_offset_coef = (0.3F),
    .lq_dft_measure_num = (256.0F),
    .lq_rls_measure_num = (32.0F), },

  .tuner_ke_cfg =
  { .ol_target_freq_hz = 200.0F, .bemf_threshold_coef = (0.25F), .ol_ramp_up_rate_hzps = 20.0F, .measure_time_ms =
            (2000.0F),
    .ol_stab_wait_ms = (1000.0F), .reset_time_ms = (1000.0F) },

  .tuner_jd_cfg =
  { .speedpi_omega = (15.0F),
    .speed_osc_freq_hz = 5.0F,
    .speed_osc_amp_coef = 0.15F,
    .speed_osc_amp_coef_min = 0.05F,
    .rls_init = (float) (50000),
    .rls_forget_k = (0.9995F),
    .dft_num = (float) (20),
    .measure_start_amp_rate = (0.97F),
    .stab_wait = (500.0F),
    .stop_time = (float) (2000), },

  .tuner_volterr_cfg =
  { .enable = (1),
    .rls_fgt_factor = (0.995F),
    .avg_sample = (float) (250),
    .avg_sample_fast = (float) (100),
    .avg_wait_time = (25.0F),
    .point_num = (64),
    .min_current_step_lsb = (float) (2),
    .iteration_num = (16),
    .rls_upper_current = (1.0F),
    .rls_lower_current = (0.9F),
    .init_r = (1.0F) },

  .base_foc_cfg =
  { .current_omega_hz = (400.0F),
    .current_zeta = (1.0F),
    .e_obs_omega_hz = (1000.0F),
    .e_obs_zeta = (1.0F),
    .pll_est_omega_hz = (50.0F),
    .pll_est_zeta = (1.0F),
    .offset_lpf_k = (1.0F / 64.0F),
    .offset_calc_time = (512.0F),
    .overcurrent_limit_mult = (1.5F),
    .ol2cl_speed_th_coef = 0.30F,
    .cl2ol_speed_th_coef = 0.25F,
    .speed_change_rate_limit = (0.125F),
    .iq_down_time = (128.0F),
    .id_up_time = (128.0F),
    .id_down_time = (128.0F),
    .phaseerr_lpf_band_hz = (10.0F),
    .r_min = (0.05F),
    .num_pole_pair_limit = (float) (100),

    .id_ref_coef = (0.8F),
    .speed_omega = (15.0F),
    .speed_offset_coef = (0.5F),
    .assumed_inertia = 1.0E-6F,
    .default_rls_init = (float) (1000),
    .default_rls_forget_k = (0.9995F),

    .mcu_adc_resolution = 4096,
    .mcu_pwm_resolution = (uint32_t) (120000000 * (50 / 1000000.0F) * 0.5F),
    .inv_info_current_full_range = 16.5F,
    .inv_info_current_limit = 12.0F,
    .inv_info_overvoltage_th = 28.0F,
    .inv_info_undervoltage_th = 6.0F,
    .inv_info_pwm_cycle_s = (50 / 1000000.0F),
    .inv_info_pwm_deadtime_s = (0.5F / 1000000.0F),
    .inv_info_pwm_duty_min = 0.1F,
    .inv_info_pwm_duty_max = 0.9F },

  .pwm_tick_per_irq = 1,
  .speed_ctrl_period = 500e-6F, };

const motor_tuner_cfg_t g_motor0_tuner_pm_cfg =
{ .p_context = NULL, .p_extend = &g_motor0_tuner_pm_extend_cfg, };

const motor_tuner_instance_t g_motor0_tuner_pm =
{ .p_ctrl = &g_motor0_tuner_pm_ctrl, .p_cfg = &g_motor0_tuner_pm_cfg, .p_api = &g_motor_tuner_on_motor_tuner_pm, };
/* motor control instance declaration */
extern motor_control_instance_ctrl_t g_motor0_control_ctrl;

/////// outer
motor_pm_foc_outer_instance_ctrl_t g_motor0_pm_foc_outer_ctrl;

const motor_pm_foc_outer_cfg_t g_motor0_pm_foc_outer_cfg =
{ .p_context = (void*) &g_motor0_control_ctrl,
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
//  .p_position_instance = NULL,
#else
//  .p_position_instance = &RA_NOT_DEFINED,
#endif
#undef RA_NOT_DEFINED
  .p_extend = (void*) &g_motor0_pm_foc_extend, };

/////// inner
motor_pm_foc_inner_instance_ctrl_t g_motor0_pm_foc_inner_ctrl;

const motor_pm_foc_inner_cfg_t g_motor0_pm_foc_inner_cfg =
{ .p_context = (void*) &g_motor0_control_ctrl, .p_extend = (void*) &g_motor0_pm_foc_extend, };

motor_design_param_t g_motor0_pm_foc_inner_design =
{ .omega = 300.0F, .zeta = 1.0F, };

motor_outer_design_params_t g_motor0_pm_foc_outer_design =
{ .speed_omega = 6.0F, .speed_zeta = 1.0F, .observer_omega = 200.0F, .observer_zeta = 1.0F, };

motor_parameter_ramp_t g_motor0_pm_foc_motor =
{ .u2_mtr_pp = 4, .f4_mtr_r = 1.3F, .f4_mtr_ld = 0.0013F, .f4_mtr_lq = 0.0013F, .f4_mtr_m = 0.01119F, .f4_mtr_j =
          0.000003666F,
  .f4_mtr_nominal_current = 1.67F, };

/* pm_foc_foc_instance_ctrl */
motor_pm_foc_instance_ctrl_t g_motor0_pm_foc_ctrl;

/* pm_foc_extend_cfg */
const motor_pm_foc_extended_cfg_t g_motor0_pm_foc_extend =
        { .pm_foc_inner_instance_ctrl = &g_motor0_pm_foc_inner_ctrl,
          .pm_foc_outer_instance_ctrl = &g_motor0_pm_foc_outer_ctrl,
          .pm_motor_parameter = &g_motor0_pm_foc_motor,
          .pm_inner_design_parameter = &g_motor0_pm_foc_inner_design,
          .pm_outer_design_parameter = &g_motor0_pm_foc_outer_design,

          .data =
                  {
                  /* inner extend data */
                  .comp_v[0] = 0.048F,
                    .comp_v[1] = 0.096F, .comp_v[2] = 0.144F, .comp_v[3] = 0.192F, .comp_v[4] = 0.240F, .comp_i[0
                            ] = 0.070F,
                    .comp_i[1] = 0.140F, .comp_i[2] = 0.220F, .comp_i[3] = 0.300F, .comp_i[4] = 0.500F, .comp_vdc_ref =
                            24.0F,
                    .comp_limit_factor = 0.5F / 50, .vcomp_enable = MOTOR_CURRENT_VOLTAGE_COMPENSATION_SELECT_ENABLE, .sample_delay_comp_enable =
                            MOTOR_INNER_SAMPLE_DELAY_COMPENSATION_ENABLE,
                    .sensor_slot = MOTOR_INNER_SLOT_1_ENABLE, .period_magnitude_value = 1.5F, .inner_control_period =
                            ((1 + 0) * 50) / 1000000.0F,
                    .current_limit = 24.0F / 2.0F, .overcurrent_limit = 3.2F, .overvoltage_limit = 28.0F, .lowvoltage_limit =
                            6.0F,

                    /* outer extend data */
                    .outer_control_period = 0.0005F,
                    .speed_mech_change_limit = 1000.0F * 2.0F * 3.14159265358979F / 60.0F, .speed_mech_cmd_limit =
                            2650.0F * 2.0F * 3.14159265358979F / 60.0F,
                    .speed_lpf_omega_t = 20.0F, .iq_limit = 1.67F, .overspeed_limit = 3000.0F * 2.0F * 3.14159265358979F
                            / 60.0F },

          .outerfunc_table.control_mode_ctrl = &motor_outer_speed_control,
          .outerfunc_table.mtpa_ctrl = &algorithm_disabled,
          .outerfunc_table.fw_ctrl = &motor_outer_fnctbl_fw_ctrl,
          .outerfunc_table.spdobsv_ctrl = &motor_outer_fnctbl_spddirct_ctrl,
          .p_callback = rm_motor_control_callback,
          /* Shared instances */
          .p_shared_data = &g_motor0_pm_foc_shared_data,
#ifdef MOTOR_CONTROL_TUNER_ENABLED
    .p_tuner_instance = &g_motor0_tuner_pm,
#else
          .p_tuner_instance = NULL,
#endif
          .p_motor_outer_cfg = &g_motor0_pm_foc_outer_cfg,
          .p_motor_inner_cfg = &g_motor0_pm_foc_inner_cfg, };

const motor_algorithm_cfg_t g_motor0_pm_foc_cfg =
{ .p_motor_hal_driver_instance = &g_motor0_hal_driver, .p_motor_sensor_instance = &g_motor0_sensor_bemf,
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
  .p_motor_sensor_instance2 = NULL,
#else
    .p_motor_sensor_instance2 = &RA_NOT_DEFINED,
#endif
#undef RA_NOT_DEFINED
  .p_timer_instance = &g_timer3,
  .p_extend = (void*) &g_motor0_pm_foc_extend, };

const motor_algorithm_instance_t g_motor0_pm_foc =
{ .p_ctrl = &g_motor0_pm_foc_ctrl, .p_cfg = &g_motor0_pm_foc_cfg, .p_api = &g_motor_algorithm_on_motor_pm_foc, };

/* FOC shared data buffer */
motor_shared_buffer_foc_t g_motor0_pm_foc_shared_data;
/* Motor sensorless control extend configuration */
motor_control_instance_ctrl_t g_motor0_control_ctrl;
const motor_control_extended_cfg_t g_motor0_control_extended_cfg =
{ .p_motor_algorithm_instance = &g_motor0_pm_foc,
#ifdef MOTOR_CONTROL_TRAJECTORY_ENABLED
  .p_motor_trajectory_instance = &g_motor0_trajectory_linear,
#else
  .p_motor_trajectory_instance = NULL,
#endif
        };

/* Motor sensorless control configuration */
const motor_cfg_t g_motor0_control_cfg =
{ .p_callback = mtr_callback_event, .p_context = NULL, .p_extend = &g_motor0_control_extended_cfg, };

/* Instance structure to use motor sensorless control module. */
const motor_instance_t g_motor0_control =
{ .p_ctrl = &g_motor0_control_ctrl, .p_cfg = &g_motor0_control_cfg, .p_api = &g_motor_on_motor_control, };
void g_hal_init(void)
{
    g_common_init ();
}
