











#ifndef __ICS2_RA8T1_H__
#define __ICS2_RA8T1_H__

#define ICS_SCI1_P213_P212     (0x10U)
#define ICS_SCI2_PA03_PA02     (0x20U)
#define ICS_SCI3_P409_P408     (0x30U)
#define ICS_SCI4_P714_P715     (0x40U)

#define ICS_SCI3_P310_P309     (0x31U) /*built-in*/

void     ics2_init(uint8_t port, uint8_t speed, uint8_t mode);
void     ics2_watchpoint(void);
uint32_t ics2_version(void);

#endif /* __ICS2_RA8T1_H__ */
