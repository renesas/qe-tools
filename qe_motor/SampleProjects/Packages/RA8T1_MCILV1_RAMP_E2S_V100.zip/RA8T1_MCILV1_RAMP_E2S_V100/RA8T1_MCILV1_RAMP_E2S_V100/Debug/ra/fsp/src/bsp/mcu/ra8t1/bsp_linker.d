ra/fsp/src/bsp/mcu/ra8t1/bsp_linker.o: \
 ../ra/fsp/src/bsp/mcu/ra8t1/bsp_linker.c \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api/bsp_api.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api/fsp_common_api.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/fsp_version.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_gen/bsp_clock_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/ra8t1/bsp_override.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/ra8t1/bsp_mcu_info.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/ra8t1/bsp_elc.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/ra8t1/bsp_feature.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/ra8t1/bsp_peripheral.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/board_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/board/ra8t1_mck/board.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/board/ra8t1_mck/board_init.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/board/ra8t1_mck/board_leds.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/board/ra8t1_mck/board_ethernet_phy.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_gen/vector_data.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_exceptions.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7FA8T1AH.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm85.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_pmu.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_cachel1.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_common.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api/fsp_common_api.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_tfu.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_sdram.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_mmf.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_ipc.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_ospi_b.h \
 bsp_linker_info.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_irq.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_io.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_clocks.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_security.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/fsp_features.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api/fsp_common_api.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_delay.h \
 C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api/bsp_api.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api/fsp_common_api.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/fsp_version.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_gen/bsp_clock_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/ra8t1/bsp_override.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/ra8t1/bsp_mcu_info.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/ra8t1/bsp_elc.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/ra8t1/bsp_feature.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/ra8t1/bsp_peripheral.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp/board_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/board/ra8t1_mck/board.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/board/ra8t1_mck/board_init.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/board/ra8t1_mck/board_leds.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/board/ra8t1_mck/board_ethernet_phy.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra_gen/vector_data.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_exceptions.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7FA8T1AH.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm85.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_pmu.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_cachel1.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_common.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api/fsp_common_api.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_tfu.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_sdram.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_mmf.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_ipc.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_ospi_b.h:
bsp_linker_info.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_irq.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_io.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_clocks.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_security.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/fsp_features.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api/fsp_common_api.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_delay.h:
C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h:
