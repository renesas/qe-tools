################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Users/a5087695/e2_studio/workspace-2026-07_RAMP660_RA8T1/RA8T1_MCILV1_RAMP_E2S_V100/src/application/user_interface/ics/ICS2_RA8T1.o

LIBS :=

