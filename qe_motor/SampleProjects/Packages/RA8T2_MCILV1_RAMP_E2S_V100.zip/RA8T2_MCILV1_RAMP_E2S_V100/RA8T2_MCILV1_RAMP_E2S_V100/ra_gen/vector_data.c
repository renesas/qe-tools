/* generated vector source file - do not edit */
#include "bsp_api.h"
/* Do not build these data structures if no interrupts are currently allocated because IAR will have build errors. */
#if VECTOR_DATA_IRQ_COUNT > 0
        BSP_DONT_REMOVE const fsp_vector_t g_vector_table[BSP_ICU_VECTOR_NUM_ENTRIES] BSP_PLACE_IN_SECTION(BSP_SECTION_APPLICATION_VECTORS) =
        {
                        [0] = adc_b_calend0_isr, /* ADC CALEND0 (End of calibration of A/D converter unit 0) */
            [1] = adc_b_calend1_isr, /* ADC CALEND1 (End of calibration of A/D converter unit 1) */
            [2] = adc_b_adi1_isr, /* ADC ADI1 (End of A/D scanning operation(Gr.1)) */
            [3] = agt_int_isr, /* AGT0 INT (AGT interrupt) */
            [4] = poeg_event_isr, /* POEG0 EVENT (Port Output disable 0 interrupt) */
        };
        #if BSP_FEATURE_ICU_HAS_IELSR
        const bsp_interrupt_event_t g_interrupt_event_link_select[BSP_ICU_VECTOR_NUM_ENTRIES] =
        {
            [0] = BSP_PRV_VECT_ENUM(EVENT_ADC_CALEND0,GROUP0), /* ADC CALEND0 (End of calibration of A/D converter unit 0) */
            [1] = BSP_PRV_VECT_ENUM(EVENT_ADC_CALEND1,GROUP1), /* ADC CALEND1 (End of calibration of A/D converter unit 1) */
            [2] = BSP_PRV_VECT_ENUM(EVENT_ADC_ADI1,GROUP2), /* ADC ADI1 (End of A/D scanning operation(Gr.1)) */
            [3] = BSP_PRV_VECT_ENUM(EVENT_AGT0_INT,GROUP3), /* AGT0 INT (AGT interrupt) */
            [4] = BSP_PRV_VECT_ENUM(EVENT_POEG0_EVENT,GROUP4), /* POEG0 EVENT (Port Output disable 0 interrupt) */
        };
        #endif
        #endif
