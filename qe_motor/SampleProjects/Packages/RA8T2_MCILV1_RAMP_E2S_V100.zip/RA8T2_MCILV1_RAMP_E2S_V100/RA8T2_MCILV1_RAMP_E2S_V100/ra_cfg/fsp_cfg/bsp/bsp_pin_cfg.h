/* generated configuration header file - do not edit */
#ifndef BSP_PIN_CFG_H_
#define BSP_PIN_CFG_H_
#include "r_ioport.h"

/* Common macro for FSP header files. There is also a corresponding FSP_FOOTER macro at the end of this file. */
FSP_HEADER

#define HU_1 (BSP_IO_PORT_10_PIN_08)
#define HW_1 (BSP_IO_PORT_10_PIN_09)
#define HV_1 (BSP_IO_PORT_10_PIN_10)

extern const ioport_cfg_t g_bsp_pin_cfg; /* RA8T2 MCK */

void BSP_PinConfigSecurityInit();

/* Common macro for FSP header files. There is also a corresponding FSP_HEADER macro at the top of this file. */
FSP_FOOTER
#endif /* BSP_PIN_CFG_H_ */
